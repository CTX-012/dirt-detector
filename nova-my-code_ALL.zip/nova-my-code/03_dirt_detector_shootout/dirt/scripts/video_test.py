"""End-to-end test of the live loop on a synthetic video.

Builds a wide tile floor with two stains, pans a 960x720 camera across it,
feeds every frame through the REAL LoopEngine (same one the webcam demo uses),
and checks that the state machine actually walks SCAN -> CHECK -> SCRUB ->
RESUME, that give-up fires, and that the report populates.

The piezo is simulated the same way a human does with the spacebar: it "hears"
debris whenever the camera is over a stain (we know where the stains are --
we painted them).

Outputs:
  data/results/video_test.json          state timeline + assertions
  data/results/loop_demo.avi            annotated video (MJPG, plays anywhere)
  data/results/examples/state_*.jpg     one still per state
"""

from __future__ import annotations

import json
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "nova_desktop_pkg"))

from loop_engine import Config, LoopEngine                       # noqa: E402

DATA = os.path.join(HERE, "..", "data")
RESULTS = os.path.join(DATA, "results")
EXAMPLES = os.path.join(RESULTS, "examples")

W, H = 960, 720
FLOOR_W = 3000
RNG = np.random.default_rng(3)


def build_floor():
    """Wide tile floor with two dark stains at known x positions."""
    img = np.full((H, FLOOR_W, 3), 175.0, np.float32)
    img += RNG.normal(0, 2.0, img.shape)
    for y in range(0, H, 120):
        img[y:y + 3, :] *= 0.55
    for x in range(0, FLOOR_W, 120):
        img[:, x:x + 3] *= 0.55
    stains = [(1200, 360, 90), (2200, 300, 70)]      # (cx, cy, radius)
    for cx, cy, r in stains:
        m = np.zeros((H, FLOOR_W), np.float32)
        cv2.circle(m, (cx, cy), r, 1.0, -1)
        m = cv2.GaussianBlur(m, (0, 0), 12)
        img *= (1 - m[..., None] * 0.60)
    return np.clip(img, 0, 255).astype(np.uint8), stains


def main():
    os.makedirs(EXAMPLES, exist_ok=True)
    floor, stains = build_floor()

    cfg = Config()
    cfg.scrub_seconds = 4.0            # short budget so give-up shows in-video
    engine = LoopEngine(cfg)

    # CHECK and RESUME are single-tick states: they are entered and left inside
    # ONE engine.step() call, so sampling telemetry once per frame never sees
    # them. Instrument the loop's own methods to record every state it passes
    # through, which is the honest way to assert the full walk.
    state_log = []

    def _wrap(fn):
        def inner(*a, **k):
            r = fn(*a, **k)
            s = engine.loop.state.value
            if not state_log or state_log[-1] != s:
                state_log.append(s)
            return r
        return inner

    engine.loop.on_dirt_ahead = _wrap(engine.loop.on_dirt_ahead)
    engine.loop.on_verified = _wrap(engine.loop.on_verified)
    engine.loop.step = _wrap(engine.loop.step)

    vw = cv2.VideoWriter(os.path.join(RESULTS, "loop_demo.avi"),
                         cv2.VideoWriter_fourcc(*"MJPG"), 20, (W, H))

    timeline, seen_states = [], set()
    saved_state_frames = set()
    x = 0
    speed = 6                           # px per frame pan
    frame_i = 0
    while x + W <= FLOOR_W:
        frame = floor[:, x:x + W].copy()
        frame = np.clip(frame.astype(np.float32)
                        + RNG.normal(0, 1.5, frame.shape), 0, 255).astype(np.uint8)

        # piezo "hears" debris when a stain is inside the central strip of view
        over_stain = any(x + W * 0.25 < sx < x + W * 0.75 for sx, _, _ in stains)
        engine.piezo = over_stain

        annotated, tel = engine.step(frame, dt=0.05)
        state = tel["state"]
        seen_states.add(state)
        timeline.append({"frame": frame_i, "x": x, "state": state,
                         "peak_sigma": round(tel.get("peak_sigma", 0), 2),
                         "suction": round(tel.get("suction", 0), 2),
                         "piezo": over_stain,
                         "cleaned": tel.get("cleaned", 0),
                         "unremovable": tel.get("unremovable", 0)})
        vw.write(annotated)
        if state not in saved_state_frames:
            cv2.imwrite(os.path.join(EXAMPLES, f"state_{state}.jpg"), annotated)
            saved_state_frames.add(state)

        # pan pauses while the loop scrubs (coverage is paused), else advance
        if state != "scrub":
            x += speed
        frame_i += 1
        if frame_i > 2500:
            break

    vw.release()
    rep = engine.loop.report()

    transitions = []
    for a, b in zip(timeline, timeline[1:]):
        if a["state"] != b["state"]:
            transitions.append(f'{a["state"]}->{b["state"]}@frame{b["frame"]}')

    states_walked = sorted(set(state_log))
    checks = {
        "all_states_visited": states_walked == ["check", "resume", "scan", "scrub"],
        "states_walked_instrumented": states_walked,
        "states_seen_per_frame": sorted(seen_states),
        "n_transitions": len(transitions),
        "transitions": transitions[:20],
        "spots_handled": rep["spots_cleaned"] + rep["spots_unremovable"],
        "final_report": rep,
        "frames": frame_i,
    }
    with open(os.path.join(RESULTS, "video_test.json"), "w") as f:
        json.dump({"checks": checks, "timeline_tail": timeline[-5:]}, f, indent=2)

    print(json.dumps(checks, indent=2))
    ok = checks["all_states_visited"] and checks["spots_handled"] >= 1
    print("\nPASS" if ok else "\nFAIL", "- state machine end-to-end")


if __name__ == "__main__":
    main()
