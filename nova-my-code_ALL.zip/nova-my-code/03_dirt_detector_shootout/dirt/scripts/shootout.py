"""Dirt clean/unclean detector shootout — CLI entry point.

Scores every registered method on identical floor cells and reports
recall@5%FPR (per floor + overall = mean-of-per-floor), AUROC (secondary),
params, and optional measured FPS/VRAM on the RTX 3060.

  python3 scripts/shootout.py --methods all --datasets synthetic,indoor --fps
  python3 scripts/shootout.py --methods histogram_diff,padim --datasets synthetic
  python3 scripts/shootout.py --list                       # show registered methods
  python3 scripts/shootout.py --gate                       # reproduction gate vs benchmark.json

Accuracy is hardware-independent (runs anywhere). --fps is the only pass that
must run on the real card; omit it on a CPU box.
"""

from __future__ import annotations

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)                     # so `import scorers`, `shootout_harness` resolve

import numpy as np

import scorers                               # noqa: F401  -- triggers auto-import of every method
from scorers.base import REGISTRY
import shootout_harness as H


def resolve_methods(spec: str):
    if spec in ("all", "*"):
        return list(REGISTRY)
    names = [s.strip() for s in spec.split(",") if s.strip()]
    unknown = [n for n in names if n not in REGISTRY]
    if unknown:
        raise SystemExit(f"unknown methods: {unknown}. registered: {sorted(REGISTRY)}")
    return names


def run(methods, datasets, do_fps):
    results = {}
    fps_scorers, fps_payload, fps_pool = [], None, None
    for ds in datasets:
        print(f"\n=== dataset: {ds} ===")
        scenes = H.build_scene_set(ds)
        pool = H.build_clean_pool(ds)
        print(f"  {len(scenes)} scenes; floors={sorted({ls.scene.floor for ls in scenes})}")
        methods_out = {}
        for name in methods:
            scorer = REGISTRY[name]()
            print(f"  [{name}] fit...", end="", flush=True)
            scorer.fit(pool)
            print(" score...", end="", flush=True)
            methods_out[name] = H.evaluate(scorer, scenes)
            ov = methods_out[name]["overall"]
            print(f" recall(mean)={ov['recall_mean']:.3f} auroc(mean)={ov['auroc_mean']:.3f}")
            if ds == "synthetic":                    # reuse synthetic scorers for the FPS pass
                fps_scorers.append(scorer)
        H.flag_traps(methods_out)
        floors = sorted({ls.scene.floor for ls in scenes})
        results[ds] = {"floors": floors, "methods": methods_out}
        if ds == "synthetic":
            fps_payload = _fps_payload(scenes)
            fps_pool = pool

    fps = None
    if do_fps and fps_payload is not None:
        print("\n=== FPS / VRAM pass (RTX 3060) ===")
        fps = H.fps_pass(fps_scorers, fps_payload, fps_pool)
    record = H.build_record(results, fps)
    path = H.write_all(record)
    print(f"\nwrote {path}")
    print(H.render_md(record))


def _fps_payload(scenes, per_floor=1):
    """One synthetic scene per floor = a small fixed payload reused for every method."""
    seen, payload = set(), []
    for ls in scenes:
        if ls.scene.floor not in seen:
            seen.add(ls.scene.floor)
            payload.append(ls.scene)
    return payload


def gate():
    """Reproduction gate: histogram_diff on synthetic must match
    benchmark.json -> differential_synthetic.per_floor exactly."""
    from scorers.base import RESULTS
    ref = json.load(open(os.path.join(RESULTS, "benchmark.json")))
    target = ref["differential_synthetic"]["per_floor"]
    scenes = H.build_scene_set("synthetic")
    scorer = REGISTRY["histogram_diff"]()
    scorer.fit({})
    out = H.evaluate(scorer, scenes)["per_floor"]
    ok = True
    print(f"{'floor':12s} {'recall Δ':>12s} {'auroc Δ':>12s}  n_pos n_neg")
    for f in sorted(target):
        t, g = target[f], out[f]
        dr = abs(t["recall_at_fpr"] - g["recall_at_fpr"])
        da = abs(t["auroc"] - g["auroc"])
        npok = (t["n_pos"] == g["n_pos"]) and (t["n_neg"] == g["n_neg"])
        cell_ok = dr < 1e-6 and da < 1e-6 and npok
        ok &= cell_ok
        print(f"{f:12s} {dr:12.2e} {da:12.2e}  {g['n_pos']}/{t['n_pos']} "
              f"{g['n_neg']}/{t['n_neg']} {'OK' if cell_ok else 'MISMATCH'}")
    print("\nGATE:", "PASS ✅" if ok else "FAIL ❌")
    return 0 if ok else 1


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--methods", default="all")
    ap.add_argument("--datasets", default="synthetic,indoor")
    ap.add_argument("--fps", action="store_true")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--gate", action="store_true")
    a = ap.parse_args(argv)
    if a.list:
        for n, c in sorted(REGISTRY.items()):
            print(f"  {n:16s} device={c.device:5s} params={c.params} note={c.note}")
        return 0
    if a.gate:
        return gate()
    run(resolve_methods(a.methods),
        [d.strip() for d in a.datasets.split(",") if d.strip()], a.fps)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
