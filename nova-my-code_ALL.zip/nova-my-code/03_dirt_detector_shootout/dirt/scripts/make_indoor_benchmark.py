"""Composite controlled dirt onto REAL indoor floor photos (homes, airports,
malls, supermarkets, offices) -> a BAN benchmark set with exact ground truth.

    data/indoor_floors/raw/<env>__<n>.jpg      real CC photos (download_indoor.py)
    -> data/indoor_floors/before/<scene>.jpg   real floor + composited dirt
       data/indoor_floors/after/<scene>.jpg    real floor, clean
       data/indoor_floors/masks/<scene>.png    exact dirt mask

Dirt is only placed in the FLOOR BAND of each photo -- interior photos are
framed with the floor in the lower part of the image, so we composite into
y in [0.55, 0.92] x in [0.15, 0.85] and evaluate only cells in that band
(benchmark reads the same band). This keeps ceilings, shelves and people out
of both the dirt placement and the scoring.
"""

from __future__ import annotations

import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from make_synthetic import (DIRT, view_nuisance)     # noqa: E402

ROOT = os.path.join(HERE, "..", "data", "indoor_floors")
RAW = os.path.join(ROOT, "raw")
MAX_W = 1280
FLOOR_BAND = (0.18, 0.58, 0.82, 0.90)     # x0, y0, x1, y1 fractions
PER_PHOTO = 3                             # scenes per photo, random dirt types
RNG = np.random.default_rng(21)


def main():
    for sub in ("before", "after", "masks"):
        os.makedirs(os.path.join(ROOT, sub), exist_ok=True)
    raws = sorted(f for f in os.listdir(RAW) if f.lower().endswith(".jpg"))
    if not raws:
        print("no raw photos -- run download_indoor.py first")
        return
    dirt_names = list(DIRT)
    n = 0
    for fname in raws:
        img0 = cv2.imread(os.path.join(RAW, fname))
        if img0 is None:
            continue
        s = MAX_W / img0.shape[1]
        if s < 1:
            img0 = cv2.resize(img0, None, fx=s, fy=s,
                              interpolation=cv2.INTER_AREA)
        base = os.path.splitext(fname)[0]              # e.g. airport__00
        # dirt size relative to the photo width (raw photos vary)
        scale = img0.shape[1] / 960.0 * 0.8
        picks = RNG.choice(len(dirt_names), size=PER_PHOTO, replace=False)
        for k in picks:
            dname = dirt_names[k]
            scene = f"{base}__{dname}"
            clean = img0.astype(np.float32)
            mask = np.zeros(clean.shape[:2], np.uint8)
            dirty = DIRT[dname](RNG, clean.copy(), mask,
                                region=FLOOR_BAND, scale=scale)
            cv2.imwrite(os.path.join(ROOT, "after", scene + ".jpg"),
                        view_nuisance(clean, RNG))
            cv2.imwrite(os.path.join(ROOT, "before", scene + ".jpg"),
                        view_nuisance(dirty, RNG))
            cv2.imwrite(os.path.join(ROOT, "masks", scene + ".png"), mask)
            n += 1
    print(f"built {n} indoor scenes from {len(raws)} real photos")


if __name__ == "__main__":
    main()
