"""PaDiM — the canonical "PatchCore trap" candidate (train-on-clean, category b).

Self-contained PaDiM on a frozen ImageNet backbone:

  * backbone: torchvision ``wide_resnet50_2`` (IMAGENET1K_V1), ``.eval()`` +
    ``requires_grad_(False)`` on cuda, fp32. Loaded ONCE (lazy). trainable ~= 0.
  * cell embedding: 32x32 BGR patch -> RGB -> /255 -> resize 64x64 ->
    ImageNet-normalise -> forward, capture layer1/2/3 feature maps via forward
    hooks -> global-average-pool each -> concat (~256+512+1024 = 1792-d) ->
    keep a FIXED seeded random subset of 300 dims (standard PaDiM reduction).
  * fit(): per floor, embed all clean cells (seeded subsample cap 2000), fit a
    single Gaussian: mean ``mu`` and ``Sigma = cov + 0.01*I``; store ``mu`` and
    ``inv(Sigma)``.
  * score(): per dirty cell, Mahalanobis distance to that floor's Gaussian.
    HIGHER = more anomalous = DIRTIER. Missing floor -> zeros.

This is the textbook trap: it tends to win AUROC yet lose recall@5%FPR, because a
fat tail of clean-but-unusual cells (grout junctions, cell edges) scores as high
as real dirt. Reported honestly, not tuned away.

Determinism: the random projection and every subsample are seeded (1234).

On a CPU-only host this module raises at import so the auto-importer skips it
(GPU-only method); the accuracy numbers are hardware-independent regardless.
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn.functional as F
import torchvision

from scorers.base import Scene, Scorer, register

# Fail fast at import on a CPU-only box -> scorers/__init__.py skips this module
# cleanly (it is a genuinely GPU-only method).
if not torch.cuda.is_available():
    raise RuntimeError("padim requires CUDA; skipping on CPU-only host")

SEED = 1234
PROJ_DIMS = 300          # random-projection target (PaDiM dim reduction)
EMBED_RES = 64           # resnet wants >=32; 64 is safer
BATCH = 256              # patches per GPU forward
MAX_PER_FLOOR = 2000     # cap on clean cells embedded per floor (seeded subsample)
COV_REG = 0.01           # Sigma += COV_REG * I
_LAYERS = ("l1", "l2", "l3")


@register
class PaDiM(Scorer):
    name = "padim"
    device = "cuda"
    trains_on_clean = True
    params = 68_900_000
    note = "PaDiM: wide_resnet50_2 (frozen) per-floor Gaussian + Mahalanobis; trainable~=0"

    def __init__(self):
        self._dev = torch.device("cuda")
        self._backbone = None
        self._feats: dict = {}
        self._proj = None                 # LongTensor[d] selected dims, on cuda
        self._mean = None                 # ImageNet normalise tensors
        self._std = None
        self._models: dict = {}           # floor -> (mu[d] float, inv_cov[d,d] float)

    # ------------------------------------------------------------ backbone -----
    def _ensure_backbone(self) -> None:
        """Lazy, once. Load frozen wide_resnet50_2, hook layer1/2/3, build the
        seeded random-projection index."""
        if self._backbone is not None:
            return
        dev = self._dev
        weights = torchvision.models.Wide_ResNet50_2_Weights.IMAGENET1K_V1
        net = torchvision.models.wide_resnet50_2(weights=weights)
        net.eval().to(dev)
        net.requires_grad_(False)

        feats = self._feats

        def _mk(tag):
            def _hook(_m, _i, out):
                feats[tag] = out.detach()
            return _hook

        net.layer1.register_forward_hook(_mk("l1"))
        net.layer2.register_forward_hook(_mk("l2"))
        net.layer3.register_forward_hook(_mk("l3"))
        self._backbone = net

        self._mean = torch.tensor([0.485, 0.456, 0.406], device=dev).view(1, 3, 1, 1)
        self._std = torch.tensor([0.229, 0.224, 0.225], device=dev).view(1, 3, 1, 1)

        # one dummy forward to learn the concatenated embedding width, then pick
        # a FIXED seeded subset of dims.
        with torch.no_grad():
            feats.clear()
            net(torch.zeros(1, 3, EMBED_RES, EMBED_RES, device=dev))
        total = int(sum(feats[k].shape[1] for k in _LAYERS))
        rng = np.random.default_rng(SEED)
        idx = np.sort(rng.choice(total, size=min(PROJ_DIMS, total), replace=False))
        self._proj = torch.as_tensor(idx, dtype=torch.long, device=dev)

    @torch.no_grad()
    def _embed(self, patches: list) -> torch.Tensor:
        """List of HxWx3 BGR uint8 patches -> (N, d) fp32 embeddings on cuda."""
        self._ensure_backbone()
        dev, feats = self._dev, self._feats
        chunks = []
        for i in range(0, len(patches), BATCH):
            arr = np.stack(patches[i:i + BATCH]).astype(np.float32)   # (n,H,W,3) BGR
            arr = np.ascontiguousarray(arr[..., ::-1])                # BGR -> RGB
            t = torch.from_numpy(arr).to(dev).permute(0, 3, 1, 2) / 255.0
            t = F.interpolate(t, size=(EMBED_RES, EMBED_RES),
                              mode="bilinear", align_corners=False)
            t = (t - self._mean) / self._std
            feats.clear()
            self._backbone(t)
            emb = torch.cat([feats[k].mean(dim=(2, 3)) for k in _LAYERS], dim=1)
            chunks.append(emb.index_select(1, self._proj))
        return torch.cat(chunks, dim=0)

    # ------------------------------------------------------------ fit ----------
    def fit(self, clean_pool: "dict[str, list]") -> None:
        self._ensure_backbone()
        self._models = {}
        rng = np.random.default_rng(SEED)
        for floor in sorted(clean_pool):
            patches = [c.patch for c in clean_pool[floor]]
            n = len(patches)
            if n < 2:
                continue
            if n > MAX_PER_FLOOR:
                sel = rng.choice(n, size=MAX_PER_FLOOR, replace=False)
                patches = [patches[j] for j in sel]
            emb = self._embed(patches).double()               # (N, d)
            mu = emb.mean(dim=0)                               # (d,)
            xc = emb - mu
            d = emb.shape[1]
            cov = (xc.t() @ xc) / (emb.shape[0] - 1)           # (d, d)
            cov += COV_REG * torch.eye(d, device=cov.device, dtype=cov.dtype)
            inv = torch.linalg.inv(cov)
            self._models[floor] = (mu.float(), inv.float())

    # ------------------------------------------------------------ score --------
    def score(self, scene: Scene) -> np.ndarray:
        n = scene.n_cells
        if n == 0:
            return np.zeros(0, np.float64)
        model = self._models.get(scene.floor)
        if model is None:                                      # unseen floor
            return np.zeros(n, np.float64)
        mu, inv = model
        emb = self._embed([p for (_, _, p) in scene.dirty_cells])   # (n, d)
        diff = emb - mu
        m2 = ((diff @ inv) * diff).sum(dim=1)                 # Mahalanobis^2
        dist = torch.sqrt(torch.clamp(m2, min=0.0))
        return dist.detach().cpu().numpy().astype(np.float64)
