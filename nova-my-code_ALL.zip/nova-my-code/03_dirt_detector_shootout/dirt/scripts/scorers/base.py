"""Scorer contract for the method shootout.

Every dirt-detection method conforms to ONE interface so the shootout harness can
run them all through the SAME cell iterator and the SAME metric (benchmark.roc_metrics).

Invariant every scorer honours:  HIGHER SCORE = DIRTIER.  A cell it cannot judge
(glare, refused histogram, out-of-band) must still get a defined score -- use 0.0.

Categories (all covered by this one interface):
  (a) differential      -- needs the paired clean cell   (histogram_diff, deep_hist, dinov2_diff)
  (b) train-on-clean    -- fit() on a clean-cell pool     (gmm_novelty, padim)
  (c) reference-free     -- per-frame, no clean image      (saliency_sr, spatial_diff)
  (d) absolute per-cell -- classify each patch            (vlm_smol)

Add a method = add ONE file in this package that defines a Scorer subclass and
decorates it with @register. scorers/__init__.py auto-imports every file, so no
shared file is ever edited on fan-out (conflict-free parallel work).
"""

from __future__ import annotations

import os
import sys
from collections import namedtuple
from dataclasses import dataclass

import numpy as np

# --- path bootstrap: make `import benchmark` and `import nova_perception.*` work
# from any scorer file, mirroring scripts/benchmark.py's own bootstrap. ----------
HERE = os.path.dirname(os.path.abspath(__file__))        # scripts/scorers
SCRIPTS = os.path.dirname(HERE)                           # scripts
REPO = os.path.dirname(SCRIPTS)                           # repo root
PKG = os.path.join(REPO, "nova_desktop_pkg")
for _p in (SCRIPTS, PKG):
    if _p not in sys.path:
        sys.path.insert(0, _p)

DATA = os.path.join(REPO, "data")
RESULTS = os.path.join(DATA, "results")


# One clean-floor cell used to fit train-on-clean methods. `gain` is the
# frame_gain() of the SOURCE image this patch came from -- carry it so features
# are gain-normalised the same way the dirty side is (never per-cell gain; see
# verification.py's warning).
CleanCell = namedtuple("CleanCell", "patch gain")


@dataclass
class Scene:
    """One before/after floor observation handed to a scorer. Holds NO labels."""

    floor: str                       # floor type (synthetic) or env (indoor) -> model key
    dirty_img: np.ndarray            # full BGR frame WITH dirt (the observation, = data/before/)
    clean_img: "np.ndarray | None"   # full BGR clean reference frame (= data/after/); None if n/a
    dirty_cells: list                # [(x, y, patch32), ...] from cells_of(dirty_img) -- shared iterator
    clean_cells: "list | None"       # [(x, y, patch32), ...] from cells_of(clean_img), 1:1 aligned
    gain_d: float                    # frame_gain(dirty_img)
    gain_c: float                    # frame_gain(clean_img)  (0.0 if no clean)
    eval_mask: np.ndarray            # bool[n_cells]: which cells count (band for indoor, all True synth)

    @property
    def n_cells(self) -> int:
        return len(self.dirty_cells)


class Scorer:
    """Base class. Subclass, set `name`, implement `score`; override `fit` if
    the method trains on clean cells."""

    name: str = "base"
    params: int = 0                  # total params (frozen backbones counted; trainable ~= 0 -- note it)
    device: str = "cpu"             # "cpu" | "cuda"
    needs_clean_ref: bool = False    # category (a)
    trains_on_clean: bool = False    # category (b)
    note: str = ""                   # free-text caveat surfaced in the FPS/JSON output

    def fit(self, clean_pool: "dict[str, list[CleanCell]]") -> None:
        """Train-on-clean methods build a per-floor model here. Default: no-op."""

    def score(self, scene: Scene) -> np.ndarray:
        """Return float score per cell in scene.dirty_cells (len == scene.n_cells).
        HIGHER = DIRTIER. Return 0.0 for cells that cannot be judged. Never raise
        on a normal frame; never look at labels (the harness holds them)."""
        raise NotImplementedError


# ------------------------------------------------------------- registry --------
REGISTRY: "dict[str, type[Scorer]]" = {}


def register(cls: "type[Scorer]") -> "type[Scorer]":
    """Class decorator: add a Scorer subclass to REGISTRY under its `name`."""
    if not getattr(cls, "name", None) or cls.name == "base":
        raise ValueError(f"{cls.__name__} must set a unique `name`")
    if cls.name in REGISTRY and REGISTRY[cls.name] is not cls:
        raise ValueError(f"duplicate scorer name {cls.name!r}")
    REGISTRY[cls.name] = cls
    return cls


def sanitize(scores, n_cells: int) -> np.ndarray:
    """Coerce a scorer's output to a finite float array of exactly n_cells.
    Non-finite -> 0.0. Wrong length is a bug, so it raises."""
    arr = np.asarray(scores, dtype=np.float64).ravel()
    if arr.shape[0] != n_cells:
        raise ValueError(f"scorer returned {arr.shape[0]} scores, expected {n_cells}")
    return np.nan_to_num(arr, nan=0.0, posinf=0.0, neginf=0.0)
