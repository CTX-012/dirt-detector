"""GMM novelty — Grünauer-style unsupervised, train-on-clean.

Category (b): fit a Gaussian Mixture on the appearance of CLEAN floor cells (per
floor type), then score each dirty cell by how UNLIKELY it is under that clean
model. No dirt labels, no paired clean reference at score time -- just "does this
cell look like the clean floor I learned?".

  anomaly(cell) = -log p(feature | clean-floor GMM)      # higher = more novel = dirtier

Feature per cell (kept small + diagonal-covariance-friendly):
  - the gain-normalised 32-bin histogram from verification.describe() -- the same
    illumination-cancelling descriptor the incumbent trusts (its `ok` flag also
    gates out glare/shadow cells), PLUS
  - two LAB chroma means ((a-128)/128, (b-128)/128): brightness-invariant colour
    moments so a coloured stain that barely dents the grey histogram still moves
    the feature. 34-d total, all O(1) scaled.

Grünauer & Vincze (2013) "novelty detection on a mobile robot's floor" is the
lineage: model the clean surface, flag departures from it. Unlike a differential
method it needs NO registered before/after pair at deploy time -- only a one-off
clean fit per floor.
"""

from __future__ import annotations

import cv2
import numpy as np

from scorers.base import Scene, Scorer, register
from nova_perception.verification import describe

K = 4                       # mixture components per floor (modest, per spec 3-5)
FEAT_CAP = 4000             # subsample cap per floor when fitting
MIN_CLEAN = 50              # need at least this many usable clean cells to fit a floor
SEED = 1234


def _feature(patch, gain):
    """34-d cell feature, or None if the cell is unjudgeable (glare/shadow/refused).

    hist(32) [gain-normalised grey histogram] ++ [(mean_a-128)/128, (mean_b-128)/128]
    (LAB chroma means, brightness-invariant). Same `describe` used by the incumbent,
    so glare/shadow cells are rejected identically (ok == False)."""
    d = describe(patch, gain)
    if not d.ok:
        return None
    lab = cv2.cvtColor(patch, cv2.COLOR_BGR2LAB)
    a = (float(lab[:, :, 1].mean()) - 128.0) / 128.0
    b = (float(lab[:, :, 2].mean()) - 128.0) / 128.0
    return np.concatenate([d.hist, (a, b)]).astype(np.float64)


@register
class GMMNovelty(Scorer):
    name = "gmm_novelty"
    device = "cpu"
    trains_on_clean = True
    note = "GMM novelty on clean floor cells (per floor)"

    def __init__(self):
        self.models: dict[str, object] = {}
        self.params = 0

    def fit(self, clean_pool):
        """Per floor: gather clean-cell features, subsample (seeded) to FEAT_CAP,
        fit a diagonal-covariance GMM. Floors with too few usable cells store None."""
        from sklearn.mixture import GaussianMixture

        self.models = {}
        rng = np.random.default_rng(SEED)
        total = 0
        for floor, cells in clean_pool.items():
            feats = [f for f in (_feature(c.patch, c.gain) for c in cells) if f is not None]
            if len(feats) < MIN_CLEAN:
                self.models[floor] = None
                continue
            X = np.asarray(feats, dtype=np.float64)
            if X.shape[0] > FEAT_CAP:
                idx = rng.choice(X.shape[0], FEAT_CAP, replace=False)
                X = X[idx]
            gmm = GaussianMixture(n_components=K, covariance_type="diag",
                                  random_state=SEED, reg_covar=1e-6)
            gmm.fit(X)
            self.models[floor] = gmm
            total += gmm.means_.size + gmm.covariances_.size + gmm.weights_.size
        self.params = int(total)

    def score(self, scene: Scene) -> np.ndarray:
        out = np.zeros(scene.n_cells, np.float64)
        gmm = self.models.get(scene.floor)
        if gmm is None:                       # floor never fitted -> no judgement
            return out
        gd = scene.gain_d
        feats, where = [], []
        for i, (_, _, patch) in enumerate(scene.dirty_cells):
            f = _feature(patch, gd)
            if f is not None:                 # unjudgeable cells stay 0.0
                feats.append(f)
                where.append(i)
        if feats:
            nll = -gmm.score_samples(np.asarray(feats, dtype=np.float64))
            out[where] = nll
        return out
