"""DINOv2-diff — frozen facebook/dinov2-small, cosine-diff vs the clean reference.

The codebase's claimed WINNER (dirt_detector.py's table asserts recall ~0.88 on
polished patterned floors), but that number was asserted, never run through this
harness. This is the first actual measurement.

Architecture identical to the incumbent -- compare the SAME cell's dirty
observation against its clean reference -- but the descriptor is a frozen DINOv2
patch-token field instead of a colour histogram. Both views come from the same
camera at the same pose (appearance-map design), so the per-cell patch tokens are
spatially aligned and correspond; distance = mean cosine distance between
corresponding tokens (Dinov2Backend.distance). Higher = dirtier.

The backbone is PRE-TRAINED and FROZEN -- 22.1M params, nothing to train, no head
to fit. It needs clean-floor IMAGES, not labels. The model lazy-loads on first
score via transformers AutoModel; if the weights are neither cached nor
downloadable (no network), the load raises and scorers/__init__ skips this module
-- the histogram methods still run. Batched by FRAME (one forward per scene over
all its cells), never per cell.
"""

from __future__ import annotations

import numpy as np

from scorers.base import Scene, Scorer, register
from nova_perception.dirt_detector import make_backend


@register
class Dinov2Diff(Scorer):
    name = "dinov2_diff"
    params = 22_100_000
    device = "cuda"
    needs_clean_ref = True
    note = "frozen facebook/dinov2-small cosine-diff vs clean ref"

    def __init__(self):
        # Lazy: hold the backend but do NOT load weights until first score, so
        # merely registering the method (e.g. --list) never touches the GPU/net.
        self._backend = None

    def _get_backend(self):
        if self._backend is None:
            import torch
            dev = "cuda" if torch.cuda.is_available() else "cpu"
            self._backend = make_backend("dinov2", device=dev)
        return self._backend

    def score(self, scene: Scene) -> np.ndarray:
        backend = self._get_backend()
        dd = backend.describe([p for _, _, p in scene.dirty_cells],
                              [scene.gain_d] * scene.n_cells)
        cd = backend.describe([p for _, _, p in scene.clean_cells],
                              [scene.gain_c] * scene.n_cells)
        out = np.zeros(scene.n_cells, np.float64)
        for i in range(scene.n_cells):
            out[i] = backend.distance(cd[i], dd[i])
        return out
