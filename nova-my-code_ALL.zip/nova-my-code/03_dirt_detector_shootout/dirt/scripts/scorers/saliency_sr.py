"""Spectral-residual saliency — the reference-free Bormann trap.

Per-frame saliency (Hou & Zhang, "Saliency Detection: A Spectral Residual
Approach", CVPR 2007), applied Bormann-style as a dirt cue: whatever the frame's
own amplitude spectrum does NOT predict is treated as "anomalous", and anomalous
is guessed to be dirt. 0 params, CPU, no clean reference, no training — it looks
only at scene.dirty_img.

This is a KNOWN-WEAK cue and is included honestly as the reference-free lower
bound, NOT tuned to win. On a regular or polished floor the saliency concentrates
on the floor's own structure (tile seams, checker edges, specular highlights)
rather than on the dirt, so it can rank clean floor as "dirtier" than the dirt —
the Bormann trap. Whatever it gives is reported as-is.

score(cell) = mean spectral-residual saliency over the cell's GRIDxGRID region in
the full frame. Higher saliency = more anomalous = guessed dirtier.
"""

from __future__ import annotations

import cv2
import numpy as np

import benchmark as B
from scorers.base import Scene, Scorer, register


@register
class SaliencySR(Scorer):
    name = "saliency_sr"
    params = 0
    device = "cpu"
    note = "spectral-residual saliency (per-frame), Bormann-style; known weak, can anti-correlate"

    # Spectral-residual hyperparameters = Hou & Zhang (2007) defaults. Fixed, NOT
    # tuned per floor — this is the honest lower-bound, so it gets no dataset knobs.
    _long_side = 128      # downscale target for the SR pass (SR is scale-tolerant -> speedup)
    _resid_k = 3          # box-filter window on the log-amplitude spectrum
    _blur_sigma = 3.0     # Gaussian smoothing of the reconstructed saliency map

    def score(self, scene: Scene) -> np.ndarray:
        sal = self._saliency_map(scene.dirty_img)          # full-frame float map, indexed [y, x]
        h, w = sal.shape
        out = np.zeros(scene.n_cells, np.float64)
        for i, (x, y, _patch) in enumerate(scene.dirty_cells):
            y1, x1 = min(y + B.GRID, h), min(x + B.GRID, w)
            region = sal[y:y1, x:x1]
            if region.size:
                out[i] = float(region.mean())              # mean saliency over the cell
        return out

    def _saliency_map(self, img_bgr: np.ndarray) -> np.ndarray:
        """Spectral-residual saliency of one BGR frame, upscaled to full size."""
        h, w = img_bgr.shape[:2]
        gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY).astype(np.float64)

        # 1. Downscale (long side -> ~_long_side). SR is scale-tolerant, so this is
        #    a free speedup; skip if the frame is already small.
        scale = self._long_side / float(max(h, w))
        if scale < 1.0:
            sw = max(1, int(round(w * scale)))
            sh = max(1, int(round(h * scale)))
            small = cv2.resize(gray, (sw, sh), interpolation=cv2.INTER_AREA)
        else:
            small = gray

        # 2. FFT -> log-amplitude & phase. Spectral residual R = logA - boxfilter(logA).
        F = np.fft.fft2(small)
        log_amp = np.log(np.abs(F) + 1e-8)
        phase = np.angle(F)
        smooth = cv2.boxFilter(log_amp, ddepth=-1,
                               ksize=(self._resid_k, self._resid_k),
                               borderType=cv2.BORDER_REPLICATE)
        residual = log_amp - smooth

        # 3. Reconstruct saliency = |IFFT( exp(R + i*P) )|^2, Gaussian-blur, normalise.
        recon = np.fft.ifft2(np.exp(residual + 1j * phase))
        sal = np.abs(recon) ** 2
        sal = cv2.GaussianBlur(sal, (0, 0), self._blur_sigma)

        # 4. Upscale back to the full frame so cell regions index cleanly.
        sal_full = cv2.resize(sal, (w, h), interpolation=cv2.INTER_LINEAR)

        # Normalise to [0, 1] (rank-preserving within the frame) for a comparable magnitude.
        lo, hi = float(sal_full.min()), float(sal_full.max())
        if hi > lo:
            sal_full = (sal_full - lo) / (hi - lo)
        else:
            sal_full = np.zeros_like(sal_full)
        return sal_full
