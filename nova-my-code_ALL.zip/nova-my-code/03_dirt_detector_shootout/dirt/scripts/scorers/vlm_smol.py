"""VLM absolute per-cell scorer — SmolVLM next-token logit probe (category (d)).

For each 32x32 floor cell we ask a small vision-language model a single question
("Is this floor patch clean or dirty?") and read the *logits* of the answer words
in ONE forward pass -- no generation loop, no text parsing. The score is
    P(dirty) = softmax([clean_logit, dirty_logit])[dirty]
a CONTINUOUS value in [0,1]; higher = dirtier. Reading logits (not a hard yes/no
decode) is load-bearing: it yields a smooth ROC instead of a degenerate 2-value
curve, which recall@FPR needs.

Model: HuggingFaceTB/SmolVLM-500M-Instruct (Idefics3 arch) via
AutoModelForImageTextToText + AutoProcessor, fp16 on CUDA (bitsandbytes is absent,
so NO 4-bit). If the primary model fails to load we fall back, in order, to other
cached SmolVLM checkpoints and record the one that actually loaded in `self.note`.
Everything heavy is lazy (first score() call) so import stays cheap and never
raises -- a load failure degrades to all-zero scores instead of skipping the file.

Speed note: ~26 cells/s at batch 32 on an RTX 3060 (fp16, single 64-token image
per patch, no image splitting) -> the full ~17k synthetic cells take ~11 min.
"""

from __future__ import annotations

import os

import numpy as np

from scorers.base import Scene, Scorer, register

# Try the primary first, then cached alternatives (offline-safe: local_files_only).
_MODEL_CANDIDATES = (
    "HuggingFaceTB/SmolVLM-500M-Instruct",
    "HuggingFaceTB/SmolVLM-256M-Instruct",
    "HuggingFaceTB/SmolVLM2-256M-Video-Instruct",
    "HuggingFaceTB/SmolVLM2-500M-Video-Instruct",
)

_PROMPT = ("Is this floor patch clean or dirty? "
           "Answer with one word: clean or dirty.")

# Answer-word variants; we logsumexp over the first sub-word id of each so the
# probe is robust to a model that prefers a bare/capitalised form. Empirically
# " clean"/" dirty" are the model's top tokens after "Assistant:".
_CLEAN_WORDS = (" clean", "clean", "Clean")
_DIRTY_WORDS = (" dirty", "dirty", "Dirty")


@register
class VLMSmol(Scorer):
    name = "vlm_smol"
    device = "cuda"
    params = 500_000_000
    note = ("SmolVLM-500M-Instruct fp16, next-token logit score "
            "(not 4-bit; bitsandbytes absent)")

    # batch of patches per forward pass; override with VLM_SMOL_BATCH.
    batch_size = int(os.environ.get("VLM_SMOL_BATCH", "32"))
    img_px = 512  # upscale each 32x32 patch to a single 512x512 (=64-token) image

    def __init__(self):
        self._loaded = False          # attempted-and-succeeded
        self._failed = False          # attempted-and-failed -> score() returns zeros
        self._model = None
        self._proc = None
        self._torch = None
        self._prompt_text = None
        self._clean_ids = None
        self._dirty_ids = None

    # ------------------------------------------------------------- model load ---
    def _ensure_loaded(self) -> bool:
        """Lazy, one-shot model load. Returns True if a model is usable."""
        if self._loaded:
            return True
        if self._failed:
            return False

        try:
            import torch
            from transformers import AutoModelForImageTextToText, AutoProcessor
        except Exception as e:                      # torch/transformers missing
            print(f"[vlm_smol] cannot import torch/transformers ({e}); scoring zeros")
            self._failed = True
            return False

        self._torch = torch
        last_err = None
        for repo in _MODEL_CANDIDATES:
            try:
                proc = AutoProcessor.from_pretrained(repo, local_files_only=True)
                model = AutoModelForImageTextToText.from_pretrained(
                    repo, torch_dtype=torch.float16, local_files_only=True)
                model = model.to("cuda").eval()
            except Exception as e:
                last_err = e
                print(f"[vlm_smol] load failed for {repo}: {type(e).__name__}: {e}")
                continue

            # left-pad so logits[:, -1] is the last REAL token for every row.
            try:
                proc.tokenizer.padding_side = "left"
            except Exception:
                pass
            # One 64-token image per patch: no splitting. The shipped
            # size.longest_edge (2048) exceeds this transformers version's 1820
            # resize cap, so clamp size to the 512 square vision input.
            ip = getattr(proc, "image_processor", None)
            if ip is not None:
                try:
                    ip.do_image_splitting = False
                    ip.size = {"longest_edge": self.img_px}
                except Exception:
                    pass

            self._proc = proc
            self._model = model
            self._prompt_text = self._build_prompt(proc)
            self._clean_ids = self._first_ids(proc.tokenizer, _CLEAN_WORDS)
            self._dirty_ids = self._first_ids(proc.tokenizer, _DIRTY_WORDS)
            if not self._clean_ids or not self._dirty_ids:
                print("[vlm_smol] answer tokens unresolved; scoring zeros")
                self._failed = True
                return False
            self._loaded = True
            self.note = (f"{repo} fp16, next-token P(dirty) logit score "
                         f"(not 4-bit; bitsandbytes absent)")
            print(f"[vlm_smol] loaded {repo}; clean_ids={self._clean_ids} "
                  f"dirty_ids={self._dirty_ids} batch={self.batch_size}")
            return True

        print(f"[vlm_smol] NO model loaded ({last_err}); scoring zeros")
        self._failed = True
        return False

    @staticmethod
    def _build_prompt(proc) -> str:
        msg = [{"role": "user", "content": [{"type": "image"},
                                            {"type": "text", "text": _PROMPT}]}]
        return proc.apply_chat_template(msg, add_generation_prompt=True)

    @staticmethod
    def _first_ids(tok, words) -> list:
        ids = []
        for w in words:
            enc = tok.encode(w, add_special_tokens=False)
            if enc:
                ids.append(enc[0])
        # dedupe, preserve determinism
        return sorted(set(ids))

    # ------------------------------------------------------------- scoring ------
    def _patch_to_pil(self, patch):
        import cv2
        from PIL import Image
        rgb = cv2.cvtColor(patch, cv2.COLOR_BGR2RGB)
        return Image.fromarray(rgb).resize((self.img_px, self.img_px), Image.BILINEAR)

    def score(self, scene: Scene) -> np.ndarray:
        n = scene.n_cells
        if n == 0:
            return np.zeros(0, np.float64)
        if not self._ensure_loaded():
            return np.zeros(n, np.float64)

        torch = self._torch
        out = np.zeros(n, np.float64)
        # Only cells the harness will actually evaluate matter; scoring the rest
        # is wasted VLM forward passes (it drops non-eval cells before metrics).
        # This is correctness-preserving: non-eval outputs stay 0 and are masked.
        idx = np.nonzero(scene.eval_mask)[0]
        if idx.size == 0:
            return out
        patches = [scene.dirty_cells[j][2] for j in idx]
        bs = max(1, self.batch_size)

        with torch.no_grad():
            for i in range(0, idx.size, bs):
                chunk = patches[i:i + bs]
                imgs = [self._patch_to_pil(p) for p in chunk]
                inputs = self._proc(
                    text=[self._prompt_text] * len(chunk),
                    images=[[im] for im in imgs],
                    return_tensors="pt", padding=True)
                inputs = {k: (v.to("cuda").half()
                              if v.dtype == torch.float32 else v.to("cuda"))
                          for k, v in inputs.items()}
                logits = self._model(**inputs).logits[:, -1, :].float()
                lc = torch.logsumexp(logits[:, self._clean_ids], dim=1)
                ld = torch.logsumexp(logits[:, self._dirty_ids], dim=1)
                p_dirty = torch.softmax(torch.stack([lc, ld], dim=1), dim=1)[:, 1]
                out[idx[i:i + len(chunk)]] = p_dirty.cpu().numpy()
        return out
