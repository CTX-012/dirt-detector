"""Spatial-diff — the shipping default, wrapped for the shootout.

The reference is not in the past and not in a stored map -- it is in the SAME
frame. Most of any floor is clean even when it is dirty, so the MEDIAN cell
descriptor across the cells in front of us right now IS the clean reference, and
dirt is what sits far from it (SpatialBackend in dirt_detector.py). 0 params, CPU,
no stored map, no clean image -- reference-free, per-frame.

This wraps scripts/benchmark.py:spatial_scores wholesale so the shootout number
reproduces the shipping default's PART-2 behaviour exactly. spatial_scores returns
a per-cell sigma array (change-from-median in robust-deviation units, clipped to
[0, 40]) aligned 1:1 with cells_of(dirty_img) == scene.dirty_cells. Higher sigma =
farther from the floor's own median = dirtier -- already the right convention.

KNOWN BLIND SPOT (inherited): a uniformly dirty floor. If every cell is equally
grimy nothing is an outlier and this sees nothing -- that is the piezo's job.
"""

from __future__ import annotations

import numpy as np

import benchmark as B
from scorers.base import Scene, Scorer, register
from nova_perception.dirt_detector import DirtDetector


@register
class SpatialDiff(Scorer):
    name = "spatial_diff"
    params = 0
    device = "cpu"
    note = "median-of-frame spatial reference (shipping default)"

    def __init__(self):
        # Construct the detector once and reuse across every scene. The spatial
        # backend stores nothing between frames, so a single instance is safe.
        self._det = DirtDetector("spatial")

    def score(self, scene: Scene) -> np.ndarray:
        sig, _cs = B.spatial_scores(scene.dirty_img, self._det)
        if sig is None:
            return np.zeros(scene.n_cells, np.float64)
        return np.asarray(sig, np.float64)
