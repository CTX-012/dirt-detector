"""Histogram-differential — the incumbent, the baseline to beat.

32-bin gain-normalised colour histogram per cell + Bhattacharyya distance vs the
SAME cell in the clean reference frame. 0 params, CPU, no model. This is the
golden reference scorer: run through the shootout harness it must reproduce
benchmark.json -> differential_synthetic.per_floor exactly (the wiring gate).

score(cell) = change(describe(clean_patch, gain_c), describe(dirty_patch, gain_d))
mirrors scripts/benchmark.py:bench_differential (reference = clean 'after',
observation = dirty 'before'). Higher = dirtier.
"""

from __future__ import annotations

import numpy as np

from scorers.base import Scene, Scorer, register
from nova_perception.verification import change, describe


@register
class HistogramDiff(Scorer):
    name = "histogram_diff"
    params = 0
    device = "cpu"
    needs_clean_ref = True
    note = "incumbent: 32-bin hist + Bhattacharyya vs clean ref"

    def score(self, scene: Scene) -> np.ndarray:
        gc, gd = scene.gain_c, scene.gain_d
        out = np.empty(scene.n_cells, np.float64)
        for i, ((_, _, dp), (_, _, cp)) in enumerate(
                zip(scene.dirty_cells, scene.clean_cells)):
            out[i] = change(describe(cp, gc), describe(dp, gd))
        return out
