"""Auto-import every scorer module so each self-registers into REGISTRY.

Adding a method = dropping a new *.py in this package. No file here is edited on
fan-out, so parallel agents never conflict. A module that fails to import (e.g. a
GPU method on a CPU-only box, or a missing optional dep) is skipped with a warning
rather than taking down the whole shootout.
"""

import importlib
import os
import pkgutil
import warnings

from scorers.base import REGISTRY, Scorer, register, Scene, CleanCell, sanitize  # noqa: F401

_pkgdir = os.path.dirname(os.path.abspath(__file__))
for _m in pkgutil.iter_modules([_pkgdir]):
    if _m.name in ("base",) or _m.name.startswith("_"):
        continue
    try:
        importlib.import_module(f"{__name__}.{_m.name}")
    except Exception as e:  # optional dep / GPU-only method missing -> skip, don't crash
        warnings.warn(f"scorer '{_m.name}' not loaded: {type(e).__name__}: {e}")
