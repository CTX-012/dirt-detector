"""Deep-hist — a richer histogram differential than the incumbent.

Same architecture as histogram_diff (compare the SAME cell's dirty observation
against its clean reference with a Bhattacharyya distance -- direction-agnostic,
shift-invariant, 0 params, CPU) but with a FATTER per-cell descriptor:

    feature = concat(
        gain-normalised intensity histogram   (verification.describe -- reuses the
                                                shipping gain normalisation + glare
                                                gate; captures a stain darkening),
        hue histogram                          (chromatic dirt: a coffee/mud stain
                                                shifts hue even when it barely darkens),
        saturation histogram,
        gradient-orientation histogram         (HOG-like: orientation bins weighted
                                                by Sobel magnitude; captures texture
                                                that dirt adds or a smear removes)
    )

Each sub-histogram is L1-normalised, then the four are concatenated with equal
weight and renormalised to sum 1. Distance = Bhattacharyya 1 - sum(sqrt(h_c*h_d)).
Higher = more change between clean and dirty = dirtier.

The intensity part alone IS the incumbent (histogram_diff); the hue/saturation/
gradient parts are the "deeper" cue that a plain grayscale histogram is blind to.
0 params, deterministic, no model, no torch, no download.

Unusable cells (glare/shadow, valid_frac < 0.5 on either side) score 0.0 -- the
same "refuse rather than guess" gate the incumbent uses, via describe().ok.
"""

from __future__ import annotations

import cv2
import numpy as np

from scorers.base import Scene, Scorer, register
from nova_perception.verification import (
    GLARE_RATIO, SATURATION_CUTOFF, SHADOW_CUTOFF, describe)

# Fixed histogram resolutions (structure, not tuned per floor -- keeps it 0-param
# and deterministic, exactly like the incumbent's 32 intensity bins).
_HUE_BINS = 12        # over [0, 180) -- OpenCV hue range
_SAT_BINS = 4         # over [0, 256)
_ORI_BINS = 9         # unsigned gradient orientation over [0, 180)


@register
class DeepHist(Scorer):
    name = "deep_hist"
    params = 0
    device = "cpu"
    needs_clean_ref = True
    note = "color+gradient-orientation histogram differential"

    def score(self, scene: Scene) -> np.ndarray:
        gc, gd = scene.gain_c, scene.gain_d
        out = np.zeros(scene.n_cells, np.float64)
        for i, ((_, _, dp), (_, _, cp)) in enumerate(
                zip(scene.dirty_cells, scene.clean_cells)):
            fd = self._feature(dp, gd)
            fc = self._feature(cp, gc)
            if fd is None or fc is None:
                out[i] = 0.0            # glare/shadow/unusable -> refuse, not guess
            else:
                # Bhattacharyya distance between two L1-normalised histograms.
                out[i] = float(1.0 - np.sum(np.sqrt(fc * fd)))
        return out

    def _feature(self, patch_bgr, gain):
        """Concatenated, equal-weight, L1-normalised feature histogram for a cell.
        Returns None if the cell is unusable (same gate as the incumbent)."""
        d = describe(patch_bgr, gain)           # gain-normalised intensity hist + ok gate
        if not d.ok:
            return None

        gray = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2GRAY)
        # Same usable-pixel criterion describe() applied: drop blown, near-black,
        # and specular-sheen pixels so glare cannot forge colour/gradient mass.
        usable = ((gray < SATURATION_CUTOFF) & (gray > SHADOW_CUTOFF)
                  & (gray < GLARE_RATIO * gain))
        if not usable.any():
            return None

        # --- colour: hue + saturation over usable pixels ---
        hsv = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2HSV)
        h_hue = np.histogram(hsv[..., 0][usable].astype(np.float64),
                             bins=_HUE_BINS, range=(0.0, 180.0))[0].astype(np.float64)
        h_sat = np.histogram(hsv[..., 1][usable].astype(np.float64),
                             bins=_SAT_BINS, range=(0.0, 256.0))[0].astype(np.float64)

        # --- gradient orientation (HOG-like), magnitude-weighted ---
        gx = cv2.Sobel(gray, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(gray, cv2.CV_32F, 0, 1, ksize=3)
        mag = np.sqrt(gx * gx + gy * gy)
        ang = np.rad2deg(np.arctan2(gy, gx)) % 180.0     # unsigned orientation
        h_ori = np.histogram(ang[usable], bins=_ORI_BINS, range=(0.0, 180.0),
                             weights=mag[usable])[0].astype(np.float64)

        # L1-normalise each block, then equal-weight concat + renormalise to sum 1.
        parts = []
        for h in (d.hist.astype(np.float64), h_hue, h_sat, h_ori):
            s = h.sum()
            parts.append(h / s if s > 0 else h)
        feat = np.concatenate(parts)
        fs = feat.sum()
        return feat / fs if fs > 0 else None
