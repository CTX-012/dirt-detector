"""Build a synthetic before/after floor benchmark in the BAN layout that
nova_perception.datasets.scatspotter_pairs() expects:

    data/synthetic/before/<scene>.jpg    floor WITH dirt   (the observation)
    data/synthetic/after/<scene>.jpg     same floor CLEAN  (the reference)
    data/synthetic/masks/<scene>.png     white where dirt was composited

Six procedural floor types x five dirt types, with per-view nuisance factors the
real system faces: sensor noise, a small gain (exposure) difference between the
two views, and a few-pixel misregistration. Ground truth is exact because we
composited the dirt ourselves.
"""

from __future__ import annotations

import os

import cv2
import numpy as np

ROOT = os.path.join(os.path.dirname(__file__), "..", "data", "synthetic")
W, H = 960, 720
RNG = np.random.default_rng(7)


# ---------------------------------------------------------------- floors ----

def floor_plain(rng):
    base = rng.uniform(120, 190)
    img = np.full((H, W, 3), base, np.float32)
    img += rng.normal(0, 2.5, (H, W, 3))
    return img


def floor_tile(rng, tile=120, dark=False):
    base = rng.uniform(40, 70) if dark else rng.uniform(140, 200)
    img = np.full((H, W, 3), base, np.float32)
    img += rng.normal(0, 2.0, (H, W, 3))
    for y in range(0, H, tile):
        img[y:y + 3, :] *= 0.55                      # grout lines
    for x in range(0, W, tile):
        img[:, x:x + 3] *= 0.55
    # slight per-tile tint variation
    for y in range(0, H, tile):
        for x in range(0, W, tile):
            img[y:y + tile, x:x + tile] *= rng.uniform(0.95, 1.05)
    return img


def floor_wood(rng):
    img = np.zeros((H, W, 3), np.float32)
    plank = 80
    for y in range(0, H, plank):
        tone = rng.uniform(90, 150)
        strip = np.full((min(plank, H - y), W, 3), tone, np.float32)
        # wood grain: low-frequency horizontal streaks
        grain = np.sin(np.linspace(0, rng.uniform(20, 60), W))[None, :, None]
        strip += grain * rng.uniform(4, 9)
        strip += rng.normal(0, 3, strip.shape)
        img[y:y + plank] = strip
        img[y:y + 2] *= 0.6                          # plank seams
    img[..., 0] *= 0.55                              # brown-ish: less blue
    img[..., 1] *= 0.75
    return img


def floor_terrazzo(rng):
    base = rng.uniform(150, 200)
    img = np.full((H, W, 3), base, np.float32)
    n = int(rng.uniform(2000, 4000))                 # speckles
    xs = rng.integers(0, W, n)
    ys = rng.integers(0, H, n)
    for x, y in zip(xs, ys):
        r = int(rng.uniform(1, 4))
        c = rng.uniform(0.5, 1.4)
        cv2.circle(img, (int(x), int(y)), r, (base * c,) * 3, -1)
    img += rng.normal(0, 2, img.shape)
    return img


def floor_checker(rng, sq=60):
    a, b = rng.uniform(60, 100), rng.uniform(170, 220)
    img = np.zeros((H, W, 3), np.float32)
    for y in range(0, H, sq):
        for x in range(0, W, sq):
            img[y:y + sq, x:x + sq] = a if ((x // sq + y // sq) % 2) else b
    img += rng.normal(0, 2.5, img.shape)
    return img


def floor_glossy(rng):
    """Plain floor with a broad specular sheen band -- the hard case."""
    img = floor_plain(rng)
    cx = rng.uniform(0.3, 0.7) * W
    xx = np.arange(W, dtype=np.float32)
    sheen = np.exp(-((xx - cx) / (0.18 * W)) ** 2) * rng.uniform(55, 90)
    img += sheen[None, :, None]
    return img


FLOORS = {
    "plain": floor_plain,
    "tile": floor_tile,
    "dark_tile": lambda r: floor_tile(r, dark=True),
    "wood": floor_wood,
    "terrazzo": floor_terrazzo,
    "checker": floor_checker,
    "glossy": floor_glossy,
}


# ------------------------------------------------------------------ dirt ----

def _blob_mask(rng, cx, cy, rx, ry, irregular=1.0, shape=None):
    """Irregular filled blob around (cx, cy)."""
    mask = np.zeros(shape or (H, W), np.float32)
    ang = np.linspace(0, 2 * np.pi, 24, endpoint=False)
    rad_x = rx * (1 + irregular * rng.uniform(-0.4, 0.4, ang.size))
    rad_y = ry * (1 + irregular * rng.uniform(-0.4, 0.4, ang.size))
    pts = np.stack([cx + rad_x * np.cos(ang), cy + rad_y * np.sin(ang)], axis=1)
    cv2.fillPoly(mask, [pts.astype(np.int32)], 1.0)
    mask = cv2.GaussianBlur(mask, (0, 0), 4)
    return mask


def _pick_center(rng, img, region, pad=0.15):
    """Random dirt centre. region = (x0, y0, x1, y1) fractions of the image;
    defaults to the padded full frame (the synthetic floors ARE all floor)."""
    h, w = img.shape[:2]
    x0, y0, x1, y1 = region or (pad, pad, 1 - pad, 1 - pad)
    return rng.uniform(x0, x1) * w, rng.uniform(y0, y1) * h


def dirt_stain(rng, img, mask_acc, region=None, scale=1.0):
    """Dark translucent coffee-like stain."""
    h, w = img.shape[:2]
    cx, cy = _pick_center(rng, img, region)
    m = _blob_mask(rng, cx, cy, rng.uniform(40, 110) * scale,
                   rng.uniform(35, 90) * scale, shape=(h, w))
    dark = rng.uniform(0.35, 0.65)
    img *= (1 - m[..., None] * (1 - dark))
    mask_acc[m > 0.25] = 255
    return img


def dirt_spill(rng, img, mask_acc, region=None, scale=1.0):
    """Large uniform dark spill -- the no-local-contrast case."""
    h, w = img.shape[:2]
    cx, cy = _pick_center(rng, img, region, pad=0.25)
    m = _blob_mask(rng, cx, cy, rng.uniform(120, 200) * scale,
                   rng.uniform(100, 160) * scale, 0.5, shape=(h, w))
    tone = rng.uniform(25, 60)
    img = img * (1 - m[..., None]) + m[..., None] * tone
    mask_acc[m > 0.25] = 255
    return img


def dirt_crumbs(rng, img, mask_acc, region=None, scale=1.0):
    """Cluster of small dark particles."""
    h, w = img.shape[:2]
    cx, cy = _pick_center(rng, img, region, pad=0.2)
    n = int(rng.uniform(50, 140))
    reg = np.zeros((h, w), np.float32)
    for _ in range(n):
        x = int(np.clip(rng.normal(cx, 60 * scale), 0, w - 1))
        y = int(np.clip(rng.normal(cy, 50 * scale), 0, h - 1))
        r = max(1, int(rng.uniform(1, 4) * scale))
        tone = rng.uniform(15, 70)
        cv2.circle(img, (x, y), r, (tone,) * 3, -1)
        cv2.circle(reg, (x, y), r + 2, 1.0, -1)
    mask_acc[reg > 0] = 255
    return img


def dirt_smear(rng, img, mask_acc, region=None, scale=1.0):
    """Elongated mud smear."""
    h, w = img.shape[:2]
    cx, cy = _pick_center(rng, img, region, pad=0.2)
    m = _blob_mask(rng, cx, cy, rng.uniform(130, 220) * scale,
                   rng.uniform(18, 40) * scale, shape=(h, w))
    ang = rng.uniform(0, 180)
    rot = cv2.getRotationMatrix2D((cx, cy), ang, 1.0)
    m = cv2.warpAffine(m, rot, (w, h))
    mud = np.array([40, 70, 95], np.float32) * rng.uniform(0.7, 1.2)
    img = img * (1 - 0.75 * m[..., None]) + 0.75 * m[..., None] * mud
    mask_acc[m > 0.25] = 255
    return img


def dirt_dust(rng, img, mask_acc, region=None, scale=1.0):
    """Light dust patch -- brightens slightly. Direction-agnostic test."""
    h, w = img.shape[:2]
    cx, cy = _pick_center(rng, img, region, pad=0.2)
    m = _blob_mask(rng, cx, cy, rng.uniform(70, 140) * scale,
                   rng.uniform(60, 110) * scale, 0.6, shape=(h, w))
    img = img + m[..., None] * rng.uniform(18, 35)
    mask_acc[m > 0.30] = 255
    return img


DIRT = {
    "stain": dirt_stain,
    "spill": dirt_spill,
    "crumbs": dirt_crumbs,
    "smear": dirt_smear,
    "dust": dirt_dust,
}


# ------------------------------------------------------------- nuisances ----

def view_nuisance(img, rng, max_shift=4):
    """What differs between two honest views of the same floor: a little
    sensor noise, a small exposure/gain difference, a few px of misregistration."""
    gain = rng.uniform(0.94, 1.06)
    out = img * gain + rng.normal(0, 2.0, img.shape)
    dx, dy = rng.integers(-max_shift, max_shift + 1, 2)
    m = np.float32([[1, 0, dx], [0, 1, dy]])
    out = cv2.warpAffine(out, m, (img.shape[1], img.shape[0]),
                         borderMode=cv2.BORDER_REFLECT)
    return np.clip(out, 0, 255).astype(np.uint8)


# ----------------------------------------------------------------- build ----

def main():
    for sub in ("before", "after", "masks"):
        os.makedirs(os.path.join(ROOT, sub), exist_ok=True)
    scenes = []
    per_combo = 3
    for fname, ffn in FLOORS.items():
        for dname, dfn in DIRT.items():
            for k in range(per_combo):
                scene = f"{fname}__{dname}__{k:02d}"
                clean = ffn(RNG)
                mask = np.zeros((H, W), np.uint8)
                dirty = dfn(RNG, clean.copy(), mask)
                cv2.imwrite(os.path.join(ROOT, "after", scene + ".jpg"),
                            view_nuisance(clean, RNG))
                cv2.imwrite(os.path.join(ROOT, "before", scene + ".jpg"),
                            view_nuisance(dirty, RNG))
                cv2.imwrite(os.path.join(ROOT, "masks", scene + ".png"), mask)
                scenes.append(scene)
    print(f"built {len(scenes)} scenes in {os.path.abspath(ROOT)}")
    print(f"floors: {list(FLOORS)}")
    print(f"dirt:   {list(DIRT)}")


if __name__ == "__main__":
    main()
