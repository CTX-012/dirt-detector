"""Method shootout harness.

Runs every registered Scorer over the SAME floor cells and reports the metric
that matters -- recall @ 5% FPR, per floor type and overall (mean of per-floor) --
plus AUROC (secondary), params, and (optionally) measured FPS/VRAM on the RTX 3060.

Reuses scripts/benchmark.py wholesale (roc_metrics, cells_of, cell_labels,
band_cell_mask) and never modifies it or benchmark.json. Emits NEW files:
  data/results/shootout.json / .md / .csv
"""

from __future__ import annotations

import csv
import io
import json
import os
import subprocess
import time
from collections import defaultdict
from dataclasses import dataclass

import numpy as np

from scorers.base import DATA, RESULTS, CleanCell, Scene, sanitize

# benchmark.py is import-safe (all work is under __main__); reuse its helpers.
import benchmark as B
from nova_perception.verification import frame_gain

import cv2

FPR = 0.05
REAL_ENVS = ("airport", "home_tile", "home_wood", "mall", "office", "supermarket")
SEED = 1234


# ------------------------------------------------------------- scene loading ---

@dataclass
class LabeledScene:
    scene: Scene
    labels: np.ndarray          # bool[n_cells], aligned to scene.dirty_cells


def _load_triple(before_p, after_p, mask_p):
    dirty = cv2.imread(before_p)
    clean = cv2.imread(after_p)
    mask = cv2.imread(mask_p, cv2.IMREAD_GRAYSCALE)
    return dirty, clean, mask


def build_scene_set(dataset: str) -> "list[LabeledScene]":
    """Build label-free Scenes (+ parallel labels) for one dataset.

    before/ = DIRTY observation, after/ = CLEAN reference, masks/ = dirt GT
    (settled by make_synthetic.py). Cells are computed ONCE here and shared by
    every scorer, guaranteeing an identical cell iterator across methods.
    """
    root = os.path.join(DATA, dataset if dataset != "indoor" else "indoor_floors")
    if dataset == "synthetic":
        pass
    elif dataset == "indoor":
        pass
    else:
        raise ValueError(f"unknown dataset {dataset!r}")

    bdir = os.path.join(root, "before")
    names = sorted(os.path.splitext(f)[0] for f in os.listdir(bdir))
    out = []
    for name in names:
        floor = name.split("__")[0]
        if dataset == "indoor" and floor not in REAL_ENVS:
            continue                      # skip kaggle_room / roboflow backgrounds
        dirty, clean, mask = _load_triple(
            os.path.join(root, "before", name + ".jpg"),
            os.path.join(root, "after", name + ".jpg"),
            os.path.join(root, "masks", name + ".png"))
        if dirty is None or clean is None or mask is None:
            continue
        gd, gc = frame_gain(dirty), frame_gain(clean)
        if gd <= 0 or gc <= 0:
            continue
        dcells = B.cells_of(dirty)
        ccells = B.cells_of(clean)
        labs = B.cell_labels(mask, len(dcells))
        if dataset == "indoor":
            eval_mask = B.band_cell_mask(dirty.shape, len(dcells))
        else:
            eval_mask = np.ones(len(dcells), bool)
        sc = Scene(floor=floor, dirty_img=dirty, clean_img=clean,
                   dirty_cells=dcells, clean_cells=ccells,
                   gain_d=gd, gain_c=gc, eval_mask=eval_mask)
        out.append(LabeledScene(sc, labs))
    return out


def build_clean_pool(dataset: str) -> "dict[str, list[CleanCell]]":
    """Clean-cell pool for train-on-clean methods, keyed by floor/env.

    indoor: band cells of the pure-clean raw/<env>__*.jpg photos (16/env).
    synthetic: cells of the after/<floor>__* clean references (no raw/ pool exists).
    """
    pool: "dict[str, list[CleanCell]]" = defaultdict(list)
    if dataset == "indoor":
        rawdir = os.path.join(DATA, "indoor_floors", "raw")
        for f in sorted(os.listdir(rawdir)):
            env = f.split("__")[0]
            if env not in REAL_ENVS:
                continue
            img = cv2.imread(os.path.join(rawdir, f))
            if img is None:
                continue
            g = frame_gain(img)
            if g <= 0:
                continue
            cells = B.cells_of(img)
            band = B.band_cell_mask(img.shape, len(cells))
            for (x, y, p), b in zip(cells, band):
                if b:
                    pool[env].append(CleanCell(p, g))
    else:  # synthetic
        adir = os.path.join(DATA, "synthetic", "after")
        for f in sorted(os.listdir(adir)):
            floor = f.split("__")[0]
            img = cv2.imread(os.path.join(adir, f))
            if img is None:
                continue
            g = frame_gain(img)
            if g <= 0:
                continue
            for (x, y, p) in B.cells_of(img):
                pool[floor].append(CleanCell(p, g))
    return dict(pool)


# ------------------------------------------------------------- evaluation ------

def evaluate(scorer, labeled_scenes) -> dict:
    """Score every scene, pool per floor, compute per-floor + overall metrics."""
    per_floor = defaultdict(lambda: ([], []))
    for ls in labeled_scenes:
        s = sanitize(scorer.score(ls.scene), ls.scene.n_cells)
        m = ls.scene.eval_mask
        per_floor[ls.scene.floor][0].append(s[m])
        per_floor[ls.scene.floor][1].append(ls.labels[m])
    return aggregate(per_floor, scorer)


def aggregate(per_floor, scorer) -> dict:
    pf = {}
    for f, (s, l) in sorted(per_floor.items()):
        pf[f] = B.roc_metrics(np.concatenate(s), np.concatenate(l), FPR)
    recalls = np.array([pf[f]["recall_at_fpr"] for f in pf], float)
    aurocs = np.array([pf[f]["auroc"] for f in pf], float)
    # pooled = one global threshold over all cells (deployment-style, for honesty)
    allS = np.concatenate([np.concatenate(s) for s, _ in per_floor.values()])
    allL = np.concatenate([np.concatenate(l) for _, l in per_floor.values()])
    pooled = B.roc_metrics(allS, allL, FPR)
    return {
        "per_floor": pf,
        "overall": {
            "recall_mean": float(np.nanmean(recalls)),     # <-- HEADLINE (mean of per-floor)
            "auroc_mean": float(np.nanmean(aurocs)),
            "recall_pooled": pooled["recall_at_fpr"],
            "auroc_pooled": pooled["auroc"],
        },
        "params": int(scorer.params),
        "device": scorer.device,
        "note": scorer.note,
        "trap": False,                                     # filled by flag_traps()
    }


INCUMBENT = "histogram_diff"


def flag_traps(methods: dict) -> None:
    """Mark the PatchCore trap: a method that BEATS the incumbent on AUROC but does
    NOT beat it on recall@5%FPR. That is the whole point of the metric -- a method
    you would have picked on AUROC yet which buys you nothing (or less) at the strict
    operating point vs the free histogram baseline. Falls back to a median rule if
    the incumbent is absent from the run."""
    names = list(methods)
    auroc = {n: methods[n]["overall"]["auroc_mean"] for n in names}
    recall = {n: methods[n]["overall"]["recall_mean"] for n in names}
    if INCUMBENT in methods:
        a0, r0 = auroc[INCUMBENT], recall[INCUMBENT]
        for n in names:
            methods[n]["trap"] = (n != INCUMBENT and auroc[n] > a0 and recall[n] <= r0)
    elif len(names) >= 3:
        top2 = set(sorted(names, key=lambda n: auroc[n], reverse=True)[:2])
        med = float(np.median([recall[n] for n in names]))
        for n in names:
            methods[n]["trap"] = (n in top2) and (recall[n] < med)


# ------------------------------------------------------------- FPS / VRAM ------

def fps_pass(scorers, payload, clean_pool, k: int = 5) -> dict:
    """Measure throughput on the ACTUAL card. Accuracy is hardware-independent;
    this pass is the only thing that must run on the RTX 3060.

    Identical payload for every method (fairness); fit + one warmup outside timing;
    CUDA sync + peak-VRAM bracketed; median of k timed runs. cells/s is reported
    WITH the device label so a CPU number is never mistaken for a GPU number.
    """
    import torch
    cuda = torch.cuda.is_available()
    dev_name = torch.cuda.get_device_name(0) if cuda else "cpu-only"
    total_cells = sum(s.n_cells for s in payload)
    out = {"device_name": dev_name, "n_cells_payload": total_cells, "k": k, "methods": {}}
    for scorer in scorers:
        rec = {"device": scorer.device, "params": int(scorer.params), "note": scorer.note}
        if scorer.device == "cuda" and not cuda:
            rec.update(cells_per_s=None, frames_per_s=None, vram_mb=None,
                       note=(scorer.note + " | NOT MEASURED: no CUDA").strip(" |"))
            out["methods"][scorer.name] = rec
            continue
        try:
            scorer.fit(clean_pool)
            for s in payload:                                   # warmup (excluded)
                sanitize(scorer.score(s), s.n_cells)
            if scorer.device == "cuda":
                torch.cuda.synchronize()
                torch.cuda.reset_peak_memory_stats()
            times = []
            for _ in range(k):
                t0 = time.perf_counter()
                for s in payload:
                    sanitize(scorer.score(s), s.n_cells)
                if scorer.device == "cuda":
                    torch.cuda.synchronize()
                times.append(time.perf_counter() - t0)
            med = float(np.median(times))
            vram = (torch.cuda.max_memory_allocated() / 1e6
                    if scorer.device == "cuda" else None)
            rec.update(cells_per_s=total_cells / med,
                       frames_per_s=len(payload) / med,
                       vram_mb=vram)
        except Exception as e:                                  # never let one method kill the pass
            rec.update(cells_per_s=None, frames_per_s=None, vram_mb=None,
                       note=(scorer.note + f" | FPS error: {type(e).__name__}: {e}").strip(" |"))
        out["methods"][scorer.name] = rec
    return out


# ------------------------------------------------------------- emitters --------

def _git_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", os.path.dirname(DATA), "rev-parse", "--short", "HEAD"],
            stderr=subprocess.DEVNULL).decode().strip()
    except Exception:
        return "unknown"


def build_record(results_by_dataset, fps=None) -> dict:
    return {
        "config": {"grid": B.GRID, "cell_px": B.CELL_PX, "mask_frac": B.MASK_FRAC,
                   "fpr": FPR, "seed": SEED, "git_commit": _git_commit(),
                   "overall_def": "mean of per-floor recall@5%FPR"},
        "datasets": results_by_dataset,
        "fps": fps,
    }


def _fmt(v, nd=3):
    return "  -  " if v is None or (isinstance(v, float) and np.isnan(v)) else f"{v:.{nd}f}"


def render_md(record) -> str:
    o = io.StringIO()
    o.write("# Dirt detector shootout — recall@5%FPR\n\n")
    c = record["config"]
    o.write(f"_config: grid={c['grid']} cell={c['cell_px']}px mask_frac={c['mask_frac']} "
            f"fpr={c['fpr']} seed={c['seed']} commit={c['git_commit']}_\n")
    o.write(f"_overall = {c['overall_def']}; AUROC column is secondary; "
            f"**trap** = wins AUROC but loses recall@5%FPR_\n\n")
    for ds, blob in record["datasets"].items():
        floors = blob["floors"]
        methods = blob["methods"]
        o.write(f"## {ds}  ({len(floors)} floor types)\n\n")
        head = ["method"] + floors + ["**OVERALL**", "AUROC", "trap", "params", "dev"]
        o.write("| " + " | ".join(head) + " |\n")
        o.write("|" + "|".join(["---"] * len(head)) + "|\n")
        order = sorted(methods, key=lambda m: methods[m]["overall"]["recall_mean"], reverse=True)
        for m in order:
            mr = methods[m]
            row = [m]
            for f in floors:
                row.append(_fmt(mr["per_floor"].get(f, {}).get("recall_at_fpr")))
            row.append(f"**{_fmt(mr['overall']['recall_mean'])}**")
            row.append(_fmt(mr["overall"]["auroc_mean"]))
            row.append("⚠️" if mr["trap"] else "")
            row.append(_pcount(mr["params"]))
            row.append(mr["device"])
            o.write("| " + " | ".join(row) + " |\n")
        o.write("\n")
    if record.get("fps"):
        fp = record["fps"]
        o.write(f"## FPS / VRAM  (measured on {fp['device_name']}, "
                f"{fp['n_cells_payload']} cells, median of {fp['k']})\n\n")
        o.write("| method | device | cells/s | frames/s | VRAM_MB | params | note |\n")
        o.write("|---|---|---|---|---|---|---|\n")
        for m, r in fp["methods"].items():
            o.write(f"| {m} | {r['device']} | {_fmt(r.get('cells_per_s'),1)} | "
                    f"{_fmt(r.get('frames_per_s'),2)} | {_fmt(r.get('vram_mb'),1)} | "
                    f"{_pcount(r['params'])} | {r.get('note','')} |\n")
        o.write("\n")
    return o.getvalue()


def _pcount(n):
    n = int(n)
    if n == 0:
        return "0"
    if n >= 1_000_000:
        return f"{n/1e6:.1f}M"
    if n >= 1000:
        return f"{n/1e3:.0f}k"
    return str(n)


def render_csv(record) -> str:
    o = io.StringIO()
    w = csv.writer(o)
    w.writerow(["dataset", "method", "floor", "recall_at_5pct_fpr", "auroc",
                "overall_recall_mean", "overall_auroc_mean", "trap", "params", "device"])
    for ds, blob in record["datasets"].items():
        for m, mr in blob["methods"].items():
            ov_r = mr["overall"]["recall_mean"]
            ov_a = mr["overall"]["auroc_mean"]
            for f in blob["floors"]:
                pf = mr["per_floor"].get(f, {})
                w.writerow([ds, m, f, pf.get("recall_at_fpr", ""), pf.get("auroc", ""),
                            ov_r, ov_a, int(mr["trap"]), mr["params"], mr["device"]])
    return o.getvalue()


def write_all(record):
    os.makedirs(RESULTS, exist_ok=True)
    with open(os.path.join(RESULTS, "shootout.json"), "w") as f:
        json.dump(record, f, indent=2)
    with open(os.path.join(RESULTS, "shootout.md"), "w") as f:
        f.write(render_md(record))
    with open(os.path.join(RESULTS, "shootout.csv"), "w") as f:
        f.write(render_csv(record))
    return os.path.join(RESULTS, "shootout.json")
