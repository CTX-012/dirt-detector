"""Benchmark the NOVA perception stack on real + synthetic data.

Reports the metric the codebase itself insists on -- recall @ 5% FPR -- plus
AUROC for context (dirt_detector.py explains why AUROC alone is a trap).

  PART 1  DIFFERENTIAL (before/after histogram change) on the synthetic BAN set.
          This is the verification path: same cell, clean reference vs dirty
          observation, verification.describe() + change().

  PART 2  SPATIAL backend (the shipping default: median-of-frame reference,
          stores nothing) on (a) the synthetic 'before' images and (b) 25 real
          ScatSpotter test photos with human polygon annotations.

  PART 3  VERDICT logic: NoiseFloor + verify_change() end to end on the
          synthetic pairs. False-CLEANED rate is the number that matters --
          it is the lie the whole feature exists to prevent.

Outputs:
  data/results/benchmark.json      all numbers
  data/results/examples/*.jpg      annotated example frames for the report
"""

from __future__ import annotations

import json
import os
import sys

import cv2
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.join(HERE, "..", "nova_desktop_pkg")
sys.path.insert(0, PKG)

from nova_perception.dirt_detector import DirtDetector                  # noqa: E402
from nova_perception.verification import (                              # noqa: E402
    NoiseFloor, Verdict, change, describe, frame_gain, verify_change)

DATA = os.path.join(HERE, "..", "data")
RESULTS = os.path.join(DATA, "results")
EXAMPLES = os.path.join(RESULTS, "examples")
GRID = 64
CELL_PX = 32
MASK_FRAC = 0.15          # cell counts as dirty if >15% covered (datasets.py convention)


# ------------------------------------------------------------- metrics ------

def roc_metrics(scores: np.ndarray, labels: np.ndarray, fpr_at: float = 0.05):
    """AUROC + recall at a fixed FPR, no sklearn needed."""
    scores = np.asarray(scores, np.float64)
    labels = np.asarray(labels, bool)
    pos, neg = scores[labels], scores[~labels]
    if len(pos) == 0 or len(neg) == 0:
        return {"auroc": float("nan"), "recall_at_fpr": float("nan"),
                "threshold": float("nan"), "n_pos": len(pos), "n_neg": len(neg)}
    # AUROC via rank statistic
    order = np.argsort(np.concatenate([pos, neg]), kind="mergesort")
    ranks = np.empty(order.size, np.float64)
    ranks[order] = np.arange(1, order.size + 1)
    # average ties
    allsc = np.concatenate([pos, neg])
    for v in np.unique(allsc):
        m = allsc == v
        if m.sum() > 1:
            ranks[m] = ranks[m].mean()
    auroc = (ranks[:len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg))
    # recall at fixed FPR: threshold = (1-fpr) quantile of the negatives
    thr = float(np.quantile(neg, 1.0 - fpr_at))
    recall = float((pos > thr).mean())
    return {"auroc": float(auroc), "recall_at_fpr": recall,
            "threshold": thr, "n_pos": int(len(pos)), "n_neg": int(len(neg))}


def cells_of(img):
    h, w = img.shape[:2]
    out = []
    for y in range(0, h - GRID + 1, GRID):
        for x in range(0, w - GRID + 1, GRID):
            p = cv2.resize(img[y:y + GRID, x:x + GRID], (CELL_PX, CELL_PX),
                           interpolation=cv2.INTER_AREA)
            out.append((x, y, p))
    return out


def cell_labels(mask, n_expected):
    labs = []
    h, w = mask.shape[:2]
    for y in range(0, h - GRID + 1, GRID):
        for x in range(0, w - GRID + 1, GRID):
            labs.append(int((mask[y:y + GRID, x:x + GRID] > 127).mean() > MASK_FRAC))
    assert len(labs) == n_expected
    return np.array(labs, bool)


# ------------------------------------------------- part 1: differential -----

def bench_differential():
    root = os.path.join(DATA, "synthetic")
    scenes = sorted(os.path.splitext(f)[0]
                    for f in os.listdir(os.path.join(root, "before")))
    all_scores, all_labels, per_floor = [], [], {}
    for scene in scenes:
        floor = scene.split("__")[0]
        dirty = cv2.imread(os.path.join(root, "before", scene + ".jpg"))
        clean = cv2.imread(os.path.join(root, "after", scene + ".jpg"))
        mask = cv2.imread(os.path.join(root, "masks", scene + ".png"),
                          cv2.IMREAD_GRAYSCALE)
        gd, gc = frame_gain(dirty), frame_gain(clean)
        if gd <= 0 or gc <= 0:
            continue
        dcells, ccells = cells_of(dirty), cells_of(clean)
        labs = cell_labels(mask, len(dcells))
        scores = []
        for (x, y, dp), (_, _, cp) in zip(dcells, ccells):
            before_d = describe(cp, gc)      # reference = clean
            after_d = describe(dp, gd)       # observation = dirty
            scores.append(change(before_d, after_d))
        scores = np.array(scores)
        all_scores.append(scores)
        all_labels.append(labs)
        per_floor.setdefault(floor, [[], []])
        per_floor[floor][0].append(scores)
        per_floor[floor][1].append(labs)

    S, L = np.concatenate(all_scores), np.concatenate(all_labels)
    out = {"overall": roc_metrics(S, L),
           "per_floor": {f: roc_metrics(np.concatenate(s), np.concatenate(l))
                         for f, (s, l) in sorted(per_floor.items())}}
    return out


# ------------------------------------------------- part 2: spatial ----------

def spatial_scores(img, det):
    """Score every cell of one image against the frame's own median (sigma units)."""
    gain = frame_gain(img)
    if gain <= 0:
        return None, None
    cs = cells_of(img)
    descs = det.describe([c[2] for c in cs], [gain] * len(cs))
    ref = det.spatial_reference(descs)
    if ref is None:
        return None, None
    raw = np.array([det.score(ref, d) for d in descs])
    med = float(np.median(raw))
    mad = max(float(np.median(np.abs(raw - med))), 0.05 * max(med, 1e-3), 5e-3)
    return np.clip((raw - med) / mad, 0, 40), cs


def bench_spatial_synthetic():
    det = DirtDetector("spatial")
    root = os.path.join(DATA, "synthetic")
    scenes = sorted(os.path.splitext(f)[0]
                    for f in os.listdir(os.path.join(root, "before")))
    S, L, per_floor = [], [], {}
    for scene in scenes:
        floor = scene.split("__")[0]
        img = cv2.imread(os.path.join(root, "before", scene + ".jpg"))
        mask = cv2.imread(os.path.join(root, "masks", scene + ".png"),
                          cv2.IMREAD_GRAYSCALE)
        sig, cs = spatial_scores(img, det)
        if sig is None:
            continue
        labs = cell_labels(mask, len(cs))
        S.append(sig); L.append(labs)
        per_floor.setdefault(floor, [[], []])
        per_floor[floor][0].append(sig); per_floor[floor][1].append(labs)
    S, L = np.concatenate(S), np.concatenate(L)
    return {"overall": roc_metrics(S, L),
            "per_floor": {f: roc_metrics(np.concatenate(s), np.concatenate(l))
                          for f, (s, l) in sorted(per_floor.items())}}


def poly_mask(sample_json, shape):
    mask = np.zeros(shape[:2], np.uint8)
    for ann in sample_json.get("annotations", []):
        seg = ann.get("segmentation")
        if not seg:
            continue
        if isinstance(seg, dict) and "exterior" in seg:
            pts = np.array(seg["exterior"], np.float32).astype(np.int32)
            cv2.fillPoly(mask, [pts], 255)
        elif isinstance(seg, list):
            for poly in seg:
                pts = np.array(poly, np.float32).reshape(-1, 2).astype(np.int32)
                cv2.fillPoly(mask, [pts], 255)
    return mask


def bench_spatial_real(save_examples=3):
    det = DirtDetector("spatial")
    root = os.path.join(DATA, "scatspotter", "test_sample")
    ids = sorted(int(os.path.splitext(f)[0]) for f in os.listdir(root)
                 if f.endswith(".json"))
    S, L, n_used = [], [], 0
    saved = 0
    for i in ids:
        img = cv2.imread(os.path.join(root, f"{i}.jpg"))
        if img is None:
            continue
        meta = json.load(open(os.path.join(root, f"{i}.json")))
        # keep resolution manageable
        scale = 1024 / max(img.shape[:2])
        if scale < 1:
            img = cv2.resize(img, None, fx=scale, fy=scale,
                             interpolation=cv2.INTER_AREA)
        mask = poly_mask(meta, (meta["height"], meta["width"]))
        mask = cv2.resize(mask, (img.shape[1], img.shape[0]),
                          interpolation=cv2.INTER_NEAREST)
        sig, cs = spatial_scores(img, det)
        if sig is None:
            continue
        labs = cell_labels(mask, len(cs))
        if labs.sum() == 0:
            continue
        S.append(sig); L.append(labs); n_used += 1
        if saved < save_examples:
            vis = img.copy()
            thr = np.quantile(sig[~labs], 0.95) if (~labs).sum() else 8.0
            for (x, y, _), s, lab in zip(cs, sig, labs):
                if s > thr:
                    cv2.rectangle(vis, (x, y), (x + GRID, y + GRID), (0, 0, 255), 2)
                if lab:
                    cv2.rectangle(vis, (x + 3, y + 3), (x + GRID - 3, y + GRID - 3),
                                  (0, 255, 0), 1)
            cv2.imwrite(os.path.join(EXAMPLES, f"real_{i}.jpg"), vis)
            saved += 1
    S, L = np.concatenate(S), np.concatenate(L)
    out = roc_metrics(S, L)
    out["n_images"] = n_used
    return out


# ------------------------------------------------- part 3: verdicts ---------

def bench_verdicts():
    """End-to-end: NoiseFloor learns from clean cells, verify_change judges.

    Simulates the robot's actual flow per scene:
      clean-vs-clean changes on non-dirt cells -> NoiseFloor samples
      then every cell gets a verdict. A dirty cell that comes back CLEANED
      (change detected = the pass 'worked') is correct here because our
      'before' is dirty and 'after' is clean -- i.e. the pass DID change it.
      We evaluate detection: dirty cells should read CLEANED (change seen),
      clean cells should read CLEAN (no change).  False-CLEANED = a clean
      cell wrongly reported as changed.
    """
    root = os.path.join(DATA, "synthetic")
    scenes = sorted(os.path.splitext(f)[0]
                    for f in os.listdir(os.path.join(root, "before")))
    tallies = {"dirty_detected": 0, "dirty_missed": 0,
               "clean_ok": 0, "false_changed": 0, "unknown": 0}
    for scene in scenes:
        dirty = cv2.imread(os.path.join(root, "before", scene + ".jpg"))
        clean = cv2.imread(os.path.join(root, "after", scene + ".jpg"))
        mask = cv2.imread(os.path.join(root, "masks", scene + ".png"),
                          cv2.IMREAD_GRAYSCALE)
        gd, gc = frame_gain(dirty), frame_gain(clean)
        if gd <= 0 or gc <= 0:
            continue
        dcells, ccells = cells_of(dirty), cells_of(clean)
        labs = cell_labels(mask, len(dcells))
        chg = []
        for (x, y, dp), (_, _, cp) in zip(dcells, ccells):
            chg.append(change(describe(cp, gc), describe(dp, gd)))
        chg = np.array(chg)

        floor = NoiseFloor(min_samples=30)
        # noise floor learns from clean cells only (piezo-silent stand-in),
        # first 60% of them, like a run warming up
        clean_idx = np.where(~labs)[0]
        for i in clean_idx[: max(30, int(0.6 * len(clean_idx)))]:
            floor.update(chg[i])

        for i, (c, lab) in enumerate(zip(chg, labs)):
            r = verify_change(c, floor, piezo_fired=False, k_sigma=8.0)
            if r.verdict == Verdict.UNKNOWN:
                tallies["unknown"] += 1
            elif lab:
                if r.verdict == Verdict.CLEANED:
                    tallies["dirty_detected"] += 1
                else:
                    tallies["dirty_missed"] += 1
            else:
                if r.verdict == Verdict.CLEANED:
                    tallies["false_changed"] += 1
                else:
                    tallies["clean_ok"] += 1
    nd = tallies["dirty_detected"] + tallies["dirty_missed"]
    nc = tallies["clean_ok"] + tallies["false_changed"]
    tallies["dirty_detection_rate"] = round(tallies["dirty_detected"] / max(nd, 1), 4)
    tallies["false_changed_rate"] = round(tallies["false_changed"] / max(nc, 1), 4)
    return tallies


# ------------------------------------------------- indoor real floors -------

INDOOR_BAND = (0.18, 0.58, 0.82, 0.90)    # must match make_indoor_benchmark.py


def band_cell_mask(shape, n_expected):
    """True for cells whose centre lies in the floor band. The robot's camera
    looks AT the floor; a room photo's upper half is walls and people. Scoring
    only the band approximates the robot's actual view."""
    h, w = shape[:2]
    x0, y0, x1, y1 = INDOOR_BAND
    out = []
    for y in range(0, h - GRID + 1, GRID):
        for x in range(0, w - GRID + 1, GRID):
            cx, cy = x + GRID / 2, y + GRID / 2
            out.append(x0 * w <= cx <= x1 * w and y0 * h <= cy <= y1 * h)
    assert len(out) == n_expected
    return np.array(out, bool)


def bench_indoor(save_examples=4):
    """Differential + spatial + verdicts on REAL indoor floors (composited
    dirt, exact masks), grouped by environment: airport, mall, supermarket,
    home_wood, home_tile, office."""
    root = os.path.join(DATA, "indoor_floors")
    bdir = os.path.join(root, "before")
    if not os.path.isdir(bdir):
        return None
    scenes = sorted(os.path.splitext(f)[0] for f in os.listdir(bdir))
    det = DirtDetector("spatial")

    dS, dL, sS, sL = [], [], [], []
    per_env = {}
    tallies = {"dirty_detected": 0, "dirty_missed": 0,
               "clean_ok": 0, "false_changed": 0, "unknown": 0}
    saved = 0
    for scene in scenes:
        env = scene.split("__")[0]
        dirty = cv2.imread(os.path.join(root, "before", scene + ".jpg"))
        clean = cv2.imread(os.path.join(root, "after", scene + ".jpg"))
        mask = cv2.imread(os.path.join(root, "masks", scene + ".png"),
                          cv2.IMREAD_GRAYSCALE)
        if dirty is None or clean is None or mask is None:
            continue
        gd, gc = frame_gain(dirty), frame_gain(clean)
        if gd <= 0 or gc <= 0:
            continue
        dcells, ccells = cells_of(dirty), cells_of(clean)
        labs = cell_labels(mask, len(dcells))
        band = band_cell_mask(dirty.shape, len(dcells))

        # differential
        chg = np.array([change(describe(cp, gc), describe(dp, gd))
                        for (_, _, dp), (_, _, cp) in zip(dcells, ccells)])
        dS.append(chg[band]); dL.append(labs[band])

        # spatial (reference from the band only -- the floor the robot sees)
        descs = det.describe([c[2] for c in dcells], [gd] * len(dcells))
        band_descs = [d for d, b in zip(descs, band) if b]
        ref = det.spatial_reference(band_descs)
        if ref is not None:
            raw = np.array([det.score(ref, d) for d in descs])
            med = float(np.median(raw[band]))
            mad = max(float(np.median(np.abs(raw[band] - med))),
                      0.05 * max(med, 1e-3), 5e-3)
            sig = np.clip((raw - med) / mad, 0, 40)
            sS.append(sig[band]); sL.append(labs[band])
        else:
            sig = None

        # verdicts (band cells only)
        floor = NoiseFloor(min_samples=20)
        quiet = np.where(band & ~labs)[0]
        for i in quiet[: max(20, int(0.6 * len(quiet)))]:
            floor.update(chg[i])
        for i in np.where(band)[0]:
            r = verify_change(chg[i], floor, piezo_fired=False, k_sigma=8.0)
            if r.verdict == Verdict.UNKNOWN:
                tallies["unknown"] += 1
            elif labs[i]:
                tallies["dirty_detected" if r.verdict == Verdict.CLEANED
                        else "dirty_missed"] += 1
            else:
                tallies["false_changed" if r.verdict == Verdict.CLEANED
                        else "clean_ok"] += 1

        per_env.setdefault(env, [[], []])
        per_env[env][0].append(chg[band]); per_env[env][1].append(labs[band])

        if saved < save_examples and sig is not None and labs[band].sum() > 0:
            vis = dirty.copy()
            x0, y0, x1, y1 = INDOOR_BAND
            h, w = vis.shape[:2]
            cv2.rectangle(vis, (int(x0 * w), int(y0 * h)),
                          (int(x1 * w), int(y1 * h)), (90, 90, 90), 1)
            for (x, y, _), s, b in zip(dcells, sig, band):
                if b and s >= 8.0:
                    a = min(float(s) / 16.0, 1.0)
                    cv2.rectangle(vis, (x, y), (x + GRID, y + GRID),
                                  (0, int(80 * (1 - a)), int(120 + 135 * a)), 2)
            cv2.imwrite(os.path.join(EXAMPLES, f"indoor_{scene}.jpg"), vis)
            saved += 1

    if not dS:
        return None
    nd = tallies["dirty_detected"] + tallies["dirty_missed"]
    nc = tallies["clean_ok"] + tallies["false_changed"]
    tallies["dirty_detection_rate"] = round(tallies["dirty_detected"] / max(nd, 1), 4)
    tallies["false_changed_rate"] = round(tallies["false_changed"] / max(nc, 1), 4)
    return {
        "differential": {
            "overall": roc_metrics(np.concatenate(dS), np.concatenate(dL)),
            "per_env": {e: roc_metrics(np.concatenate(s), np.concatenate(l))
                        for e, (s, l) in sorted(per_env.items())}},
        "spatial": {"overall": roc_metrics(np.concatenate(sS), np.concatenate(sL))},
        "verdicts": tallies,
        "n_scenes": len(scenes),
    }


# ------------------------------------------------- real captured pairs ------

def bench_real_pairs():
    """YOUR phone-captured pairs: real dirt, same floor, before/after.

    Protocol (webapp /capture): CLEAN A (reference), CLEAN B (control, same
    pose), then real dirt, then DIRTY (same pose).

        positive pair = DIRTY  vs CLEAN A   -> should fire
        negative pair = CLEAN B vs CLEAN A  -> pure capture noise, should not

    No masks needed: the negatives ARE the false-positive calibration. The
    scene-level question is the product question -- 'did the detector see the
    dirt that is genuinely there?' -- and the negative twin of every scene
    prices the false-alarm side at the same pose error.
    """
    root = os.path.join(DATA, "real_pairs")
    if not os.path.isdir(os.path.join(root, "before")):
        return None
    scenes = sorted(
        os.path.splitext(f)[0] for f in os.listdir(os.path.join(root, "before"))
        if os.path.exists(os.path.join(root, "after", f))
        and os.path.exists(os.path.join(root, "neg", f)))
    if not scenes:
        return None

    pos_cells, neg_cells = [], []          # cell-level change values
    pos_peak, neg_peak = [], []            # scene-level peak change
    per_floor = {}
    for scene in scenes:
        dirty = cv2.imread(os.path.join(root, "before", scene + ".jpg"))
        clean = cv2.imread(os.path.join(root, "after", scene + ".jpg"))
        neg = cv2.imread(os.path.join(root, "neg", scene + ".jpg"))
        if dirty is None or clean is None or neg is None:
            continue
        if dirty.shape != clean.shape:
            dirty = cv2.resize(dirty, (clean.shape[1], clean.shape[0]))
        if neg.shape != clean.shape:
            neg = cv2.resize(neg, (clean.shape[1], clean.shape[0]))
        gd, gc, gn = frame_gain(dirty), frame_gain(clean), frame_gain(neg)
        if min(gd, gc, gn) <= 0:
            continue
        dcells, ccells, ncells = cells_of(dirty), cells_of(clean), cells_of(neg)
        pos = np.array([change(describe(cp, gc), describe(dp, gd))
                        for (_, _, dp), (_, _, cp) in zip(dcells, ccells)])
        ctl = np.array([change(describe(cp, gc), describe(npc, gn))
                        for (_, _, npc), (_, _, cp) in zip(ncells, ccells)])
        pos_cells.append(pos); neg_cells.append(ctl)
        pos_peak.append(float(pos.max())); neg_peak.append(float(ctl.max()))
        fl = scene.split("__")[0]
        per_floor.setdefault(fl, [[], []])
        per_floor[fl][0].append(float(pos.max()))
        per_floor[fl][1].append(float(ctl.max()))

    if not pos_peak:
        return None
    pos_peak, neg_peak = np.array(pos_peak), np.array(neg_peak)
    # scene-level: threshold = highest control peak that keeps 5% FPR
    scene_roc = roc_metrics(np.concatenate([pos_peak, neg_peak]),
                            np.concatenate([np.ones(len(pos_peak), bool),
                                            np.zeros(len(neg_peak), bool)]))
    # cell-level distributions for context
    pc, nc = np.concatenate(pos_cells), np.concatenate(neg_cells)
    return {
        "n_scenes": len(pos_peak),
        "scene_level": scene_roc,
        "cell_noise_p99": float(np.quantile(nc, 0.99)),
        "cell_dirty_peak_median": float(np.median(pos_peak)),
        "separation": float(np.median(pos_peak)
                            / max(np.quantile(nc, 0.99), 1e-6)),
        "per_floor": {
            f: {"n": len(p), "median_peak": float(np.median(p)),
                "median_ctl_peak": float(np.median(c))}
            for f, (p, c) in sorted(per_floor.items())},
    }


# ------------------------------------------------- examples for report ------

def save_synth_examples(n=4):
    det = DirtDetector("spatial")
    root = os.path.join(DATA, "synthetic")
    picks = ["tile__stain__00", "wood__smear__00", "checker__spill__00",
             "glossy__crumbs__00"]
    for scene in picks[:n]:
        img = cv2.imread(os.path.join(root, "before", scene + ".jpg"))
        if img is None:
            continue
        sig, cs = spatial_scores(img, det)
        if sig is None:
            continue
        vis = img.copy()
        for (x, y, _), s in zip(cs, sig):
            if s >= 8.0:
                a = min(s / 16.0, 1.0)
                cv2.rectangle(vis, (x, y), (x + GRID, y + GRID),
                              (0, int(80 * (1 - a)), int(120 + 135 * a)), 2)
        cv2.imwrite(os.path.join(EXAMPLES, f"synth_{scene}.jpg"), vis)


def main():
    os.makedirs(EXAMPLES, exist_ok=True)
    print("PART 1: differential before/after (synthetic, 105 scenes)...")
    p1 = bench_differential()
    print(json.dumps(p1["overall"], indent=2))

    print("\nPART 2a: spatial backend (synthetic)...")
    p2a = bench_spatial_synthetic()
    print(json.dumps(p2a["overall"], indent=2))

    print("\nPART 2b: spatial backend (REAL ScatSpotter, 25 photos)...")
    p2b = bench_spatial_real()
    print(json.dumps(p2b, indent=2))

    print("\nPART 3: verdict logic (NoiseFloor + verify_change)...")
    p3 = bench_verdicts()
    print(json.dumps(p3, indent=2))

    print("\nPART 4: REAL indoor floors (airport/mall/home/office + composited dirt)...")
    p4 = bench_indoor()
    if p4 is not None:
        print(json.dumps({"differential": p4["differential"]["overall"],
                          "spatial": p4["spatial"]["overall"],
                          "verdicts": {k: p4["verdicts"][k] for k in
                                       ("dirty_detection_rate", "false_changed_rate")}},
                         indent=2))
    else:
        print("  (no indoor set -- run download_indoor.py + make_indoor_benchmark.py)")

    print("\nPART 5: YOUR captured real pairs (phone protocol)...")
    p5 = bench_real_pairs()
    if p5 is not None:
        print(json.dumps(p5, indent=2))
    else:
        print("  (none yet -- open /capture on your phone and shoot some)")

    save_synth_examples()

    results = {"real_pairs": p5,
               "differential_synthetic": p1,
               "spatial_synthetic": p2a,
               "spatial_real_scatspotter": p2b,
               "verdict_logic": p3,
               "indoor_real_floors": p4,
               "config": {"grid": GRID, "cell_px": CELL_PX,
                          "mask_frac": MASK_FRAC, "fpr_operating_point": 0.05}}
    with open(os.path.join(RESULTS, "benchmark.json"), "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nwrote {os.path.abspath(os.path.join(RESULTS, 'benchmark.json'))}")


if __name__ == "__main__":
    main()
