"""Pull clean-floor datasets from Roboflow Universe.

    set ROBOFLOW_API_KEY=xxxxxxxx
    python scripts/download_roboflow.py                          # default sets
    python scripts/download_roboflow.py ws/proj[/version] ...    # extra sets

Known-good defaults (found via Universe search, July 2026):
  compvision-bfglv/clean-unclean-floor      1194 imgs; litter boxes (trash/
                                            metal/plastic/paper) on floors --
                                            images with NO boxes are clean
  clean-or-dirty-floor/clean-or-dirty-floor-0bv1f
                                            317 imgs; "Clean floor" vs
                                            "Dirty floor" boxes

What the download becomes:
  data/roboflow/<slug>/{clean,dirty}/*.jpg   showcase (Datasets tab, testable)
  data/roboflow/manifest.json                licence/source/counts
  data/indoor_floors/raw/roboflow__rNN.jpg   CLEAN images join the compositing
                                             background pool

Whole-image / box classification is the WRONG SHAPE to benchmark a
differential detector. Clean halves = real floor textures = backgrounds.
"""

from __future__ import annotations

import io
import json
import os
import sys
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
RROOT = os.path.join(DATA, "roboflow")
RAW_BG = os.path.join(DATA, "indoor_floors", "raw")

DEFAULT_SETS = [
    "compvision-bfglv/clean-unclean-floor",
    "clean-or-dirty-floor/clean-or-dirty-floor-0bv1f",
]
DIRTY_WORDS = ("dirty", "unclean", "trash", "metal", "plastic", "paper",
               "stain", "dirt", "litter", "waste")


def api_json(url):
    return json.loads(urllib.request.urlopen(url, timeout=120).read())


def pull(spec, key):
    parts = spec.split("/")
    ws, proj = parts[0], parts[1]
    if len(parts) >= 3:
        ver = parts[2]
    else:
        meta = api_json(f"https://api.roboflow.com/{ws}/{proj}?api_key={key}")
        versions = meta.get("versions", [])
        if not versions:
            raise RuntimeError("no versions published")
        ver = versions[0]["id"].split("/")[-1]

    print(f"{ws}/{proj}/{ver}: requesting coco export...")
    link = None
    for attempt in range(20):                 # export is generated on demand
        meta = api_json(f"https://api.roboflow.com/{ws}/{proj}/{ver}/coco?api_key={key}")
        link = meta.get("export", {}).get("link")
        if link:
            break
        import time
        print(f"  export generating (progress={meta.get('progress')}), waiting...")
        time.sleep(6)
    if not link:
        raise RuntimeError(f"export never became ready: {json.dumps(meta)[:200]}")
    print("  downloading zip...")
    buf = urllib.request.urlopen(link, timeout=900).read()
    z = zipfile.ZipFile(io.BytesIO(buf))

    # union of all split annotation files -> which images carry dirty boxes
    dirty_files, all_files = set(), {}
    for n in z.namelist():
        if n.endswith("_annotations.coco.json"):
            d = json.loads(z.read(n))
            cats = {c["id"]: c["name"].lower() for c in d.get("categories", [])}
            dirty_ids = set()
            for a in d.get("annotations", []):
                if any(w in cats.get(a.get("category_id"), "") for w in DIRTY_WORDS):
                    dirty_ids.add(a["image_id"])
            prefix = os.path.dirname(n)
            for i in d.get("images", []):
                path = f"{prefix}/{i['file_name']}" if prefix else i["file_name"]
                all_files[path] = i["id"] in dirty_ids

    slug = f"{ws}__{proj}".replace("/", "__")
    counts = {"clean": 0, "dirty": 0}
    for path, is_dirty in all_files.items():
        if path not in z.namelist():
            continue
        cls = "dirty" if is_dirty else "clean"
        dst_dir = os.path.join(RROOT, slug, cls)
        os.makedirs(dst_dir, exist_ok=True)
        stem, ext = os.path.splitext(os.path.basename(path))
        base = f"{counts[cls]:04d}_{stem[:36]}{ext or '.jpg'}"
        with open(os.path.join(dst_dir, base), "wb") as f:
            f.write(z.read(path))
        counts[cls] += 1
    print(f"  {counts}")
    return {"slug": spec, "dir": slug, "counts": counts,
            "source": f"https://universe.roboflow.com/{ws}/{proj}",
            "licence": "see Universe project page",
            "role": "showcase + clean-class backgrounds"}


def export_clean_backgrounds():
    os.makedirs(RAW_BG, exist_ok=True)
    n0 = len([f for f in os.listdir(RAW_BG) if f.startswith("roboflow__r")])
    n = n0
    for slug in sorted(os.listdir(RROOT)):
        cdir = os.path.join(RROOT, slug, "clean")
        if not os.path.isdir(cdir):
            continue
        for f in sorted(os.listdir(cdir)):
            if f.lower().endswith((".jpg", ".jpeg", ".png")):
                dst = os.path.join(RAW_BG, f"roboflow__r{n:03d}.jpg")
                if not os.path.exists(dst):
                    import shutil
                    shutil.copy2(os.path.join(cdir, f), dst)
                    n += 1
    print(f"backgrounds: {n - n0} new clean floors -> indoor_floors/raw")


def main():
    key = os.environ.get("ROBOFLOW_API_KEY")
    if not key:
        print(__doc__)
        print("ROBOFLOW_API_KEY is not set -- nothing downloaded.")
        return 1
    specs = [a for a in sys.argv[1:] if "/" in a] or DEFAULT_SETS
    os.makedirs(RROOT, exist_ok=True)
    mpath = os.path.join(RROOT, "manifest.json")
    manifest = json.load(open(mpath)) if os.path.exists(mpath) else {}
    for spec in specs:
        try:
            manifest[spec] = pull(spec, key)
        except Exception as e:
            print(f"  FAILED {spec}: {type(e).__name__}: {e}")
    with open(mpath, "w") as f:
        json.dump(manifest, f, indent=2)
    export_clean_backgrounds()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
