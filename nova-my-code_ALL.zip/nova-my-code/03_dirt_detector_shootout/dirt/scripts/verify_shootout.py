"""Automated verification of the shootout — mechanical checks, not eyeballing.

Every claim the shootout makes must survive an automated check:
  1. GATE        histogram_diff reproduces benchmark.json (harness wiring correct)
  2. DETERMINISM each scorer gives identical output on a re-run (seeded)
  3. SIGN        each scorer scores dirty cells higher than clean, on average
  4. NO-LABELS   Scene carries no labels; scorers cannot see ground truth
  5. LEAKAGE     leave-one-scene-out re-fit of the train-on-clean methods on
                 synthetic, to quantify how much the same-domain clean pool
                 (after/ frames) inflates padim/gmm vs the honest indoor raw/ pool

Run:  python3 scripts/verify_shootout.py [--methods a,b,...]
Exit code 0 iff GATE + DETERMINISM + SIGN + NO-LABELS all pass.
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import fields

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import scorers  # noqa: F401
from scorers.base import REGISTRY, Scene
import shootout_harness as H
import benchmark as B


def _synth_scenes():
    return H.build_scene_set("synthetic")


def check_no_labels() -> bool:
    """Structural: the Scene handed to scorers must not contain labels/masks."""
    fnames = {f.name for f in fields(Scene)}
    banned = {"labels", "label", "mask", "masks", "gt", "y"}
    leaked = fnames & banned
    ok = not leaked
    print(f"[NO-LABELS] Scene fields={sorted(fnames)} -> {'OK' if ok else f'LEAK {leaked}'}")
    return ok


def check_gate() -> bool:
    import json
    from scorers.base import RESULTS
    ref = json.load(open(os.path.join(RESULTS, "benchmark.json")))
    target = ref["differential_synthetic"]["per_floor"]
    scenes = _synth_scenes()
    out = H.evaluate(REGISTRY["histogram_diff"](), scenes)["per_floor"]
    ok = True
    for f in target:
        dr = abs(target[f]["recall_at_fpr"] - out[f]["recall_at_fpr"])
        da = abs(target[f]["auroc"] - out[f]["auroc"])
        ok &= (dr < 1e-6 and da < 1e-6)
    print(f"[GATE] histogram_diff vs benchmark.json -> {'OK' if ok else 'MISMATCH'}")
    return ok


def check_determinism(name, scenes) -> bool:
    s1 = REGISTRY[name](); s1.fit(H.build_clean_pool("synthetic"))
    a = np.concatenate([np.asarray(s1.score(ls.scene)) for ls in scenes[:8]])
    s2 = REGISTRY[name](); s2.fit(H.build_clean_pool("synthetic"))
    b = np.concatenate([np.asarray(s2.score(ls.scene)) for ls in scenes[:8]])
    ok = np.allclose(a, b, atol=1e-9, equal_nan=True)
    print(f"[DETERMINISM] {name:14s} -> {'OK' if ok else 'NON-DETERMINISTIC'}")
    return ok


def check_sign(name, scenes, pool) -> bool:
    """dirty cells should score higher than clean, averaged over scenes."""
    s = REGISTRY[name](); s.fit(pool)
    wins, total, dmean, cmean = 0, 0, [], []
    for ls in scenes:
        sc = np.asarray(s.score(ls.scene), float)
        m = ls.scene.eval_mask
        lab = ls.labels[m]
        sc = sc[m]
        if lab.sum() == 0 or (~lab).sum() == 0:
            continue
        total += 1
        d, c = sc[lab].mean(), sc[~lab].mean()
        dmean.append(d); cmean.append(c)
        wins += int(d > c)
    frac = wins / max(total, 1)
    ok = frac >= 0.6            # majority of scenes score dirty higher
    print(f"[SIGN] {name:14s} dirty>clean in {wins}/{total} scenes "
          f"({frac:.0%})  meanDirt={np.mean(dmean):.4g} meanClean={np.mean(cmean):.4g} "
          f"-> {'OK' if ok else 'WRONG-SIGN/WEAK'}")
    return ok


def _load_named_scene(dataset, name):
    """Rebuild one Scene+labels by scene name (train-on-clean leakage probe)."""
    import cv2
    from nova_perception.verification import frame_gain
    root = os.path.join(H.DATA, dataset if dataset != "indoor" else "indoor_floors")
    dirty = cv2.imread(os.path.join(root, "before", name + ".jpg"))
    clean = cv2.imread(os.path.join(root, "after", name + ".jpg"))
    mask = cv2.imread(os.path.join(root, "masks", name + ".png"), cv2.IMREAD_GRAYSCALE)
    gd, gc = frame_gain(dirty), frame_gain(clean)
    dcells, ccells = B.cells_of(dirty), B.cells_of(clean)
    labs = B.cell_labels(mask, len(dcells))
    sc = Scene(name.split("__")[0], dirty, clean, dcells, ccells, gd, gc,
               np.ones(len(dcells), bool))
    return sc, labs


def check_leakage(name) -> None:
    """Same-scene leakage bound for a train-on-clean method on synthetic.

    Full pool = ALL after/<floor>__* cells, which INCLUDES each scored scene's own
    clean reference frame. For one held-out scene per floor we re-fit that floor's
    model with the held-out scene's own after-cells REMOVED, then score it both
    ways. A large recall gap => the synthetic number is inflated by scoring against
    a model that saw the very cell it is judging. (The honest cross-domain test is
    simply the indoor result, whose clean pool is the disjoint raw/ photos.)
    """
    from collections import defaultdict
    import cv2
    from scorers.base import CleanCell
    from nova_perception.verification import frame_gain

    adir = os.path.join(H.DATA, "synthetic", "after")
    by_floor = defaultdict(list)
    for f in sorted(os.listdir(adir)):
        by_floor[f.split("__")[0]].append(os.path.splitext(f)[0])

    full_pool = H.build_clean_pool("synthetic")
    held_r, full_r = [], []
    for floor, names in by_floor.items():
        held = names[0]                                   # one held-out scene / floor
        pool = defaultdict(list)
        for nm in names:
            if nm == held:
                continue                                  # drop its own clean frame
            img = cv2.imread(os.path.join(adir, nm + ".jpg"))
            g = frame_gain(img)
            if g <= 0:
                continue
            for (x, y, p) in B.cells_of(img):
                pool[floor].append(CleanCell(p, g))
        sc, labs = _load_named_scene("synthetic", held)
        s_held = REGISTRY[name](); s_held.fit(dict(pool))
        s_full = REGISTRY[name](); s_full.fit(full_pool)
        held_r.append(B.roc_metrics(np.asarray(s_held.score(sc)), labs)["recall_at_fpr"])
        full_r.append(B.roc_metrics(np.asarray(s_full.score(sc)), labs)["recall_at_fpr"])
    gap = np.nanmean(full_r) - np.nanmean(held_r)
    print(f"[LEAKAGE] {name:14s} held-out recall(mean)={np.nanmean(held_r):.3f} "
          f"vs full-pool={np.nanmean(full_r):.3f} (gap={gap:+.3f}; "
          f"large gap => synthetic number is same-domain-inflated)")


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--methods", default="all")
    a = ap.parse_args(argv)
    names = list(REGISTRY) if a.methods == "all" else a.methods.split(",")
    scenes = _synth_scenes()
    pool = H.build_clean_pool("synthetic")

    results = {"NO-LABELS": check_no_labels(), "GATE": check_gate()}
    det = all(check_determinism(n, scenes) for n in names if n != "vlm_smol")
    sign = all(check_sign(n, scenes, pool) for n in names if n != "vlm_smol")
    results["DETERMINISM"] = det
    results["SIGN"] = sign
    print("\n--- leakage probe (train-on-clean methods on synthetic) ---")
    for n in names:
        if REGISTRY[n].trains_on_clean:
            check_leakage(n)

    print("\n=== VERIFY SUMMARY ===")
    for k, v in results.items():
        print(f"  {k:12s} {'PASS' if v else 'FAIL'}")
    ok = all(results.values())
    print("OVERALL:", "PASS ✅" if ok else "FAIL ❌")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
