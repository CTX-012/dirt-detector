"""Download real CC-licensed indoor floor photos from Wikimedia Commons.

Target environments = the robot's deployment domain: homes, offices, and
commercial sites (airports, malls, supermarkets, hospitals). Saves full
attribution (author, licence, source URL) to credits.json -- CC compliance.

    python scripts/download_indoor.py
        -> data/indoor_floors/raw/<env>__<n>.jpg
        -> data/indoor_floors/credits.json
"""

from __future__ import annotations

import json
import os
import time
import urllib.parse
import urllib.request

ROOT = os.path.join(os.path.dirname(__file__), "..", "data", "indoor_floors")
RAW = os.path.join(ROOT, "raw")
API = "https://commons.wikimedia.org/w/api.php"
# Wikimedia UA policy (https://w.wiki/4wJS): descriptive agent + contact.
UA = ("NOVA-FloorBenchmark/1.0 "
      "(robotics research benchmark; kkhkfx6r2y@privaterelay.appleid.com) "
      "python-urllib/3.12")

# search terms per environment class -- phrased to find floor-dominant shots
QUERIES = {
    "airport": ['airport terminal interior', 'airport departure hall',
                'airport concourse', 'airport gate seating'],
    "mall": ['shopping mall interior', 'shopping centre interior',
             'shopping arcade interior', 'mall atrium'],
    "supermarket": ['supermarket interior aisle', 'supermarket interior',
                    'grocery store interior', 'hypermarket interior'],
    "home_wood": ['parquet floor', 'wooden floor room interior',
                  'hardwood floor apartment', 'living room wooden floor'],
    "home_tile": ['tiled floor interior', 'kitchen interior',
                  'bathroom tiled floor', 'hallway tiled floor'],
    "office": ['office corridor', 'hospital corridor',
               'office interior open plan', 'school corridor interior'],
}
# floor PLANS and diagrams are not floors
BAD_TITLE_WORDS = ("plan", "map", "diagram", "blueprint", "scheme", "layout",
                   "drawing", "logo")
PER_ENV = 6          # default; override with --per-env N (bulk mode)
MIN_W, MIN_H = 800, 600

OK_LICENCES = ("cc0", "cc by", "cc-by", "public domain", "pd")


def api(params):
    q = urllib.parse.urlencode({**params, "format": "json"})
    req = urllib.request.Request(f"{API}?{q}", headers={"User-Agent": UA})
    return json.loads(urllib.request.urlopen(req, timeout=60).read())


def search_images(term, limit=25, offset=0):
    """Commons file search with image info + licence metadata."""
    r = api({
        "action": "query",
        "generator": "search",
        "gsrsearch": f"filetype:bitmap {term}",
        "gsrnamespace": 6,                    # File:
        "gsrlimit": limit,
        "gsroffset": offset,
        "prop": "imageinfo",
        "iiprop": "url|size|extmetadata",
        "iiurlwidth": 1280,
    })
    return list(r.get("query", {}).get("pages", {}).values())


def licence_of(page):
    md = page["imageinfo"][0].get("extmetadata", {})
    lic = (md.get("LicenseShortName", {}).get("value") or "").lower()
    artist = md.get("Artist", {}).get("value") or "unknown"
    # strip html from artist
    import re
    artist = re.sub(r"<[^>]+>", "", artist).strip()
    return lic, artist


def main(per_env=PER_ENV):
    os.makedirs(RAW, exist_ok=True)
    # resume-friendly: keep existing files + credits, continue numbering
    cred_path = os.path.join(ROOT, "credits.json")
    credits = {}
    if os.path.exists(cred_path):
        credits = json.load(open(cred_path, encoding="utf-8"))
    n_total = 0
    for env, terms in QUERIES.items():
        existing = [f for f in os.listdir(RAW) if f.startswith(env + "__")]
        got = len(existing)
        if got >= per_env:
            print(f"{env}: {got} already present, skipping")
            continue
        seen = set()
        pages_iter = []
        for term in terms:
            for offset in (0, 25):
                pages_iter.append((term, offset))
        for term, offset in pages_iter:
            if got >= per_env:
                break
            try:
                pages = search_images(term, offset=offset)
            except Exception as e:
                print(f"  search failed for {term!r}: {e}")
                continue
            for p in pages:
                if got >= per_env:
                    break
                try:
                    title = (p.get("title") or "").lower()
                    if any(w in title for w in BAD_TITLE_WORDS):
                        continue
                    ii = p["imageinfo"][0]
                    if ii["width"] < MIN_W or ii["height"] < MIN_H:
                        continue
                    lic, artist = licence_of(p)
                    if not any(k in lic for k in OK_LICENCES):
                        continue
                    url = ii.get("thumburl") or ii["url"]
                    if url in seen:
                        continue
                    seen.add(url)
                    name = f"{env}__{got:02d}.jpg"
                    dst = os.path.join(RAW, name)
                    data = None
                    for attempt in range(3):
                        try:
                            req = urllib.request.Request(
                                url, headers={"User-Agent": UA})
                            data = urllib.request.urlopen(req, timeout=60).read()
                            break
                        except urllib.error.HTTPError as he:
                            if he.code == 429:
                                wait = 20 * (attempt + 1)
                                print(f"    429 rate-limited, waiting {wait}s...")
                                time.sleep(wait)
                            else:
                                raise
                    if data is None:
                        continue
                    if len(data) < 30_000:
                        continue
                    with open(dst, "wb") as f:
                        f.write(data)
                    credits[name] = {
                        "title": p.get("title"),
                        "artist": artist,
                        "licence": lic,
                        "source": ii.get("descriptionurl"),
                    }
                    got += 1
                    n_total += 1
                    print(f"  {name}  [{lic}]  {p.get('title', '')[:60]}")
                    time.sleep(3.0)          # stay well under the rate limit
                except Exception as e:
                    print(f"    skip {p.get('title', '?')[:50]}: "
                          f"{type(e).__name__} {e}")
                    time.sleep(1.0)
                    continue
        print(f"{env}: {got} images")
    with open(os.path.join(ROOT, "credits.json"), "w", encoding="utf-8") as f:
        json.dump(credits, f, indent=2, ensure_ascii=False)
    print(f"\ntotal {n_total} images -> {os.path.abspath(RAW)}")
    print("attribution -> credits.json")


if __name__ == "__main__":
    import sys
    pe = PER_ENV
    if "--per-env" in sys.argv:
        pe = int(sys.argv[sys.argv.index("--per-env") + 1])
    main(per_env=pe)
