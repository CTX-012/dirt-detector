"""Download public Kaggle floor/room datasets (no account needed - kagglehub).

    pip install kagglehub
    python scripts/download_kaggle.py                     # default slug list
    python scripts/download_kaggle.py owner/dataset ...   # extra slugs

What each set is, honestly (see the project discussion): whole-image
clean-vs-messy CLASSIFICATION -- the wrong shape to benchmark a differential
detector. Their value here:

  - SHOWCASE: browsable samples in the web demo's Datasets tab, testable
    with one click against the spatial detector.
  - BACKGROUNDS: the CLEAN-class images are real interiors; they join
    data/indoor_floors/raw/ as compositing backgrounds (kaggle_room__rNN.jpg)
    so the composited benchmark gets more diverse real floors.

Outputs:
    data/kaggle/<slug>/<class>/*.jpg
    data/kaggle/manifest.json
    data/indoor_floors/raw/kaggle_room__rNN.jpg   (clean class only)
"""

from __future__ import annotations

import json
import os
import shutil
import sys

DEFAULT_SLUGS = [
    "cdawn1/messy-vs-clean-room",     # the famous one: 192 train + val/test
]

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
KROOT = os.path.join(DATA, "kaggle")
RAW_BG = os.path.join(DATA, "indoor_floors", "raw")

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp")
CLEAN_WORDS = ("clean",)
DIRTY_WORDS = ("messy", "dirty", "unclean")


def class_of(path_parts):
    """Infer clean/messy label from any directory component."""
    joined = "/".join(p.lower() for p in path_parts)
    if any(w in joined for w in DIRTY_WORDS):
        return "messy"
    if any(w in joined for w in CLEAN_WORDS):
        return "clean"
    return "unlabelled"


def pull(slug):
    import kagglehub
    print(f"downloading {slug} ...")
    src = kagglehub.dataset_download(slug)
    safe = slug.replace("/", "__")
    dst_root = os.path.join(KROOT, safe)
    counts = {}
    n = 0
    for root, _, files in os.walk(src):
        rel_parts = os.path.relpath(root, src).split(os.sep)
        cls = class_of(rel_parts)
        for f in files:
            if not f.lower().endswith(IMAGE_EXT):
                continue
            dst_dir = os.path.join(dst_root, cls)
            os.makedirs(dst_dir, exist_ok=True)
            dst = os.path.join(dst_dir, f"{n:04d}_{f}")
            shutil.copy2(os.path.join(root, f), dst)
            counts[cls] = counts.get(cls, 0) + 1
            n += 1
    print(f"  {n} images: {counts}")
    return {"slug": slug, "dir": safe, "counts": counts,
            "source": f"https://www.kaggle.com/datasets/{slug}",
            "licence": "see dataset page (Kaggle public dataset)",
            "role": "showcase + clean-class backgrounds"}


def export_clean_backgrounds():
    """Copy every clean-class image into the compositing background pool."""
    os.makedirs(RAW_BG, exist_ok=True)
    existing = len([f for f in os.listdir(RAW_BG)
                    if f.startswith("kaggle_room__r")])
    n = existing
    for slug_dir in sorted(os.listdir(KROOT)):
        cdir = os.path.join(KROOT, slug_dir, "clean")
        if not os.path.isdir(cdir):
            continue
        for f in sorted(os.listdir(cdir)):
            if not f.lower().endswith(IMAGE_EXT):
                continue
            dst = os.path.join(RAW_BG, f"kaggle_room__r{n:03d}.jpg")
            if not os.path.exists(dst):
                shutil.copy2(os.path.join(cdir, f), dst)
                n += 1
    print(f"backgrounds: {n - existing} new clean-room images -> indoor_floors/raw")
    return n - existing


def main():
    slugs = DEFAULT_SLUGS + [a for a in sys.argv[1:] if "/" in a]
    os.makedirs(KROOT, exist_ok=True)
    manifest = {}
    mpath = os.path.join(KROOT, "manifest.json")
    if os.path.exists(mpath):
        manifest = json.load(open(mpath, encoding="utf-8"))
    for slug in slugs:
        try:
            manifest[slug] = pull(slug)
        except Exception as e:
            print(f"  FAILED {slug}: {type(e).__name__}: {e}")
    with open(mpath, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)
    export_clean_backgrounds()
    print(f"manifest -> {os.path.abspath(mpath)}")


if __name__ == "__main__":
    main()
