"""NOVA demo web app -- upload an image / before-after pair / video, or use the
live webcam, and see the real perception stack's output in the browser.

    pip install flask opencv-python numpy
    python webapp/app.py
    -> http://127.0.0.1:5000

Everything runs the SAME modules the robot runs (nova_perception + loop_engine).
The server is local; nothing leaves the machine.
"""

from __future__ import annotations

import json
import os
import re
import socket
import sys
import threading
import time
import uuid

import cv2
import numpy as np
from flask import Flask, Response, jsonify, render_template, request

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "nova_desktop_pkg"))

from loop_engine import Config, LoopEngine                              # noqa: E402
from nova_perception.dirt_detector import DirtDetector                  # noqa: E402
from nova_perception.verification import (                              # noqa: E402
    NoiseFloor, change, describe, frame_gain, verify_change)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024
UPLOADS = os.path.join(HERE, "uploads")
os.makedirs(UPLOADS, exist_ok=True)

GRID = 64
CELL_PX = 32

# job registry for video / webcam streams
JOBS: dict[str, dict] = {}

# ------------------------------------------------------------- samples ------
# Demo images selectable in the UI. IDs map to files on disk; the client never
# sends a path, only an id from this registry.

DATA_DIR = os.path.join(HERE, "..", "data")
REAL_PAIRS = os.path.join(DATA_DIR, "real_pairs")
SAMPLE_SETS = {
    "real": REAL_PAIRS,
    "indoor": os.path.join(DATA_DIR, "indoor_floors"),
    "synth": os.path.join(DATA_DIR, "synthetic"),
}
DEMO_VIDEO = os.path.join(DATA_DIR, "results", "loop_demo.avi")


def _sample_scenes(kind, limit=None):
    """Scene names that have both a before and an after image."""
    root = SAMPLE_SETS.get(kind)
    if not root or not os.path.isdir(os.path.join(root, "before")):
        return []
    scenes = sorted(os.path.splitext(f)[0]
                    for f in os.listdir(os.path.join(root, "before"))
                    if f.lower().endswith(".jpg"))
    return scenes[:limit] if limit else scenes


def _sample_path(kind, scene, which):
    """Resolve a sample id to a file path, refusing anything not in the
    registry (no client-supplied paths ever touch the filesystem)."""
    if kind not in SAMPLE_SETS or which not in ("before", "after"):
        return None
    if scene not in _sample_scenes(kind):
        return None
    p = os.path.join(SAMPLE_SETS[kind], which, scene + ".jpg")
    return p if os.path.exists(p) else None


@app.route("/samples")
def samples():
    """Curated demo picks per tab, plus the full lists."""
    def entry(kind, scene):
        return {"kind": kind, "scene": scene,
                "label": scene.replace("__", " · "),
                "thumb": f"/sample/{kind}/{scene}/before?w=220"}
    # a spread of environments and dirt types, real floors first
    indoor_all = _sample_scenes("indoor")
    picks, seen_env = [], set()
    for sc in indoor_all:                     # one per environment, then extras
        env = sc.split("__")[0]
        if env not in seen_env:
            picks.append(sc); seen_env.add(env)
    extras = [sc for sc in indoor_all if sc not in picks]
    indoor = picks[:6] + extras[:6]
    synth = ["tile__stain__00", "wood__smear__00", "checker__spill__00",
             "glossy__crumbs__00", "terrazzo__dust__00", "dark_tile__stain__00"]
    synth = [sc for sc in synth if sc in _sample_scenes("synth")]
    # YOUR captured pairs come first -- real dirt beats composited dirt
    real = _sample_scenes("real", limit=12)
    return jsonify({
        "images": [entry("real", sc) for sc in real[:6]]
                  + [entry("indoor", sc) for sc in indoor]
                  + [entry("synth", sc) for sc in synth],
        "pairs": [entry("real", sc) for sc in real]
                 + [entry("indoor", sc) for sc in indoor[:8]]
                 + [entry("synth", sc) for sc in synth[:4]],
        "video": os.path.exists(DEMO_VIDEO),
    })


@app.route("/sample/<kind>/<scene>/<which>")
def sample_image(kind, scene, which):
    p = _sample_path(kind, scene, which)
    if p is None:
        return jsonify({"error": "unknown sample"}), 404
    img = cv2.imread(p)
    w = request.args.get("w", type=int)
    if w and w < img.shape[1]:
        s = w / img.shape[1]
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    ok, enc = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return Response(enc.tobytes(), mimetype="image/jpeg")


# single-image sources (no before/after structure): id = index into a sorted
# enumeration -- the client can only ever name a list position, never a path.
KAGGLE_ROOT = os.path.join(DATA_DIR, "kaggle")
ROBOFLOW_ROOT = os.path.join(DATA_DIR, "roboflow")
SCAT_ROOT = os.path.join(DATA_DIR, "scatspotter", "test_sample")


def _walk_class_tree(root):
    out = []
    if not os.path.isdir(root):
        return out
    for slug in sorted(os.listdir(root)):
        sd = os.path.join(root, slug)
        if not os.path.isdir(sd):
            continue
        for cls in sorted(os.listdir(sd)):
            cd = os.path.join(sd, cls)
            if not os.path.isdir(cd):
                continue
            for f in sorted(os.listdir(cd)):
                if f.lower().endswith((".jpg", ".jpeg", ".png")):
                    out.append((f"{cls} · {f[:24]}", os.path.join(cd, f)))
    return out


def _single_items(kind):
    """Sorted (label, abspath) list for a single-image source."""
    out = []
    if kind == "kaggle":
        out = _walk_class_tree(KAGGLE_ROOT)
    elif kind == "roboflow":
        out = _walk_class_tree(ROBOFLOW_ROOT)
    elif kind == "scat" and os.path.isdir(SCAT_ROOT):
        for f in sorted(os.listdir(SCAT_ROOT)):
            if f.lower().endswith(".jpg"):
                out.append((f"photo {os.path.splitext(f)[0]}",
                            os.path.join(SCAT_ROOT, f)))
    return out


def _single_path(kind, idx):
    items = _single_items(kind)
    try:
        i = int(idx)
    except (TypeError, ValueError):
        return None
    if 0 <= i < len(items):
        return items[i][1]
    return None


@app.route("/sample_single/<kind>/<idx>")
def sample_single(kind, idx):
    p = _single_path(kind, idx)
    if p is None:
        return jsonify({"error": "unknown sample"}), 404
    img = cv2.imread(p)
    if img is None:
        return jsonify({"error": "unreadable"}), 404
    w = request.args.get("w", type=int)
    if w and w < img.shape[1]:
        s = w / img.shape[1]
        img = cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    ok, enc = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 82])
    return Response(enc.tobytes(), mimetype="image/jpeg")


def _load_sample_or_upload(file_field, kind_field="sample_kind",
                           scene_field="sample_scene", which="before"):
    """An endpoint's input: either an uploaded file or a sample id."""
    f = request.files.get(file_field)
    if f:
        return _decode_upload(f)
    kind = request.form.get(kind_field)
    scene = request.form.get(scene_field)
    if not kind or scene is None:
        return None
    if kind in ("kaggle", "scat", "roboflow"):
        p = _single_path(kind, scene)
    else:
        p = _sample_path(kind, scene, which)
    if p:
        img = cv2.imread(p)
        if img is not None:
            return _fit_size(img)
    return None


# ------------------------------------------------------------- helpers ------

def _fit_size(img, max_side=1280, min_side=700):
    """Downscale huge frames; upscale tiny ones so the 64px cell grid still
    has enough cells to form a reference (small Kaggle images were 422-ing)."""
    m = max(img.shape[:2])
    if m > max_side:
        s = max_side / m
        return cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_AREA)
    if m < min_side:
        s = min_side / m
        return cv2.resize(img, None, fx=s, fy=s, interpolation=cv2.INTER_CUBIC)
    return img


def _decode_upload(file_storage, max_side=1280):
    buf = np.frombuffer(file_storage.read(), np.uint8)
    img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    if img is None:
        return None
    return _fit_size(img, max_side)


def _jpeg_b64(img, q=85):
    import base64
    ok, enc = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, q])
    return "data:image/jpeg;base64," + base64.b64encode(enc).decode()


def _cells(img):
    h, w = img.shape[:2]
    out = []
    for y in range(0, h - GRID + 1, GRID):
        for x in range(0, w - GRID + 1, GRID):
            p = cv2.resize(img[y:y + GRID, x:x + GRID], (CELL_PX, CELL_PX),
                           interpolation=cv2.INTER_AREA)
            out.append((x, y, p))
    return out


def spatial_sigmas(img):
    det = DirtDetector("spatial")
    gain = frame_gain(img)
    if gain <= 0:
        return None, None
    cs = _cells(img)
    if len(cs) < 20:
        return None, None
    descs = det.describe([c[2] for c in cs], [gain] * len(cs))
    ref = det.spatial_reference(descs)
    if ref is None:
        return None, None
    raw = np.array([det.score(ref, d) for d in descs])
    med = float(np.median(raw))
    mad = max(float(np.median(np.abs(raw - med))), 0.05 * max(med, 1e-3), 5e-3)
    return np.clip((raw - med) / mad, 0, 40), cs


def draw_boxes(img, cs, sig, thr):
    vis = img.copy()
    for (x, y, _), s in zip(cs, sig):
        if s >= thr:
            a = min(float(s) / (thr * 2), 1.0)
            cv2.rectangle(vis, (x, y), (x + GRID, y + GRID),
                          (0, int(80 * (1 - a)), int(120 + 135 * a)), 2)
    return vis


# --------------------------------------------------------------- routes -----

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/analyze/image", methods=["POST"])
def analyze_image():
    """Single image -> spatial detector. Upload OR sample_kind+sample_scene."""
    thr = float(request.form.get("threshold", 8.0))
    img = _load_sample_or_upload("image")
    if img is None:
        return jsonify({"error": "no image (upload one or pick a sample)"}), 400
    sig, cs = spatial_sigmas(img)
    if sig is None:
        return jsonify({"error": "not enough usable floor in frame "
                                 "(too dark, too small, or all glare)"}), 422
    flagged = int((sig >= thr).sum())
    vis = draw_boxes(img, cs, sig, thr)
    hist, edges = np.histogram(sig, bins=40, range=(0, 40))
    return jsonify({
        "annotated": _jpeg_b64(vis),
        "cells": len(cs),
        "flagged": flagged,
        "flagged_pct": round(100 * flagged / len(cs), 1),
        "peak_sigma": round(float(sig.max()), 2),
        "median_sigma": round(float(np.median(sig)), 2),
        "threshold": thr,
        "sigma_hist": {"counts": hist.tolist(),
                       "edges": [round(float(e), 1) for e in edges.tolist()]},
    })


@app.route("/analyze/pair", methods=["POST"])
def analyze_pair():
    """Before/after pair -> differential verification path.
    Uploads OR a sample id (which loads both sides of the pair)."""
    dirty = _load_sample_or_upload("before", which="before")
    clean = _load_sample_or_upload("after", which="after")
    if dirty is None or clean is None:
        return jsonify({"error": "need both images (or pick a sample pair)"}), 400
    if dirty.shape != clean.shape:
        dirty = cv2.resize(dirty, (clean.shape[1], clean.shape[0]))
    gd, gc = frame_gain(dirty), frame_gain(clean)
    if gd <= 0 or gc <= 0:
        return jsonify({"error": "unusable frames"}), 422

    dcells, ccells = _cells(dirty), _cells(clean)
    changes = np.array([change(describe(cp, gc), describe(dp, gd))
                        for (_, _, dp), (_, _, cp) in zip(dcells, ccells)])

    # noise floor from the quieter half of cells, verdicts on all
    floor = NoiseFloor(min_samples=20)
    for c in np.sort(changes)[: max(20, len(changes) // 2)]:
        floor.update(float(c))
    sigs = np.array([floor.sigmas(float(c)) for c in changes])

    k = 8.0
    verdicts = [verify_change(float(c), floor, piezo_fired=False, k_sigma=k).verdict
                for c in changes]
    changed = int(sum(v == "cleaned" for v in verdicts))

    vis = dirty.copy()
    for (x, y, _), s in zip(dcells, sigs):
        if s >= k:
            a = min(float(s) / (k * 2), 1.0)
            cv2.rectangle(vis, (x, y), (x + GRID, y + GRID),
                          (0, int(80 * (1 - a)), int(120 + 135 * a)), 2)
    return jsonify({
        "annotated": _jpeg_b64(vis),
        "cells": len(dcells),
        "changed_cells": changed,
        "changed_pct": round(100 * changed / len(dcells), 1),
        "peak_change": round(float(changes.max()), 4),
        "noise_floor": round(float(np.median(changes)), 4),
        "peak_sigma": round(float(sigs.max()), 1),
    })


def _run_video_job(job_id, path):
    """Feed a video through the real LoopEngine; store frames + telemetry."""
    job = JOBS[job_id]
    cap = cv2.VideoCapture(path)
    cfg = Config()
    cfg.scrub_seconds = 6.0
    engine = LoopEngine(cfg)
    n = 0
    try:
        while cap.isOpened() and not job["stop"]:
            ok, frame = cap.read()
            if not ok:
                break
            s = 960 / max(frame.shape[:2])
            if s < 1:
                frame = cv2.resize(frame, None, fx=s, fy=s,
                                   interpolation=cv2.INTER_AREA)
            annotated, tel = engine.step(frame, dt=0.05)
            ok2, enc = cv2.imencode(".jpg", annotated,
                                    [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ok2:
                job["frame"] = enc.tobytes()
            job["tel"] = {k: (round(v, 2) if isinstance(v, float) else v)
                          for k, v in tel.items()}
            job["states"].setdefault(tel.get("state", "?"), 0)
            job["states"][tel.get("state", "?")] += 1
            n += 1
            time.sleep(0.01)
    finally:
        cap.release()
        job["done"] = True
        job["tel"] = dict(job.get("tel") or {},
                          report=engine.loop.report(), frames=n)


@app.route("/analyze/video", methods=["POST"])
def analyze_video():
    f = request.files.get("video")
    job_id = uuid.uuid4().hex[:12]
    if f:
        path = os.path.join(UPLOADS, job_id + os.path.splitext(f.filename)[1])
        f.save(path)
    elif request.form.get("sample") == "demo" and os.path.exists(DEMO_VIDEO):
        path = DEMO_VIDEO
    else:
        return jsonify({"error": "no video (upload one or use the demo)"}), 400
    JOBS[job_id] = {"frame": None, "tel": {}, "states": {},
                    "done": False, "stop": False, "path": path}
    threading.Thread(target=_run_video_job, args=(job_id, path),
                     daemon=True).start()
    return jsonify({"job": job_id})


def _run_webcam_job(job_id, cam_index=0):
    job = JOBS[job_id]
    cap = cv2.VideoCapture(cam_index)
    if not cap.isOpened():
        job["error"] = f"could not open camera {cam_index}"
        job["done"] = True
        return
    cfg = Config()
    engine = LoopEngine(cfg)
    last = time.time()
    try:
        while not job["stop"]:
            ok, frame = cap.read()
            if not ok:
                break
            now = time.time()
            dt = min(now - last, 0.1)
            last = now
            engine.piezo = job.get("piezo", False)
            annotated, tel = engine.step(frame, dt)
            ok2, enc = cv2.imencode(".jpg", annotated,
                                    [cv2.IMWRITE_JPEG_QUALITY, 80])
            if ok2:
                job["frame"] = enc.tobytes()
            job["tel"] = {k: (round(v, 2) if isinstance(v, float) else v)
                          for k, v in tel.items()}
    finally:
        cap.release()
        job["done"] = True


@app.route("/webcam/start", methods=["POST"])
def webcam_start():
    # stop any prior webcam job
    for j in JOBS.values():
        if j.get("kind") == "webcam":
            j["stop"] = True
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"frame": None, "tel": {}, "states": {}, "done": False,
                    "stop": False, "kind": "webcam", "piezo": False}
    threading.Thread(target=_run_webcam_job, args=(job_id,), daemon=True).start()
    return jsonify({"job": job_id})


@app.route("/job/<job_id>/piezo", methods=["POST"])
def job_piezo(job_id):
    j = JOBS.get(job_id)
    if j:
        j["piezo"] = bool(request.json.get("on"))
    return jsonify({"ok": True})


@app.route("/job/<job_id>/stop", methods=["POST"])
def job_stop(job_id):
    j = JOBS.get(job_id)
    if j:
        j["stop"] = True
    return jsonify({"ok": True})


@app.route("/stream/<job_id>")
def stream(job_id):
    def gen():
        while True:
            j = JOBS.get(job_id)
            if j is None:
                break
            fr = j.get("frame")
            if fr:
                yield (b"--frame\r\nContent-Type: image/jpeg\r\n\r\n"
                       + fr + b"\r\n")
            if j.get("done") and not fr:
                break
            time.sleep(0.04)
    return Response(gen(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/job/<job_id>/telemetry")
def telemetry(job_id):
    j = JOBS.get(job_id)
    if j is None:
        return jsonify({"error": "no such job"}), 404
    return jsonify({"tel": j.get("tel", {}), "states": j.get("states", {}),
                    "done": j.get("done", False), "error": j.get("error")})


@app.route("/datasets")
def datasets():
    """Every data source on disk: what it is, licence, counts, samples."""
    cards = []

    real = _sample_scenes("real")
    if real:                       # only shown once pairs actually exist
        cards.append({
            "id": "captured", "name": "Your captured pairs",
            "licence": "yours", "count": len(real), "test_tab": "pair",
            "desc": ("Real dirt, same floor, before/after + a clean-clean "
                     "control shot. The only fully-real benchmark. Shoot more "
                     "at /capture on your phone."),
            "role": "BENCHMARK (the one that counts)",
            "samples": [{"kind": "real", "scene": sc,
                         "label": sc.split("__")[0] + " · " + sc.split("__")[1],
                         "thumb": f"/sample/real/{sc}/before?w=220"}
                        for sc in real[:8]],
        })

    indoor = _sample_scenes("indoor")
    n_raw = len([f for f in os.listdir(os.path.join(DATA_DIR, "indoor_floors", "raw"))
                 if f.endswith(".jpg")]) if os.path.isdir(
                     os.path.join(DATA_DIR, "indoor_floors", "raw")) else 0
    n_kbg = len([f for f in os.listdir(os.path.join(DATA_DIR, "indoor_floors", "raw"))
                 if f.startswith("kaggle_room")]) if os.path.isdir(
                     os.path.join(DATA_DIR, "indoor_floors", "raw")) else 0
    cards.append({
        "id": "wikimedia", "name": "Real interiors — composited benchmark",
        "licence": "CC / public domain (credits.json + Kaggle)",
        "count": len(indoor), "test_tab": "pair",
        "desc": (f"{n_raw - n_kbg} Wikimedia photos (airports, malls, "
                 f"supermarkets, homes, offices) + {n_kbg} Kaggle clean rooms "
                 f"as backgrounds; controlled dirt composited into the floor "
                 f"band with exact masks -> {len(indoor)} scenes. The headline "
                 "composited benchmark."),
        "role": "BENCHMARK (composited dirt, real floors)",
        "samples": [{"kind": "indoor", "scene": sc,
                     "label": sc.replace("__", " · "),
                     "thumb": f"/sample/indoor/{sc}/before?w=220"}
                    for sc in indoor[::max(1, len(indoor) // 8)][:8]],
    })

    synth = _sample_scenes("synth")
    cards.append({
        "id": "synthetic", "name": "Synthetic floors",
        "licence": "generated", "count": len(synth), "test_tab": "pair",
        "desc": ("7 procedural floor types x 5 dirt types with exact ground "
                 "truth. Controlled ablation: isolates what breaks the "
                 "detector (pattern, gloss, misregistration)."),
        "role": "ABLATION",
        "samples": [{"kind": "synth", "scene": sc,
                     "label": sc.replace("__", " · "),
                     "thumb": f"/sample/synth/{sc}/before?w=220"}
                    for sc in synth[::max(1, len(synth) // 8)][:8]],
    })

    kg = _single_items("kaggle")
    km = {}
    km_path = os.path.join(KAGGLE_ROOT, "manifest.json")
    if os.path.exists(km_path):
        km = json.load(open(km_path, encoding="utf-8"))
    kg_desc = ", ".join(f'{v["slug"]} ({sum(v["counts"].values())} imgs)'
                        for v in km.values()) or "none downloaded yet"
    # spread thumbs across classes (clean block first, then messy)
    step = max(1, len(kg) // 8)
    cards.append({
        "id": "kaggle", "name": "Kaggle: messy vs clean room",
        "licence": "Kaggle public dataset", "count": len(kg),
        "test_tab": "image",
        "desc": (f"{kg_desc}. Whole-image classification — the WRONG SHAPE to "
                 "benchmark a differential detector (no pairs, no masks). "
                 "Used as: showcase + clean-class images join the "
                 "compositing background pool."),
        "role": "BACKGROUNDS + SHOWCASE, not a benchmark",
        "samples": [{"kind": "kaggle", "scene": str(i), "label": kg[i][0],
                     "thumb": f"/sample_single/kaggle/{i}?w=220"}
                    for i in range(0, len(kg), step)][:8],
    })

    sc_items = _single_items("scat")
    cards.append({
        "id": "scatspotter", "name": "ScatSpotter (subsample)",
        "licence": "CC-BY 4.0 (Kitware)", "count": len(sc_items),
        "test_tab": "image",
        "desc": ("25 real annotated outdoor photos from the 9,000-image "
                 "before/after dataset. Out of domain for an indoor cleaning "
                 "robot (scored chance level) — kept because it is the only "
                 "public dataset with the RIGHT SHAPE: same-view "
                 "before/after/negative."),
        "role": "REFERENCE (right shape, wrong domain)",
        "samples": [{"kind": "scat", "scene": str(i), "label": sc_items[i][0],
                     "thumb": f"/sample_single/scat/{i}?w=220"}
                    for i in range(0, min(len(sc_items), 8))],
    })

    rf = _single_items("roboflow")
    if rf:
        # spread across the class blocks (clean first, then dirty)
        step = max(1, len(rf) // 8)
        cards.append({
            "id": "roboflow", "name": "Roboflow: floor datasets",
            "licence": "Universe (see project pages)", "count": len(rf),
            "test_tab": "image",
            "desc": ("compvision-bfglv/clean-unclean-floor (2,030 imgs — "
                     "litter on floors: trash/metal/plastic/paper boxes; every "
                     "image has litter, so showcase/test only) + "
                     "clean-or-dirty-floor (317 imgs — 144 clean floors joined "
                     "the compositing background pool). Try the dirty ones "
                     "against the detector."),
            "role": "BACKGROUNDS (clean) + TEST IMAGES (dirty)",
            "samples": [{"kind": "roboflow", "scene": str(i),
                         "label": rf[i][0],
                         "thumb": f"/sample_single/roboflow/{i}?w=220"}
                        for i in range(0, len(rf), step)][:8],
        })
    else:
        cards.append({
            "id": "roboflow", "name": "Roboflow Universe clean-floor sets",
            "licence": "varies per project", "count": 0, "test_tab": None,
            "desc": ("Ready to pull — needs a free API key. "
                     "set ROBOFLOW_API_KEY=... then: python scripts/"
                     "download_roboflow.py"),
            "role": "PENDING (needs your free API key)",
            "samples": [],
        })
    return jsonify({"cards": cards})


# ------------------------------------------------------------- capture ------
# Guided phone capture: CLEAN A (reference) -> CLEAN B (negative control,
# same pose) -> add real dirt -> DIRTY (same pose). The B shot is what makes
# the numbers honest: it measures the hand-held misregistration noise that a
# real robot would also have, and it is the FPR calibration for the benchmark.

CAPTURE_ROLES = {"clean_a": "after", "clean_b": "neg", "dirty": "before"}
_SCENE_RE = re.compile(r"^[a-z0-9_]{1,40}__[a-z0-9_]{1,40}__\d{8,14}$")


def _pairs_manifest_path():
    return os.path.join(REAL_PAIRS, "manifest.json")


def _load_manifest():
    p = _pairs_manifest_path()
    if os.path.exists(p):
        return json.load(open(p, encoding="utf-8"))
    return {}


def _save_manifest(m):
    os.makedirs(REAL_PAIRS, exist_ok=True)
    with open(_pairs_manifest_path(), "w", encoding="utf-8") as f:
        json.dump(m, f, indent=1)


@app.route("/capture")
def capture_page():
    return render_template("capture.html")


@app.route("/capture/upload", methods=["POST"])
def capture_upload():
    scene = request.form.get("scene", "")
    role = request.form.get("role", "")
    f = request.files.get("photo")
    if role not in CAPTURE_ROLES or not f:
        return jsonify({"error": "need role (clean_a/clean_b/dirty) + photo"}), 400
    if not _SCENE_RE.match(scene):
        return jsonify({"error": "bad scene id"}), 400
    img = _decode_upload(f, max_side=1600)
    if img is None:
        return jsonify({"error": "could not decode photo"}), 400
    sub = CAPTURE_ROLES[role]
    os.makedirs(os.path.join(REAL_PAIRS, sub), exist_ok=True)
    path = os.path.join(REAL_PAIRS, sub, scene + ".jpg")
    cv2.imwrite(path, img, [cv2.IMWRITE_JPEG_QUALITY, 92])

    m = _load_manifest()
    e = m.setdefault(scene, {"floor": scene.split("__")[0],
                             "dirt": scene.split("__")[1], "shots": []})
    if role not in e["shots"]:
        e["shots"].append(role)
    _save_manifest(m)
    return jsonify({"ok": True, "scene": scene, "have": e["shots"]})


@app.route("/capture/analyze", methods=["POST"])
def capture_analyze():
    """Instant feedback after the third shot: does the positive pair fire and
    the negative control stay quiet? GOOD PAIR / RESHOOT verdict."""
    scene = request.json.get("scene", "")
    if not _SCENE_RE.match(scene):
        return jsonify({"error": "bad scene id"}), 400
    paths = {sub: os.path.join(REAL_PAIRS, sub, scene + ".jpg")
             for sub in ("before", "after", "neg")}
    if not all(os.path.exists(p) for p in paths.values()):
        return jsonify({"error": "scene incomplete"}), 400
    dirty = cv2.imread(paths["before"])
    clean = cv2.imread(paths["after"])
    neg = cv2.imread(paths["neg"])
    if dirty is None or clean is None or neg is None:
        return jsonify({"error": "could not read a saved shot"}), 500
    gd, gc, gn = frame_gain(dirty), frame_gain(clean), frame_gain(neg)
    if min(gd, gc, gn) <= 0:
        return jsonify({"error": "a shot has no usable floor (too dark/blown)"}), 422
    if dirty.shape != clean.shape:
        dirty = cv2.resize(dirty, (clean.shape[1], clean.shape[0]))
    if neg.shape != clean.shape:
        neg = cv2.resize(neg, (clean.shape[1], clean.shape[0]))

    dcells, ccells, ncells = _cells(dirty), _cells(clean), _cells(neg)
    pos = np.array([change(describe(cp, gc), describe(dp, gd))
                    for (_, _, dp), (_, _, cp) in zip(dcells, ccells)])
    ctl = np.array([change(describe(cp, gc), describe(npch, gn))
                    for (_, _, npch), (_, _, cp) in zip(ncells, ccells)])

    # noise floor from the CONTROL pair -- the honest way
    floor = NoiseFloor(min_samples=20)
    for c in ctl:
        floor.update(float(c))
    sig = np.array([floor.sigmas(float(c)) for c in pos])
    ctl_sig = np.array([floor.sigmas(float(c)) for c in ctl])

    k = 8.0
    fired = int((sig >= k).sum())
    ctl_fired = int((ctl_sig >= k).sum())

    vis = dirty.copy()
    for (x, y, _), s in zip(dcells, sig):
        if s >= k:
            a = min(float(s) / (k * 2), 1.0)
            cv2.rectangle(vis, (x, y), (x + GRID, y + GRID),
                          (0, int(80 * (1 - a)), int(120 + 135 * a)), 2)

    good = fired >= 1 and ctl_fired <= max(1, len(ctl) // 50)
    if fired == 0:
        note = ("No cell fired. Either the dirt is at the noise floor for this "
                "surface (that is a real, reportable result) or the poses "
                "differ too much. Check the control number below.")
    elif not good:
        note = (f"Control pair fired {ctl_fired} cells -- the two CLEAN shots "
                "disagree. Pose or lighting moved between shots. Re-shoot "
                "with the phone braced.")
    else:
        note = "Good pair. Dirt fires, control is quiet. Keep going."

    m = _load_manifest()
    if scene in m:
        m[scene]["result"] = {"fired": fired, "ctl_fired": ctl_fired,
                              "good": bool(good)}
        _save_manifest(m)
    return jsonify({
        "annotated": _jpeg_b64(vis),
        "good": bool(good),
        "note": note,
        "cells": len(dcells),
        "fired": fired,
        "control_fired": ctl_fired,
        "peak_sigma": round(float(sig.max()), 1),
        "control_peak_sigma": round(float(ctl_sig.max()), 1),
    })


@app.route("/capture/stats")
def capture_stats():
    m = _load_manifest()
    done = [s for s, e in m.items() if len(e.get("shots", [])) == 3]
    good = [s for s in done if m[s].get("result", {}).get("good")]
    return jsonify({"scenes": len(m), "complete": len(done), "good": len(good)})


@app.route("/benchmark")
def benchmark_json():
    p = os.path.join(HERE, "..", "data", "results", "benchmark.json")
    if not os.path.exists(p):
        return jsonify({"error": "run scripts/benchmark.py first"}), 404
    return jsonify(json.load(open(p)))


def _lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except OSError:
        return "127.0.0.1"


if __name__ == "__main__":
    ip = _lan_ip()
    print("\n  NOVA demo     ->  http://127.0.0.1:5000")
    print(f"  phone capture ->  http://{ip}:5000/capture")
    print("  (phone must be on the same wifi; allow Python through the "
          "Windows firewall when prompted)\n")
    app.run(host="0.0.0.0", port=5000, debug=False, threaded=True)
