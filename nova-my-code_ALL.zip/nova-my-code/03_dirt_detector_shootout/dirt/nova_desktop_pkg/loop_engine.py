"""nova_desktop -- the clean loop on a laptop. No ROS, no robot. Windows/Mac/Linux.

    python nova_desktop.py            # live webcam
    python nova_desktop.py video.mp4  # a video file
    python nova_desktop.py photo.jpg  # a single image (or a folder of them)

WHAT THIS IS -- AND WHAT IT IS NOT
----------------------------------
This runs the EXACT loop that runs on the robot: clean_loop.CleanLoop, the real
dirt_detector, the real verification, the real controllers. Not a re-implementation.
The only thing swapped out is the plumbing -- a webcam instead of a ROS camera
topic, your screen instead of /cmd_vel. So every LOGIC bug you find here is a real
bug, and every threshold you tune here is a real threshold.

It is a LOGIC SIMULATOR, not a robot simulator. Be honest about the difference:

  IT TESTS          detect fires at the right sigma; scrub oscillates; give-up
                    triggers on budget and on asymptote; the report populates;
                    both controllers behave; the hazard clamp holds; the whole
                    SCAN -> CHECK -> SCRUB -> RESUME state machine.

  IT CANNOT TEST    the camera projection math (geometry.py needs real calibration
                    + TF), cross-camera registration, DDS timing, or the moving
                    before/after that the two-pass architecture depends on. One
                    laptop webcam is ONE view -- it is not a robot driving over a
                    cell and looking back at it.

So: use this to get the LOGIC right and the thresholds close, fast, on your desk.
Then prove it on a floor in Ignition. This does not replace that step -- it makes
that step start from a working loop instead of a broken one.

HOW THE SINGLE-CAMERA BEFORE/AFTER IS FAKED, AND WHY THAT IS OK
--------------------------------------------------------------
On the robot the rear camera sees a cell AFTER the front camera saw it. Here there
is one camera, so we take the BEFORE from an earlier frame of the SAME cell (a
short ring buffer) and the AFTER from now. It is a legitimate stand-in for testing
the LOGIC -- the loop cannot tell the difference -- but it is NOT the real
geometry, and the numbers here will not match the robot's. That is expected.
"""

from __future__ import annotations

import sys
from collections import deque
from dataclasses import dataclass

import cv2
import numpy as np

# the real loop core. no ROS. same code the robot runs.
from nova_perception.clean_loop import CleanLoop, State, Tuning
from nova_perception.controllers import Limits, make_controller
from nova_perception.dirt_detector import DirtDetector
from nova_perception.verification import NoiseFloor, frame_gain

CELL_PX = 32                 # cell size in image pixels for the desk demo
GRID = 48                    # source grid before resize


@dataclass
class Config:
    controller: str = "proportional"
    dirt_threshold: float = 8.0
    scrub_seconds: float = 20.0
    grid: int = GRID
    history: int = 30        # frames of ring buffer for the fake "before"


class LoopEngine:
    """Feed it a BGR frame, it runs one tick of the real loop and returns an
    annotated frame. This is the whole bridge between 'a picture' and 'the robot's
    brain'. Every input mode -- webcam, video, image -- calls step() and nothing
    else."""

    def __init__(self, cfg: Config):
        self.cfg = cfg
        self.detector = DirtDetector("spatial")      # stores nothing, patent-clear
        self.loop = CleanLoop(Tuning(
            dirt_threshold=cfg.dirt_threshold,
            scrub_seconds=cfg.scrub_seconds), clock=self._clock)
        self.ctrl = make_controller(cfg.controller, lim=Limits())
        self.floor = NoiseFloor(min_samples=30)
        self._t = 0.0
        # per-cell ring buffer: the "before" the single camera cannot otherwise have
        self.before: dict[tuple[int, int], deque] = {}
        self.piezo = False                            # spacebar = simulate debris heard

    def _clock(self):
        return self._t

    def _cells(self, frame):
        h, w = frame.shape[:2]
        g = self.cfg.grid
        out = []
        for y in range(0, h - g + 1, g):
            for x in range(0, w - g + 1, g):
                patch = cv2.resize(frame[y:y + g, x:x + g], (CELL_PX, CELL_PX),
                                   interpolation=cv2.INTER_AREA)
                out.append(((x // g, y // g), x, y, patch))
        return out

    def step(self, frame, dt=0.05):
        """One tick. Returns (annotated_frame, telemetry dict)."""
        self._t += dt
        gain = frame_gain(frame)
        cells = self._cells(frame)
        if gain <= 0 or len(cells) < 20:
            return frame, {"state": self.loop.state.value, "note": "no floor"}

        patches = [c[3] for c in cells]
        descs = self.detector.describe(patches, [gain] * len(patches))
        ref = self.detector.spatial_reference(descs)     # median cell = the floor
        if ref is None:
            return frame, {"state": self.loop.state.value, "note": "warming up"}

        # spatial score for every cell: how far is it from the floor's own median?
        scores = np.array([self.detector.score(ref, d) for d in descs])
        med = float(np.median(scores))
        raw_mad = float(np.median(np.abs(scores - med)))
        # floor the MAD at 5% of the median score, never below a small absolute --
        # on a very uniform floor raw_mad -> 0 and a single stain would otherwise
        # read hundreds of sigma and strobe the overlay.
        mad = max(raw_mad, 0.05 * max(med, 1e-3), 5e-3)
        sig = np.clip((scores - med) / mad, 0, 40)

        # feed the ring buffer + drive the loop
        worst = int(np.argmax(sig))
        worst_cell = cells[worst][0]

        # DETECT (only matters in SCAN)
        if self.loop.state is State.SCAN:
            cx, cy = cells[worst][1], cells[worst][2]
            self.loop.on_dirt_ahead(worst_cell, cx / 100.0, cy / 100.0, float(sig[worst]))

        # CHECK / SCRUB verification: compare the target cell now vs its own history
        if self.loop.spot is not None:
            tgt = self.loop.spot.cell
            for (cell, x, y, patch), d in zip(cells, descs):
                buf = self.before.setdefault(cell, deque(maxlen=self.cfg.history))
                if cell == tgt and len(buf) > 0:
                    change = self.detector.score(buf[0], d)      # oldest = "before"
                    s = self.floor.sigmas(change) if self.floor.ready else 0.0
                    self.loop.on_verified(cell, change, s, self.piezo)
                elif cell != tgt and not self.piezo:
                    # bootstrap the noise floor from quiet cells, same as the robot
                    if len(buf) > 0:
                        self.floor.update(self.detector.score(buf[0], d))
                buf.append(d)
        else:
            for (cell, x, y, patch), d in zip(cells, descs):
                self.before.setdefault(cell, deque(maxlen=self.cfg.history)).append(d)

        cmd = self.loop.step(dt)
        drive = self.ctrl.command(float(sig[worst]))

        annotated = self._draw(frame, cells, sig, cmd, drive)
        return annotated, {
            "state": self.loop.state.value,
            "peak_sigma": float(sig[worst]),
            "suction": drive.power,
            "speed": cmd.linear_x if cmd.pause_coverage else drive.speed,
            "scrubbing": self.loop.state is State.SCRUB,
            "cleaned": self.loop.cleaned,
            "unremovable": len(self.loop.unremovable),
        }

    def _draw(self, frame, cells, sig, cmd, drive):
        f = frame.copy()
        g = self.cfg.grid
        thr = self.cfg.dirt_threshold
        for (cell, x, y, patch), s in zip(cells, sig):
            if s >= thr:
                # a cell the detector thinks changed -> red box, brighter = dirtier
                a = min(s / (thr * 2), 1.0)
                cv2.rectangle(f, (x, y), (x + g, y + g),
                              (0, int(80 * (1 - a)), int(120 + 135 * a)), 2)

        st = self.loop.state
        color = {"scan": (200, 160, 60), "check": (60, 200, 200),
                 "scrub": (40, 120, 240), "resume": (100, 200, 120)}.get(st.value, (200, 200, 200))

        h, w = f.shape[:2]
        cv2.rectangle(f, (0, 0), (w, 34), (30, 30, 30), -1)
        cv2.putText(f, f"STATE: {st.value.upper()}", (10, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)
        cv2.putText(f, f"suction {drive.power:.0%}", (200, 24),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (220, 220, 220), 1)

        # the scrub oscillation, drawn as a moving marker so it is visible
        if st is State.SCRUB:
            phase = (self._t * 4) % 2
            off = int(40 * (phase - 1))
            cx = w // 2 + off
            cv2.arrowedLine(f, (w // 2, h - 40), (cx, h - 40), (40, 120, 240), 3, tipLength=0.3)
            cv2.putText(f, "SCRUB fro-and-back", (w // 2 - 90, h - 55),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (40, 120, 240), 2)

        cv2.putText(f, f"cleaned {self.loop.cleaned}  |  couldn't remove {len(self.loop.unremovable)}",
                    (10, h - 12), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (180, 180, 180), 1)
        return f
