"""nova_desktop -- run the clean loop on Windows with a webcam, a video, or an image.

    python nova_desktop.py                 live webcam (default: camera 0)
    python nova_desktop.py --cam 1         a different webcam
    python nova_desktop.py clip.mp4        a video file
    python nova_desktop.py floor.jpg       one image
    python nova_desktop.py ./photos/       a folder of images (arrow keys to step)

CONTROLS (in the window)
    SPACE   hold to simulate the piezo hearing debris (forces STILL_DIRTY -> SCRUB)
    c       switch controller: proportional <-> binary
    [ / ]   lower / raise the dirt threshold (sigma)
    r       reset the loop
    n / p   next / previous image (folder mode)
    q / ESC quit

Same loop the robot runs. See loop_engine.py for what this can and cannot test.
"""

from __future__ import annotations

import os
import sys
import time

import cv2

from loop_engine import Config, LoopEngine

WINDOW = "NOVA clean loop (desktop)"
IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp")
VIDEO_EXT = (".mp4", ".avi", ".mov", ".mkv", ".webm")


def _hud(engine, cfg):
    return (f"controller={cfg.controller}  threshold={cfg.dirt_threshold:.1f} sigma  "
            f"[SPACE]=piezo [c]=controller []=thresh [r]=reset [q]=quit")


def run_stream(source, cfg, is_camera):
    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        print(f"could not open {'camera' if is_camera else 'video'}: {source}")
        print("  on Windows, try --cam 1, or check no other app holds the camera.")
        return
    engine = LoopEngine(cfg)
    cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
    print(_hud(engine, cfg))
    last = time.time()
    while True:
        ok, frame = cap.read()
        if not ok:
            if is_camera:
                break
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)          # loop the video
            engine = LoopEngine(cfg)                     # and the loop state
            continue
        now = time.time()
        dt = min(now - last, 0.1)
        last = now

        annotated, tel = engine.step(frame, dt)
        cv2.putText(annotated, _hud(engine, cfg), (10, annotated.shape[0] - 32),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.42, (140, 140, 140), 1)
        cv2.imshow(WINDOW, annotated)

        k = cv2.waitKey(1) & 0xFF
        engine.piezo = (k == ord(" "))                   # hold space = debris heard
        if k in (ord("q"), 27):
            break
        elif k == ord("c"):
            cfg.controller = "binary" if cfg.controller == "proportional" else "proportional"
            engine = LoopEngine(cfg); print(f"controller -> {cfg.controller}")
        elif k == ord("["):
            cfg.dirt_threshold = max(2.0, cfg.dirt_threshold - 0.5); engine = LoopEngine(cfg)
        elif k == ord("]"):
            cfg.dirt_threshold = min(20.0, cfg.dirt_threshold + 0.5); engine = LoopEngine(cfg)
        elif k == ord("r"):
            engine = LoopEngine(cfg); print("loop reset")
    cap.release()
    cv2.destroyAllWindows()


def run_images(paths, cfg):
    """Folder / single image mode. Each image is fed repeatedly so the ring-buffer
    'before' fills and the loop can actually transition -- a single frame of a
    single image has no 'before', so we let it settle over a few ticks."""
    engine = LoopEngine(cfg)
    cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
    i = 0
    while True:
        img = cv2.imread(paths[i])
        if img is None:
            print(f"could not read {paths[i]}"); i = (i + 1) % len(paths); continue

        # settle: feed the image a few times so the before/after buffer populates
        for _ in range(engine.cfg.history + 5):
            annotated, tel = engine.step(img.copy(), 0.05)
            engine.piezo = False

        name = os.path.basename(paths[i])
        cv2.putText(annotated, f"[{i+1}/{len(paths)}] {name}   [n]ext [p]rev [SPACE]=piezo [q]uit",
                    (10, annotated.shape[0] - 32), cv2.FONT_HERSHEY_SIMPLEX, 0.42, (140, 140, 140), 1)
        cv2.imshow(WINDOW, annotated)

        k = cv2.waitKey(0) & 0xFF
        if k in (ord("q"), 27):
            break
        elif k in (ord("n"), 83, 32):
            i = (i + 1) % len(paths); engine = LoopEngine(cfg)
        elif k in (ord("p"), 81):
            i = (i - 1) % len(paths); engine = LoopEngine(cfg)
        elif k == ord("c"):
            cfg.controller = "binary" if cfg.controller == "proportional" else "proportional"
            engine = LoopEngine(cfg)
    cv2.destroyAllWindows()


def main(argv):
    cfg = Config()
    cam = 0
    if "--cam" in argv:
        cam = int(argv[argv.index("--cam") + 1])
        argv = [a for j, a in enumerate(argv)
                if j != argv.index("--cam") and j != argv.index("--cam") + 1]

    src = argv[1] if len(argv) > 1 and not argv[1].startswith("--") else None

    if src is None:
        print("mode: LIVE WEBCAM")
        run_stream(cam, cfg, is_camera=True)
    elif os.path.isdir(src):
        paths = sorted(os.path.join(src, f) for f in os.listdir(src)
                       if f.lower().endswith(IMAGE_EXT))
        if not paths:
            print(f"no images in {src}"); return
        print(f"mode: IMAGE FOLDER ({len(paths)} images)")
        run_images(paths, cfg)
    elif src.lower().endswith(IMAGE_EXT):
        print("mode: SINGLE IMAGE")
        run_images([src], cfg)
    elif src.lower().endswith(VIDEO_EXT):
        print("mode: VIDEO FILE")
        run_stream(src, cfg, is_camera=False)
    else:
        print(f"unrecognised input: {src}")
        print("  give a webcam (no arg), a video (.mp4/.mov/...), an image, or a folder.")


if __name__ == "__main__":
    main(sys.argv)
