"""Cleaning verification: did the pass actually change this floor cell?

THE JOB THIS MODULE DOES *NOT* DO
---------------------------------
It does not detect dirt. Deliberately.

Detecting dirt from a single image means answering "is this pixel dirt?" on a
floor you have never seen under lighting you have never seen. That question gets
you 90% recall at 45% false positives (Bormann et al., ICRA 2013): a dark tile,
a shadow, a grout line and a coffee stain all look like "a dark thing on a
floor". A detector that cries dirt on half its alarms cannot be allowed to
trigger a cleaning pass, which means it cannot drive anything, which means it is
decoration.

So we do not ask the camera that question. We ask it the one it is good at:

    "This exact floor cell. Before the pass, and after it. Did it CHANGE?"

Every confounder that breaks an absolute classifier -- floor colour, texture,
grout, gloss, ambient light -- is IDENTICAL in both observations and cancels.
The measurement is blind to what the floor looks like. It only sees what the
brush took away.

"Was there dirt at all" is answered by the PIEZO debris sensor, which hears
particles hit the bin. Different physics, uncorrelated errors, 25 years of
iRobot shipping it, and it costs about a hundred rupees. Let each sensor do the
thing it is actually good at.

    camera  -> did it change?     (verification)
    piezo   -> was there dirt?    (detection)
    both    -> closed-loop cleaning

TWO DESIGNS DIED TO GET HERE. Both are worth knowing about, because both are the
obvious thing to try.

  DEAD DESIGN 1 -- "dirt = local texture deviation", scored per patch, with an
  adaptive (robust MAD) threshold. FAILED: on a patterned floor the local
  variance is already high, so the adaptive threshold rises, so real stains stop
  clearing it. A single patch has no reference for "what does clean look like
  here", so per-patch normalisation cannot separate "textured" from "dirty".

  DEAD DESIGN 2 -- same score, but normalised against a live per-floor baseline
  instead of per-patch. FAILED HARDER, and in an instructive way: on a textured
  floor a stain COVERS the texture, so adding dirt makes the patch score go
  DOWN, not up. The sign of the signal is floor-dependent. Any scalar
  "dirtiness" is therefore unusable as a detector. Measured, not guessed:
  patterned rug scored 0.748 clean and 0.651 stained.

  What survived: compare the two patches DIRECTLY, direction-agnostically.

AND ONE MORE TRAP, THE BIG ONE
------------------------------
The obvious way to compare two patches is per-pixel. Do not.

To line up the same physical cell across two robot poses you would need the pose
to sub-pixel accuracy. A 5 cm cell at 96 px means 1 px = 0.5 mm. AMCL gives you
centimetres. Measured: a 2 px misregistration on a patterned floor produced a
change signal of 0.768 -- LARGER than a genuinely cleaned stain (0.417). The
noise beats the signal. Pose-based pixel registration cannot work, and image
alignment (phase correlation) aliases on periodic floors -- it locked onto the
wrong grout line and reported a 32 px shift when the truth was 5.

The fix is to stop needing registration at all. We compare SHIFT-INVARIANT
descriptors -- an illumination-normalised histogram. A histogram does not care
where the pixels are. We never needed sub-cell spatial detail anyway; the output
is one verdict per cell.

Measured after the fix: an 8 px misregistration moves the signal by 0.002, while
a real cleaned stain reads 0.165 to 0.230. Signal is 20-100x the noise floor.

KNOWN LIMITS, honestly:
  - Fine granular debris on a BUSY PATTERNED floor sits at the noise floor
    (crumbs on a rug measured 0.007). The rug's histogram swamps a few crumbs.
    This is the piezo's job, and the piezo does not care what the rug looks like.
  - Very dark floors have less headroom for illumination normalisation; a large
    lighting swing reads ~0.04. Keep the rear LED at a constant, known output --
    which we can, because we own it.
  - Specular glare on polished floors. Saturated pixels are dropped, which helps
    and does not fully solve it. Glossy floors remain the hard case, same as they
    were for the ORG drivable-area work.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

# ABSOLUTE saturation. Catches BLOWN pixels only.
SATURATION_CUTOFF = 245

# RELATIVE glare cutoff, as a multiple of the frame's own floor brightness.
#
# This exists because the absolute cutoff is not enough, and the sim proved it.
# A satin floor's specular sheen raises a cell's brightness WITHOUT clipping it
# to 255 -- it sails straight past SATURATION_CUTOFF and lands in the histogram
# looking exactly like clean floor that got brighter.
#
# And gloss is the one confounder that CANNOT cancel in the differential. Every
# other confounder in this design (colour, texture, grout, ambient light) is a
# property of the FLOOR and is therefore identical in both views. Specular
# reflection is a property of the GEOMETRY -- it depends on where the camera is.
# The front camera sees a cell at 32 degrees; the rear sees the same cell at 58.
# Different angle, different highlight, from the same physical patch.
#
# Measured, patterned floor, gloss 0.35: separation collapsed 37.7x -> 1.0x,
# false-cleaned 4.7% -> 38.5%, and the deliberately-failed stain went 12/12
# caught -> 0/12. Not degraded. Blind.
GLARE_RATIO = 1.28

# If the two views of a cell disagree this much about how much of it was USABLE,
# they are not looking at the same thing -- one of them is staring into a
# highlight. Refuse, do not guess. Refusing is honest; a confident wrong answer
# inside a proof-of-work report is not.
MAX_VALID_FRAC_GAP = 0.25
# Near-black pixels carry no usable signal. Dropped.
SHADOW_CUTOFF = 4

HIST_BINS = 32
# Wide, so that sensor noise on a featureless floor stays SUB-BIN. A narrow
# range makes the noise straddle bin edges and the distance explodes on nothing.
HIST_RANGE = (0.30, 1.50)
# Smoothing, in bins. NOT cosmetic -- see describe(). Without it, a 3% error in
# the frame-gain estimate produced a change of 0.41 on a plain floor, LARGER
# than a real stain (0.27). With it, that error costs 0.019. Measured.
HIST_SMOOTH_BINS = 2.0


@dataclass(frozen=True)
class Descriptor:
    """Shift-invariant, gain-normalised appearance of one floor cell."""

    hist: np.ndarray      # normalised, sums to 1
    valid_frac: float     # fraction of pixels usable (not glare, not shadow)
    ok: bool


def frame_gain(image_bgr: np.ndarray, floor_mask: np.ndarray | None = None) -> float:
    """The brightness of THIS camera's view of the floor, right now. One scalar.

    This is the normalisation, and WHERE it happens is the whole game.

    An earlier version normalised per patch, dividing each cell by its own
    heavy blur. It FAILED twice over:

      1. On a featureless floor the ratio g/blur(g) contains nothing but SENSOR
         NOISE -- a narrow spike at 1.0 whose WIDTH is the noise-to-signal ratio.
         The rear camera runs its own LED and averages more pixels, so its noise
         differs, so its spike has a different width, so identical clean floor
         read as CHANGED. On a dark floor the noise (0.143) exceeded a real stain
         (0.129). Signal-to-noise below one.

      2. Worse, it was BLIND to the thing that matters most. A cell in the middle
         of a big spill has NO local contrast -- it is uniformly dark. Divide by
         its own blur and you get 1.0. After cleaning it is uniformly light --
         divide by its own blur and you get 1.0 again. The local ratio normalised
         away the single strongest signal there is: the cell got brighter.

    Normalise GLOBALLY instead. Each camera divides by its OWN frame's floor
    brightness, so a gain or exposure mismatch between the two cameras cancels --
    while the absolute darkness of a stain, relative to the floor around it,
    survives intact. A big uniform spill now reads 1.000, the maximum possible
    signal, on every floor we tested.

    Robust median, because furniture, shadows and glare are in frame too and a
    mean would chase them.

    CALL THIS ON THE WHOLE CAMERA FRAME. NEVER ON A SINGLE CELL.

    If you hand it one cell, and that cell happens to BE a spill, then its own
    median IS the spill -- you divide the spill by itself, get 1.0, and normalise
    away the exact signal you were trying to measure. The gain must come from the
    surrounding floor, which is what the full frame gives you. A unit test caught
    this by making that mistake, and it is an easy one to make.

    Corollary and known limit: if a spill covers more than half of everything the
    camera can see, the robust median IS the spill and this fails. That is a spill
    roughly a metre across filling the entire frame. We accept it, and note it.
    """
    g = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    if floor_mask is not None:
        v = g[floor_mask.astype(bool) & (g < SATURATION_CUTOFF) & (g > SHADOW_CUTOFF)]
    else:
        v = g[(g < SATURATION_CUTOFF) & (g > SHADOW_CUTOFF)]
    if v.size < 100:
        return 0.0        # nothing usable in frame -- caller must skip
    return float(np.median(v))


def describe(patch_bgr: np.ndarray, gain: float,
             min_valid_frac: float = 0.5) -> Descriptor:
    """Build the cell descriptor.

    gain: the frame_gain() of the image this patch was cut from. Each camera
        supplies its own, which is what makes the two cameras comparable.

    Three properties, each of which was bought with a failure:

      SHIFT-INVARIANT. It is a histogram, so it does not care where the pixels
      are. Pixel-wise comparison needs sub-millimetre pose (a 5 cm cell at 96 px
      means 1 px = 0.5 mm) and AMCL gives centimetres. A 2 px misregistration on
      a patterned floor produced a change of 0.768 -- larger than a real cleaned
      stain at 0.417. The noise beat the signal. A histogram cannot have that bug.

      GAIN-NORMALISED, GLOBALLY. See frame_gain().

      SMOOTHED. On a featureless floor the distribution is a near-delta spike,
      and Bhattacharyya distance then swings on nothing but where that spike
      falls relative to a bin edge. Smoothing makes sub-bin position irrelevant
      and absorbs error in the gain estimate.

    CALLER MUST BAND-LIMIT THE PATCH FIRST. The front camera sees a cell from 1 m
    (about 20 source px) and the rear from 0.3 m (about 126). Warp both to the
    same size and the front is blurred interpolation while the rear is sharp --
    different histograms from identical floor. Downsample both to a common
    resolution before calling this. verify_node._warp_cell does it.
    """
    if patch_bgr is None or patch_bgr.size == 0 or gain <= 0.0:
        return Descriptor(np.zeros(HIST_BINS), 0.0, False)

    g = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2GRAY)
    # Two cutoffs. The absolute one catches blown pixels; the RELATIVE one catches
    # specular sheen that is brighter than the floor but never reaches 255.
    usable = ((g < SATURATION_CUTOFF) & (g > SHADOW_CUTOFF)
              & (g < GLARE_RATIO * gain))
    valid_frac = float(usable.mean())
    if valid_frac < min_valid_frac:
        # Refuse rather than emit a confident wrong number. On a polished floor
        # this WILL refuse a lot of cells. That is the correct behaviour: "we
        # cannot verify this floor" beats "we verified it" when we did not.
        return Descriptor(np.zeros(HIST_BINS), valid_frac, False)

    # Clip, do not drop. A very dark stain's core would fall outside the range
    # and be silently discarded, and the renormalised remainder would look like
    # clean floor. Clipping pins that mass into the bottom bin, where it belongs.
    r = np.clip(g[usable].astype(np.float32) / gain, *HIST_RANGE)

    h = np.histogram(r, bins=HIST_BINS, range=HIST_RANGE)[0].astype(np.float64)
    if HIST_SMOOTH_BINS > 0:
        k = cv2.getGaussianKernel(int(6 * HIST_SMOOTH_BINS) | 1,
                                  HIST_SMOOTH_BINS).ravel()
        h = np.convolve(h, k, mode="same")
    ssum = h.sum()
    if ssum <= 0:
        return Descriptor(np.zeros(HIST_BINS), valid_frac, False)
    return Descriptor(h / ssum, valid_frac, True)


def views_disagree(before: Descriptor, after: Descriptor) -> bool:
    """Did one of the two cameras spend this cell staring into a highlight?

    Gloss is view-dependent, so the front (32 deg) and rear (58 deg) views of the
    SAME cell can have wildly different amounts of usable floor in them. When they
    do, they are not measuring the same thing and no distance between their
    histograms means anything. Refuse.
    """
    return abs(before.valid_frac - after.valid_frac) > MAX_VALID_FRAC_GAP


def change(before: Descriptor, after: Descriptor) -> float:
    """Bhattacharyya distance between two views of the SAME physical cell.

    0.0 = identical. Higher = the pass altered this cell.

    Direction-agnostic on purpose. It does not matter whether cleaning made the
    cell brighter (a stain lifted), more textured (a rug's weave reappearing) or
    less (crumbs swept off tile). All of it is change, and change is all we claim
    to measure. An earlier scalar "dirtiness" score had a floor-dependent SIGN --
    on a rug, adding a stain made the score go DOWN, because the stain covered
    the texture. Measured: 0.748 clean, 0.651 stained. Any scalar dirtiness is
    unusable. This is not a scalar.
    """
    if not before.ok or not after.ok:
        return 0.0
    return float(1.0 - np.sum(np.sqrt(before.hist * after.hist)))


class NoiseFloor:
    """Live estimate of how much 'change' this floor shows when NOTHING happened.

    We cannot hard-code a threshold: a plain tile floor's noise floor is ~0.000
    and a busy rug's is ~0.003, and a real deployment will find worse. So learn
    it, per surface, from the run itself.

    Fed from every cell where the PIEZO HEARD NOTHING -- regardless of what
    verdict we reached. Those are, by definition, "no debris was there", so
    whatever change we measured on them is pure measurement noise.

    THIS IS LOAD-BEARING AND IT WAS ONCE A DEADLOCK. An earlier version fed the
    baseline only from cells that came back CLEAN. But a cell cannot come back
    CLEAN until the baseline is ready, and the baseline is never ready because
    no cell ever comes back CLEAN. The node emitted UNKNOWN forever, on every
    floor, and the unit tests missed it because the fixture primed the baseline
    by hand and bypassed the real path.

    The piezo breaks the cycle. It is an INDEPENDENT sensor -- it does not need
    the camera's baseline to know it heard nothing. Which is one more reason the
    two-sensor design is the right one: each sensor can bootstrap the other.

    Robust (median + MAD): the dirty minority cannot drag the floor up and hide
    itself. The median survives up to 50% contamination; if more than half your
    floor is dirt, you do not have a detection problem, you have a mop problem.
    """

    def __init__(self, window: int = 500, min_samples: int = 40):
        self.window = window
        self.min_samples = min_samples
        self._s: list[float] = []

    def update(self, change_value: float) -> None:
        self._s.append(float(change_value))
        if len(self._s) > self.window:
            self._s = self._s[-self.window:]

    @property
    def ready(self) -> bool:
        return len(self._s) >= self.min_samples

    def stats(self) -> tuple[float, float]:
        a = np.asarray(self._s, dtype=np.float64)
        med = float(np.median(a))
        mad = float(np.median(np.abs(a - med)))
        # Floor the MAD: a perfectly uniform floor gives MAD == 0 and would make
        # every speck of noise an infinite-sigma event.
        return med, max(mad, 2e-3)

    def sigmas(self, change_value: float) -> float:
        """How many robust deviations above pure noise this change sits.

        Returns 0.0 until enough samples exist -- 'no evidence', which is the
        fail-open answer. We do not guess before we have seen the floor.
        """
        if not self.ready:
            return 0.0
        med, mad = self.stats()
        return (change_value - med) / mad


class Verdict:
    CLEANED = "cleaned"          # the pass demonstrably changed this cell
    STILL_DIRTY = "still_dirty"  # piezo heard dirt, cell did not change -> re-pass
    CLEAN = "clean"              # nothing was there, nothing happened
    UNKNOWN = "unknown"          # unusable patch, or floor not yet baselined


@dataclass(frozen=True)
class Result:
    verdict: str
    change: float
    sigmas: float
    piezo: bool


def verify(before: Descriptor, after: Descriptor, floor: NoiseFloor,
           piezo_fired: bool, k_sigma: float = 6.0) -> Result:
    """The whole verification decision. Two sensors, each doing its own job.

    piezo_fired: did the debris sensor hear anything while we were over this
        cell? This is the DETECTION channel. The camera never answers it.

    k_sigma: how far above the floor's own noise a change must sit before we
        call it real. 6 is deliberately conservative -- with signal at 20-100x
        the noise floor we have the headroom to spend, and a false CLEANED
        pollutes the proof-of-work report we are asking a customer to trust.

    The asymmetry, and which way it fails:

      - False CLEANED is CHEAP but DISHONEST: we would tell a facility manager a
        cell is clean when it is not. That is the one lie the whole
        proof-of-work feature exists to prevent, so we set k_sigma high.
      - False STILL_DIRTY is EXPENSIVE: a wasted re-pass, burning battery and
        time. Exactly the error that made a 45%-FPR detector useless. So it
        requires the PIEZO to have fired -- an independent sensor with
        uncorrelated failure modes. The camera cannot raise it alone.
      - Anything uncertain -> UNKNOWN -> do NOTHING, keep cleaning normally,
        fall back to plain systematic coverage.

    FAIL-OPEN by construction. The cleaning path is ALLOWED to fail; systematic
    coverage is the safety net underneath it. (The hazard path is the opposite --
    see hazard_node, which fails CLOSED. Different error costs, opposite
    thresholds. That asymmetry is the core of the whole perception design.)
    """
    if not before.ok or not after.ok:
        return Result(Verdict.UNKNOWN, 0.0, 0.0, piezo_fired)

    c = change(before, after)
    if not floor.ready:
        return Result(Verdict.UNKNOWN, c, 0.0, piezo_fired)

    s = floor.sigmas(c)

    if s >= k_sigma:
        # The cell measurably changed. Something was there and is now gone.
        # This is the proof-of-work event, and the sample that feeds the dirt
        # prior map for cross-run route planning.
        return Result(Verdict.CLEANED, c, s, piezo_fired)

    if piezo_fired:
        # The debris sensor heard dirt here, and the cell did NOT change. The
        # pass failed. This is the only path to a re-pass, and it needs BOTH
        # sensors to agree.
        return Result(Verdict.STILL_DIRTY, c, s, piezo_fired)

    # Nothing heard, nothing changed. Nothing was there. This sample is what
    # teaches the NoiseFloor what "nothing" looks like on this surface.
    return Result(Verdict.CLEAN, c, s, piezo_fired)


class ConfirmationGate:
    """N agreeing observations before a cell may cost a real cleaning pass.

    Even with two sensors agreeing, one reading does not spend battery. Two
    independent STILL_DIRTY verdicts -- different pose, different lighting -- is
    evidence. Costs one dict and a boolean. Kills most of the residual FPR.
    """

    def __init__(self, votes_needed: int = 2):
        self.votes_needed = votes_needed
        self._v: dict[tuple[int, int], int] = {}

    def vote(self, cell: tuple[int, int], verdict: str) -> bool:
        """True only when the cell is CONFIRMED dirty and worth re-cleaning."""
        if verdict != Verdict.STILL_DIRTY:
            self._v.pop(cell, None)
            return False
        n = self._v.get(cell, 0) + 1
        self._v[cell] = n
        return n >= self.votes_needed

    def clear(self, cell: tuple[int, int]) -> None:
        self._v.pop(cell, None)

    def reset(self) -> None:
        self._v.clear()


def verify_change(change_value: float, floor: NoiseFloor, piezo_fired: bool,
                  k_sigma: float = 8.0) -> Result:
    """verify(), but on a change value already pooled across several looks.

    The rear camera sees each cell about 15 times as it tracks through the strip.
    The node takes the MEDIAN of those looks and calls this. One noisy frame can
    no longer produce a verdict by itself, which roughly halved the false-cleaned
    rate for free.
    """
    if not floor.ready:
        return Result(Verdict.UNKNOWN, change_value, 0.0, piezo_fired)
    s = floor.sigmas(change_value)
    if s >= k_sigma:
        return Result(Verdict.CLEANED, change_value, s, piezo_fired)
    if piezo_fired:
        return Result(Verdict.STILL_DIRTY, change_value, s, piezo_fired)
    return Result(Verdict.CLEAN, change_value, s, piezo_fired)
