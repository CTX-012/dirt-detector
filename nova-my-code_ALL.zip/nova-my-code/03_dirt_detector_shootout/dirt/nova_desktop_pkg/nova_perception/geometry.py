"""Camera <-> ground geometry.

Everything here assumes the REP-103 optical frame convention for cameras:
    +z forward (out of the lens), +x right, +y down.
and a robot frame (base_footprint) with +z up, floor at z == 0.

The flat-floor assumption is doing a LOT of work here. It is exact in Gazebo.
On real floors it degrades with ramps, thresholds, and thick rugs. Every
function that relies on it says so.

No ROS imports in this module -- it is pure numpy so it can be unit-tested
without a ROS environment. The nodes do the tf2 lookups and hand us matrices.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class Pinhole:
    """Camera intrinsics, straight off sensor_msgs/CameraInfo."""

    fx: float
    fy: float
    cx: float
    cy: float
    width: int
    height: int

    @classmethod
    def from_k(cls, k, width: int, height: int) -> "Pinhole":
        k = np.asarray(k, dtype=np.float64).reshape(3, 3)
        return cls(fx=k[0, 0], fy=k[1, 1], cx=k[0, 2], cy=k[1, 2],
                   width=int(width), height=int(height))

    @property
    def k(self) -> np.ndarray:
        return np.array([[self.fx, 0.0, self.cx],
                         [0.0, self.fy, self.cy],
                         [0.0, 0.0, 1.0]], dtype=np.float64)

    def in_bounds(self, u: float, v: float, margin: int = 0) -> bool:
        return (margin <= u < self.width - margin
                and margin <= v < self.height - margin)


def pixel_to_ground(u: float, v: float, cam: Pinhole,
                    t_base_cam: np.ndarray) -> np.ndarray | None:
    """Back-project a pixel onto the floor plane (z == 0) in the base frame.

    t_base_cam: 4x4 homogeneous transform, camera-optical -> base frame.

    Returns [x, y] in the base frame, or None if the ray never hits the floor
    (points at or above the horizon).

    That None is not an error case -- it is a free sanity gate. Anything above
    the horizon is a wall, a person, or the ceiling, and it is not floor. Both
    nodes lean on this.
    """
    d_cam = np.array([(u - cam.cx) / cam.fx,
                      (v - cam.cy) / cam.fy,
                      1.0], dtype=np.float64)

    r = t_base_cam[:3, :3]
    o = t_base_cam[:3, 3]
    d = r @ d_cam

    # Ray must be pointing DOWN in the base frame to ever reach z == 0.
    # A tiny epsilon guards against near-horizontal rays, which project to
    # absurd distances and would otherwise poison the map with points at 400 m.
    if d[2] > -1e-6:
        return None

    s = -o[2] / d[2]
    if s <= 0.0:
        return None

    p = o + s * d
    return p[:2]


def ground_to_pixel(x: float, y: float, cam: Pinhole,
                    t_cam_base: np.ndarray) -> tuple[float, float] | None:
    """Project a floor point (base frame, z == 0) into the image.

    t_cam_base: 4x4 homogeneous transform, base frame -> camera-optical.
    Returns (u, v), or None if the point is behind the camera.

    Note it can return a (u, v) outside the image. Callers check in_bounds --
    a point can be legitimately behind us or off to the side.
    """
    p_base = np.array([x, y, 0.0, 1.0], dtype=np.float64)
    p_cam = (t_cam_base @ p_base)[:3]

    if p_cam[2] <= 1e-6:
        return None

    u = cam.fx * p_cam[0] / p_cam[2] + cam.cx
    v = cam.fy * p_cam[1] / p_cam[2] + cam.cy
    return float(u), float(v)


def ground_footprint(cam: Pinhole, t_base_cam: np.ndarray,
                     max_range: float = 3.0) -> np.ndarray:
    """The floor quad this camera can actually see, in the base frame.

    Back-projects the four image corners. Corners above the horizon are
    dropped, so a camera tilted toward the ceiling returns fewer than 4 points
    (or none). Clipped to max_range because a nearly-horizontal ray hitting the
    floor 40 m away is technically visible and practically garbage -- one pixel
    covers a square metre out there.

    max_range is measured FROM THE CAMERA, not from the origin of whatever frame
    t_base_cam happens to target. That distinction was a real bug and it was
    nasty: this function is called with a map-frame transform, and the clip used
    hypot(p) -- distance from the MAP ORIGIN. Once the robot drove more than
    max_range away from that origin, EVERY corner tripped the clip and the whole
    quad got rescaled back toward (0, 0). The field of view silently collapsed
    into a garbage triangle near the map origin, the node stopped seeing the
    floor in front of it, and the cell count froze no matter how far we drove.

    It is invisible if you test with the robot sitting at the origin. Which is
    exactly how it survived the first review.
    """
    corners = [(0, 0), (cam.width - 1, 0),
               (cam.width - 1, cam.height - 1), (0, cam.height - 1)]
    origin = t_base_cam[:2, 3]          # the CAMERA, in the target frame
    pts = []
    for u, v in corners:
        p = pixel_to_ground(u, v, cam, t_base_cam)
        if p is None:
            continue
        d = float(np.hypot(p[0] - origin[0], p[1] - origin[1]))
        if d > max_range:
            p = origin + (p - origin) * (max_range / d)
        pts.append(p)
    return np.array(pts, dtype=np.float64) if pts else np.zeros((0, 2))


def cell_patch_pixels(cx: float, cy: float, half_m: float, cam: Pinhole,
                      t_cam_base: np.ndarray) -> np.ndarray | None:
    """Image-space quad covering the square floor cell centred at (cx, cy).

    Returns a 4x2 float array of pixel corners (TL, TR, BR, BL in floor terms),
    or None if any corner falls behind the camera. Used to warp a ground cell
    out of an image so the same physical patch can be compared across two
    different camera poses.
    """
    corners_m = [(cx - half_m, cy + half_m), (cx + half_m, cy + half_m),
                 (cx + half_m, cy - half_m), (cx - half_m, cy - half_m)]
    out = []
    for x, y in corners_m:
        uv = ground_to_pixel(x, y, cam, t_cam_base)
        if uv is None:
            return None
        out.append(uv)
    return np.array(out, dtype=np.float32)


def invert_transform(t: np.ndarray) -> np.ndarray:
    """Invert a 4x4 rigid transform without a general matrix inverse."""
    r = t[:3, :3]
    o = t[:3, 3]
    out = np.eye(4, dtype=np.float64)
    out[:3, :3] = r.T
    out[:3, 3] = -r.T @ o
    return out


def transform_from_quat(tx: float, ty: float, tz: float,
                        qx: float, qy: float, qz: float,
                        qw: float) -> np.ndarray:
    """Build a 4x4 from a ROS translation + quaternion (tf2 gives us these)."""
    n = qx * qx + qy * qy + qz * qz + qw * qw
    if n < 1e-12:
        r = np.eye(3)
    else:
        s = 2.0 / n
        xx, yy, zz = qx * qx * s, qy * qy * s, qz * qz * s
        xy, xz, yz = qx * qy * s, qx * qz * s, qy * qz * s
        wx, wy, wz = qw * qx * s, qw * qy * s, qw * qz * s
        r = np.array([
            [1.0 - (yy + zz), xy - wz, xz + wy],
            [xy + wz, 1.0 - (xx + zz), yz - wx],
            [xz - wy, yz + wx, 1.0 - (xx + yy)],
        ], dtype=np.float64)
    t = np.eye(4, dtype=np.float64)
    t[:3, :3] = r
    t[:3, 3] = [tx, ty, tz]
    return t
