"""Adaptive coverage. Fly over clean floor, dwell and dig in on dirt.

THE TWO INVARIANTS. Everything else is tuning; break either of these and you have
built something dangerous.

  1. THE COVERAGE PLAN IS NOT OURS TO CHANGE.
     The planner (opennav_coverage) owns WHERE the robot goes and guarantees every
     cell is crossed. This controller owns only HOW FAST and HOW HARD. It can
     never skip a cell, shorten a lane, or re-order a path. If dirt detection is
     wrong -- and it will sometimes be wrong -- the worst case is that the robot
     cleans a clean floor slowly. It is NEVER that a dirty patch goes uncovered.

     Systematic coverage is the safety net underneath the whole perception stack.
     Do not cut a hole in it to save thirty seconds.

  2. THE HAZARD LIMIT IS A CEILING, NOT A SUGGESTION.
     hazard_node publishes a speed limit and it FAILS CLOSED -- a stale camera
     means the robot is blind and must crawl. This controller may only ever ask
     for a speed BELOW that ceiling.

         v = min(v_dirt, v_hazard, v_max)

     One min(). It is one line and it is the line between "the robot slows for
     dirt" and "the robot speeds up through a room it cannot see."

WHERE THE SIGNAL COMES FROM -- a cascade, because each source has a different lag

    FEED-FORWARD, slow   the appearance map. "this spot was dirty last week."
                         Free, and the only one with enough lead time to plan.

    FEED-FORWARD, fast   the FRONT camera, 0.4-1.2 m ahead. Gloss wrecks its
                         PRECISION, which is why it cannot do verification -- but
                         TARGETING tolerates false positives. A wrong "slow down"
                         costs three seconds; a wrong "cleaned" is a lie in a
                         report a customer paid for. Opposite error costs, so the
                         same camera is useless for one job and fine for the other.

    FEEDBACK, real-time  the piezo. Reactive -- you are already over the cell --
                         but it is the only sensor that KNOWS dirt was there.

    VERIFICATION, after  the rear camera. Did it actually work? Drives the re-pass.

TIMING. At 0.5 m/s with 0.5 m/s^2 of deceleration, dropping to 0.15 m/s takes
0.7 s = 0.23 m of travel. The front camera sees 0.41-1.2 m ahead. So there is
lead time -- but only just, and only if the detector runs at >= 5 Hz.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Limits:
    v_clean: float = 0.50       # m/s over floor we believe is clean
    v_dirty: float = 0.15       # m/s over dirt -- slow = more brush passes per metre
    v_min: float = 0.05
    accel: float = 0.5          # m/s^2. Sets how much lead time we need.

    p_clean: float = 0.35       # suction, 0..1. Most of the floor is clean; most
    p_dirty: float = 1.00       # of the time we should not be running at full tilt.

    scrub_budget_s: float = 30.0   # hard cap on dwelling over one stubborn spot
    min_improvement: float = 0.05  # below this, another pass is not going to help
    stall_passes: int = 2          # consecutive non-improving passes before we quit


@dataclass
class CellState:
    dirty_belief: float = 0.0   # 0..1
    passes: int = 0
    scrub_time: float = 0.0
    last_change: float = 0.0
    improving: bool = True
    unremovable: bool = False


class AdaptiveCoverage:
    """Speed and power per cell. Never the path."""

    def __init__(self, lim: Limits | None = None):
        self.lim = lim or Limits()
        self.cells: dict[tuple[int, int], CellState] = field(default_factory=dict)
        self.cells = {}
        self.hazard_ceiling = 0.0      # 0.0 == NO LIMIT, per nav2 NO_SPEED_LIMIT

    # ---- inputs ------------------------------------------------------------

    def on_hazard_limit(self, speed_limit: float):
        """From /speed_limit. 0.0 means unrestricted (nav2's NO_SPEED_LIMIT)."""
        self.hazard_ceiling = float(speed_limit)

    def on_prior(self, cell, belief: float):
        """From the appearance map: this spot has historically been dirty."""
        s = self.cells.setdefault(cell, CellState())
        s.dirty_belief = max(s.dirty_belief, min(belief, 0.7))
        # Capped at 0.7: a prior is a hint, not evidence. It may pre-emptively slow
        # us, but it must never be enough on its own to claim we cleaned anything.

    def on_lookahead(self, cell, score: float):
        """From the FRONT camera. Noisy on glossy floors -- and that is fine here.
        We are aiming effort, not writing a report."""
        s = self.cells.setdefault(cell, CellState())
        s.dirty_belief = max(s.dirty_belief, min(score, 1.0))

    def on_piezo(self, cell, fired: bool):
        """The only sensor that KNOWS dirt was there -- when it can hear it."""
        s = self.cells.setdefault(cell, CellState())
        if fired:
            s.dirty_belief = 1.0

    def on_verified(self, cell, change: float, still_dirty: bool):
        """From the rear camera, after the pass. This closes the loop."""
        s = self.cells.setdefault(cell, CellState())
        s.passes += 1
        improvement = change - s.last_change
        s.improving = improvement >= self.lim.min_improvement
        s.last_change = change

        if not still_dirty:
            s.dirty_belief = 0.0
            return

        # It is still dirty. Do we keep scrubbing, or is this as good as it gets?
        if s.scrub_time >= self.lim.scrub_budget_s:
            self._give_up(s, "budget")
        elif s.passes >= self.lim.stall_passes and not s.improving:
            # Two passes, no improvement. It is not coming up. Further scrubbing
            # burns battery and wears the pad for nothing.
            self._give_up(s, "asymptote")

    def _give_up(self, s: CellState, why: str):
        s.unremovable = True
        s.dirty_belief = 0.0
        # THIS MUST APPEAR IN THE CUSTOMER REPORT as "detected, could not remove".
        # NOT silently dropped. The moment the robot starts hiding known dirt to
        # keep its numbers pretty, the proof-of-work feature is worth less than
        # nothing -- it is actively lying. Persist it so we do not burn 30 s on the
        # same permanent scuff every single visit, and RE-TEST it monthly, because
        # a mark that would not lift in March may lift after an April re-wax.

    # ---- outputs -----------------------------------------------------------

    def command(self, cell) -> tuple[float, float]:
        """(speed m/s, suction 0..1) for the cell we are about to cross."""
        s = self.cells.get(cell)
        b = 0.0 if (s is None or s.unremovable) else s.dirty_belief

        v_dirt = self.lim.v_clean + (self.lim.v_dirty - self.lim.v_clean) * b
        power = self.lim.p_clean + (self.lim.p_dirty - self.lim.p_clean) * b

        # INVARIANT 2. The hazard ceiling wins. Always. 0.0 == no limit.
        v = v_dirt
        if self.hazard_ceiling > 0.0:
            v = min(v, self.hazard_ceiling)
        return max(v, self.lim.v_min), power

    def tick(self, cell, dt: float):
        s = self.cells.get(cell)
        if s and s.dirty_belief > 0.5:
            s.scrub_time += dt

    def needs_repass(self, cell) -> bool:
        s = self.cells.get(cell)
        return bool(s and s.dirty_belief > 0.5 and not s.unremovable
                    and s.scrub_time < self.lim.scrub_budget_s)

    def report(self) -> dict:
        un = [c for c, s in self.cells.items() if s.unremovable]
        return {
            "cells_tracked": len(self.cells),
            "unremovable": len(un),
            "unremovable_cells": [f"{c[0]},{c[1]}" for c in un[:50]],
            "claim": "cells listed as unremovable were DETECTED and NOT REMOVED. "
                     "They are reported, not hidden.",
        }
