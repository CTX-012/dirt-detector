"""Datasets. What exists, what does not, and what you will have to pay for.

Researched, not guessed. Read the MISSING section before you budget anything.


=============================================================================
WHAT EXISTS AND IS FREE
=============================================================================

SCATSPOTTER  (Jonathan Crall, Kitware. arXiv 2412.16473. CC-BY 4.0)
    9000+ full-resolution phone images, 6000 polygon annotations of DOG FECES.

    *** AND IT IS BUILT ON OUR EXACT ARCHITECTURE. ***

    Collected with a "before/after/negative" (BAN) protocol: an image with the
    object PRESENT, an image FROM THE SAME VIEWPOINT AFTER REMOVAL, and a nearby
    NEGATIVE scene containing visually similar confusers.

    That is a before/after differential benchmark, with real photographs, from a
    real camera, on real ground, for free. We can run our detector on it TODAY,
    without collecting a single frame. Nobody in the cleaning-robot literature
    appears to have noticed it.

    And their headline result should reset expectations: "Zero-shot DINO performs
    poorly, indicating limited foundational-model coverage of this category."
    Their BEST model -- a TUNED DINO -- reaches box AP 0.69.

    Feces is genuinely hard for an ABSOLUTE detector, because it is small,
    amorphous and camouflaged. Our differential does not need the model to KNOW
    what feces is. It only needs to see that the cell CHANGED. On their own
    before/after pairs we may beat their tuned model, and that is a paper.

ACIN  (TU Wien, Grunauer et al., ICVS 2017) + the MDPI re-annotation
    Real labelled floor dirt. The MDPI team (Technologies 2021, 9(4):94) found
    ACIN only PARTIALLY labelled, re-annotated it from scratch, TRIPLED the
    labelled images, corrected bad labels, and PUBLISHED all of it -- plus their
    synthetic dirt generator. Free, today, no collection.

MVTec AD
    Not floors, but it is what every anomaly-detection paper (PatchCore, PaDiM,
    AnomalyDINO) reports on. Use it ONLY to sanity-check an implementation.
    DO NOT trust its numbers as a floor result: published work shows SOTA methods
    fall from ~99% AUROC on MVTec to 74-86% on realistic operational data.


=============================================================================
WHAT DOES NOT EXIST -- AND THIS IS A REAL BUDGET LINE
=============================================================================

THERE IS NO PUBLIC FLOOR-HAZARD DATASET. NONE.

    Ecovacs: "thousands of image datasets featuring common household objects,
             such as charging cables, socks, shoes and dog poops."  PROPRIETARY.
    Narwal:  "recognizes over 120 types of obstacles."                PROPRIETARY.
    Roborock: 73 objects.                                             PROPRIETARY.

    Every incumbent built one. None of them shared it. This is the single biggest
    unavoidable data cost in the project, and no amount of cleverness removes it.

    The mitigation is NOT to label by hand. It is to DISTIL:
      Grounding DINO (Apache-2.0, zero-shot) draws the boxes  ->  train RF-DETR
      (Apache-2.0) on those boxes  ->  deploy the fast student.
    You never draw a box yourself. But VALIDATE the teacher first: cables are
    thin, low-contrast, and COCO has no concept of "cable on a floor". Grounding
    DINO may simply be bad at it. Test 100 frames before betting a pipeline on it.


=============================================================================
DO NOT BUILD A HAIR DATASET
=============================================================================

Look at what every vendor actually lists as an obstacle class: cords, cables,
socks, shoes, toys, pet waste, pet bowls, furniture legs.

HAIR IS NEVER ON THE LIST. Not once. Across Ecovacs, Narwal, Roborock, iRobot.

And yet hair entanglement is the NUMBER ONE failure -- Consumer Reports, 135,906
vacuums: "Owners of 1 out of 3 robotics (33 percent) have had this issue." iRobot's
own floorcare category manager calls it "the number one culprit."

The industry has all the data in the world and does not detect hair. Why? Because
YOU CANNOT AVOID HAIR. It is on the floor and your job is to pick it up. Detecting
it changes nothing you would do.

Hair is a MECHANICAL problem -- brush geometry, end-cap design, anti-tangle combs
(see US 11,058,271 and US 11,812,916, an entire patent sub-genre devoted to it).
It is not a perception problem.

DO NOT SPEND A RUPEE LABELLING HAIR. Spend it on the brush.


=============================================================================
PET FECES -- AND THE SENSOR NOBODY TALKS ABOUT
=============================================================================

Feces is the catastrophic class. Smearing it across a floor is not a bad clean, it
is a destroyed customer. iRobot staked a product guarantee on avoiding it.

Vision is a weak defence: zero-shot DINO fails on it, the best tuned model reaches
AP 0.69, and a miss is unrecoverable.

There is a NON-VISION detector, and it is almost free:

    US 12,042,106 ("Movable electronic apparatus") describes MOISTURE-SENSITIVE
    RESISTORS arranged in a ring around the robot's lower edge. Wet waste contacts
    them, resistance changes, the robot STOPS.

    Different physics. Uncorrelated with the camera. Works in the dark. Works on a
    glossy floor. Works when the model has never seen this particular mess.

    IT IS PATENTED (granted 2024, presumed live) -- so route it to the attorney
    with the rest. But conductivity/moisture contact sensing is old art in general;
    the claim is likely about the specific arrangement. Ask.

The principle is the same one that runs through this whole stack: when the failure
is catastrophic and unrecoverable, do not trust a model. Add a sensor with
different physics and let it veto.
"""

from __future__ import annotations

import glob
import os

import cv2
import numpy as np

CELL_PX = 32


def scatspotter_pairs(root: str, grid: int = 64):
    """Load ScatSpotter's before/after pairs as (before, after, label) cells.

    Expects the BAN structure: for each scene, an image WITH the object and one
    from the SAME VIEWPOINT after removal.

        root/before/<scene>.jpg
        root/after/<scene>.jpg
        root/masks/<scene>.png     (optional; white where the object was)

    Note the direction. ScatSpotter's "before" has the object; "after" is clean.
    For US, the CLEAN one is the reference and the DIRTY one is the observation --
    so we hand them back as (reference=after, current=before). Getting this
    backwards would invert the whole benchmark and it would still LOOK like it
    worked, because change() is direction-agnostic. Be careful.
    """
    pairs = []
    for bp in sorted(glob.glob(os.path.join(root, "before", "*"))):
        name = os.path.basename(bp)
        ap = os.path.join(root, "after", name)
        if not os.path.exists(ap):
            continue
        dirty, clean = cv2.imread(bp), cv2.imread(ap)
        if dirty is None or clean is None:
            continue
        if dirty.shape != clean.shape:
            dirty = cv2.resize(dirty, (clean.shape[1], clean.shape[0]))

        mask = None
        mp = os.path.join(root, "masks", os.path.splitext(name)[0] + ".png")
        if os.path.exists(mp):
            mask = cv2.imread(mp, cv2.IMREAD_GRAYSCALE)
            if mask is not None and mask.shape[:2] != clean.shape[:2]:
                mask = cv2.resize(mask, (clean.shape[1], clean.shape[0]))

        from nova_perception.verification import frame_gain
        gc, gd = frame_gain(clean), frame_gain(dirty)
        if gc <= 0 or gd <= 0:
            continue

        h, w = clean.shape[:2]
        for y in range(0, h - grid + 1, grid):
            for x in range(0, w - grid + 1, grid):
                ref = cv2.resize(clean[y:y + grid, x:x + grid], (CELL_PX, CELL_PX),
                                 interpolation=cv2.INTER_AREA)
                cur = cv2.resize(dirty[y:y + grid, x:x + grid], (CELL_PX, CELL_PX),
                                 interpolation=cv2.INTER_AREA)
                lab = 0
                if mask is not None:
                    lab = int((mask[y:y + grid, x:x + grid] > 127).mean() > 0.15)
                pairs.append((cur, gd, ref, gc, lab))
    return pairs


HAZARD_CLASSES = [
    # What the industry actually detects. Sourced from Ecovacs' and Narwal's own
    # obstacle lists, not from our imagination.
    "cable",        # the #1 entanglement offender. Thin, low-contrast, HARD.
    "cord",
    "sock",
    "shoe",
    "toy",
    "pet_bowl",
    "pet_waste",    # catastrophic. Back it with a moisture sensor, not just vision.
    # NOT "hair". See the module docstring. Hair is a brush problem.
]


MANIFEST = {
    "scatspotter": {
        "url": "arXiv:2412.16473 (Kitware)",
        "licence": "CC-BY 4.0",
        "size": "9000+ images, 6000 polygons",
        "why": "REAL before/after pairs from the same viewpoint. Our architecture, "
               "pre-built. Best tuned model on it is only AP 0.69 -- beatable.",
        "cost": "FREE",
        "action": "DOWNLOAD THIS WEEK. Run our differential on it. It is the "
                  "fastest path from 'sim result' to 'real result'.",
    },
    "acin_mdpi": {
        "url": "TU Wien ACIN + MDPI Technologies 2021, 9(4):94",
        "licence": "public (re-annotated + synthetic generator released)",
        "why": "Real labelled floor dirt. Benchmark the dirt detector honestly.",
        "cost": "FREE",
        "action": "Download. Report recall@5%FPR, not mAP.",
    },
    "floor_hazards": {
        "url": None,
        "licence": None,
        "why": "DOES NOT EXIST PUBLICLY. Every incumbent has one; none shared it.",
        "cost": "REAL. This is the budget line.",
        "action": "Distil it: Grounding DINO (zero-shot teacher) -> RF-DETR "
                  "(fast student). Validate the teacher on 100 frames FIRST -- "
                  "cables may simply defeat it.",
    },
    "hair": {
        "url": None,
        "why": "DO NOT BUILD. Nobody detects hair, because you cannot avoid it. "
               "33% of owners hit entanglement and the fix is BRUSH GEOMETRY.",
        "cost": "0 -- do not spend it here",
        "action": "Put the money into the brush and the anti-tangle comb.",
    },
    "our_floors": {
        "url": "your rosbags",
        "why": "The only data that is yours, and the only thing an incumbent "
               "cannot copy. Clean floors FIRST -- that is a reference set and it "
               "costs nothing but a rosbag.",
        "cost": "time only",
        "action": "START RECORDING THIS WEEK. Code has no lead time. Data does.",
    },
}


def print_manifest():
    print("\nDATASETS -- what to get, what to skip, what to pay for\n" + "=" * 74)
    for k, v in MANIFEST.items():
        print(f"\n[{k}]  cost: {v['cost']}")
        print(f"  why    : {v['why']}")
        print(f"  action : {v['action']}")


if __name__ == "__main__":
    print(__doc__)
    print_manifest()
