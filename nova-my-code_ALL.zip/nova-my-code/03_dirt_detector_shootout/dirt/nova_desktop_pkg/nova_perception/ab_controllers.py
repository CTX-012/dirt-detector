"""A/B the two controllers on identical data. Then stop arguing.

    python3 -m nova_perception.ab_controllers                  # sim
    python3 -m nova_perception.ab_controllers --bag run.csv    # your rosbag

THE METRIC THAT DECIDES IT IS "UNDER-CLEANED".
A dirty cell that received LESS cleaning effort than a dumb constant-speed robot
would have given it. Not "missed" -- MADE WORSE. You took a cell that a $200 vacuum
would have cleaned, decided it was clean, flew over it at 0.5 m/s on 35% suction,
and left dirt on a customer's floor that a dumber machine would have picked up.

Every adaptive-coverage pitch in this industry quotes m2/hour and battery life.
None of them quote this column. Ask why.

effort = suction x dwell = power x (cell_size / speed)
A dumb robot gives every cell 1.00 x (0.05 / 0.30) = 0.167.
Fall below that on a dirty cell and you have gone backwards.
"""

from __future__ import annotations

import sys

import numpy as np

from nova_perception.controllers import BinaryController, Limits, ProportionalController

CELL = 0.05
BASELINE_EFFORT = 1.00 * (CELL / 0.30)      # what a dumb robot gives every cell


def synth(n=10000, dirty_frac=0.08, recall=0.62, seed=11):
    """A floor, and a detector that is WRONG SOMETIMES -- because ours is.

    recall=0.62 is our measured spatial detector on a polished patterned floor.
    A controller that only works with a perfect detector is not a controller.
    """
    rng = np.random.default_rng(seed)
    dirty = rng.random(n) < dirty_frac
    # dirty cells read high but noisily; clean cells mostly read low, some high.
    mu = 6.0 + 8.0 * recall
    sigma = np.where(dirty, rng.normal(mu, 5.0, n), rng.normal(1.5, 2.2, n))
    return dirty, sigma.clip(0)


def load_bag(path):
    """CSV from a real run: sigma,is_dirty per cell. Ground truth from the piezo,
    or from a human walking the floor afterwards with a clipboard. Either is worth
    more than my synthetic distribution."""
    d = np.loadtxt(path, delimiter=",", skiprows=1)
    return d[:, 1].astype(bool), d[:, 0].astype(float)


def evaluate(ctrl, dirty, sigma, hazard=0.0):
    t = e = 0.0
    lifted = under = boosted_clean = 0
    for i in range(len(sigma)):
        d = ctrl.command(float(sigma[i]), hazard)
        dwell = CELL / d.speed
        effort = d.power * dwell
        t += dwell
        e += d.power * dwell
        if dirty[i]:
            if effort >= BASELINE_EFFORT:
                lifted += 1
            else:
                under += 1                     # WE MADE THIS CELL WORSE
        elif d.boosted:
            boosted_clean += 1                 # burned power on a clean cell
    nd = int(dirty.sum())
    return {
        "name": ctrl.name,
        "min": t / 60,
        "energy": e / 60,
        "lifted_pct": 100 * lifted / max(nd, 1),
        "under_pct": 100 * under / max(nd, 1),
        "under_n": under,
        "wasted": boosted_clean,
    }


def main(argv):
    if "--bag" in argv:
        dirty, sigma = load_bag(argv[argv.index("--bag") + 1])
        src = "YOUR ROSBAG"
    else:
        dirty, sigma = synth()
        src = "sim (0.62 recall detector -- our measured spatial one)"

    lim = Limits()
    rows = [
        evaluate(ProportionalController(lim), dirty, sigma),
        evaluate(BinaryController(lim), dirty, sigma),
    ]
    # the dumb robot, for reference. It is the thing you must beat.
    t = len(sigma) * (CELL / 0.30)
    base = {"name": "BASELINE (dumb)", "min": t / 60, "energy": t / 60,
            "lifted_pct": 100.0, "under_pct": 0.0, "under_n": 0, "wasted": 0}

    print(f"\ndata: {src}   |   {len(sigma)} cells, {int(dirty.sum())} dirty\n")
    print(f"{'controller':<20}{'min':>7}{'energy':>8}{'LIFTED':>9}"
          f"{'UNDER-CLEANED':>15}{'wasted on clean':>17}")
    print("-" * 76)
    for r in [base] + rows:
        print(f"{r['name']:<20}{r['min']:>7.1f}{r['energy']:>8.1f}"
              f"{r['lifted_pct']:>8.0f}%{r['under_pct']:>13.0f}%"
              f" ({r['under_n']:>3}){r['wasted']:>10} cells")
    print("-" * 76)

    p, b = rows[0], rows[1]
    print(f"""
PROPORTIONAL under-cleans {p['under_n']} cells. BINARY under-cleans {b['under_n']}.
BINARY saves {100*(1 - b['energy']/p['energy']):.0f}% more energy and finishes {p['min']-b['min']:.1f} min sooner.

So: is {b['under_n'] - p['under_n']} extra dirty cells worth {100*(1 - b['energy']/p['energy']):.0f}% of your battery?

That is a BUSINESS question, not an engineering one, and it has a different answer
for a hospital than for a warehouse. Which is exactly why both controllers are in
the box and why it is ONE config line:

    ros2 run nova_perception clean_loop --ros-args -p controller:=binary
    ros2 run nova_perception clean_loop --ros-args -p controller:=proportional

DEFAULT IS PROPORTIONAL. An under-cleaned cell is dirt you left on a customer's
floor that a dumber machine would have picked up. Start by not going backwards;
buy the battery back later, once the verification loop is proving it is safe to.

AND NOTE THE BASELINE ROW. The dumb robot lifts 100%. BOTH adaptive controllers
lift less. Adaptive coverage TRADES CLEANING FOR BATTERY -- there is no free lunch
here, and anyone who tells you otherwise is selling something.

The verify-and-re-pass loop is what buys the cleaning back. A cheap 0.4 s re-pass
on an under-cleaned cell, not a 30 s scrub. THAT is why the two features are one
feature. Ship adaptive power without verification and you have built a robot that
saves battery by quietly missing dirt.""")


if __name__ == "__main__":
    main(sys.argv[1:])
