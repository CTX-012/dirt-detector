"""Dirt detection. The thing that tells you a floor is unclean.

BENCHMARKED, not asserted. Four approaches, identical cells, real DINOv2 weights,
measured at the operating point that actually matters -- recall at 5% false
positive rate, because a re-pass costs battery and mAP hides the operating point.

                                  patterned   patterned      dark     patterned
                                  clean sim   POLISHED     POLISHED  EVERYTHING
    absolute (no reference)         0.31        0.08         0.08       0.08
    histogram-diff (no model)       1.00        0.58         0.38       0.58
    PatchCore + DINOv2 (1-class)    1.00        0.08         0.65       0.08
    DINOv2-diff  <-- WINNER         0.96        0.88         1.00       0.88

Read the first column against the last and the whole design falls out:

    no reference, no model  ->  0.08     what everyone tries first
    reference,    no model  ->  0.58     +0.50 from the appearance map
    reference,  + DINOv2    ->  0.88     +0.30 from the neural descriptor

THE REFERENCE IS WORTH MORE THAN THE MODEL. But you need both. Neither alone
ships.

TWO RESULTS THAT WOULD HAVE BURNED US
-------------------------------------
1. The reference-free detector scores AUROC 0.13 on a dark floor. That is not
   weak -- that is ANTI-CORRELATED. It systematically ranks clean floor as
   dirtier than dirt. This is the 90%-recall-at-45%-FPR problem (Bormann, ICRA
   2013) reproduced on our own data, and it is why nobody ships this feature.

2. PatchCore scores AUROC 0.88-0.93 -- a beautiful number -- and recall@5%FPR of
   0.08. It has a fat tail of clean-but-unusual patches (grout junctions, cell
   edges) scoring as high as real dirt. HAD WE BENCHMARKED ON AUROC WE WOULD HAVE
   SHIPPED IT. Pick the metric before you pick the model.

THE MODEL
---------
facebook/dinov2-small. Apache-2.0. 22.1M params. PRE-TRAINED.
There is NOTHING TO TRAIN. The backbone is frozen; there is no head to fit. You
need clean-floor IMAGES, not labels. For dirt you COLLECT, you do not TRAIN.

(The only training run anywhere in NOVA is fine-tuning RF-DETR on hazard boxes
that Grounding DINO drew for you. And no Ultralytics anywhere -- YOLO/YOLOE are
AGPL-3.0 and the licence covers the WEIGHTS YOU TRAIN.)

WHO HAS AUTHORITY
-----------------
Not this file. This produces a SCORE. `verification.verify_change()` -- a pure
if/else with no weights -- turns the score into a verdict, and the piezo gets a
vote. A neural network never decides "clean" on its own. When IEC 63327 asks how
the call was made, "a network decided" is not an answer.
"""

from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np


@dataclass(frozen=True)
class CellDescriptor:
    """What one floor cell looks like. Backend-agnostic."""

    vec: np.ndarray       # histogram (32,) or DINOv2 tokens (T, 384)
    valid_frac: float
    ok: bool
    kind: str             # "histogram" | "dinov2"


class HistogramBackend:
    """No model. 0.38 ms/cell. Recall 0.58 on polished patterned.

    Ships TODAY, on any machine, with no torch, no download, no licence review.
    Keep it: it is the fallback when the GPU is busy, the regression baseline the
    neural path must beat, and the thing that runs if DINOv2 ever fails to load.
    """

    kind = "histogram"

    def describe(self, patches, gains):
        from nova_perception.verification import describe
        return [CellDescriptor(d.hist, d.valid_frac, d.ok, "histogram")
                for d in (describe(p, g) for p, g in zip(patches, gains))]

    def distance(self, a: CellDescriptor, b: CellDescriptor) -> float:
        if not a.ok or not b.ok:
            return 0.0
        return float(1.0 - np.sum(np.sqrt(a.vec * b.vec)))     # Bhattacharyya


class Dinov2Backend:
    """facebook/dinov2-small, frozen. Recall 0.88 on polished patterned.

    BATCHED BY FRAME, NOT BY CELL. Scoring one cell at a time means one forward
    pass per cell -- 682 passes for a single sweep, which is both absurd here and
    wrong on the robot. The swath is ~8 cells wide, so one batched forward per
    frame covers every cell we care about.

    On the Orin: export to ONNX, then TensorRT FP16. The seam is `_forward` and
    nothing above it changes when you swap the runtime.
    """

    kind = "dinov2"

    def __init__(self, size=70, device="cpu"):
        # size must be a multiple of 14 (DINOv2 patch size). 70 -> 5x5 = 25 tokens
        # per cell, which was enough for 0.88. Raise it if the benchmark says so.
        assert size % 14 == 0, "DINOv2 patch size is 14"
        self.size = size
        self.device = device
        self._m = None

    def _model(self):
        if self._m is None:
            import torch
            from transformers import AutoModel
            self._m = AutoModel.from_pretrained("facebook/dinov2-small").eval()
            self._m.to(self.device)
            self._torch = torch
        return self._m

    def _forward(self, patches):
        """THE SEAM. Swap this for onnxruntime / TensorRT on the robot."""
        import torch
        m = self._model()
        n, s = len(patches), self.size
        x = np.stack([cv2.resize(p, (s, s), interpolation=cv2.INTER_AREA)
                      for p in patches])
        x = x[..., ::-1].astype(np.float32) / 255.0                # BGR -> RGB
        x = (x - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
        t = torch.from_numpy(np.ascontiguousarray(
            x.transpose(0, 3, 1, 2))).float().to(self.device)
        with torch.no_grad():
            h = m(pixel_values=t).last_hidden_state[:, 1:, :]      # drop CLS
            h = torch.nn.functional.normalize(h, dim=-1)
        return h.cpu().numpy()

    def describe(self, patches, gains):
        if not patches:
            return []
        toks = self._forward(list(patches))
        out = []
        for i, p in enumerate(patches):
            g = cv2.cvtColor(p, cv2.COLOR_BGR2GRAY)
            vf = float(((g < 245) & (g > 4)).mean())
            out.append(CellDescriptor(toks[i], vf, vf >= 0.5, "dinov2"))
        return out

    def distance(self, a: CellDescriptor, b: CellDescriptor) -> float:
        if not a.ok or not b.ok:
            return 0.0
        # mean cosine distance between corresponding patch tokens.
        # Both views come from the SAME camera at the SAME pose (appearance-map
        # architecture), so the tokens are spatially aligned and correspond.
        return float((1.0 - (a.vec * b.vec).sum(-1)).mean())


class SpatialBackend:
    """THE DEFAULT. No stored reference. No map. No prior run. No patent exposure.

    The clean reference is not in the past -- it is in the SAME FRAME. Most of any
    floor is clean, even a dirty one: dirt is a minority by area. So the MEDIAN
    descriptor across the cells in front of us right now IS the clean reference,
    and dirt is what sits far from it.

    Benchmarked, recall @5% FPR:

        spatial  (stores NOTHING)     0.62      <-- this
        map-diff (stores a map)       0.58      <-- patent-encumbered, and WORSE
        DINOv2-diff (stores a map)    0.88      <-- best, but encumbered
        absolute (no reference)       0.08      <-- what everyone tries first

    The encumbered route is not even the better route today. That is luck, and we
    should take it.

    WHY THE DUMB DESCRIPTOR WINS HERE, and it is not obvious:
    In SPATIAL mode we compare DIFFERENT cells, so structural oddities -- grout
    junctions, pattern edges, cell boundaries -- do NOT cancel. A rich descriptor
    (DINOv2) finds all of them "unusual" and buries the dirt in a fat tail of
    clean-but-weird cells: measured AUROC 0.96, recall 0.15. The histogram is
    BLIND to that structure, and its blindness is exactly what saves it (0.62).
    In TEMPORAL mode the same cell cancels its own structure, and then the rich
    descriptor wins (0.88). Match the descriptor to the reference, not to a
    leaderboard.

    KNOWN BLIND SPOT: a uniformly dirty floor. If every cell is equally grimy,
    nothing is an outlier and this sees nothing. The piezo catches that (it picks
    up debris everywhere) -- and honestly, uniform grime needs no TARGETING, you
    just clean everything. Detection is for aiming effort and proving it worked.
    """

    kind = "spatial"

    def describe(self, patches, gains):
        from nova_perception.verification import describe
        return [CellDescriptor(x.hist, x.valid_frac, x.ok, "spatial")
                for x in (describe(p, g) for p, g in zip(patches, gains))]

    def reference(self, descs):
        """The floor's own median appearance, from the cells we can see NOW.

        Robust median: the dirty minority cannot drag the reference toward itself
        and hide. Breakdown point 50% -- if more than half your floor is dirt you
        do not have a detection problem, you have a mop problem.
        """
        ok = [d for d in descs if d.ok]
        if len(ok) < 20:
            return None
        m = np.median(np.stack([d.vec for d in ok]), axis=0)
        return CellDescriptor(m / max(m.sum(), 1e-9), 1.0, True, "spatial")

    def distance(self, a: CellDescriptor, b: CellDescriptor) -> float:
        if a is None or b is None or not a.ok or not b.ok:
            return 0.0
        return float(1.0 - np.sum(np.sqrt(a.vec * b.vec)))


def make_backend(kind: str, **kw):
    if kind == "spatial":
        return SpatialBackend()
    if kind == "histogram":
        return HistogramBackend()
    if kind == "dinov2":
        return Dinov2Backend(**kw)
    raise ValueError(f"unknown dirt backend: {kind}. "
                     f"'histogram' (no deps) or 'dinov2' (torch).")


class DirtDetector:
    """Score how much a cell has changed from its known-clean reference.

    This is a DIFFERENTIAL detector and that is not a detail -- it is the reason
    it works. A single-image classifier has to answer "is this dirt?" on a floor
    it has never seen under lighting it has never seen, and it scores 0.08. Give
    it the same cell's clean reference and it scores 0.88.

    Both observations come from the SAME camera, at the SAME pose, under the SAME
    LED. That is what makes specular gloss cancel -- and gloss is the ONE
    confounder that no software fix touches. Measured: front-camera-vs-rear-camera
    on a polished floor gives 38% false-cleaned and catches 0 of 12 stains.
    Rear-vs-its-own-appearance-map gives 3.4% and catches 12.
    """

    def __init__(self, backend="spatial", **kw):
        # DEFAULT = spatial. Stores nothing, scores 0.62, patent-clear.
        # 'histogram' and 'dinov2' both require a stored reference map and are
        # therefore gated behind AppearanceMap's FTO check. Do not default to them.
        self.backend = make_backend(backend, **kw)

    def spatial_reference(self, descs):
        """Only the spatial backend has one. Returns None otherwise."""
        return (self.backend.reference(descs)
                if hasattr(self.backend, "reference") else None)

    @property
    def kind(self):
        return self.backend.kind

    def describe(self, patches, gains):
        """Batched. Call once per frame with every swath cell, never per cell."""
        return self.backend.describe(patches, gains)

    def score(self, reference: CellDescriptor, current: CellDescriptor) -> float:
        """0 = unchanged. Higher = this cell is not what it was.

        NOTE THIS RETURNS A SCORE, NOT A VERDICT. Turning it into clean/dirty is
        verification.verify_change()'s job, and that function has no weights in
        it. Keep it that way -- the certification body will want to read it.
        """
        return self.backend.distance(reference, current)
