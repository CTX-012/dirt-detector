"""THE LOOP. Detect -> clean -> check -> not clean? scrub in place -> move on.

    SCAN     coverage is running. The camera watches the floor ahead.
             Dirt seen -> remember the spot.

    CHECK    the robot has now driven over it. Did the cell CHANGE?
             changed  -> CLEANED. back to SCAN.
             no change + dirt was there -> it did not come up. SCRUB.

    SCRUB    stop the coverage path. Oscillate over the spot -- forward, back,
             forward, back -- at full suction. Re-check after every sweep.
                 improving          -> keep going
                 not improving x2   -> it is not coming up. GIVE UP.
                 30 s elapsed       -> hard budget. GIVE UP.

    RESUME   log it, resume coverage exactly where we left off. Move on.

That is the whole product. Everything else in this package exists to make these
four states honest.

TWO RULES THAT ARE NOT NEGOTIABLE
--------------------------------
1. SCRUB NEVER SKIPS A CELL. It pauses coverage and resumes it at the same point.
   The coverage planner owns WHERE the robot goes and guarantees every cell is
   crossed. This loop owns only HOW LONG we linger. If the detector is wrong --
   and sometimes it will be -- the worst case is that we scrub a clean floor.
   It is NEVER that a dirty patch goes uncovered.

2. THE HAZARD SPEED LIMIT WINS. Always. Even mid-scrub. hazard_node fails CLOSED:
   a stale camera means the robot is blind and must crawl. This loop may only ever
   ask for a speed BELOW that ceiling. One min(). It is the line between "the robot
   scrubs a stain" and "the robot oscillates at full tilt in a room it cannot see."

WHEN WE GIVE UP, WE SAY SO
--------------------------
A cell we could not clean is REPORTED as "detected, could not remove". It is not
silently dropped. The moment the robot starts hiding known dirt to keep its numbers
pretty, the whole verification feature is worth less than nothing -- it is actively
lying to the person paying for it.

And we persist it, so we do not burn 30 seconds on the same permanent scuff mark
on every single visit. Re-test it monthly: a mark that would not lift in March may
lift after an April re-wax.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from enum import Enum


class State(Enum):
    SCAN = "scan"
    CHECK = "check"
    SCRUB = "scrub"
    RESUME = "resume"


@dataclass
class Tuning:
    dirt_threshold: float = 8.0     # sigma above the floor's OWN noise
    scrub_seconds: float = 30.0     # hard budget on one spot. Faiz: "15-30 sec"
    sweep_m: float = 0.20           # how far forward/back each oscillation goes
    scrub_speed: float = 0.12       # m/s while scrubbing. Slow = more brush passes.
    min_improvement: float = 0.05   # below this, another sweep will not help
    stall_sweeps: int = 2           # non-improving sweeps before we quit
    power_clean: float = 0.35       # suction on clean floor
    power_scrub: float = 1.00       # suction on dirt


@dataclass
class Spot:
    cell: tuple[int, int]
    x: float
    y: float
    sweeps: int = 0
    t_start: float = 0.0
    best_change: float = 0.0
    stalled: int = 0
    unremovable: bool = False
    reason: str = ""


@dataclass
class Command:
    """What the loop wants the robot to do, right now."""
    resume_coverage: bool = False   # let Nav2 carry on
    pause_coverage: bool = False    # hold the coverage path, we are busy
    linear_x: float = 0.0           # m/s. Only during SCRUB.
    suction: float = 0.35           # 0..1
    state: str = "scan"


class CleanLoop:
    """Detect, clean, check, scrub, move on."""

    def __init__(self, tune: Tuning | None = None, clock=time.monotonic):
        self.t = tune or Tuning()
        self.clock = clock
        self.state = State.SCAN
        self.spot: Spot | None = None
        self.hazard_ceiling = 0.0          # 0.0 == nav2 NO_SPEED_LIMIT
        self.sweep_dir = 1                  # +1 forward, -1 back
        self.sweep_travel = 0.0
        self.done: list[Spot] = []
        self.unremovable: list[Spot] = []
        self.cleaned = 0

    # ---- inputs ------------------------------------------------------------

    def on_hazard_limit(self, v: float):
        """From /speed_limit. hazard_node fails CLOSED. This is a CEILING."""
        self.hazard_ceiling = float(v)

    def on_dirt_ahead(self, cell, x, y, sigma: float):
        """Front camera, while SCANning. Noisy on glossy floors -- and that is
        FINE here. We are aiming effort, not writing a report. A wrong 'slow down'
        costs three seconds; a wrong 'cleaned' is a lie in a customer's report.
        Opposite error costs, so the same camera is useless for one job and good
        for the other."""
        if self.state is not State.SCAN or sigma < self.t.dirt_threshold:
            return
        self.spot = Spot(cell=cell, x=x, y=y)
        self.state = State.CHECK

    def on_verified(self, cell, change: float, sigma: float, piezo: bool):
        """Rear camera, after the robot has crossed the cell. THE loop closes here."""
        if self.spot is None or cell != self.spot.cell:
            return

        s = self.spot
        cleaned = sigma >= self.t.dirt_threshold

        if self.state is State.CHECK:
            if cleaned:
                self._finish(cleaned=True)          # it came up. move on.
            elif piezo:
                self._start_scrub()                 # dirt was there, it did not move.
            else:
                self._finish(cleaned=False)         # nothing was there after all.
            return

        if self.state is State.SCRUB:
            s.sweeps += 1
            improvement = change - s.best_change
            s.best_change = max(s.best_change, change)

            if cleaned:
                self._finish(cleaned=True)          # it finally came up.
                return

            elapsed = self.clock() - s.t_start
            if elapsed >= self.t.scrub_seconds:
                self._give_up("budget")             # 30 s. that is the deal.
                return

            if improvement < self.t.min_improvement:
                s.stalled += 1
                if s.stalled >= self.t.stall_sweeps:
                    # Two sweeps, no improvement. It is not coming up. More
                    # scrubbing burns battery and wears the pad for nothing.
                    self._give_up("asymptote")
                    return
            else:
                s.stalled = 0

    # ---- transitions -------------------------------------------------------

    def _start_scrub(self):
        self.state = State.SCRUB
        self.spot.t_start = self.clock()
        self.sweep_dir = 1
        self.sweep_travel = 0.0

    def _finish(self, cleaned: bool):
        if cleaned and self.spot:
            self.cleaned += 1
            self.done.append(self.spot)
        self.spot = None
        self.state = State.RESUME

    def _give_up(self, reason: str):
        s = self.spot
        s.unremovable = True
        s.reason = reason
        self.unremovable.append(s)
        self.spot = None
        self.state = State.RESUME
        # REPORTED, not hidden. See the module docstring.

    # ---- output ------------------------------------------------------------

    def step(self, dt: float) -> Command:
        """Call at the control rate. Returns what the robot should do now."""
        c = Command(state=self.state.value)

        if self.state is State.SCAN:
            c.resume_coverage = True
            c.suction = self.t.power_clean
            return c

        if self.state is State.CHECK:
            # The robot is crossing the dirt under normal coverage motion. Do not
            # stop -- just dig in. The rear camera will tell us if it worked.
            c.resume_coverage = True
            c.suction = self.t.power_scrub
            return c

        if self.state is State.SCRUB:
            # Fro and back over the spot, exactly as specified. Coverage is PAUSED,
            # not abandoned -- it resumes at the same point.
            c.pause_coverage = True
            c.suction = self.t.power_scrub

            v = self.t.scrub_speed
            # INVARIANT 2. The hazard ceiling wins, even mid-scrub.
            if self.hazard_ceiling > 0.0:
                v = min(v, self.hazard_ceiling)

            c.linear_x = v * self.sweep_dir
            self.sweep_travel += abs(c.linear_x) * dt
            if self.sweep_travel >= self.t.sweep_m:
                self.sweep_dir *= -1                # reverse. fro -> back -> fro.
                self.sweep_travel = 0.0

            if self.spot and (self.clock() - self.spot.t_start) >= self.t.scrub_seconds:
                self._give_up("budget")
            return c

        if self.state is State.RESUME:
            self.state = State.SCAN                 # INVARIANT 1: coverage carries on
            c.resume_coverage = True
            c.suction = self.t.power_clean
            return c

        return c

    # ---- report ------------------------------------------------------------

    def report(self) -> dict:
        return {
            "state": self.state.value,
            "spots_cleaned": self.cleaned,
            "spots_unremovable": len(self.unremovable),
            "unremovable": [
                {"x": round(s.x, 2), "y": round(s.y, 2),
                 "sweeps": s.sweeps, "why": s.reason}
                for s in self.unremovable
            ],
            "claim": "Spots listed as unremovable were DETECTED and NOT REMOVED. "
                     "They are reported, not hidden. Coverage was completed "
                     "regardless -- scrubbing pauses the path, it never skips it.",
        }
