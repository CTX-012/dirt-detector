"""The appearance map. The clean-floor reference the whole detector depends on.

WHAT IT IS
----------
A persistent, per-site record of what every 5 cm cell of this floor looks like
WHEN CLEAN, as seen by the rear camera under its own LED.

WHY IT EXISTS
-------------
Because the reference is worth more than the model. Measured, at 5% FPR:

    no reference, no model  ->  0.08 recall     what everyone tries first
    reference,    no model  ->  0.58
    reference,  + DINOv2    ->  0.88

And because it is the only thing that makes SPECULAR GLOSS cancel. Gloss is
view-dependent: it depends on where the camera is, not on what the floor is. So
it does NOT cancel between a front camera at 32 degrees and a rear camera at 58
degrees -- measured, on a polished floor: 38% false-cleaned, 0 of 12 stains
caught, and no software fix works (we swept the illumination-field blur scale
from 12 cm to 1 m; every scale broken).

Compare the same cell against ITS OWN RECORD, taken by the SAME camera at the
SAME pose under the SAME LED, and the highlight is identical. It cancels exactly.
3.4% false-cleaned, 12 of 12 stains caught, gloss costs 1.4 points.

It also fills the piezo's blind spot. The piezo hears debris ENTERING THE BIN. A
dried stain never enters the bin -- the brush passes over it and the sensor stays
silent. That is precisely the dirt that needs a re-pass, and the map is the only
thing that sees it.

And it upgrades the claim: with a known-clean reference, "does this cell match its
clean state?" IS answerable. That is proof of CLEANLINESS, not merely proof of
CLEANING.

*** PATENT WARNING -- READ BEFORE BUILDING ON THIS ***
US 7,920,941 "Dust detection method and apparatus for cleaning robot" claims,
among other things: acquiring a current floor image; computing a DIFFERENCE
against a background image selected from a FEATURE MAP of stored floor images;
detecting a dusty area from that difference; and generating that feature map by
first having the robot CLEAN the floor, then storing floor images together with
the robot's locations from a localization system.

That is this file. Claim for claim, including the commissioning run.

This code is NOT legal advice and I am NOT a lawyer, and I cannot make it
"FTO-safe" -- only a patent attorney can tell you that. What you must do before
shipping: get a freedom-to-operate opinion on this patent number. Check the filing
date, the assignee, the expiry, and which jurisdictions it is live in. Grant
numbers near 7.9M are roughly 2011, so a ~2007-08 filing expires ~2027-28 --
inside the commercial window. This surfaces in Series-A diligence, not in the lab.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass

import numpy as np


@dataclass
class MapCell:
    vec: np.ndarray
    updated: float
    n_updates: int


class AppearanceMap:
    """Per-site record of the clean floor. Load it, compare against it, and be
    extremely careful about when you write to it."""

    def __init__(self, site: str, kind: str = "histogram", cell_size: float = 0.05,
                 fto_cleared: bool = False):
        # *** HARD GATE. DO NOT REMOVE UNTIL COUNSEL SAYS SO. ***
        #
        # This class implements a stored clean-floor reference map + difference.
        # That is the exact claim element shared by:
        #
        #   LG   US 11,422,566 B2  -- LIVE, granted 2022. Stores a floor
        #                             "background image"; compares front image,
        #                             rear-after image, and background to decide
        #                             whether cleaning is complete. This is the
        #                             closest live patent to this file and it is
        #                             the first thing to send to an attorney.
        #   Samsung US 7,920,941 B2 -- difference vs a FEATURE MAP of clean floor
        #                             images + adjust cleaning power. Google Patents
        #                             says "Expired - Fee Related", adjusted
        #                             expiration 2027-07-04. VERIFY THE LAPSE IS
        #                             FINAL; check for surviving continuations.
        #   US 9,820,625 B2         -- stores a "first reference image ... in the
        #                             cleaned state after cleaning", then compares.
        #
        # The SPATIAL detector (dirt_detector.SpatialBackend) stores NOTHING -- no
        # map, no reference image, no prior run -- and benchmarks at 0.62 recall
        # @5%FPR versus 0.58 for this map-based path. The encumbered route is not
        # even the better one right now. Ship spatial; keep this behind the gate.
        if not fto_cleared:
            raise RuntimeError(
                "AppearanceMap is PATENT-ENCUMBERED and is not cleared for use.\n"
                "  See LG US 11,422,566 B2 (live) and Samsung US 7,920,941 B2.\n"
                "  The default shipping path is dirt_detector backend='spatial',\n"
                "  which stores NO reference and scores HIGHER (0.62 vs 0.58).\n"
                "  Pass fto_cleared=True only when an attorney has said so in writing."
            )
        self.site = site
        self.kind = kind          # must match the detector backend
        self.cell_size = cell_size
        self.cells: dict[tuple[int, int], MapCell] = {}
        self.built = 0.0
        self.commissioned = False

    # ---- the only write path, and the only thing standing between you and a
    # ---- robot that learns to ignore its own failures -----------------------

    def update(self, cell, vec, verdict: str, force_commission: bool = False):
        """Write a cell into the map. ONLY from a CLEAN verdict. Ever.

        THIS RULE IS THE WHOLE INTEGRITY OF THE SYSTEM AND IT IS ONE LINE.

        Floors legitimately change -- wear, re-waxing, sun bleaching -- so the map
        must adapt. But if it adapts EAGERLY, it will absorb a permanent stain
        into "normal floor" and silently stop reporting it. The robot would learn
        to ignore exactly the dirt it failed to clean, and the failure would be
        invisible: the reports would get cleaner as the floor got dirtier.

        So: update from cells that verified CLEAN. NEVER from a cell you gave up
        on. Never from an UNKNOWN. Never from a STILL_DIRTY, no matter how many
        times you have seen it.

        force_commission is ONLY for the commissioning run on a floor a human has
        certified clean. It is not a shortcut.
        """
        if not force_commission and verdict != "clean":
            return False
        prev = self.cells.get(cell)
        self.cells[cell] = MapCell(
            vec=np.asarray(vec, np.float32),
            updated=time.time(),
            n_updates=(prev.n_updates + 1) if prev else 1)
        return True

    def get(self, cell):
        c = self.cells.get(cell)
        return c.vec if c else None

    # ---- state --------------------------------------------------------------

    def ready(self, min_cells: int = 200) -> bool:
        """A map with 12 cells in it is not a reference, it is a rumour."""
        return self.commissioned and len(self.cells) >= min_cells

    def coverage(self) -> int:
        return len(self.cells)

    def stale_cells(self, max_age_days: float = 30.0):
        """Cells we have not re-confirmed lately. Also: `unremovable` cells must
        be RE-TESTED on this schedule rather than trusted forever -- a scuff that
        would not come up in March may come up after a re-wax in April."""
        cutoff = time.time() - max_age_days * 86400
        return [c for c, m in self.cells.items() if m.updated < cutoff]

    # ---- persistence --------------------------------------------------------

    def save(self, path: str):
        if not self.cells:
            raise ValueError("refusing to save an empty map")
        keys = np.array([[k[0], k[1]] for k in self.cells], np.int32)
        vecs = np.stack([m.vec for m in self.cells.values()])
        meta = dict(site=self.site, kind=self.kind, cell_size=self.cell_size,
                    built=self.built, commissioned=self.commissioned,
                    n=len(self.cells))
        np.savez_compressed(path, keys=keys, vecs=vecs,
                            updated=np.array([m.updated for m in self.cells.values()]),
                            n_updates=np.array([m.n_updates for m in self.cells.values()]),
                            meta=json.dumps(meta))

    @classmethod
    def load(cls, path: str) -> "AppearanceMap":
        z = np.load(path, allow_pickle=False)
        meta = json.loads(str(z["meta"]))
        # A map that is already ON DISK was written by someone who passed the
        # gate. Loading it is not a second decision -- but it IS still encumbered,
        # so the file existing at all is the audit trail.
        m = cls(meta["site"], meta["kind"], meta["cell_size"], fto_cleared=True)
        m.built = meta["built"]
        m.commissioned = bool(meta["commissioned"])
        for k, v, u, n in zip(z["keys"], z["vecs"], z["updated"], z["n_updates"]):
            m.cells[(int(k[0]), int(k[1]))] = MapCell(v, float(u), int(n))
        return m

    # ---- commissioning ------------------------------------------------------

    def commission(self, cells_and_vecs):
        """Build the map from a floor a HUMAN has certified clean.

        Run 1 at a new site is a CALIBRATION PASS. The robot cleans, records, and
        makes NO verification claims -- because it has no reference yet and a
        detector without a reference scores 0.08.

        This is a real product behaviour, not a hidden assumption. Sell it as
        commissioning. A facility manager understands "the first clean teaches it
        your floor" far better than they will understand a silently wrong report.
        """
        for cell, vec in cells_and_vecs:
            self.update(cell, vec, "clean", force_commission=True)
        self.built = time.time()
        self.commissioned = True
        return len(self.cells)
