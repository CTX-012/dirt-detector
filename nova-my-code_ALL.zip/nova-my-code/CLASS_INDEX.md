# Code by object class

Which files deal with each floor object. A file counts when the class word appears in it at least twice; most-mentioned first.

Locked-6 names: hair → `loose_debris` (tracked sub-class) · dirt/debris → `loose_debris` · paper → `paper_flat` · textile/sock/cloth → `soft_object` · cable/wire/cord → `cable_cord` · poop → `pet_waste` · spill → `spill_coloured`.


## hair — 16 files

| Mentions | File | What it is |
|---|---|---|
| 24 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 16 | `01_perception_kit_classes/kit/hair_ingest.py` | Turn human hair masks (labelme JSON) into YOLO-seg labels, refusing anything that breaks the rules (2026-10-07). |
| 14 | `01_perception_kit_classes/kit/test_inspect.py` | Tests for inspect_dataset.py — each of the five traps this project already hit must be flagged. |
| 11 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/datasets.py` | Datasets. What exists, what does not, and what you will have to pay for. |
| 11 | `01_perception_kit_classes/kit/test_paired.py` | Tests for paired_compare.py — including the case the CI-overlap rule gets wrong. |
| 9 | `01_perception_kit_classes/kit/test_g8.py` | Tests for g8_agreement.py — the selftests named in G8_DOUBLE_LABEL.md, on synthetic labels. |
| 8 | `01_perception_kit_classes/kit/test_hair_ingest.py` | Tests for hair_ingest.py — human masks become YOLO-seg only if they obey the labelling rules. |
| 7 | `01_perception_kit_classes/kit/hair_split.py` | Build the hair mask-labelling workspace with the held-out split fixed BEFORE anything is labelled (2026-10-07). |
| 5 | `01_perception_kit_classes/kit/g8_agreement.py` | G8 — inter-annotator agreement on a blind double-labelled set. |
| 4 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 3 | `01_perception_kit_classes/kit/test_score_real.py` | Tests for score_real.py — the pre-registered hit and false-safe rules, on a synthetic real val. |
| 3 | `01_perception_kit_classes/kit/test_make_train_view.py` | Tests for make_train_view.py — ultralytics must read the REMAPPED labels, never the originals. |
| 3 | `01_perception_kit_classes/kit/test_hair_split.py` | Tests for hair_split.py — the held-out set must be fixed, contiguous, guarded and duplicate-free. |
| 3 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 2 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |
| 2 | `01_perception_kit_classes/kit/paired_compare.py` | Phase 5 — compare two arms that were scored on THE SAME objects (added 2026-09-28). |

## dirt / debris — 68 files

| Mentions | File | What it is |
|---|---|---|
| 57 | `03_dirt_detector_shootout/dirt/scripts/benchmark.py` | Benchmark the NOVA perception stack on real + synthetic data. |
| 42 | `05_nova_apps_vision_voice_social/nova_backup/auto_cleaner.py` | auto_cleaner.py - roller-aligned dirt cleaning. |
| 42 | `02_nova_robot_ros2/nova/nova/auto_cleaner.py` | auto_cleaner.py - roller-aligned dirt cleaning. |
| 37 | `03_dirt_detector_shootout/dirt/webapp/app.py` | NOVA demo web app -- upload an image / before-after pair / video, or use the |
| 28 | `02_nova_robot_ros2/nova/nova/dirt_finder.py` | dirt_finder.py (v2) - nadir-camera dirt detection via map-frame evidence grid. |
| 27 | `05_nova_apps_vision_voice_social/nova_backup/dirt_mapper.py` | dirt_mapper.py - find dirt with the CAMERA, not by asking Gazebo. |
| 27 | `02_nova_robot_ros2/nova/nova/dirt_mapper.py` | dirt_mapper.py - find dirt with the CAMERA, not by asking Gazebo. |
| 26 | `02_nova_robot_ros2/nova/nova/world_cleaner.py` | world_cleaner.py - whole-world coverage + clean-on-detect, native to nova. |
| 24 | `03_dirt_detector_shootout/dirt/scripts/make_synthetic.py` | Build a synthetic before/after floor benchmark in the BAN layout that |
| 23 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/verification.py` | Cleaning verification: did the pass actually change this floor cell? |
| 22 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/coverage_control.py` | Adaptive coverage. Fly over clean floor, dwell and dig in on dirt. |
| 22 | `02_nova_robot_ros2/nova/nova/room_cleaner.py` | room_cleaner.py - clean the world ROOM BY ROOM (lawnmower sweep per room). |
| 21 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/ab_controllers.py` | A/B the two controllers on identical data. Then stop arguing. |
| 20 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 19 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/controllers.py` | Two controllers. One interface. Swap with one config line and let the floor decide. |
| 17 | `03_dirt_detector_shootout/dirt/scripts/download_roboflow.py` | Pull clean-floor datasets from Roboflow Universe. |
| 17 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/dirt_detector.py` | Dirt detection. The thing that tells you a floor is unclean. |
| 15 | `03_dirt_detector_shootout/dirt/scripts/make_indoor_benchmark.py` | Composite controlled dirt onto REAL indoor floor photos (homes, airports, |
| 14 | `03_dirt_detector_shootout/dirt/scripts/shootout_harness.py` | Method shootout harness. |
| 14 | `03_dirt_detector_shootout/dirt/scripts/scorers/vlm_smol.py` | VLM absolute per-cell scorer — SmolVLM next-token logit probe (category (d)). |
| 14 | `02_nova_robot_ros2/nova/nova/dirt_cleaner.py` | dirt_cleaner.py — queries Gazebo for dirt_* models, deletes when brush cleans. |
| 14 | `02_nova_robot_ros2/nova/launch/clean.launch.py` | clean.launch.py - the full autonomous cleaning stack (yesterday's working setup). |
| 13 | `02_nova_robot_ros2/nova/nova/dirt_spawner.py` | dirt_spawner.py — spawns magenta dirt via ros_gz_sim create tool. Call /make_dirty. |
| 12 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/datasets.py` | Datasets. What exists, what does not, and what you will have to pay for. |
| 12 | `02_nova_robot_ros2/nova/setup.py` |  |
| 12 | `02_nova_robot_ros2/nova/nova/dirt_detector.py` | dirt_detector.py — detects magenta dirt from the down camera, projects to floor. |
| 11 | `03_dirt_detector_shootout/dirt/scripts/scorers/spatial_diff.py` | Spatial-diff — the shipping default, wrapped for the shootout. |
| 11 | `03_dirt_detector_shootout/dirt/scripts/scorers/base.py` | Scorer contract for the method shootout. |
| 11 | `01_perception_kit_classes/kit/test_score_real.py` | Tests for score_real.py — the pre-registered hit and false-safe rules, on a synthetic real val. |
| 10 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/clean_loop.py` | THE LOOP. Detect -> clean -> check -> not clean? scrub in place -> move on. |
| 10 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/loop_engine.py` | nova_desktop -- the clean loop on a laptop. No ROS, no robot. Windows/Mac/Linux. |
| 10 | `02_nova_robot_ros2/nova/nova/dirt_manager.py` | dirt_manager.py — dirt spots (RViz markers) that vanish when cleaned. |
| 9 | `03_dirt_detector_shootout/dirt/scripts/scorers/saliency_sr.py` | Spectral-residual saliency — the reference-free Bormann trap. |
| 9 | `02_nova_robot_ros2/nova/nova/explore_cleaner.py` | explore_cleaner.py - clean dirt WHILE frontier-exploring an unknown world. |
| 8 | `04_robot_tests_obstacle_speed/nova_tests/smoke.py` | Construct every nova node. Catches the class of bug where a node attribute |
| 8 | `03_dirt_detector_shootout/dirt/scripts/verify_shootout.py` | Automated verification of the shootout — mechanical checks, not eyeballing. |
| 8 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/appearance_map.py` | The appearance map. The clean-floor reference the whole detector depends on. |
| 8 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_desktop.py` | nova_desktop -- run the clean loop on Windows with a webcam, a video, or an image. |
| 8 | `02_nova_robot_ros2/nova/launch/dirt_find.launch.py` | dirt_find.launch.py - realistic-dirt detection (dust + paper) + vacuum. |
| 8 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 7 | `04_robot_tests_obstacle_speed/nova_tests/decompose.py` | Decompose each coverage pass's wall time from a run's nova_clean.log: |
| 6 | `05_nova_apps_vision_voice_social/nova-ai/ros2_ws/src/nova_coverage_tracker/nova_coverage_tracker/coverage_store.py` | coverage_store — pure rasterization + stats. No ROS dependencies. |
| 6 | `03_dirt_detector_shootout/dirt/scripts/scorers/deep_hist.py` | Deep-hist — a richer histogram differential than the incumbent. |
| 6 | `02_nova_robot_ros2/nova_coverage_tracker/nova_coverage_tracker/coverage_store.py` | coverage_store — pure rasterization + stats. No ROS dependencies. |
| 6 | `02_nova_robot_ros2/nova/launch/room_clean.launch.py` | room_clean.launch.py - rooms + dirt detection + room-by-room cleaning. |
| 5 | `05_nova_apps_vision_voice_social/nova_backup/cleaning.launch.py` | cleaning.launch.py — spawn 3 dirt patches + autonomous clean. |
| 5 | `03_dirt_detector_shootout/dirt/scripts/scorers/dinov2_diff.py` | DINOv2-diff — frozen facebook/dinov2-small, cosine-diff vs the clean reference. |
| 5 | `02_nova_robot_ros2/nova/launch/cleaning.launch.py` | cleaning.launch.py — spawn 3 dirt patches + autonomous clean. |
| 5 | `01_perception_kit_classes/kit/test_inspect.py` | Tests for inspect_dataset.py — each of the five traps this project already hit must be flagged. |
| 5 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 4 | `04_robot_tests_obstacle_speed/nova_tests/mission_report.py` | Acceptance report for one run directory against the MISSION definition: |
| 4 | `03_dirt_detector_shootout/dirt/scripts/scorers/padim.py` | PaDiM — the canonical "PatchCore trap" candidate (train-on-clean, category b). |
| 4 | `03_dirt_detector_shootout/dirt/scripts/scorers/histogram_diff.py` | Histogram-differential — the incumbent, the baseline to beat. |
| 4 | `03_dirt_detector_shootout/dirt/scripts/scorers/gmm_novelty.py` | GMM novelty — Grünauer-style unsupervised, train-on-clean. |
| 4 | `01_perception_kit_classes/kit/test_g8.py` | Tests for g8_agreement.py — the selftests named in G8_DOUBLE_LABEL.md, on synthetic labels. |
| 4 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |
| 3 | `04_robot_tests_obstacle_speed/nova_tests/window.py` | Same-window comparison across runs: PASS 2 start + [A, B] seconds. |
| 3 | `04_robot_tests_obstacle_speed/nova_tests/capture_detect_view.py` | Capture /dirt/detect_view frames (plus the raw camera frame and the robot pose) |
| 3 | `03_dirt_detector_shootout/dirt/scripts/download_kaggle.py` | Download public Kaggle floor/room datasets (no account needed - kagglehub). |
| 3 | `01_perception_kit_classes/kit/test_paired.py` | Tests for paired_compare.py — including the case the CI-overlap rule gets wrong. |
| 2 | `05_nova_apps_vision_voice_social/nova_backup/nova.launch.py` |  |
| 2 | `03_dirt_detector_shootout/dirt/scripts/video_test.py` | End-to-end test of the live loop on a synthetic video. |
| 2 | `02_nova_robot_ros2/nova/launch/world_clean.launch.py` | world_clean.launch.py - whole-world coverage + clean-on-detect. |
| 2 | `02_nova_robot_ros2/nova/launch/nova.launch.py` |  |
| 2 | `01_perception_kit_classes/kit/test_make_train_view.py` | Tests for make_train_view.py — ultralytics must read the REMAPPED labels, never the originals. |
| 2 | `01_perception_kit_classes/kit/test_hair_ingest.py` | Tests for hair_ingest.py — human masks become YOLO-seg only if they obey the labelling rules. |
| 2 | `01_perception_kit_classes/kit/g8_agreement.py` | G8 — inter-annotator agreement on a blind double-labelled set. |
| 2 | `01_perception_kit_classes/contract_hazard_report/contract/test_contract.py` | Every contract rule is broken once, in isolation, and must be caught with exactly its own code. |

## paper — 12 files

| Mentions | File | What it is |
|---|---|---|
| 8 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 7 | `02_nova_robot_ros2/nova/nova/dirt_finder.py` | dirt_finder.py (v2) - nadir-camera dirt detection via map-frame evidence grid. |
| 5 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 4 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 3 | `01_perception_kit_classes/contract_hazard_report/contract/contract_check.py` | Check PerceptionFrame messages (JSON form) against perception interface contract v0.1. |
| 2 | `04_robot_tests_obstacle_speed/nova_tests/run_report.py` | Report for one run directory: bring-up, per-pass time/coverage/rate, |
| 2 | `04_robot_tests_obstacle_speed/nova_tests/mission_report.py` | Acceptance report for one run directory against the MISSION definition: |
| 2 | `03_dirt_detector_shootout/dirt/scripts/download_roboflow.py` | Pull clean-floor datasets from Roboflow Universe. |
| 2 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/datasets.py` | Datasets. What exists, what does not, and what you will have to pay for. |
| 2 | `01_perception_kit_classes/kit/test_inspect.py` | Tests for inspect_dataset.py — each of the five traps this project already hit must be flagged. |
| 2 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |
| 2 | `01_perception_kit_classes/kit/inspect_dataset.py` | Open a downloaded dataset BEFORE training on it (added 2026-10-01). |

## textile / sock / cloth — 8 files

| Mentions | File | What it is |
|---|---|---|
| 7 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 7 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 6 | `03_dirt_detector_shootout/dirt/webapp/app.py` | NOVA demo web app -- upload an image / before-after pair / video, or use the |
| 5 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 4 | `05_nova_apps_vision_voice_social/nova-vision-bot-v5/robot/main.py` | NOVA Vision Bot v4.1 — entry point. |
| 3 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/datasets.py` | Datasets. What exists, what does not, and what you will have to pay for. |
| 3 | `01_perception_kit_classes/contract_hazard_report/contract/contract_check.py` | Check PerceptionFrame messages (JSON form) against perception interface contract v0.1. |
| 2 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |

## cable / wire / cord — 12 files

| Mentions | File | What it is |
|---|---|---|
| 16 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 11 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 8 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/datasets.py` | Datasets. What exists, what does not, and what you will have to pay for. |
| 7 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 6 | `01_perception_kit_classes/kit/g8_agreement.py` | G8 — inter-annotator agreement on a blind double-labelled set. |
| 6 | `01_perception_kit_classes/contract_hazard_report/contract/contract_check.py` | Check PerceptionFrame messages (JSON form) against perception interface contract v0.1. |
| 5 | `01_perception_kit_classes/kit/test_g8.py` | Tests for g8_agreement.py — the selftests named in G8_DOUBLE_LABEL.md, on synthetic labels. |
| 4 | `01_perception_kit_classes/contract_hazard_report/contract/test_contract.py` | Every contract rule is broken once, in isolation, and must be caught with exactly its own code. |
| 3 | `01_perception_kit_classes/kit/test_score_real.py` | Tests for score_real.py — the pre-registered hit and false-safe rules, on a synthetic real val. |
| 2 | `01_perception_kit_classes/kit/test_inspect.py` | Tests for inspect_dataset.py — each of the five traps this project already hit must be flagged. |
| 2 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |
| 2 | `01_perception_kit_classes/kit/inspect_dataset.py` | Open a downloaded dataset BEFORE training on it (added 2026-10-01). |

## poop / pet waste — 6 files

| Mentions | File | What it is |
|---|---|---|
| 7 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/datasets.py` | Datasets. What exists, what does not, and what you will have to pay for. |
| 7 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 5 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 3 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 2 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |
| 2 | `01_perception_kit_classes/contract_hazard_report/contract/contract_check.py` | Check PerceptionFrame messages (JSON form) against perception interface contract v0.1. |

## spill / liquid — 10 files

| Mentions | File | What it is |
|---|---|---|
| 12 | `01_perception_kit_classes/kit/test_kit.py` | Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator. |
| 10 | `01_perception_kit_classes/kit/test_inspect.py` | Tests for inspect_dataset.py — each of the five traps this project already hit must be flagged. |
| 8 | `03_dirt_detector_shootout/dirt/nova_desktop_pkg/nova_perception/verification.py` | Cleaning verification: did the pass actually change this floor cell? |
| 8 | `01_perception_kit_classes/kit/migrate_policy.py` | Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain. |
| 7 | `01_perception_kit_classes/contract_hazard_report/contract/contract_check.py` | Check PerceptionFrame messages (JSON form) against perception interface contract v0.1. |
| 3 | `01_perception_kit_classes/kit/relabel_locked6.py` | Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place. |
| 2 | `03_dirt_detector_shootout/dirt/scripts/make_synthetic.py` | Build a synthetic before/after floor benchmark in the BAN layout that |
| 2 | `01_perception_kit_classes/kit/score_real.py` | Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29). |
| 2 | `01_perception_kit_classes/kit/g8_agreement.py` | G8 — inter-annotator agreement on a blind double-labelled set. |
| 2 | `01_perception_kit_classes/contract_hazard_report/contract/test_contract.py` | Every contract rule is broken once, in isolation, and must be caught with exactly its own code. |
