# nova-my-code

My own Python code for the NOVA floor-cleaning robot and its perception, collected 2026-10-29: **242 `.py` files** in 6 groups.

**What it does:** the robot finds objects on the floor (dirt, hair, spills, paper, socks/textiles, cables/wires, pet waste), decides per object whether to CLEAN, AVOID or ALERT, and covers the floor. See `CLASS_INDEX.md` for which file handles which object.

| Folder | Files | What's in it |
|---|---|---|
| `01_perception_kit_classes/` | 32 | Perception tool kit: dataset inspection, OBB→seg conversion, remap to the locked 6 classes, training view, hair split/ingest, SSL pretraining, real-val scoring, paired statistics, calibration, interface contract, hazard levels |
| `02_nova_robot_ros2/` | 52 | NOVA robot ROS 2 packages: cleaning behaviour (world/room cleaner, dirt finder/detector/cleaner, coverage, missions, docking, floors), launch files, coverage tracker |
| `03_dirt_detector_shootout/` | 33 | Dirt detector shootout (recall@5%FPR): histogram, PaDiM, GMM, DINOv2, saliency, VLM scorers + harness, plus the desktop perception demo |
| `04_robot_tests_obstacle_speed/` | 19 | Robot sim test scripts: obstacle/jam, waypoint failure, freeze, climb, speed, duty cycle, termination rule, mission reports |
| `05_nova_apps_vision_voice_social/` | 72 | NOVA apps: vision bot, voice gate (GPU speech-to-text), social receptionist kiosk, LLM/memory agent |
| `06_home_scripts/` | 34 | Standalone scripts from the home folder: mapping, auto-navigation, exploration, LLM robot experiments |

## Not in this repo, on purpose

- **Datasets, images, model weights.** Weights trained on public data are benchmark-only and are not distributed.
- **Code already on GitHub elsewhere:** `Rob` (robot vacuum coverage stack) → `CTX-012/Rob`; `nova-vlm-1bit` and its worktrees → `CTX-012/nova-vlm-1bit`.
- **Third-party code:** AWS RoboMaker worlds, m-explore-ros2, rf2o_laser_odometry, Isaac Sim, Blender, AnomalyDINO.
- **Backups** (`*.bak`) and auto-generated ROS lint tests.
- **Code on the Windows 3080:** the deployed detector `nova_seg_r1` and the arbiter `identify.py`.

No API keys are in this code: scripts read them from environment variables. Paths inside point at the original machine and need changing before running.

## Running the perception tests

```bash
cd 01_perception_kit_classes/kit
PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python3 -m pytest -q -p no:randomly
```
