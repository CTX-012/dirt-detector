#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22 - Logger
═══════════════════════════════════════════════════════════════════════════════
All logs in terminal. Timestamps on everything. Full traceability.
═══════════════════════════════════════════════════════════════════════════════
"""

from datetime import datetime
from enum import Enum
from typing import Optional
import sys


class LogLevel(Enum):
    DEBUG = 0
    INFO = 1
    WARN = 2
    ERROR = 3


class LogCategory(Enum):
    SENSOR = "SENSOR"
    STATE = "STATE"
    VLM = "VLM"
    LLM = "LLM"
    MOVE = "MOVE"
    MEMORY = "MEMORY"
    VOID = "VOID"
    DOOR = "DOOR"
    SAFETY = "SAFETY"
    SYSTEM = "SYSTEM"


class Colors:
    """ANSI color codes for terminal output."""
    CYAN = "\033[36m"
    YELLOW = "\033[33m"
    MAGENTA = "\033[35m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    RED = "\033[31m"
    WHITE = "\033[37m"
    BOLD = "\033[1m"
    RESET = "\033[0m"
    
    # Category-specific colors
    CATEGORY_COLORS = {
        LogCategory.SENSOR: CYAN,
        LogCategory.STATE: YELLOW,
        LogCategory.VLM: MAGENTA,
        LogCategory.LLM: GREEN,
        LogCategory.MOVE: WHITE,
        LogCategory.MEMORY: BLUE,
        LogCategory.VOID: RED,
        LogCategory.DOOR: CYAN,
        LogCategory.SAFETY: RED,
        LogCategory.SYSTEM: WHITE,
    }
    
    # Level-specific colors
    LEVEL_COLORS = {
        LogLevel.DEBUG: WHITE,
        LogLevel.INFO: WHITE,
        LogLevel.WARN: YELLOW,
        LogLevel.ERROR: RED,
    }


class NovaLogger:
    """
    Centralized logging for NOVA.
    
    Features:
    - Timestamps on every line
    - Color coding by category
    - Level filtering
    - Consistent format
    """
    
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        """Singleton pattern - one logger for entire system."""
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance
    
    def __init__(
        self,
        min_level: LogLevel = LogLevel.INFO,
        use_colors: bool = True,
        show_timestamps: bool = True
    ):
        if self._initialized:
            return
            
        self.min_level = min_level
        self.use_colors = use_colors
        self.show_timestamps = show_timestamps
        self._initialized = True
        
        # Session start marker
        self._log_raw("\n" + "═" * 70)
        self._log_raw("  NOVA SENTINEL v22 - Session Started")
        self._log_raw(f"  {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        self._log_raw("═" * 70 + "\n")
    
    def _get_timestamp(self) -> str:
        """Get current timestamp in consistent format."""
        return datetime.now().strftime("%H:%M:%S.%f")[:-3]  # HH:MM:SS.mmm
    
    def _colorize(self, text: str, color: str) -> str:
        """Wrap text in ANSI color codes."""
        if self.use_colors:
            return f"{color}{text}{Colors.RESET}"
        return text
    
    def _log_raw(self, message: str):
        """Print raw message to stdout."""
        print(message, flush=True)
    
    def log(
        self,
        category: LogCategory,
        message: str,
        level: LogLevel = LogLevel.INFO,
        data: Optional[dict] = None
    ):
        """
        Log a message with timestamp and category.
        
        Args:
            category: Which system component
            message: The log message
            level: Severity level
            data: Optional structured data to append
        """
        if level.value < self.min_level.value:
            return
        
        # Build log line
        parts = []
        
        # Timestamp
        if self.show_timestamps:
            timestamp = self._get_timestamp()
            parts.append(f"[{timestamp}]")
        
        # Category with color
        cat_color = Colors.CATEGORY_COLORS.get(category, Colors.WHITE)
        cat_str = self._colorize(f"[{category.value:6s}]", cat_color)
        parts.append(cat_str)
        
        # Level indicator for WARN/ERROR
        if level == LogLevel.WARN:
            parts.append(self._colorize("⚠", Colors.YELLOW))
        elif level == LogLevel.ERROR:
            parts.append(self._colorize("✗", Colors.RED))
        
        # Message
        msg_color = Colors.LEVEL_COLORS.get(level, Colors.WHITE)
        parts.append(self._colorize(message, msg_color))
        
        # Print main line
        self._log_raw(" ".join(parts))
        
        # Print data if provided (indented)
        if data:
            for key, value in data.items():
                data_line = f"           {key}: {value}"
                self._log_raw(self._colorize(data_line, Colors.WHITE))
    
    # ─────────────────────────────────────────────────────────────────────────
    # CONVENIENCE METHODS
    # ─────────────────────────────────────────────────────────────────────────
    
    def sensor(self, message: str, data: dict = None):
        """Log sensor data."""
        self.log(LogCategory.SENSOR, message, LogLevel.INFO, data)
    
    def state(self, message: str, data: dict = None):
        """Log state transition."""
        self.log(LogCategory.STATE, message, LogLevel.INFO, data)
    
    def vlm(self, message: str, data: dict = None):
        """Log VLM (vision) output."""
        self.log(LogCategory.VLM, message, LogLevel.INFO, data)
    
    def llm(self, message: str, data: dict = None):
        """Log LLM (decision) output."""
        self.log(LogCategory.LLM, message, LogLevel.INFO, data)
    
    def move(self, message: str, data: dict = None):
        """Log movement command."""
        self.log(LogCategory.MOVE, message, LogLevel.INFO, data)
    
    def memory(self, message: str, data: dict = None):
        """Log memory update."""
        self.log(LogCategory.MEMORY, message, LogLevel.INFO, data)
    
    def void(self, message: str, data: dict = None):
        """Log void detection (always WARN level)."""
        self.log(LogCategory.VOID, message, LogLevel.WARN, data)
    
    def door(self, message: str, data: dict = None):
        """Log door detection."""
        self.log(LogCategory.DOOR, message, LogLevel.INFO, data)
    
    def safety(self, message: str, data: dict = None):
        """Log safety event (always WARN level)."""
        self.log(LogCategory.SAFETY, message, LogLevel.WARN, data)
    
    def system(self, message: str, level: LogLevel = LogLevel.INFO, data: dict = None):
        """Log system event."""
        self.log(LogCategory.SYSTEM, message, level, data)
    
    def error(self, category: LogCategory, message: str, data: dict = None):
        """Log an error."""
        self.log(category, message, LogLevel.ERROR, data)
    
    def debug(self, category: LogCategory, message: str, data: dict = None):
        """Log debug info (only if min_level is DEBUG)."""
        self.log(category, message, LogLevel.DEBUG, data)
    
    # ─────────────────────────────────────────────────────────────────────────
    # SPECIAL FORMATTERS
    # ─────────────────────────────────────────────────────────────────────────
    
    def lidar_summary(self, front: float, left: float, right: float, back: float):
        """Log LiDAR readings in compact format."""
        self.sensor(f"LiDAR: F={front:.2f}m L={left:.2f}m R={right:.2f}m B={back:.2f}m")
    
    def state_transition(self, from_state: str, to_state: str, reason: str = ""):
        """Log state machine transition."""
        msg = f"{from_state} → {to_state}"
        if reason:
            msg += f" ({reason})"
        self.state(msg)
    
    def vlm_response(self, scene_type: str, density: str, door_direction: Optional[str] = None):
        """Log VLM analysis result."""
        msg = f"Scene: {scene_type} | Density: {density}"
        if door_direction:
            msg += f" | Door: {door_direction}"
        self.vlm(msg)
    
    def llm_decision(self, action: str, reason: str):
        """Log LLM decision."""
        self.llm(f"Decision: {action}", {"reason": reason})
    
    def movement_command(self, linear: float, angular: float, duration: float = None):
        """Log movement command."""
        msg = f"cmd_vel: linear={linear:.2f} angular={angular:.2f}"
        if duration:
            msg += f" for {duration:.1f}s"
        self.move(msg)
    
    def object_detected(self, label: str, confidence: float, x: float, y: float):
        """Log object detection."""
        self.memory(f"Detected: {label} (conf={confidence:.2f}) at ({x:.2f}, {y:.2f})")
    
    def separator(self, title: str = ""):
        """Print a visual separator."""
        if title:
            self._log_raw(f"\n{'─' * 20} {title} {'─' * 20}")
        else:
            self._log_raw("─" * 50)


# ═══════════════════════════════════════════════════════════════════════════════
# GLOBAL LOGGER INSTANCE
# ═══════════════════════════════════════════════════════════════════════════════

# Create singleton instance
logger = NovaLogger()


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Force new instance for testing
    NovaLogger._instance = None
    log = NovaLogger(min_level=LogLevel.DEBUG)
    
    log.separator("SENSOR TEST")
    log.lidar_summary(1.5, 0.8, 2.1, 3.0)
    
    log.separator("STATE TEST")
    log.state_transition("STOP", "WAIT", "stabilizing")
    log.state_transition("WAIT", "CAPTURE", "500ms elapsed")
    
    log.separator("VLM TEST")
    log.vlm_response("corridor", "low", "LEFT")
    
    log.separator("LLM TEST")
    log.llm_decision("TURN_LEFT", "Door detected on left side")
    
    log.separator("MOVEMENT TEST")
    log.movement_command(0.0, 0.35, 2.5)
    
    log.separator("MEMORY TEST")
    log.object_detected("chair", 0.75, 2.3, -1.1)
    
    log.separator("VOID TEST")
    log.void("All directions clear - retreating", {
        "front": "5.2m",
        "left": "4.8m",
        "right": "6.1m"
    })
    
    log.separator("SAFETY TEST")
    log.safety("Emergency stop triggered", {"obstacle_distance": "0.22m"})
    
    log.separator("ERROR TEST")
    log.error(LogCategory.SYSTEM, "VLM timeout after 10s")
    
    print("\n✅ Logger test complete")
