#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22 - Memory System
═══════════════════════════════════════════════════════════════════════════════
Simple JSON-based persistent memory. No frameworks. Full control.
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
import math


@dataclass
class ObjectMemory:
    """A detected object with world coordinates."""
    id: str
    label: str
    x: float
    y: float
    confidence: float
    views: int
    first_seen: str
    last_seen: str
    status: str  # "confirmed", "uncertain", "lost"


@dataclass
class RoomMemory:
    """A discovered room with properties."""
    id: str
    room_type: str  # "living_room", "kitchen", "corridor", "unknown"
    center_x: float
    center_y: float
    object_density: str  # "high", "medium", "low", "empty"
    explored: bool
    doors: List[str]
    discovered: str


@dataclass
class ObstacleMemory:
    """A static obstacle location."""
    id: str
    x: float
    y: float
    radius: float
    hit_count: int
    last_hit: str


class NovaMemory:
    """
    Persistent memory system for NOVA.
    
    Features:
    - JSON file persistence
    - Object merging by distance
    - Coordinate-based storage (not direction-only)
    - Auto-repair for missing keys
    """
    
    def __init__(self, base_path: str = "memory/", merge_radius: float = 0.5):
        self.base_path = base_path
        self.merge_radius = merge_radius
        
        # Ensure directory exists
        os.makedirs(base_path, exist_ok=True)
        
        # File paths
        self.objects_file = os.path.join(base_path, "objects.json")
        self.rooms_file = os.path.join(base_path, "rooms.json")
        self.obstacles_file = os.path.join(base_path, "obstacles.json")
        self.visited_file = os.path.join(base_path, "visited.json")
        self.lessons_file = os.path.join(base_path, "lessons.json")
        
        # In-memory data
        self.objects: List[Dict] = []
        self.rooms: List[Dict] = []
        self.obstacles: List[Dict] = []
        self.visited_cells: set = set()
        self.lessons: List[Dict] = []
        
        # Counters for IDs
        self.object_counter = 0
        self.room_counter = 0
        self.obstacle_counter = 0
        
        # Load existing data
        self._load_all()
    
    # ─────────────────────────────────────────────────────────────────────────
    # LOADING
    # ─────────────────────────────────────────────────────────────────────────
    
    def _load_json(self, filepath: str, default: any) -> any:
        """Load JSON file with fallback to default."""
        try:
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            print(f"[MEMORY] Warning: Could not load {filepath}: {e}")
        return default
    
    def _load_all(self):
        """Load all memory files."""
        # Objects
        data = self._load_json(self.objects_file, {"objects": [], "counter": 0})
        self.objects = data.get("objects", [])
        self.object_counter = data.get("counter", len(self.objects))
        
        # Rooms
        data = self._load_json(self.rooms_file, {"rooms": [], "counter": 0})
        self.rooms = data.get("rooms", [])
        self.room_counter = data.get("counter", len(self.rooms))
        
        # Obstacles
        data = self._load_json(self.obstacles_file, {"obstacles": [], "counter": 0})
        self.obstacles = data.get("obstacles", [])
        self.obstacle_counter = data.get("counter", len(self.obstacles))
        
        # Visited cells (stored as list, converted to set)
        data = self._load_json(self.visited_file, {"cells": []})
        self.visited_cells = set(tuple(c) for c in data.get("cells", []))
        
        # RLHF Lessons
        data = self._load_json(self.lessons_file, {"lessons": []})
        self.lessons = data.get("lessons", [])
        
        print(f"[MEMORY] Loaded: {len(self.objects)} objects, {len(self.rooms)} rooms, "
              f"{len(self.obstacles)} obstacles, {len(self.visited_cells)} visited cells")
    
    # ─────────────────────────────────────────────────────────────────────────
    # SAVING
    # ─────────────────────────────────────────────────────────────────────────
    
    def _save_json(self, filepath: str, data: any):
        """Save data to JSON file."""
        try:
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=2)
        except IOError as e:
            print(f"[MEMORY] Error saving {filepath}: {e}")
    
    def save_all(self):
        """Persist all memory to disk."""
        self._save_json(self.objects_file, {
            "objects": self.objects,
            "counter": self.object_counter
        })
        self._save_json(self.rooms_file, {
            "rooms": self.rooms,
            "counter": self.room_counter
        })
        self._save_json(self.obstacles_file, {
            "obstacles": self.obstacles,
            "counter": self.obstacle_counter
        })
        self._save_json(self.visited_file, {
            "cells": list(self.visited_cells)
        })
        self._save_json(self.lessons_file, {
            "lessons": self.lessons
        })
    
    # ─────────────────────────────────────────────────────────────────────────
    # OBJECT MEMORY
    # ─────────────────────────────────────────────────────────────────────────
    
    def _distance(self, x1: float, y1: float, x2: float, y2: float) -> float:
        """Euclidean distance between two points."""
        return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    
    def _find_nearby_object(self, label: str, x: float, y: float) -> Optional[Dict]:
        """Find existing object of same type within merge radius."""
        for obj in self.objects:
            if obj["label"] == label:
                dist = self._distance(obj["x"], obj["y"], x, y)
                if dist < self.merge_radius:
                    return obj
        return None
    
    def add_object(self, label: str, x: float, y: float, confidence: float) -> Dict:
        """
        Add or update an object in memory.
        
        If same object type exists within merge_radius, update it.
        Otherwise, create new entry.
        """
        now = datetime.now().isoformat()
        
        existing = self._find_nearby_object(label, x, y)
        
        if existing:
            # Update existing object
            existing["views"] += 1
            existing["last_seen"] = now
            # Update position with weighted average (more views = more stable)
            weight = 1.0 / existing["views"]
            existing["x"] = existing["x"] * (1 - weight) + x * weight
            existing["y"] = existing["y"] * (1 - weight) + y * weight
            # Update confidence (boost with more views)
            existing["confidence"] = min(0.99, existing["confidence"] + 0.05)
            # Mark as confirmed if seen 3+ times
            if existing["views"] >= 3:
                existing["status"] = "confirmed"
            return existing
        else:
            # Create new object
            self.object_counter += 1
            new_obj = {
                "id": f"{label}_{self.object_counter:03d}",
                "label": label,
                "x": round(x, 2),
                "y": round(y, 2),
                "confidence": round(confidence, 2),
                "views": 1,
                "first_seen": now,
                "last_seen": now,
                "status": "uncertain" if confidence < 0.7 else "confirmed"
            }
            self.objects.append(new_obj)
            return new_obj
    
    def get_object_by_label(self, label: str) -> List[Dict]:
        """Get all objects with a specific label."""
        return [obj for obj in self.objects if obj["label"] == label]
    
    def get_nearest_object(self, label: str, robot_x: float, robot_y: float) -> Optional[Dict]:
        """Get the nearest object of a type to the robot."""
        candidates = self.get_object_by_label(label)
        if not candidates:
            return None
        
        return min(candidates, key=lambda obj: self._distance(obj["x"], obj["y"], robot_x, robot_y))
    
    # ─────────────────────────────────────────────────────────────────────────
    # ROOM MEMORY
    # ─────────────────────────────────────────────────────────────────────────
    
    def add_room(self, room_type: str, center_x: float, center_y: float, 
                 object_density: str = "unknown") -> Dict:
        """Add a discovered room."""
        self.room_counter += 1
        new_room = {
            "id": f"room_{self.room_counter:03d}",
            "room_type": room_type,
            "center_x": round(center_x, 2),
            "center_y": round(center_y, 2),
            "object_density": object_density,
            "explored": False,
            "doors": [],
            "discovered": datetime.now().isoformat()
        }
        self.rooms.append(new_room)
        return new_room
    
    def mark_room_explored(self, room_id: str):
        """Mark a room as fully explored."""
        for room in self.rooms:
            if room["id"] == room_id:
                room["explored"] = True
                break
    
    def get_unexplored_rooms(self) -> List[Dict]:
        """Get all rooms not yet fully explored."""
        return [room for room in self.rooms if not room["explored"]]
    
    # ─────────────────────────────────────────────────────────────────────────
    # OBSTACLE MEMORY
    # ─────────────────────────────────────────────────────────────────────────
    
    def add_obstacle(self, x: float, y: float, radius: float = 0.3) -> Dict:
        """Record a collision/obstacle location."""
        now = datetime.now().isoformat()
        
        # Check if obstacle already known nearby
        for obs in self.obstacles:
            dist = self._distance(obs["x"], obs["y"], x, y)
            if dist < radius * 2:
                obs["hit_count"] += 1
                obs["last_hit"] = now
                return obs
        
        # New obstacle
        self.obstacle_counter += 1
        new_obs = {
            "id": f"obstacle_{self.obstacle_counter:03d}",
            "x": round(x, 2),
            "y": round(y, 2),
            "radius": radius,
            "hit_count": 1,
            "last_hit": now
        }
        self.obstacles.append(new_obs)
        return new_obs
    
    # ─────────────────────────────────────────────────────────────────────────
    # VISITED CELLS
    # ─────────────────────────────────────────────────────────────────────────
    
    def mark_visited(self, x: float, y: float, cell_size: float = 0.25):
        """Mark a grid cell as visited."""
        cell_x = int(x / cell_size)
        cell_y = int(y / cell_size)
        self.visited_cells.add((cell_x, cell_y))
    
    def is_visited(self, x: float, y: float, cell_size: float = 0.25) -> bool:
        """Check if a cell has been visited."""
        cell_x = int(x / cell_size)
        cell_y = int(y / cell_size)
        return (cell_x, cell_y) in self.visited_cells
    
    def get_coverage_stats(self) -> Dict:
        """Get exploration coverage statistics."""
        return {
            "visited_cells": len(self.visited_cells),
            "objects_found": len(self.objects),
            "rooms_discovered": len(self.rooms),
            "rooms_explored": len([r for r in self.rooms if r["explored"]])
        }
    
    # ─────────────────────────────────────────────────────────────────────────
    # RLHF LESSONS
    # ─────────────────────────────────────────────────────────────────────────
    
    def add_lesson(self, lesson_type: str, description: str, context: Dict = None):
        """Record a lesson learned from feedback."""
        self.lessons.append({
            "type": lesson_type,
            "description": description,
            "context": context or {},
            "timestamp": datetime.now().isoformat()
        })
    
    def get_relevant_lessons(self, context_keywords: List[str]) -> List[Dict]:
        """Get lessons relevant to current context."""
        relevant = []
        for lesson in self.lessons:
            for keyword in context_keywords:
                if keyword.lower() in lesson["description"].lower():
                    relevant.append(lesson)
                    break
        return relevant
    
    # ─────────────────────────────────────────────────────────────────────────
    # SUMMARY FOR LLM CONTEXT
    # ─────────────────────────────────────────────────────────────────────────
    
    def get_summary_for_llm(self, robot_x: float, robot_y: float, max_objects: int = 10) -> str:
        """Generate a concise summary for LLM context injection."""
        lines = []
        
        # Nearby objects (sorted by distance)
        if self.objects:
            sorted_objs = sorted(
                self.objects,
                key=lambda o: self._distance(o["x"], o["y"], robot_x, robot_y)
            )[:max_objects]
            
            lines.append("KNOWN OBJECTS:")
            for obj in sorted_objs:
                dist = self._distance(obj["x"], obj["y"], robot_x, robot_y)
                lines.append(f"  - {obj['label']} at ({obj['x']}, {obj['y']}), {dist:.1f}m away, {obj['status']}")
        
        # Rooms
        if self.rooms:
            lines.append("\nDISCOVERED ROOMS:")
            for room in self.rooms:
                status = "explored" if room["explored"] else "unexplored"
                lines.append(f"  - {room['room_type']} at ({room['center_x']}, {room['center_y']}), {status}")
        
        # Coverage
        stats = self.get_coverage_stats()
        lines.append(f"\nCOVERAGE: {stats['visited_cells']} cells visited, "
                    f"{stats['objects_found']} objects, {stats['rooms_explored']}/{stats['rooms_discovered']} rooms explored")
        
        return "\n".join(lines)
    
    def clear_all(self):
        """Reset all memory (use with caution)."""
        self.objects = []
        self.rooms = []
        self.obstacles = []
        self.visited_cells = set()
        self.lessons = []
        self.object_counter = 0
        self.room_counter = 0
        self.obstacle_counter = 0
        self.save_all()
        print("[MEMORY] All memory cleared")


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("Testing NovaMemory...")
    
    mem = NovaMemory(base_path="/tmp/nova_test_memory/")
    
    # Add some objects
    mem.add_object("chair", 2.0, 1.5, 0.75)
    mem.add_object("table", 3.0, 2.0, 0.82)
    mem.add_object("chair", 2.1, 1.6, 0.68)  # Should merge with first chair
    
    # Add a room
    mem.add_room("living_room", 2.5, 1.75, "medium")
    
    # Mark some cells visited
    mem.mark_visited(0.0, 0.0)
    mem.mark_visited(0.25, 0.0)
    mem.mark_visited(0.5, 0.0)
    
    # Save
    mem.save_all()
    
    # Print summary
    print("\n" + mem.get_summary_for_llm(0.0, 0.0))
    
    print("\n✅ Memory test complete")
