#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22 - Void Detector
═══════════════════════════════════════════════════════════════════════════════
THE CRITICAL RULE:
    If ALL directions show > 3m distance → ROBOT IS LOST IN EMPTY SPACE
    
This prevents the #1 failure mode: Robot driving into featureless void.
═══════════════════════════════════════════════════════════════════════════════
"""

from dataclasses import dataclass
from typing import List, Tuple, Optional
import math


@dataclass
class LidarSectors:
    """Processed LiDAR readings by sector."""
    front: float        # Minimum distance in front sector
    front_left: float
    left: float
    back: float
    right: float
    front_right: float
    
    # Raw statistics
    min_reading: float
    max_reading: float
    valid_count: int
    inf_count: int


@dataclass
class VoidAnalysis:
    """Result of void detection analysis."""
    is_void: bool           # True if robot appears to be in void/empty space
    confidence: float       # 0.0 to 1.0
    reason: str            # Human-readable explanation
    recommended_action: str # What to do about it
    safe_direction: Optional[str]  # Which direction has walls/features


class VoidDetector:
    """
    Detects when robot is in featureless empty space.
    
    The Problem:
        Basic LiDAR logic thinks "high distance = good path"
        But "high distance in ALL directions" = lost in void
        
    The Solution:
        Check if ALL sectors show readings > threshold
        If so, robot needs to retreat to nearest wall/feature
    """
    
    def __init__(
        self,
        void_threshold_m: float = 3.0,
        min_valid_readings: int = 5,
        total_rays: int = 360
    ):
        self.void_threshold = void_threshold_m
        self.min_valid_readings = min_valid_readings
        self.total_rays = total_rays
        
        # Sector definitions (degrees)
        self.sectors = {
            "front": (-30, 30),
            "front_left": (30, 60),
            "left": (60, 120),
            "back": (150, 210),
            "right": (240, 300),
            "front_right": (300, 330)
        }
    
    def _normalize_angle(self, angle: float) -> int:
        """Convert angle to valid index (0-359)."""
        while angle < 0:
            angle += 360
        while angle >= 360:
            angle -= 360
        return int(angle)
    
    def _get_sector_readings(
        self, 
        ranges: List[float], 
        start_deg: int, 
        end_deg: int
    ) -> List[float]:
        """Extract readings for a specific sector."""
        readings = []
        
        # Handle wrap-around (e.g., -30 to 30)
        if start_deg < 0:
            # From start_deg to 0
            for i in range(self._normalize_angle(start_deg), 360):
                if i < len(ranges) and not math.isinf(ranges[i]) and ranges[i] > 0.01:
                    readings.append(ranges[i])
            # From 0 to end_deg
            for i in range(0, end_deg + 1):
                if i < len(ranges) and not math.isinf(ranges[i]) and ranges[i] > 0.01:
                    readings.append(ranges[i])
        else:
            for i in range(start_deg, end_deg + 1):
                if i < len(ranges) and not math.isinf(ranges[i]) and ranges[i] > 0.01:
                    readings.append(ranges[i])
        
        return readings
    
    def _get_sector_min(self, ranges: List[float], start_deg: int, end_deg: int) -> float:
        """Get minimum valid reading in a sector."""
        readings = self._get_sector_readings(ranges, start_deg, end_deg)
        return min(readings) if readings else float('inf')
    
    def process_lidar(self, ranges: List[float]) -> LidarSectors:
        """
        Process raw LiDAR ranges into sector summaries.
        
        Args:
            ranges: List of 360 distance readings (meters)
            
        Returns:
            LidarSectors with minimum distance per sector
        """
        # Count valid vs invalid readings
        valid_count = 0
        inf_count = 0
        valid_readings = []
        
        for r in ranges:
            if math.isinf(r) or r <= 0.01:
                inf_count += 1
            else:
                valid_count += 1
                valid_readings.append(r)
        
        # Get minimum per sector
        sectors = LidarSectors(
            front=self._get_sector_min(ranges, -30, 30),
            front_left=self._get_sector_min(ranges, 30, 60),
            left=self._get_sector_min(ranges, 60, 120),
            back=self._get_sector_min(ranges, 150, 210),
            right=self._get_sector_min(ranges, 240, 300),
            front_right=self._get_sector_min(ranges, 300, 330),
            min_reading=min(valid_readings) if valid_readings else float('inf'),
            max_reading=max(valid_readings) if valid_readings else float('inf'),
            valid_count=valid_count,
            inf_count=inf_count
        )
        
        return sectors
    
    def analyze(self, ranges: List[float]) -> Tuple[LidarSectors, VoidAnalysis]:
        """
        Analyze LiDAR data for void detection.
        
        Args:
            ranges: Raw LiDAR ranges (360 readings)
            
        Returns:
            Tuple of (processed sectors, void analysis)
        """
        sectors = self.process_lidar(ranges)
        
        # Count sectors that are "clear" (> threshold)
        clear_sectors = []
        blocked_sectors = []
        
        sector_distances = {
            "front": sectors.front,
            "front_left": sectors.front_left,
            "left": sectors.left,
            "back": sectors.back,
            "right": sectors.right,
            "front_right": sectors.front_right
        }
        
        for name, dist in sector_distances.items():
            if dist > self.void_threshold:
                clear_sectors.append(name)
            else:
                blocked_sectors.append((name, dist))
        
        # Check for void condition
        # Void = all main directions (front, left, right) are clear
        main_sectors_clear = (
            sectors.front > self.void_threshold and
            sectors.left > self.void_threshold and
            sectors.right > self.void_threshold
        )
        
        # Also void if too many inf readings
        too_many_inf = sectors.inf_count > (self.total_rays * 0.7)
        
        # Also void if almost no valid readings
        too_few_valid = sectors.valid_count < self.min_valid_readings
        
        is_void = main_sectors_clear or too_many_inf or too_few_valid
        
        # Calculate confidence
        if is_void:
            confidence = len(clear_sectors) / 6.0  # 6 total sectors
        else:
            confidence = 0.0
        
        # Determine reason
        if too_few_valid:
            reason = f"Insufficient LiDAR data ({sectors.valid_count} valid readings)"
        elif too_many_inf:
            reason = f"Too many infinite readings ({sectors.inf_count}/{self.total_rays})"
        elif main_sectors_clear:
            reason = f"All main directions clear (F={sectors.front:.1f}m, L={sectors.left:.1f}m, R={sectors.right:.1f}m)"
        else:
            reason = "Normal environment with obstacles"
        
        # Find safest direction (closest wall)
        safe_direction = None
        if blocked_sectors:
            # Sort by distance, pick the closest wall
            blocked_sectors.sort(key=lambda x: x[1])
            safe_direction = blocked_sectors[0][0]
        
        # Recommended action
        if is_void:
            if safe_direction:
                recommended_action = f"RETREAT: Turn toward {safe_direction} ({blocked_sectors[0][1]:.1f}m) and approach wall"
            else:
                recommended_action = "RETREAT: Turn 180° and move backward slowly"
        else:
            recommended_action = "CONTINUE: Normal navigation"
        
        analysis = VoidAnalysis(
            is_void=is_void,
            confidence=confidence,
            reason=reason,
            recommended_action=recommended_action,
            safe_direction=safe_direction
        )
        
        return sectors, analysis
    
    def get_retreat_command(self, sectors: LidarSectors) -> Tuple[float, float]:
        """
        Calculate retreat velocity command when in void.
        
        Returns:
            Tuple of (linear_vel, angular_vel) to escape void
        """
        # Find direction with closest obstacle (that's where features are)
        sector_distances = {
            "front": (sectors.front, 0.0),           # No turn needed
            "front_left": (sectors.front_left, 0.5),  # Turn left
            "left": (sectors.left, 1.0),              # Turn more left
            "back": (sectors.back, 3.14),             # Turn around
            "right": (sectors.right, -1.0),           # Turn right
            "front_right": (sectors.front_right, -0.5) # Turn slightly right
        }
        
        # Find closest non-void direction
        closest_sector = min(sector_distances.items(), key=lambda x: x[1][0])
        target_turn = closest_sector[1][1]
        
        # If back is closest, just reverse
        if closest_sector[0] == "back":
            return -0.1, 0.0  # Reverse slowly
        
        # Otherwise, turn toward the wall and move forward slowly
        if abs(target_turn) > 0.1:
            return 0.0, 0.35 if target_turn > 0 else -0.35  # Turn first
        else:
            return 0.1, 0.0  # Then move forward
    
    def format_for_log(self, sectors: LidarSectors, analysis: VoidAnalysis) -> str:
        """Format analysis for terminal logging."""
        lines = [
            f"LiDAR: F={sectors.front:.1f}m L={sectors.left:.1f}m R={sectors.right:.1f}m B={sectors.back:.1f}m",
            f"Valid: {sectors.valid_count}/{self.total_rays} | Inf: {sectors.inf_count}",
        ]
        
        if analysis.is_void:
            lines.append(f"⚠️  VOID DETECTED: {analysis.reason}")
            lines.append(f"    Action: {analysis.recommended_action}")
        
        return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import random
    
    detector = VoidDetector(void_threshold_m=3.0)
    
    print("=" * 60)
    print("TEST 1: Normal environment with walls")
    print("=" * 60)
    
    # Simulate normal room: walls at 1-2m
    normal_ranges = [random.uniform(1.0, 2.0) for _ in range(360)]
    sectors, analysis = detector.analyze(normal_ranges)
    print(detector.format_for_log(sectors, analysis))
    print(f"Is Void: {analysis.is_void}")
    print()
    
    print("=" * 60)
    print("TEST 2: Void (all directions clear)")
    print("=" * 60)
    
    # Simulate void: all readings > 5m
    void_ranges = [random.uniform(5.0, 10.0) for _ in range(360)]
    sectors, analysis = detector.analyze(void_ranges)
    print(detector.format_for_log(sectors, analysis))
    print(f"Is Void: {analysis.is_void}")
    
    if analysis.is_void:
        linear, angular = detector.get_retreat_command(sectors)
        print(f"Retreat command: linear={linear}, angular={angular}")
    print()
    
    print("=" * 60)
    print("TEST 3: Partial void (one wall visible)")
    print("=" * 60)
    
    # Simulate partial void: wall only on left
    partial_ranges = [random.uniform(5.0, 10.0) for _ in range(360)]
    # Add wall on left (indices 60-120)
    for i in range(60, 120):
        partial_ranges[i] = random.uniform(0.8, 1.5)
    
    sectors, analysis = detector.analyze(partial_ranges)
    print(detector.format_for_log(sectors, analysis))
    print(f"Is Void: {analysis.is_void}")
    print(f"Safe direction: {analysis.safe_direction}")
    print()
    
    print("✅ Void detector tests complete")
