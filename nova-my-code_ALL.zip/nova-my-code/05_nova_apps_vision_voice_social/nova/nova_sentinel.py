#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22.2 - EXPLORATION FOCUSED
═══════════════════════════════════════════════════════════════════════════════

PHILOSOPHY:
- VLM describes what it SEES (printed in terminal)
- Before backing up: LOOK RIGHT, LOOK LEFT first
- Only back up if memory confirms back is clear
- Goal: EXPLORE the TurtleBot3 house, not just avoid walls

FLOW:
    SPAWN_SCAN → STOP → WAIT → CAPTURE → VLM (describe) → DECIDE → MOVE

═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import time
import math
from enum import Enum
from dataclasses import dataclass
from typing import Optional, List
from collections import deque

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy

from sensor_msgs.msg import LaserScan, Image
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

from cv_bridge import CvBridge
import numpy as np

# Local imports
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nova_logger import NovaLogger, LogLevel, LogCategory
from void_detector import VoidDetector
from memory_system import NovaMemory
from vlm_client import VLMClient
from llm_client import LLMClient, Action


# ═══════════════════════════════════════════════════════════════════════════════
# STATE MACHINE
# ═══════════════════════════════════════════════════════════════════════════════

class State(Enum):
    INITIALIZING = "INIT"
    SPAWN_SCAN = "SPAWN_SCAN"      # 360° scan on startup
    STOP = "STOP"
    WAIT = "WAIT"
    CAPTURE = "CAPTURE"
    ANALYZE = "ANALYZE"            # VLM describes what it sees
    LOOK_AROUND = "LOOK_AROUND"    # NEW: Check left/right before deciding
    DECIDE = "DECIDE"
    EXECUTE = "EXECUTE"
    VOID_RECOVERY = "VOID_REC"
    STUCK_RECOVERY = "STUCK_REC"
    COMPLETE = "COMPLETE"


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN NODE
# ═══════════════════════════════════════════════════════════════════════════════

class NovaSentinel(Node):
    """
    NOVA Sentinel v22.2 - Exploration Focused
    
    Key behaviors:
    - VLM DESCRIBES what it sees (full text in terminal)
    - LOOK before you leap (check right/left before backing up)
    - EXPLORE the house, don't just avoid walls
    - Memory tracks: rooms found, doors found, areas explored
    """
    
    def __init__(self):
        super().__init__('nova_sentinel')
        
        # ─────────────────────────────────────────────────────────────────────
        # LOGGER
        # ─────────────────────────────────────────────────────────────────────
        
        self.log = NovaLogger(min_level=LogLevel.INFO)
        self.log.system("═" * 50)
        self.log.system("NOVA SENTINEL v22.2 - EXPLORATION MODE")
        self.log.system("═" * 50)
        
        # ─────────────────────────────────────────────────────────────────────
        # CONFIGURATION
        # ─────────────────────────────────────────────────────────────────────
        
        # Timing
        self.WAIT_DURATION = 0.5
        self.MOVE_DURATION = 2.0
        self.TURN_DURATION = 2.2       # Tuned for ~90°
        
        # Speeds
        self.LINEAR_SPEED = 0.15
        self.ANGULAR_SPEED = 0.4       # rad/s for turns
        self.RETREAT_SPEED = -0.12     # Backing up
        
        # Thresholds
        self.VOID_THRESHOLD = 5.0       # Increased: only void if ALL > 5m
        self.EMERGENCY_DISTANCE = 0.35
        self.CAUTION_DISTANCE = 0.5
        
        # Stuck detection
        self.STUCK_THRESHOLD = 0.08
        self.STUCK_CHECK_INTERVAL = 4.0
        self.MAX_STUCK_COUNT = 3
        
        # Anti-oscillation
        self.TURN_COOLDOWN_CYCLES = 3   # Don't reverse turn for N cycles
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE
        # ─────────────────────────────────────────────────────────────────────
        
        self.state = State.INITIALIZING
        self.state_start_time = time.time()
        
        # Sensor data
        self.lidar_front = float('inf')
        self.lidar_left = float('inf')
        self.lidar_right = float('inf')
        self.lidar_back = float('inf')
        self.lidar_min = float('inf')
        self.lidar_raw = []
        self.lidar_valid = False
        
        # Position
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0
        
        # Camera
        self.current_frame = None
        self.frame_valid = False
        self.bridge = CvBridge()
        
        # Void detection
        self.void_detector = VoidDetector(void_threshold_m=self.VOID_THRESHOLD)
        self.is_void = False
        
        # Stuck detection
        self.position_history = deque(maxlen=20)
        self.stuck_counter = 0
        self.last_stuck_check = time.time()
        
        # Anti-oscillation tracking
        self.last_turn_direction = None  # "left" or "right"
        self.turn_cooldown = 0           # Cycles remaining before can reverse
        
        # Spawn scan state
        self.spawn_scan_count = 0        # How many 90° turns done
        self.spawn_scan_complete = False
        
        # Look-around state (check directions before deciding)
        self.look_around_phase = 0       # 0=front, 1=right, 2=left, 3=done
        self.direction_scans = {}        # Store scan results per direction
        
        # Decision state
        self.last_vlm_result = None
        self.last_decision = None
        self.cycle_count = 0
        self.consecutive_emergency = 0
        
        # Exploration tracking
        self.doors_found = []            # List of door locations
        self.rooms_entered = 0
        self.total_distance = 0.0
        self.last_position = (0.0, 0.0)
        
        # ─────────────────────────────────────────────────────────────────────
        # COMPONENTS
        # ─────────────────────────────────────────────────────────────────────
        
        # Memory
        memory_path = os.path.join(os.path.dirname(__file__), "memory/")
        # Ensure it's a directory, not files
        if os.path.exists(memory_path):
            # Check if any "file" is actually a directory with wrong name
            for fname in ["objects.json", "rooms.json", "obstacles.json", "visited.json", "lessons.json"]:
                fpath = os.path.join(memory_path, fname)
                if os.path.isdir(fpath):
                    self.log.error(LogCategory.MEMORY, f"Removing invalid directory: {fpath}")
                    import shutil
                    shutil.rmtree(fpath)
        
        self.memory = NovaMemory(base_path=memory_path)
        self.log.memory(f"Memory path: {memory_path}")
        
        # API Key
        self.api_key = os.environ.get("GROQ_API_KEY", "")
        if not self.api_key:
            self.log.error(LogCategory.SYSTEM, "GROQ_API_KEY not set! Using rule-based fallback.")
        
        # VLM Client
        self.vlm = VLMClient(
            api_key=self.api_key,
            model="meta-llama/llama-4-maverick-17b-128e-instruct"
        ) if self.api_key else None
        
        # LLM Client
        self.llm = LLMClient(
            api_key=self.api_key,
            model="meta-llama/llama-4-scout-17b-16e-instruct"
        ) if self.api_key else None
        
        # ─────────────────────────────────────────────────────────────────────
        # ROS 2 SETUP
        # ─────────────────────────────────────────────────────────────────────
        
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            depth=10
        )
        
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        self.lidar_sub = self.create_subscription(
            LaserScan, '/scan', self._lidar_callback, qos
        )
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self._odom_callback, qos
        )
        self.camera_sub = self.create_subscription(
            Image, '/camera/image_raw', self._camera_callback, qos
        )
        
        # Main loop at 10 Hz
        self.control_timer = self.create_timer(0.1, self._control_loop)
        
        # Memory save at 30s
        self.save_timer = self.create_timer(30.0, self._save_memory)
        
        self.log.system("Initialization complete. Waiting for sensors...")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _lidar_callback(self, msg: LaserScan):
        """Process LiDAR scan into sectors."""
        self.lidar_raw = list(msg.ranges)
        
        sectors, void_analysis = self.void_detector.analyze(self.lidar_raw)
        
        self.lidar_front = sectors.front
        self.lidar_left = sectors.left
        self.lidar_right = sectors.right
        self.lidar_back = sectors.back
        self.lidar_min = sectors.min_reading
        self.is_void = void_analysis.is_void
        
        self.lidar_valid = sectors.valid_count > 10
    
    def _odom_callback(self, msg: Odometry):
        """Process odometry."""
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y
        
        q = msg.pose.pose.orientation
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.robot_yaw = math.atan2(siny_cosp, cosy_cosp)
    
    def _camera_callback(self, msg: Image):
        """Process camera image."""
        try:
            self.current_frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.frame_valid = True
        except Exception as e:
            self.log.error(LogCategory.SENSOR, f"Camera error: {e}")
            self.frame_valid = False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATE MACHINE
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _change_state(self, new_state: State, reason: str = ""):
        """Transition to new state."""
        old_state = self.state
        self.state = new_state
        self.state_start_time = time.time()
        self.log.state_transition(old_state.value, new_state.value, reason)
    
    def _state_elapsed(self) -> float:
        """Time in current state."""
        return time.time() - self.state_start_time
    
    def _control_loop(self):
        """Main control loop - 10 Hz."""
        
        # Decrement turn cooldown
        if self.turn_cooldown > 0:
            self.turn_cooldown -= 1
        
        # ─────────────────────────────────────────────────────────────────────
        # INITIALIZING: Wait for sensors
        # ─────────────────────────────────────────────────────────────────────
        if self.state == State.INITIALIZING:
            if self.lidar_valid:
                self.log.system("Sensors online! Starting spawn scan...")
                self._change_state(State.SPAWN_SCAN, "sensors ready")
            elif self._state_elapsed() > 10.0:
                self.log.error(LogCategory.SYSTEM, "Sensor timeout!")
        
        # ─────────────────────────────────────────────────────────────────────
        # SPAWN_SCAN: 360° rotation to understand surroundings
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.SPAWN_SCAN:
            if self.spawn_scan_count < 4:
                direction = ["NORTH", "EAST", "SOUTH", "WEST"][self.spawn_scan_count]
                
                self.log.system("═" * 50)
                self.log.system(f"SPAWN SCAN {self.spawn_scan_count + 1}/4: Facing {direction}")
                self.log.system("═" * 50)
                
                self.log.lidar_summary(
                    self.lidar_front, self.lidar_left,
                    self.lidar_right, self.lidar_back
                )
                
                # VLM describe what we see
                if self.vlm and self.frame_valid:
                    result = self.vlm.analyze_cv2_frame(self.current_frame)
                    self.log.system("┌" + "─" * 40 + "┐")
                    self.log.vlm(f"│ {direction}: \"{result.description}\"")
                    self.log.vlm(f"│ Type: {result.scene_type} | Density: {result.object_density}")
                    if result.door_detected:
                        self.log.door(f"│ 🚪 DOOR: {result.door_direction}")
                        self.doors_found.append((self.robot_x, self.robot_y, result.door_direction))
                    self.log.system("└" + "─" * 40 + "┘")
                
                self.memory.mark_visited(self.robot_x, self.robot_y)
                
                # Turn 90° for next scan
                self.log.move("Turning 90°...")
                self._execute_turn_90(direction="right")
                self.spawn_scan_count += 1
                
                time.sleep(0.5)
            else:
                self.spawn_scan_complete = True
                self.log.system("═" * 50)
                self.log.system("SPAWN SCAN COMPLETE")
                self.log.system(f"Doors found: {len(self.doors_found)}")
                self.log.system("Beginning exploration...")
                self.log.system("═" * 50)
                self._change_state(State.STOP, "scan complete")
        
        # ─────────────────────────────────────────────────────────────────────
        # STOP: Ensure motors stopped
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.STOP:
            self._send_velocity(0.0, 0.0)
            self._change_state(State.WAIT, "motors stopped")
        
        # ─────────────────────────────────────────────────────────────────────
        # WAIT: Stabilization pause
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.WAIT:
            if self._state_elapsed() >= self.WAIT_DURATION:
                self._change_state(State.CAPTURE, "stabilized")
        
        # ─────────────────────────────────────────────────────────────────────
        # CAPTURE: Read sensors, check safety
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.CAPTURE:
            # Log sensor state
            self.log.lidar_summary(
                self.lidar_front, self.lidar_left,
                self.lidar_right, self.lidar_back
            )
            self.log.sensor(f"Position: ({self.robot_x:.2f}, {self.robot_y:.2f}) Yaw: {math.degrees(self.robot_yaw):.0f}°")
            
            # Track distance traveled
            dx = self.robot_x - self.last_position[0]
            dy = self.robot_y - self.last_position[1]
            self.total_distance += math.sqrt(dx*dx + dy*dy)
            self.last_position = (self.robot_x, self.robot_y)
            
            # Mark cell visited
            self.memory.mark_visited(self.robot_x, self.robot_y)
            
            # ─────────────────────────────────────────────────────────────────
            # SAFETY CHECK 1: Void detection
            # ─────────────────────────────────────────────────────────────────
            if self.is_void:
                self.log.void("VOID DETECTED - All directions clear!")
                self._change_state(State.VOID_RECOVERY, "void detected")
                return
            
            # ─────────────────────────────────────────────────────────────────
            # CHECK: Is front blocked? If so, LOOK AROUND first
            # ─────────────────────────────────────────────────────────────────
            if self.lidar_front < self.EMERGENCY_DISTANCE:
                self.log.safety(f"Front blocked at {self.lidar_front:.2f}m - will look around")
                self.look_around_phase = 0
                self.direction_scans = {"front": {
                    "lidar": self.lidar_front,
                    "blocked": True
                }}
                self._change_state(State.LOOK_AROUND, "need to check directions")
                return
            
            # ─────────────────────────────────────────────────────────────────
            # Continue to VLM analysis
            # ─────────────────────────────────────────────────────────────────
            if self.frame_valid:
                self._change_state(State.ANALYZE, "frame ready")
            else:
                self._change_state(State.DECIDE, "no camera")
        
        # ─────────────────────────────────────────────────────────────────────
        # LOOK_AROUND: Check right and left before deciding (when front blocked)
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.LOOK_AROUND:
            if self.look_around_phase == 0:
                # Phase 0: Turn RIGHT and check
                self.log.system("LOOK AROUND: Checking RIGHT...")
                self._execute_turn_90("right")
                time.sleep(0.3)  # Let sensors settle
                
                # Capture what we see
                right_clear = self.lidar_front > self.CAUTION_DISTANCE
                self.direction_scans["right"] = {
                    "lidar": self.lidar_front,
                    "clear": right_clear
                }
                
                # VLM describe right side
                if self.vlm and self.frame_valid:
                    result = self.vlm.analyze_cv2_frame(self.current_frame)
                    self.direction_scans["right"]["vlm"] = result
                    self.log.system("─" * 40)
                    self.log.vlm(f"RIGHT SIDE: {result.description}")
                    self.log.vlm(f"  Scene: {result.scene_type} | Density: {result.object_density}")
                    if result.door_detected:
                        self.log.door(f"  DOOR DETECTED: {result.door_direction}")
                    self.log.system("─" * 40)
                
                self.look_around_phase = 1
            
            elif self.look_around_phase == 1:
                # Phase 1: Turn LEFT (180° from right = left of original)
                self.log.system("LOOK AROUND: Checking LEFT...")
                self._execute_turn_180()  # From right, turn 180 to face left
                time.sleep(0.3)
                
                left_clear = self.lidar_front > self.CAUTION_DISTANCE
                self.direction_scans["left"] = {
                    "lidar": self.lidar_front,
                    "clear": left_clear
                }
                
                # VLM describe left side
                if self.vlm and self.frame_valid:
                    result = self.vlm.analyze_cv2_frame(self.current_frame)
                    self.direction_scans["left"]["vlm"] = result
                    self.log.system("─" * 40)
                    self.log.vlm(f"LEFT SIDE: {result.description}")
                    self.log.vlm(f"  Scene: {result.scene_type} | Density: {result.object_density}")
                    if result.door_detected:
                        self.log.door(f"  DOOR DETECTED: {result.door_direction}")
                    self.log.system("─" * 40)
                
                self.look_around_phase = 2
            
            elif self.look_around_phase == 2:
                # Phase 2: Turn back to RIGHT (90° from left)
                # Now we have: front (blocked), right, left scanned
                self._execute_turn_90("right")  # Face original front
                
                # Decide based on what we saw
                right_data = self.direction_scans.get("right", {})
                left_data = self.direction_scans.get("left", {})
                
                right_clear = right_data.get("clear", False)
                left_clear = left_data.get("clear", False)
                right_dist = right_data.get("lidar", 0)
                left_dist = left_data.get("lidar", 0)
                
                # Check for doors
                right_has_door = right_data.get("vlm", {})
                left_has_door = left_data.get("vlm", {})
                if hasattr(right_has_door, 'door_detected'):
                    right_has_door = right_has_door.door_detected
                else:
                    right_has_door = False
                if hasattr(left_has_door, 'door_detected'):
                    left_has_door = left_has_door.door_detected
                else:
                    left_has_door = False
                
                self.log.system("═" * 40)
                self.log.system("LOOK AROUND RESULTS:")
                self.log.system(f"  RIGHT: {'CLEAR' if right_clear else 'BLOCKED'} ({right_dist:.2f}m) {'🚪 DOOR!' if right_has_door else ''}")
                self.log.system(f"  LEFT:  {'CLEAR' if left_clear else 'BLOCKED'} ({left_dist:.2f}m) {'🚪 DOOR!' if left_has_door else ''}")
                self.log.system(f"  BACK:  {self.lidar_back:.2f}m")
                self.log.system("═" * 40)
                
                # Priority: Door > Clear path > Back up
                if right_has_door and right_clear:
                    self.log.system("DECISION: Go RIGHT (door detected!)")
                    self._execute_turn_90("right")
                    self.last_turn_direction = "right"
                elif left_has_door and left_clear:
                    self.log.system("DECISION: Go LEFT (door detected!)")
                    self._execute_turn_90("left")
                    self.last_turn_direction = "left"
                elif right_clear and right_dist > left_dist:
                    self.log.system(f"DECISION: Go RIGHT (clearer: {right_dist:.2f}m)")
                    self._execute_turn_90("right")
                    self.last_turn_direction = "right"
                elif left_clear:
                    self.log.system(f"DECISION: Go LEFT (clearer: {left_dist:.2f}m)")
                    self._execute_turn_90("left")
                    self.last_turn_direction = "left"
                elif self.lidar_back > self.CAUTION_DISTANCE:
                    self.log.system(f"DECISION: BACK UP (only option: {self.lidar_back:.2f}m)")
                    self._execute_turn_180()
                else:
                    self.log.safety("ALL DIRECTIONS BLOCKED - Attempting escape")
                    self._execute_retreat()
                    self._execute_turn_90("right")
                
                self.look_around_phase = 0
                self.turn_cooldown = self.TURN_COOLDOWN_CYCLES
                self._change_state(State.STOP, "look around complete")
        
        # ─────────────────────────────────────────────────────────────────────
        # ANALYZE: VLM DESCRIBES what it sees (printed in terminal)
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.ANALYZE:
            if self.vlm and self.current_frame is not None:
                self.log.system("Analyzing scene with VLM...")
                
                result = self.vlm.analyze_cv2_frame(self.current_frame)
                self.last_vlm_result = result
                
                # ═══════════════════════════════════════════════════════════════
                # PRINT FULL VLM DESCRIPTION
                # ═══════════════════════════════════════════════════════════════
                self.log.system("┌" + "─" * 48 + "┐")
                self.log.system("│ 👁️  VLM SEES:                                    │")
                self.log.system("├" + "─" * 48 + "┤")
                self.log.vlm(f"│ \"{result.description}\"")
                self.log.system("├" + "─" * 48 + "┤")
                self.log.vlm(f"│ Scene Type: {result.scene_type}")
                self.log.vlm(f"│ Object Density: {result.object_density}")
                self.log.vlm(f"│ Navigable: {', '.join(result.navigable_directions)}")
                if result.door_detected:
                    self.log.door(f"│ 🚪 DOOR DETECTED: {result.door_direction}")
                    # Track door location
                    door_loc = (self.robot_x, self.robot_y, result.door_direction)
                    if door_loc not in self.doors_found:
                        self.doors_found.append(door_loc)
                        self.log.door(f"│ New door added! Total doors found: {len(self.doors_found)}")
                self.log.vlm(f"│ Confidence: {result.confidence:.0%}")
                self.log.vlm(f"│ Latency: {result.latency_ms}ms")
                self.log.system("└" + "─" * 48 + "┘")
                
                self._change_state(State.DECIDE, "VLM done")
            else:
                self.log.system("No VLM available, using LiDAR only")
                self._change_state(State.DECIDE, "VLM skip")
        
        # ─────────────────────────────────────────────────────────────────────
        # DECIDE: LLM action selection (with anti-oscillation)
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.DECIDE:
            # Get VLM data
            vlm = self.last_vlm_result
            if vlm:
                scene_type = vlm.scene_type
                density = vlm.object_density
                door_detected = vlm.door_detected
                door_dir = vlm.door_direction
                navigable = vlm.navigable_directions
                description = vlm.description.lower() if vlm.description else ""
            else:
                scene_type = "unknown"
                density = "unknown"
                door_detected = False
                door_dir = None
                navigable = ["front"]
                description = ""
            
            # ─────────────────────────────────────────────────────────────────
            # SPECIAL CASE: VLM sees "void" but also mentions "wall"
            # This means we're NEAR the house - move toward the wall!
            # ─────────────────────────────────────────────────────────────────
            if scene_type == "void" and ("wall" in description or "wooden" in description):
                self.log.system("VLM sees void BUT also wall - moving toward wall!")
                decision = self._make_decision(Action.MOVE_FORWARD, "Wall detected in void - approaching house")
                self.last_decision = decision
                self.log.llm_decision(decision.action.value, decision.reason)
                self._change_state(State.EXECUTE, "wall in void - approach")
                return
            
            # ─────────────────────────────────────────────────────────────────
            # SPECIAL CASE: In void, prefer rotation over retreat
            # ─────────────────────────────────────────────────────────────────
            if scene_type == "void":
                # Check if any direction has a wall nearby
                if self.lidar_front < 3.0:
                    self.log.system("Void but front has feature - moving forward")
                    decision = self._make_decision(Action.MOVE_FORWARD, "Feature ahead in void")
                elif self.lidar_left < self.lidar_right and self.lidar_left < 3.0:
                    self.log.system("Void but left has feature - turning left")
                    decision = self._make_decision(Action.TURN_LEFT, "Feature on left in void")
                elif self.lidar_right < 3.0:
                    self.log.system("Void but right has feature - turning right")
                    decision = self._make_decision(Action.TURN_RIGHT, "Feature on right in void")
                else:
                    self.log.system("Pure void - will scan for walls")
                    decision = self._make_decision(Action.SCAN, "Scanning for walls in void")
                
                self.last_decision = decision
                self.log.llm_decision(decision.action.value, decision.reason)
                self._change_state(State.EXECUTE, "void handling")
                return
            
            # Get memory context
            memory_context = self.memory.get_summary_for_llm(self.robot_x, self.robot_y, max_objects=5)
            
            # Make decision
            if self.llm:
                self.log.system("Calling LLM...")
                
                decision = self.llm.decide(
                    lidar_front=self.lidar_front,
                    lidar_left=self.lidar_left,
                    lidar_right=self.lidar_right,
                    lidar_back=self.lidar_back,
                    vlm_scene_type=scene_type,
                    vlm_object_density=density,
                    vlm_door_detected=door_detected,
                    vlm_door_direction=door_dir,
                    vlm_navigable=navigable,
                    is_void=self.is_void,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    memory_context=memory_context
                )
            else:
                decision = self._rule_based_decision()
            
            # ─────────────────────────────────────────────────────────────────
            # ANTI-OSCILLATION: Prevent immediate turn reversal
            # ─────────────────────────────────────────────────────────────────
            if self.turn_cooldown > 0:
                if decision.action == Action.TURN_LEFT and self.last_turn_direction == "right":
                    self.log.system(f"Anti-oscillation: Blocked LEFT (just turned RIGHT)")
                    # Override to move forward or continue right
                    if self.lidar_front > self.CAUTION_DISTANCE:
                        decision = self._make_decision(Action.MOVE_FORWARD, "Anti-oscillation: forward instead")
                    else:
                        decision = self._make_decision(Action.TURN_RIGHT, "Anti-oscillation: continue right")
                
                elif decision.action == Action.TURN_RIGHT and self.last_turn_direction == "left":
                    self.log.system(f"Anti-oscillation: Blocked RIGHT (just turned LEFT)")
                    if self.lidar_front > self.CAUTION_DISTANCE:
                        decision = self._make_decision(Action.MOVE_FORWARD, "Anti-oscillation: forward instead")
                    else:
                        decision = self._make_decision(Action.TURN_LEFT, "Anti-oscillation: continue left")
            
            self.last_decision = decision
            
            self.log.llm_decision(decision.action.value, decision.reason)
            if decision.latency_ms > 0:
                self.log.llm(f"Latency: {decision.latency_ms}ms | Conf: {decision.confidence:.2f}")
            
            self._change_state(State.EXECUTE, "decided")
        
        # ─────────────────────────────────────────────────────────────────────
        # EXECUTE: Perform the action
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.EXECUTE:
            decision = self.last_decision
            
            if decision is None:
                self._change_state(State.STOP, "no decision")
                return
            
            action = decision.action
            
            # Execute and track turn direction
            if action == Action.MOVE_FORWARD:
                self._execute_forward()
            elif action == Action.TURN_LEFT:
                self._execute_turn_90("left")
                self.last_turn_direction = "left"
                self.turn_cooldown = self.TURN_COOLDOWN_CYCLES
            elif action == Action.TURN_RIGHT:
                self._execute_turn_90("right")
                self.last_turn_direction = "right"
                self.turn_cooldown = self.TURN_COOLDOWN_CYCLES
            elif action == Action.TURN_AROUND:
                self._execute_turn_180()
            elif action == Action.RETREAT:
                self._execute_retreat()
            elif action == Action.APPROACH_DOOR:
                self._execute_forward()
            elif action == Action.ENTER_ROOM:
                self._execute_forward()
            elif action == Action.SCAN:
                self._execute_scan()
            else:
                pass  # STOP
            
            self.cycle_count += 1
            stats = self.memory.get_coverage_stats()
            self.log.separator(f"Cycle {self.cycle_count} | Cells: {stats['visited_cells']} | Doors: {len(self.doors_found)} | Dist: {self.total_distance:.1f}m")
            
            # Check stuck
            self._check_stuck()
            
            self._change_state(State.STOP, "executed")
        
        # ─────────────────────────────────────────────────────────────────────
        # VOID_RECOVERY: ROTATE to find walls, then move toward them
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.VOID_RECOVERY:
            self.log.void("VOID RECOVERY: Rotating to find walls/features...")
            
            # Strategy: Do a full 360° scan, find direction with LOWEST distance
            # (lowest = closest wall = that's where the house is)
            
            best_direction = None
            best_distance = float('inf')
            scan_results = {}
            
            # Scan 4 directions (0°, 90°, 180°, 270°)
            for i, direction_name in enumerate(["CURRENT", "RIGHT_90", "BACK_180", "LEFT_270"]):
                # Read current LiDAR
                current_min = min(self.lidar_front, self.lidar_left, self.lidar_right)
                
                # Skip inf values - we want the CLOSEST wall
                if current_min < best_distance and current_min < 10.0:  # 10m = reasonable max
                    best_distance = current_min
                    best_direction = direction_name
                
                scan_results[direction_name] = {
                    "front": self.lidar_front,
                    "min": current_min
                }
                
                self.log.void(f"  {direction_name}: F={self.lidar_front:.2f}m, min={current_min:.2f}m")
                
                # Turn 90° for next scan (except on last iteration)
                if i < 3:
                    self._execute_turn_90("right")
                    time.sleep(0.3)  # Let sensors settle
            
            self.log.system("═" * 40)
            self.log.void(f"VOID SCAN COMPLETE:")
            self.log.void(f"  Best direction: {best_direction} at {best_distance:.2f}m")
            self.log.system("═" * 40)
            
            # Now turn to face the best direction and MOVE TOWARD the wall
            if best_direction == "RIGHT_90":
                self._execute_turn_90("right")
            elif best_direction == "BACK_180":
                self._execute_turn_180()
            elif best_direction == "LEFT_270":
                self._execute_turn_90("left")
            # CURRENT = already facing right way
            
            # Move toward the wall (the house!)
            if best_distance < 10.0:
                self.log.void(f"Moving TOWARD wall at {best_distance:.2f}m")
                # Move most of the way, but stop before hitting
                move_distance = max(0.3, best_distance - 0.5)
                move_time = move_distance / self.LINEAR_SPEED
                self._send_velocity(self.LINEAR_SPEED, 0.0)
                time.sleep(min(move_time, 3.0))  # Max 3 seconds
                self._send_velocity(0.0, 0.0)
            else:
                # No walls found at all - try a random direction
                self.log.void("No walls found! Trying random exploration...")
                self._execute_turn_90("right")
                self._execute_forward()
            
            self._change_state(State.STOP, "void recovery done")
        
        # ─────────────────────────────────────────────────────────────────────
        # STUCK_RECOVERY: Escape when not making progress
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.STUCK_RECOVERY:
            self.log.safety("Stuck recovery: back up and turn")
            
            # Back up
            self._send_velocity(self.RETREAT_SPEED, 0.0)
            time.sleep(1.5)
            self._send_velocity(0.0, 0.0)
            
            # Turn toward most open
            self._smart_turn()
            
            self.stuck_counter = 0
            self.position_history.clear()
            
            self._change_state(State.STOP, "stuck recovery done")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MOVEMENT HELPERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _send_velocity(self, linear: float, angular: float):
        """Send velocity command."""
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        self.cmd_vel_pub.publish(msg)
    
    def _execute_forward(self):
        """Move forward."""
        self.log.movement_command(self.LINEAR_SPEED, 0.0, self.MOVE_DURATION)
        self._send_velocity(self.LINEAR_SPEED, 0.0)
        time.sleep(self.MOVE_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_turn_90(self, direction: str):
        """Turn 90 degrees."""
        angular = self.ANGULAR_SPEED if direction == "left" else -self.ANGULAR_SPEED
        self.log.movement_command(0.0, angular, self.TURN_DURATION)
        self._send_velocity(0.0, angular)
        time.sleep(self.TURN_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_turn_180(self):
        """Turn 180 degrees."""
        duration = self.TURN_DURATION * 2
        self.log.movement_command(0.0, self.ANGULAR_SPEED, duration)
        self._send_velocity(0.0, self.ANGULAR_SPEED)
        time.sleep(duration)
        self._send_velocity(0.0, 0.0)
    
    def _execute_retreat(self):
        """Back up."""
        self.log.movement_command(self.RETREAT_SPEED, 0.0, self.MOVE_DURATION)
        self._send_velocity(self.RETREAT_SPEED, 0.0)
        time.sleep(self.MOVE_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_scan(self):
        """360° scan."""
        duration = self.TURN_DURATION * 4
        self.log.movement_command(0.0, self.ANGULAR_SPEED, duration)
        self._send_velocity(0.0, self.ANGULAR_SPEED)
        time.sleep(duration)
        self._send_velocity(0.0, 0.0)
    
    def _smart_turn(self):
        """Turn toward the most open direction."""
        # Compare left, right, and back
        if self.lidar_right > self.lidar_left and self.lidar_right > self.CAUTION_DISTANCE:
            self.log.move(f"Smart turn: RIGHT is clearer ({self.lidar_right:.2f}m)")
            self._execute_turn_90("right")
            self.last_turn_direction = "right"
            self.turn_cooldown = self.TURN_COOLDOWN_CYCLES
        elif self.lidar_left > self.CAUTION_DISTANCE:
            self.log.move(f"Smart turn: LEFT is clearer ({self.lidar_left:.2f}m)")
            self._execute_turn_90("left")
            self.last_turn_direction = "left"
            self.turn_cooldown = self.TURN_COOLDOWN_CYCLES
        elif self.lidar_back > self.CAUTION_DISTANCE:
            self.log.move(f"Smart turn: BACK is clearer ({self.lidar_back:.2f}m)")
            self._execute_turn_180()
        else:
            # All directions blocked, just turn right
            self.log.move("Smart turn: All blocked, turning right")
            self._execute_turn_90("right")
            self.last_turn_direction = "right"
            self.turn_cooldown = self.TURN_COOLDOWN_CYCLES
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STUCK DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _check_stuck(self):
        """Check if robot is stuck."""
        now = time.time()
        
        if now - self.last_stuck_check < self.STUCK_CHECK_INTERVAL:
            return
        
        self.last_stuck_check = now
        self.position_history.append((self.robot_x, self.robot_y, now))
        
        if len(self.position_history) < 3:
            return
        
        # Check movement over history
        old = self.position_history[0]
        new = self.position_history[-1]
        
        dx = new[0] - old[0]
        dy = new[1] - old[1]
        distance = math.sqrt(dx*dx + dy*dy)
        
        if distance < self.STUCK_THRESHOLD:
            self.stuck_counter += 1
            self.log.safety(f"Stuck detected ({self.stuck_counter}/{self.MAX_STUCK_COUNT})")
            
            if self.stuck_counter >= self.MAX_STUCK_COUNT:
                self._change_state(State.STUCK_RECOVERY, "stuck threshold")
        else:
            self.stuck_counter = 0
    
    # ═══════════════════════════════════════════════════════════════════════════
    # DECISION HELPERS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _make_decision(self, action: Action, reason: str):
        """Create a simple decision object."""
        from llm_client import Decision
        return Decision(
            action=action,
            reason=reason,
            confidence=0.9,
            target_direction=None,
            parameters={},
            raw_response="[OVERRIDE]",
            latency_ms=0
        )
    
    def _rule_based_decision(self):
        """Fallback rule-based decision."""
        from llm_client import Decision
        
        if self.is_void:
            return self._make_decision(Action.RETREAT, "Void detected")
        
        if self.lidar_front < self.CAUTION_DISTANCE:
            if self.lidar_right > self.lidar_left:
                return self._make_decision(Action.TURN_RIGHT, f"Obstacle ahead, right clearer ({self.lidar_right:.2f}m)")
            else:
                return self._make_decision(Action.TURN_LEFT, f"Obstacle ahead, left clearer ({self.lidar_left:.2f}m)")
        
        return self._make_decision(Action.MOVE_FORWARD, "Path clear ahead")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _save_memory(self):
        """Periodic memory save."""
        self.memory.save_all()
        stats = self.memory.get_coverage_stats()
        self.log.memory(f"Saved: {stats['visited_cells']} cells, {stats['objects_found']} objects")


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main(args=None):
    rclpy.init(args=args)
    
    node = NovaSentinel()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.log.system("Shutdown requested...")
    finally:
        node._send_velocity(0.0, 0.0)
        node.memory.save_all()
        node.log.system("Goodbye!")
        
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
