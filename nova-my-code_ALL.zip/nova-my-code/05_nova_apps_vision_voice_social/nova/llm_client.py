#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22 - LLM Client (Scout)
═══════════════════════════════════════════════════════════════════════════════
Decision-making LLM. Takes sensor data + VLM analysis → outputs action command.
BE SLOW BUT CORRECT: Only called when robot is STOPPED.
═══════════════════════════════════════════════════════════════════════════════
"""

import json
import re
import time
from dataclasses import dataclass
from typing import Optional, List
from enum import Enum


class Action(Enum):
    """Valid robot actions."""
    MOVE_FORWARD = "move_forward"
    TURN_LEFT = "turn_left"
    TURN_RIGHT = "turn_right"
    TURN_AROUND = "turn_around"
    RETREAT = "retreat"
    APPROACH_DOOR = "approach_door"
    ENTER_ROOM = "enter_room"
    STOP = "stop"
    SCAN = "scan"


@dataclass
class Decision:
    """Result of LLM decision making."""
    action: Action
    reason: str
    confidence: float
    target_direction: Optional[str]  # "left", "right", "front", etc.
    parameters: dict  # Action-specific params (speed, duration, etc.)
    raw_response: str
    latency_ms: int


class LLMClient:
    """
    Client for Scout LLM decision making.
    
    Features:
    - Structured prompts with sensor context
    - 3-tier JSON extraction
    - Action validation
    - Memory context injection
    """
    
    def __init__(
        self,
        api_key: str,
        model: str = "meta-llama/llama-4-scout-17b-16e-instruct",
        max_tokens: int = 256,
        temperature: float = 0.1,
        timeout_s: float = 5.0
    ):
        self.api_key = api_key
        self.model = model
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.timeout = timeout_s
        
        self.client = None
        self._init_client()
    
    def _init_client(self):
        """Initialize Groq client."""
        try:
            from groq import Groq
            self.client = Groq(api_key=self.api_key)
        except ImportError:
            print("[LLM] Warning: groq package not installed")
            self.client = None
        except Exception as e:
            print(f"[LLM] Warning: Could not initialize Groq client: {e}")
            self.client = None
    
    def _build_system_prompt(self) -> str:
        """Build the system prompt for Scout."""
        return """You are Scout, the navigation brain for NOVA robot.

Your job: Analyze sensor data and VLM scene analysis, then decide the best action.

CRITICAL RULES:
1. If in VOID (all LiDAR > 3m): ALWAYS choose "retreat" - you're lost in empty space
2. If door detected: Approach and enter if path is clear
3. If obstacle ahead (front < 0.5m): Turn to clearest direction
4. Prefer exploring new areas over revisiting
5. Stay near walls when possible (wall following)

VALID ACTIONS:
- "move_forward": Clear path ahead, continue exploring
- "turn_left": Turn 90° left
- "turn_right": Turn 90° right  
- "turn_around": Turn 180° (dead end)
- "retreat": Back up (void detected, need features)
- "approach_door": Move toward detected door
- "enter_room": Pass through doorway
- "stop": Wait/observe
- "scan": Rotate in place to gather data

Respond with ONLY a JSON object:
{
    "action": "action_name",
    "reason": "brief explanation",
    "confidence": 0.0-1.0,
    "target_direction": "left" | "right" | "front" | null,
    "parameters": {}
}"""
    
    def _build_user_prompt(
        self,
        lidar_front: float,
        lidar_left: float,
        lidar_right: float,
        lidar_back: float,
        vlm_scene_type: str,
        vlm_object_density: str,
        vlm_door_detected: bool,
        vlm_door_direction: Optional[str],
        vlm_navigable: List[str],
        is_void: bool,
        robot_x: float,
        robot_y: float,
        memory_context: str = ""
    ) -> str:
        """Build the user prompt with current sensor state."""
        
        prompt = f"""CURRENT STATE:

LIDAR (distances in meters):
- Front: {lidar_front:.2f}m
- Left: {lidar_left:.2f}m
- Right: {lidar_right:.2f}m
- Back: {lidar_back:.2f}m

VLM ANALYSIS:
- Scene: {vlm_scene_type}
- Object density: {vlm_object_density}
- Door detected: {vlm_door_detected}
- Door direction: {vlm_door_direction or 'none'}
- Navigable directions: {', '.join(vlm_navigable)}

ROBOT POSITION: ({robot_x:.2f}, {robot_y:.2f})

VOID STATUS: {"⚠️ IN VOID - RETREAT IMMEDIATELY" if is_void else "Normal"}
"""
        
        if memory_context:
            prompt += f"\nMEMORY CONTEXT:\n{memory_context}\n"
        
        prompt += "\nWhat action should the robot take? Respond with JSON only."
        
        return prompt
    
    def _extract_json(self, response: str) -> Optional[dict]:
        """3-tier JSON extraction."""
        text = response.strip()
        
        # Tier 1: Direct parse
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        
        # Tier 2: Regex
        patterns = [
            r'```json\s*(.*?)\s*```',
            r'```\s*(.*?)\s*```',
            r'(\{[^{}]*\})',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.DOTALL)
            for match in matches:
                try:
                    cleaned = match.replace("'", '"')
                    return json.loads(cleaned)
                except json.JSONDecodeError:
                    continue
        
        # Tier 3: Brace counting
        try:
            start = text.find('{')
            if start == -1:
                return None
            
            depth = 0
            end = start
            for i, char in enumerate(text[start:], start):
                if char == '{':
                    depth += 1
                elif char == '}':
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            
            json_str = text[start:end]
            json_str = json_str.replace("'", '"')
            json_str = re.sub(r',\s*}', '}', json_str)
            json_str = re.sub(r',\s*]', ']', json_str)
            
            return json.loads(json_str)
        except:
            return None
    
    def _validate_action(self, action_str: str) -> Action:
        """Convert string to valid Action enum."""
        action_str = action_str.lower().strip()
        
        # Map variations to standard actions
        action_map = {
            "move_forward": Action.MOVE_FORWARD,
            "forward": Action.MOVE_FORWARD,
            "go_forward": Action.MOVE_FORWARD,
            "turn_left": Action.TURN_LEFT,
            "left": Action.TURN_LEFT,
            "turn_right": Action.TURN_RIGHT,
            "right": Action.TURN_RIGHT,
            "turn_around": Action.TURN_AROUND,
            "turnaround": Action.TURN_AROUND,
            "reverse": Action.TURN_AROUND,
            "retreat": Action.RETREAT,
            "back": Action.RETREAT,
            "backup": Action.RETREAT,
            "approach_door": Action.APPROACH_DOOR,
            "approach": Action.APPROACH_DOOR,
            "enter_room": Action.ENTER_ROOM,
            "enter": Action.ENTER_ROOM,
            "stop": Action.STOP,
            "wait": Action.STOP,
            "scan": Action.SCAN,
            "rotate": Action.SCAN,
        }
        
        return action_map.get(action_str, Action.STOP)
    
    def decide(
        self,
        lidar_front: float,
        lidar_left: float,
        lidar_right: float,
        lidar_back: float,
        vlm_scene_type: str,
        vlm_object_density: str,
        vlm_door_detected: bool,
        vlm_door_direction: Optional[str],
        vlm_navigable: List[str],
        is_void: bool,
        robot_x: float,
        robot_y: float,
        memory_context: str = ""
    ) -> Decision:
        """
        Make a navigation decision.
        
        Args:
            lidar_*: LiDAR distances for each sector
            vlm_*: VLM analysis results
            is_void: Whether void detector triggered
            robot_x, robot_y: Current position
            memory_context: Optional context from memory
            
        Returns:
            Decision with action and reasoning
        """
        start_time = time.time()
        
        # Default fallback decision
        fallback = Decision(
            action=Action.STOP,
            reason="LLM decision failed",
            confidence=0.0,
            target_direction=None,
            parameters={},
            raw_response="",
            latency_ms=0
        )
        
        # Override: If void, don't even ask LLM - retreat immediately
        if is_void:
            return Decision(
                action=Action.RETREAT,
                reason="VOID DETECTED - All directions clear, retreating to find walls",
                confidence=1.0,
                target_direction="back",
                parameters={"speed": -0.1},
                raw_response="[VOID OVERRIDE - LLM bypassed]",
                latency_ms=0
            )
        
        # Override: Emergency stop if obstacle too close
        if lidar_front < 0.3:
            # Pick clearest direction
            if lidar_left > lidar_right:
                return Decision(
                    action=Action.TURN_LEFT,
                    reason="Obstacle ahead, left is clearer",
                    confidence=1.0,
                    target_direction="left",
                    parameters={},
                    raw_response="[SAFETY OVERRIDE - LLM bypassed]",
                    latency_ms=0
                )
            else:
                return Decision(
                    action=Action.TURN_RIGHT,
                    reason="Obstacle ahead, right is clearer",
                    confidence=1.0,
                    target_direction="right",
                    parameters={},
                    raw_response="[SAFETY OVERRIDE - LLM bypassed]",
                    latency_ms=0
                )
        
        if not self.client:
            fallback.reason = "LLM client not initialized"
            return fallback
        
        try:
            # Build prompts
            system_prompt = self._build_system_prompt()
            user_prompt = self._build_user_prompt(
                lidar_front, lidar_left, lidar_right, lidar_back,
                vlm_scene_type, vlm_object_density,
                vlm_door_detected, vlm_door_direction, vlm_navigable,
                is_void, robot_x, robot_y, memory_context
            )
            
            # Make API call
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=self.max_tokens,
                temperature=self.temperature
            )
            
            raw_response = response.choices[0].message.content
            
            # Extract JSON
            data = self._extract_json(raw_response)
            
            if data is None:
                fallback.raw_response = raw_response
                fallback.reason = "Could not parse LLM response"
                fallback.latency_ms = int((time.time() - start_time) * 1000)
                return fallback
            
            latency_ms = int((time.time() - start_time) * 1000)
            
            # Build decision
            action = self._validate_action(data.get("action", "stop"))
            
            return Decision(
                action=action,
                reason=data.get("reason", "No reason provided"),
                confidence=float(data.get("confidence", 0.5)),
                target_direction=data.get("target_direction"),
                parameters=data.get("parameters", {}),
                raw_response=raw_response,
                latency_ms=latency_ms
            )
            
        except Exception as e:
            fallback.reason = f"LLM error: {str(e)}"
            fallback.latency_ms = int((time.time() - start_time) * 1000)
            return fallback
    
    def decide_simple(
        self,
        lidar_front: float,
        lidar_left: float,
        lidar_right: float,
        is_void: bool
    ) -> Decision:
        """
        Simple rule-based decision without LLM.
        Use as fallback or for fast reactions.
        """
        # Void: retreat
        if is_void:
            return Decision(
                action=Action.RETREAT,
                reason="Void detected",
                confidence=1.0,
                target_direction="back",
                parameters={},
                raw_response="[RULE-BASED]",
                latency_ms=0
            )
        
        # Obstacle ahead
        if lidar_front < 0.5:
            if lidar_left > lidar_right:
                return Decision(
                    action=Action.TURN_LEFT,
                    reason=f"Obstacle ahead ({lidar_front:.2f}m), left clearer",
                    confidence=0.9,
                    target_direction="left",
                    parameters={},
                    raw_response="[RULE-BASED]",
                    latency_ms=0
                )
            else:
                return Decision(
                    action=Action.TURN_RIGHT,
                    reason=f"Obstacle ahead ({lidar_front:.2f}m), right clearer",
                    confidence=0.9,
                    target_direction="right",
                    parameters={},
                    raw_response="[RULE-BASED]",
                    latency_ms=0
                )
        
        # Clear ahead
        return Decision(
            action=Action.MOVE_FORWARD,
            reason="Path clear ahead",
            confidence=0.8,
            target_direction="front",
            parameters={},
            raw_response="[RULE-BASED]",
            latency_ms=0
        )


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import os
    
    print("Testing LLM Client...")
    
    # Test rule-based decisions
    client = LLMClient(api_key="dummy")
    
    print("\n--- Rule-based tests ---")
    
    # Test void
    decision = client.decide_simple(5.0, 5.0, 5.0, is_void=True)
    print(f"Void scenario: {decision.action.value} - {decision.reason}")
    
    # Test obstacle
    decision = client.decide_simple(0.3, 1.5, 0.8, is_void=False)
    print(f"Obstacle scenario: {decision.action.value} - {decision.reason}")
    
    # Test clear
    decision = client.decide_simple(2.0, 1.0, 1.0, is_void=False)
    print(f"Clear scenario: {decision.action.value} - {decision.reason}")
    
    # Test JSON extraction
    print("\n--- JSON extraction tests ---")
    
    test_responses = [
        '{"action": "move_forward", "reason": "clear path", "confidence": 0.8}',
        '```json\n{"action": "turn_left", "confidence": 0.7}\n```',
        'Based on analysis: {"action": "retreat", "reason": "void"} is my recommendation.',
    ]
    
    for resp in test_responses:
        result = client._extract_json(resp)
        if result:
            print(f"  ✅ Extracted action: {result.get('action', 'N/A')}")
        else:
            print(f"  ❌ Failed to extract")
    
    print("\n✅ LLM client tests complete")
