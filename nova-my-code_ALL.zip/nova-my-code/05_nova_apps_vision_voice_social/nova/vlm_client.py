#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22 - VLM Client (Maverick)
═══════════════════════════════════════════════════════════════════════════════
Vision-Language Model for scene understanding.
BE SLOW BUT CORRECT: Only called when robot is STOPPED.
═══════════════════════════════════════════════════════════════════════════════
"""

import base64
import json
import re
import time
from dataclasses import dataclass
from typing import Optional, Tuple
from io import BytesIO

# Will be imported when ROS is available
# from PIL import Image
# from groq import Groq


@dataclass
class SceneAnalysis:
    """Result of VLM scene analysis."""
    scene_type: str          # "room", "corridor", "void", "doorway"
    object_density: str      # "high", "medium", "low", "empty"
    door_detected: bool
    door_direction: Optional[str]  # "left", "right", "front", None
    navigable_directions: list     # ["front", "left", "right"]
    description: str         # Brief scene description
    confidence: float        # 0.0 to 1.0
    raw_response: str        # Original LLM response for debugging
    latency_ms: int          # How long the call took


class VLMClient:
    """
    Client for Maverick VLM scene analysis.
    
    Features:
    - Image preprocessing (resize, compress)
    - 3-tier JSON extraction (handles malformed responses)
    - Rate limiting
    - Timeout handling
    """
    
    def __init__(
        self,
        api_key: str,
        model: str = "meta-llama/llama-4-maverick-17b-128e-instruct",
        resize_width: int = 512,
        resize_height: int = 512,
        jpeg_quality: int = 50,
        timeout_s: float = 10.0,
        min_interval_s: float = 4.0
    ):
        self.api_key = api_key
        self.model = model
        self.resize_width = resize_width
        self.resize_height = resize_height
        self.jpeg_quality = jpeg_quality
        self.timeout = timeout_s
        self.min_interval = min_interval_s
        
        self.last_call_time = 0.0
        self.client = None
        
        # Initialize Groq client
        self._init_client()
    
    def _init_client(self):
        """Initialize Groq client."""
        try:
            from groq import Groq
            self.client = Groq(api_key=self.api_key)
        except ImportError:
            print("[VLM] Warning: groq package not installed")
            self.client = None
        except Exception as e:
            print(f"[VLM] Warning: Could not initialize Groq client: {e}")
            self.client = None
    
    def _preprocess_image(self, image_bytes: bytes) -> str:
        """
        Resize and compress image, return base64 string.
        
        Args:
            image_bytes: Raw image bytes (from ROS message)
            
        Returns:
            Base64-encoded JPEG string
        """
        try:
            from PIL import Image
            
            # Load image
            img = Image.open(BytesIO(image_bytes))
            
            # Resize
            img = img.resize((self.resize_width, self.resize_height), Image.LANCZOS)
            
            # Convert to RGB if needed
            if img.mode != 'RGB':
                img = img.convert('RGB')
            
            # Compress to JPEG
            buffer = BytesIO()
            img.save(buffer, format='JPEG', quality=self.jpeg_quality)
            
            # Encode to base64
            return base64.b64encode(buffer.getvalue()).decode('utf-8')
            
        except Exception as e:
            print(f"[VLM] Image preprocessing error: {e}")
            return None
    
    def _preprocess_cv2_frame(self, cv2_frame) -> str:
        """
        Preprocess OpenCV frame to base64.
        
        Args:
            cv2_frame: NumPy array from cv2/ROS
            
        Returns:
            Base64-encoded JPEG string
        """
        try:
            import cv2
            
            # Resize
            resized = cv2.resize(cv2_frame, (self.resize_width, self.resize_height))
            
            # Encode to JPEG
            _, buffer = cv2.imencode('.jpg', resized, [cv2.IMWRITE_JPEG_QUALITY, self.jpeg_quality])
            
            # Encode to base64
            return base64.b64encode(buffer).decode('utf-8')
            
        except Exception as e:
            print(f"[VLM] CV2 preprocessing error: {e}")
            return None
    
    def _build_prompt(self) -> str:
        """Build the scene analysis prompt."""
        return """Analyze this robot camera image and respond with ONLY a JSON object (no other text):

{
    "scene_type": "room" | "corridor" | "void" | "doorway",
    "object_density": "high" | "medium" | "low" | "empty",
    "door_detected": true | false,
    "door_direction": "left" | "right" | "front" | null,
    "navigable_directions": ["front", "left", "right"],
    "description": "brief 10-word description",
    "confidence": 0.0-1.0
}

RULES:
- "void" = featureless grey/empty space (simulation boundary)
- "doorway" = clear opening leading to another space
- navigable_directions = directions with clear path (no obstacles within 1m)
- door_direction = where you see a door/opening, null if none
- BE ACCURATE about what you see, not what you expect"""
    
    def _extract_json(self, response: str) -> Optional[dict]:
        """
        3-tier JSON extraction to handle malformed LLM responses.
        
        Tier 1: Direct parse
        Tier 2: Regex extraction
        Tier 3: Brace counting
        """
        # Clean response
        text = response.strip()
        
        # Tier 1: Direct parse
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            pass
        
        # Tier 2: Regex for JSON block (handles ```json...```)
        patterns = [
            r'```json\s*(.*?)\s*```',  # Markdown code block
            r'```\s*(.*?)\s*```',       # Generic code block
            r'(\{[^{}]*\})',            # Simple object
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.DOTALL)
            for match in matches:
                try:
                    # Fix common issues
                    cleaned = match.replace("'", '"')  # Single to double quotes
                    return json.loads(cleaned)
                except json.JSONDecodeError:
                    continue
        
        # Tier 3: Brace counting extraction
        try:
            start = text.find('{')
            if start == -1:
                return None
            
            depth = 0
            end = start
            for i, char in enumerate(text[start:], start):
                if char == '{':
                    depth += 1
                elif char == '}':
                    depth -= 1
                    if depth == 0:
                        end = i + 1
                        break
            
            json_str = text[start:end]
            # Fix common issues
            json_str = json_str.replace("'", '"')
            json_str = re.sub(r',\s*}', '}', json_str)  # Trailing comma
            json_str = re.sub(r',\s*]', ']', json_str)  # Trailing comma in array
            
            return json.loads(json_str)
            
        except (json.JSONDecodeError, Exception):
            return None
    
    def _validate_response(self, data: dict) -> dict:
        """Validate and fill missing fields with defaults."""
        defaults = {
            "scene_type": "unknown",
            "object_density": "unknown",
            "door_detected": False,
            "door_direction": None,
            "navigable_directions": ["front"],
            "description": "Unable to analyze scene",
            "confidence": 0.0
        }
        
        for key, default in defaults.items():
            if key not in data:
                data[key] = default
        
        # Normalize values
        data["scene_type"] = data["scene_type"].lower()
        data["object_density"] = data["object_density"].lower()
        
        if data["door_direction"]:
            data["door_direction"] = data["door_direction"].lower()
        
        # Ensure navigable_directions is a list
        if not isinstance(data["navigable_directions"], list):
            data["navigable_directions"] = ["front"]
        
        return data
    
    def analyze_scene(self, image_base64: str) -> SceneAnalysis:
        """
        Analyze scene from base64-encoded image.
        
        Args:
            image_base64: Base64-encoded JPEG image
            
        Returns:
            SceneAnalysis result
        """
        start_time = time.time()
        
        # Rate limiting
        elapsed = time.time() - self.last_call_time
        if elapsed < self.min_interval:
            wait_time = self.min_interval - elapsed
            time.sleep(wait_time)
        
        # Default error response
        error_response = SceneAnalysis(
            scene_type="unknown",
            object_density="unknown",
            door_detected=False,
            door_direction=None,
            navigable_directions=["front"],
            description="VLM analysis failed",
            confidence=0.0,
            raw_response="",
            latency_ms=0
        )
        
        if not self.client:
            error_response.description = "VLM client not initialized"
            return error_response
        
        if not image_base64:
            error_response.description = "No image provided"
            return error_response
        
        try:
            # Build message with image
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{image_base64}"
                            }
                        },
                        {
                            "type": "text",
                            "text": self._build_prompt()
                        }
                    ]
                }
            ]
            
            # Make API call
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                max_tokens=256,
                temperature=0.1
            )
            
            self.last_call_time = time.time()
            raw_response = response.choices[0].message.content
            
            # Extract JSON
            data = self._extract_json(raw_response)
            
            if data is None:
                error_response.raw_response = raw_response
                error_response.description = "Could not parse VLM response"
                error_response.latency_ms = int((time.time() - start_time) * 1000)
                return error_response
            
            # Validate and fill defaults
            data = self._validate_response(data)
            
            latency_ms = int((time.time() - start_time) * 1000)
            
            return SceneAnalysis(
                scene_type=data["scene_type"],
                object_density=data["object_density"],
                door_detected=data["door_detected"],
                door_direction=data["door_direction"],
                navigable_directions=data["navigable_directions"],
                description=data["description"],
                confidence=float(data["confidence"]),
                raw_response=raw_response,
                latency_ms=latency_ms
            )
            
        except Exception as e:
            error_response.description = f"VLM error: {str(e)}"
            error_response.latency_ms = int((time.time() - start_time) * 1000)
            return error_response
    
    def analyze_cv2_frame(self, cv2_frame) -> SceneAnalysis:
        """
        Analyze scene from OpenCV frame.
        
        Args:
            cv2_frame: NumPy array from cv2/ROS
            
        Returns:
            SceneAnalysis result
        """
        image_base64 = self._preprocess_cv2_frame(cv2_frame)
        return self.analyze_scene(image_base64)


# ═══════════════════════════════════════════════════════════════════════════════
# STANDALONE TEST
# ═══════════════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    import os
    
    # Check for API key
    api_key = os.environ.get("GROQ_API_KEY")
    
    if not api_key:
        print("Set GROQ_API_KEY environment variable to test")
        print("\nTesting JSON extraction only...")
        
        client = VLMClient(api_key="dummy")
        
        # Test various malformed responses
        test_responses = [
            '{"scene_type": "room", "object_density": "high", "door_detected": false, "door_direction": null, "navigable_directions": ["front"], "description": "test", "confidence": 0.8}',
            '```json\n{"scene_type": "corridor", "confidence": 0.7}\n```',
            'Here is my analysis: {"scene_type": "void", "confidence": 0.5} Hope that helps!',
            "{'scene_type': 'room', 'confidence': 0.6}",  # Single quotes
        ]
        
        for i, response in enumerate(test_responses):
            print(f"\nTest {i+1}: {response[:50]}...")
            result = client._extract_json(response)
            if result:
                print(f"  ✅ Extracted: {result.get('scene_type', 'N/A')}")
            else:
                print(f"  ❌ Failed to extract")
        
        print("\n✅ JSON extraction tests complete")
    else:
        print("API key found, but no image to test with")
        print("Run with ROS to test full VLM pipeline")
