#!/usr/bin/env python3
"""map_relay.py - republish the latched /map as a VOLATILE topic.

rosbridge subscribes VOLATILE, so it can NEVER receive map_server's
TRANSIENT_LOCAL (latched) map - that message was published once, before
rosbridge existed. This relay bridges the gap.
"""
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
from nav_msgs.msg import OccupancyGrid


class MapRelay(Node):
    def __init__(self):
        super().__init__('map_relay')
        self.declare_parameter('in_topic', '/map')
        self.declare_parameter('out_topic', '/map_relay')
        self.declare_parameter('rate', 0.2)
        g = self.get_parameter
        src = g('in_topic').value
        dst = g('out_topic').value

        latched = QoSProfile(
            depth=1,
            history=QoSHistoryPolicy.KEEP_LAST,
            reliability=QoSReliabilityPolicy.RELIABLE,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
        )
        volatile = QoSProfile(
            depth=1,
            history=QoSHistoryPolicy.KEEP_LAST,
            reliability=QoSReliabilityPolicy.RELIABLE,
            durability=QoSDurabilityPolicy.VOLATILE,
        )

        self.msg = None
        self.create_subscription(OccupancyGrid, src, self._cb, latched)
        self.pub = self.create_publisher(OccupancyGrid, dst, volatile)
        self.create_timer(1.0 / max(0.1, g('rate').value), self._tick)
        self.get_logger().info(f"map_relay: {src} (latched) -> {dst} (volatile)")

    def _cb(self, m):
        if self.msg is None:
            self.get_logger().info(
                f"got map {m.info.width}x{m.info.height} @ {m.info.resolution}")
        self.msg = m

    def _tick(self):
        if self.msg is not None:
            self.pub.publish(self.msg)


def main():
    rclpy.init()
    n = MapRelay()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
