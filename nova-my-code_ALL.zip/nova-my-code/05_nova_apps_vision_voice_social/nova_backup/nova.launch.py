import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_desc  = get_package_share_directory('nova')
    pkg_world = get_package_share_directory('aws_robomaker_small_house_world')

    xacro_file = os.path.join(pkg_desc, 'urdf', 'nova.urdf.xacro')

    # Spawn pose — MUST match AMCL initial_pose in nav2_params.yaml.
    # Change both together if you move the start point.
    spawn_x = LaunchConfiguration('x', default='0.0')
    spawn_y = LaunchConfiguration('y', default='0.0')
    spawn_z = LaunchConfiguration('z', default='0.15')
    spawn_yaw = LaunchConfiguration('yaw', default='0.0')

    robot_desc = ParameterValue(
        Command(['xacro ', xacro_file, ' use_sim:=true']), value_type=str)
    robot_desc_param = {'robot_description': robot_desc, 'use_sim_time': True}

    set_resource_path = SetEnvironmentVariable(
        name='IGN_GAZEBO_RESOURCE_PATH',
        value=os.path.join(pkg_desc, '..', '..'))

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_world, 'launch', 'small_house.launch.py')))

    rsp = Node(
        package='robot_state_publisher', executable='robot_state_publisher',
        name='robot_state_publisher', output='screen',
        parameters=[robot_desc_param])

    # NOTE: NO standalone joint_state_publisher here.
    # The Gazebo JointStatePublisher plugin already publishes real /joint_states;
    # running the standalone node too causes competing/zeroed joint states and
    # wheel-TF jitter. robot_state_publisher consumes the plugin's /joint_states.

    spawn = Node(
        package='ros_gz_sim', executable='create',
        arguments=['-name', 'nova', '-topic', '/robot_description',
                   '-x', spawn_x, '-y', spawn_y, '-z', spawn_z, '-Y', spawn_yaw],
        output='screen')

    # Bridge: clock, cmd_vel, odom, joint_states, sensors.
    # IMPORTANT: we DO bridge /tf (DiffDrive's odom->base_footprint). That is the
    # ONLY source of odom->base_footprint. Do not run any other odom TF publisher.
    bridge = Node(
        package='ros_gz_bridge', executable='parameter_bridge',
        name='ros_gz_bridge', output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
            '/cmd_vel@geometry_msgs/msg/Twist]ignition.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry[ignition.msgs.Odometry',
            '/joint_states@sensor_msgs/msg/JointState[ignition.msgs.Model',
            '/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            '/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/imu/data@sensor_msgs/msg/Imu[ignition.msgs.IMU',
            '/camera/image@sensor_msgs/msg/Image[ignition.msgs.Image',
            '/dirt_cam/image@sensor_msgs/msg/Image[ignition.msgs.Image',
            '/dirt_cam/camera_info@sensor_msgs/msg/CameraInfo[ignition.msgs.CameraInfo',
            '/cliff/fl@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/cliff/fr@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/cliff/rl@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/cliff/rr@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ultrasonic/left@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ultrasonic/center@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ultrasonic/right@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ir/left@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ir/right@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
        ])

    converter = Node(
        package='nova', executable='range_converter',
        name='range_converter', output='screen',
        parameters=[{'use_sim_time': True}])

    rviz = Node(package='rviz2', executable='rviz2', name='rviz2', output='screen')


    odom_tf = Node(
        package='nova', executable='odom_tf_broadcaster',
        name='odom_tf_broadcaster', output='screen',
        parameters=[{'use_sim_time': True}])

    return LaunchDescription([
        DeclareLaunchArgument('x', default_value='0.0'),
        DeclareLaunchArgument('y', default_value='0.0'),
        DeclareLaunchArgument('z', default_value='0.15'),
        DeclareLaunchArgument('yaw', default_value='0.0'),
        set_resource_path, gazebo, rsp, spawn, bridge, converter, rviz,
    ])