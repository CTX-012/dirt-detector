#!/usr/bin/env python3
"""
Export YOLOv8n-seg to a TensorRT engine for faster inference.

Run once after install. Produces models/yolov8n-seg.engine which can be
referenced from config/nova.toml under models.yolo_engine_path.

Usage:
  python scripts/export_yolo_trt.py                    # FP16 (recommended)
  python scripts/export_yolo_trt.py --int8             # INT8 (small accuracy hit)
  python scripts/export_yolo_trt.py --imgsz 480        # smaller input

Requirements:
  - NVIDIA GPU with TensorRT installed (comes with `ultralytics[export]`)
  - pip install ultralytics[export]

Expected speedup on RTX 3060/3080:
  PyTorch fp16 → TensorRT fp16: ~2× faster
  TensorRT fp16 → TensorRT int8: another ~1.3× faster, ~5% mAP loss
"""
import argparse
import sys
from pathlib import Path


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--model", default="yolov8n-seg.pt", help="source .pt file")
    p.add_argument("--imgsz", type=int, default=640, help="export resolution")
    p.add_argument("--int8", action="store_true", help="INT8 quantization (else FP16)")
    p.add_argument("--out", default="models/yolov8n-seg.engine", help="output path")
    args = p.parse_args()

    try:
        from ultralytics import YOLO
    except ImportError:
        print("❌ ultralytics not installed. Run: pip install ultralytics[export]")
        sys.exit(1)

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    print(f"📦 Exporting {args.model} → {out_path}")
    print(f"   imgsz={args.imgsz}, precision={'INT8' if args.int8 else 'FP16'}")

    model = YOLO(args.model)
    # `format='engine'` triggers Ultralytics' built-in ONNX → TensorRT pipeline
    engine_file = model.export(
        format="engine",
        imgsz=args.imgsz,
        half=not args.int8,
        int8=args.int8,
        device=0,
    )
    # Ultralytics writes the engine alongside the .pt — copy/rename if needed
    src = Path(engine_file)
    if src != out_path:
        src.rename(out_path)

    print(f"\n✅ Done. Engine: {out_path}")
    print(f"\nNext: edit config/nova.toml and set:")
    print(f'  [models]')
    print(f'  yolo_engine_path = "{out_path}"')


if __name__ == "__main__":
    main()
