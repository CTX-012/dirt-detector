#!/usr/bin/env python3
"""
Standalone calibration runner. Use this if auto-calibration on first boot
didn't work, or after physically moving the camera mount.

Usage:
  python scripts/calibrate.py                 # spin, observe, save
  python scripts/calibrate.py --manual        # interactive: enter measurements
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from robot.config import load_config
from robot.hardware import Camera, MotorController
from robot.perception import GroundPlaneCalibrator


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--manual", action="store_true",
                   help="Skip auto-cal; enter height/tilt manually")
    p.add_argument("--height", type=float, default=None,
                   help="Camera height above floor (mm)")
    p.add_argument("--tilt", type=float, default=None,
                   help="Camera tilt below horizontal (degrees)")
    args = p.parse_args()

    cfg = load_config()
    out_path = Path(cfg.calibration.file_path)

    if args.manual or args.height is not None:
        height = args.height if args.height is not None else float(
            input("Camera height above floor in mm (e.g. 80): "))
        tilt = args.tilt if args.tilt is not None else float(
            input("Camera tilt angle in degrees (e.g. 20): "))
        cal = GroundPlaneCalibrator(camera_height_mm=height, camera_tilt_deg=tilt)
        cal.data.confidence = 1.0
        cal.data.notes = "manually entered"
        cal.save(out_path)
        print(f"✅ Calibration saved with manual values.")
        return

    # Auto path
    print("Auto-calibration: the robot will spin slowly for 5 seconds.")
    print("Make sure it's on a flat surface with floor visible.")
    input("Press Enter when ready (Ctrl-C to cancel)...")

    camera = Camera(index=cfg.hardware.camera_index)
    if not camera.is_open:
        print("❌ Camera not available. Check config/nova.toml.")
        sys.exit(1)

    motor = MotorController(port=cfg.hardware.arduino_port,
                            baud_rate=cfg.hardware.arduino_baud)
    if not motor.is_connected:
        print("⚠️  Motors not connected. Continuing in simulation mode (no spin).")
        print("   This will produce a low-confidence default calibration.")

    cal = GroundPlaneCalibrator(
        camera_height_mm=cfg.calibration.camera_height_mm,
        camera_tilt_deg=cfg.calibration.camera_tilt_deg,
    )
    success = cal.calibrate_from_spin(camera, motor, duration_s=5.0)
    cal.save(out_path)

    camera.release()
    motor.close()

    if success:
        print(f"\n✅ Calibration complete.")
        print(f"   Camera tilt:    {cal.data.camera_tilt_deg:.1f}°")
        print(f"   Camera height:  {cal.data.camera_height_m * 1000:.0f} mm")
        print(f"   Confidence:     {cal.data.confidence:.2f}")
    else:
        print(f"\n⚠️  Calibration didn't converge — saved defaults.")
        print(f"   Try --manual to enter values directly.")


if __name__ == "__main__":
    main()
