#!/usr/bin/env python3
"""
Export Depth Anything V2-Small to a TensorRT engine.

This pulls the ONNX model from the community-maintained Hugging Face repo
(faster + more battle-tested than exporting from PyTorch ourselves), then
builds a TensorRT engine optimized for your specific GPU.

Usage:
  python scripts/export_depth_trt.py                # FP16 at 518×518
  python scripts/export_depth_trt.py --imgsz 384    # smaller, faster

Requirements:
  - tensorrt (comes with NVIDIA's TensorRT install)
  - onnx, onnxruntime (for verification)
  - huggingface_hub (to download the ONNX model)

Expected latency on RTX 3060/3080 at 518² FP16:
  ~10-15 ms (3060) / ~6-10 ms (3080)
"""
import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def download_onnx(out_dir: Path, imgsz: int) -> Path:
    try:
        from huggingface_hub import hf_hub_download
    except ImportError:
        print("❌ huggingface_hub not installed. Run: pip install huggingface_hub")
        sys.exit(1)

    print("📥 Downloading Depth Anything V2-Small ONNX...")
    # onnx-community maintains pre-exported ONNX models for HF transformers
    onnx_path = hf_hub_download(
        repo_id="onnx-community/depth-anything-v2-small",
        filename="onnx/model.onnx",
        cache_dir=str(out_dir / ".hf_cache"),
    )
    return Path(onnx_path)


def build_engine(onnx_path: Path, engine_path: Path, imgsz: int):
    """Use the `trtexec` binary that ships with TensorRT."""
    trtexec = shutil.which("trtexec")
    if not trtexec:
        print("❌ trtexec not found in PATH.")
        print("   Install TensorRT and ensure /usr/src/tensorrt/bin is in PATH,")
        print("   or use the polygraphy Python API as a fallback.")
        sys.exit(1)

    print(f"🔨 Building TensorRT engine (FP16, {imgsz}x{imgsz})...")
    cmd = [
        trtexec,
        f"--onnx={onnx_path}",
        f"--saveEngine={engine_path}",
        "--fp16",
        f"--minShapes=pixel_values:1x3x{imgsz}x{imgsz}",
        f"--optShapes=pixel_values:1x3x{imgsz}x{imgsz}",
        f"--maxShapes=pixel_values:1x3x{imgsz}x{imgsz}",
    ]
    result = subprocess.run(cmd, capture_output=False)
    if result.returncode != 0:
        print("❌ trtexec failed. Check the output above.")
        sys.exit(1)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--imgsz", type=int, default=518)
    p.add_argument("--out", default="models/depth_anything_v2_small.engine")
    args = p.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    onnx_path = download_onnx(out_path.parent, args.imgsz)
    build_engine(onnx_path, out_path, args.imgsz)

    print(f"\n✅ Done. Engine: {out_path}")
    print(f"\nNext: edit config/nova.toml and set:")
    print(f'  [models]')
    print(f'  depth_engine_path = "{out_path}"')


if __name__ == "__main__":
    main()
