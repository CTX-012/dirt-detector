#!/usr/bin/env python3
"""
NOVA universal setup wizard.

Works on Windows + Ubuntu + macOS, with or without GPU.
Steps:
  1. Verify Python + bootstrap uv (or fall back to conda/pip).
  2. Detect NVIDIA GPU and pick the right torch + LLM backend.
  3. Install dependencies via the chosen package manager.
  4. Probe cameras and let user pick one if multiple.
  5. Collect API keys interactively, save to .env (never echoed back).
  6. Pull required model weights so first run is fast.

Run once:  python scripts/setup.py
"""
from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

# Stdlib only — this script must run BEFORE any pip install.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = PROJECT_ROOT / ".env"
CONFIG_FILE = PROJECT_ROOT / "config" / "nova.toml"


# ────────────────────────────── helpers ──────────────────────────────

def say(msg: str, kind: str = "info") -> None:
    prefix = {"info": "  ", "ok": "✅", "warn": "⚠️ ", "err": "❌", "step": "▶ "}[kind]
    print(f"{prefix} {msg}")


def run(cmd: list[str], check: bool = True, capture: bool = False) -> subprocess.CompletedProcess:
    say(" ".join(cmd), "info")
    return subprocess.run(cmd, check=check, capture_output=capture, text=True)


def have(binary: str) -> bool:
    return shutil.which(binary) is not None


def confirm(prompt: str, default: bool = True) -> bool:
    yn = "[Y/n]" if default else "[y/N]"
    ans = input(f"{prompt} {yn} ").strip().lower()
    if not ans:
        return default
    return ans in ("y", "yes")


# ────────────────────────────── step 1: python + pkg manager ──────────────────────────────

def check_python() -> None:
    say("Step 1: Python version", "step")
    if sys.version_info < (3, 10) or sys.version_info >= (3, 13):
        say(f"Python 3.10–3.12 required (you have {sys.version.split()[0]}).", "err")
        sys.exit(1)
    say(f"Python {sys.version.split()[0]} ✓", "ok")


def pick_package_manager() -> str:
    """Returns 'uv', 'conda', or 'pip' (in preference order)."""
    say("Step 2: Package manager", "step")
    if have("uv"):
        say("uv detected — using uv (fast path)", "ok")
        return "uv"
    if have("conda") or have("mamba"):
        say("conda detected — using conda", "ok")
        return "conda"
    say("Neither uv nor conda found.", "warn")
    if confirm("Bootstrap uv automatically? (recommended)"):
        install_uv()
        if have("uv"):
            return "uv"
    say("Falling back to plain pip in current environment.", "warn")
    return "pip"


def install_uv() -> None:
    system = platform.system()
    if system in ("Linux", "Darwin"):
        run(["sh", "-c", "curl -LsSf https://astral.sh/uv/install.sh | sh"])
    elif system == "Windows":
        run(["powershell", "-c",
             "irm https://astral.sh/uv/install.ps1 | iex"])
    # uv installs to ~/.local/bin or %USERPROFILE%\.local\bin — refresh PATH hint
    say("uv installed. You may need to restart your shell to pick it up.", "warn")


# ────────────────────────────── step 3: GPU detection ──────────────────────────────

def detect_gpu() -> tuple[bool, str | None, int | None]:
    """Returns (has_nvidia, gpu_name, vram_mb)."""
    say("Step 3: GPU detection", "step")
    if not have("nvidia-smi"):
        say("No nvidia-smi — assuming CPU-only.", "info")
        return False, None, None
    try:
        out = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=name,memory.total",
             "--format=csv,noheader,nounits"], text=True).strip()
        name, vram = out.splitlines()[0].split(", ")
        vram_mb = int(vram)
        say(f"GPU: {name} ({vram_mb} MB VRAM) ✓", "ok")
        return True, name, vram_mb
    except Exception as e:
        say(f"GPU probe failed: {e}", "warn")
        return False, None, None


def pick_llm_backend(has_gpu: bool, vram_mb: int | None) -> str:
    """vllm (Linux+GPU), llamacpp (anywhere), or groq (cloud)."""
    system = platform.system()
    if has_gpu and system == "Linux" and (vram_mb or 0) >= 8000:
        return "vllm"
    if has_gpu and (vram_mb or 0) >= 6000:
        return "llamacpp"     # Windows GPU users land here — llama-cpp-python has CUDA wheels
    return "groq"             # CPU-only or low VRAM → use cloud


# ────────────────────────────── step 4: install deps ──────────────────────────────

def install_deps(pm: str, has_gpu: bool, backend: str) -> None:
    say("Step 4: Installing dependencies", "step")

    extras = []
    extras.append("gpu" if has_gpu else "cpu")
    if backend == "vllm":
        extras.append("vllm")
    elif backend == "llamacpp":
        extras.append("llamacpp")
    extras_str = "[" + ",".join(extras) + "]"

    if pm == "uv":
        run(["uv", "sync", "--extra", ",".join(extras)] if False  # placeholder; uv uses --extra repeatedly
            else ["uv", "pip", "install", "-e", f".{extras_str}"])
    elif pm == "conda":
        env_name = "nova"
        if subprocess.run(["conda", "env", "list"], capture_output=True, text=True).stdout.find(env_name) == -1:
            run(["conda", "create", "-n", env_name, f"python={sys.version_info.major}.{sys.version_info.minor}", "-y"])
        run(["conda", "run", "-n", env_name, "pip", "install", "-e", f".{extras_str}"])
        say(f"Activate the env: conda activate {env_name}", "info")
    else:
        run([sys.executable, "-m", "pip", "install", "-e", f".{extras_str}"])

    # CUDA torch needs the special index URL when installing GPU extras
    if has_gpu and pm in ("uv", "pip"):
        torch_install = (
            ["uv", "pip", "install", "torch", "torchvision",
             "--index-url", "https://download.pytorch.org/whl/cu121"]
            if pm == "uv"
            else [sys.executable, "-m", "pip", "install", "torch", "torchvision",
                  "--index-url", "https://download.pytorch.org/whl/cu121"])
        run(torch_install, check=False)


# ────────────────────────────── step 5: camera ──────────────────────────────

def pick_camera() -> int | None:
    say("Step 5: Camera selection", "step")
    try:
        import cv2
    except ImportError:
        say("OpenCV not yet installed — skipping camera probe. Re-run setup after install.", "warn")
        return None

    found: list[tuple[int, str]] = []
    for idx in range(5):
        cap = cv2.VideoCapture(idx)
        if cap.isOpened():
            ok, _ = cap.read()
            if ok:
                w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                found.append((idx, f"index {idx}: {w}x{h}"))
        cap.release()

    if not found:
        say("No working camera detected. Chat-only mode will be used.", "warn")
        return None
    if len(found) == 1:
        idx, desc = found[0]
        say(f"One camera found ({desc}) — auto-selecting.", "ok")
        return idx

    say("Multiple cameras found:", "info")
    for i, (_, desc) in enumerate(found):
        print(f"   [{i}] {desc}")
    while True:
        choice = input(f"Select [0-{len(found)-1}]: ").strip()
        if choice.isdigit() and 0 <= int(choice) < len(found):
            return found[int(choice)][0]
        print("   invalid choice")


# ────────────────────────────── step 6: API keys + .env ──────────────────────────────

def collect_keys(backend: str) -> dict[str, str]:
    say("Step 6: API keys", "step")
    keys: dict[str, str] = {}

    need_groq = backend == "groq" or confirm(
        "Configure Groq cloud as fallback (even with local backend)?", default=True)

    if need_groq:
        # getpass would echo nothing — better here since keys shouldn't appear on screen
        from getpass import getpass
        existing = os.environ.get("GROQ_API_KEY", "")
        prompt = "Paste GROQ_API_KEY (input hidden)"
        if existing:
            prompt += " [press Enter to keep existing]"
        prompt += ": "
        val = getpass(prompt).strip() or existing
        if val:
            keys["GROQ_API_KEY"] = val
            say("Groq key saved (not echoed to terminal).", "ok")

    return keys


def write_env(keys: dict[str, str], camera_idx: int | None,
              backend: str, has_gpu: bool) -> None:
    """Write .env with secrets and a sibling config/nova.toml with non-secret settings."""
    # .env: secrets only, never committed
    lines = [f"{k}={v}" for k, v in keys.items()]
    ENV_FILE.write_text("\n".join(lines) + "\n")
    say(f"Wrote {ENV_FILE} (chmod 600 recommended)", "ok")
    if platform.system() != "Windows":
        os.chmod(ENV_FILE, 0o600)

    # config/nova.toml: non-secret settings, safe to commit
    CONFIG_FILE.parent.mkdir(exist_ok=True)
    cfg = f"""# Auto-generated by setup.py — safe to edit, safe to commit
[hardware]
camera_index = {camera_idx if camera_idx is not None else -1}
arduino_port = "{'COM6' if platform.system() == 'Windows' else '/dev/ttyUSB0'}"
arduino_baud = 9600

[compute]
device = "{'cuda' if has_gpu else 'cpu'}"
llm_backend = "{backend}"

[models]
yolo = "yolov8n-seg.pt"
depth = "MiDaS_small"
vlm_cloud = "meta-llama/llama-4-scout-17b-16e-instruct"
# Used when llm_backend != 'groq':
vlm_local = "Qwen/Qwen2-VL-7B-Instruct"
llm_local = "Qwen/Qwen2.5-7B-Instruct"

[safety]
critical_depth = 0.15
warning_depth  = 0.40
safe_depth     = 0.70
vlm_required   = true   # if false, system runs without VLM (depth+YOLO only)

[telemetry]
log_latencies = true
log_path = "logs/nova.jsonl"
"""
    CONFIG_FILE.write_text(cfg)
    say(f"Wrote {CONFIG_FILE}", "ok")


# ────────────────────────────── step 7: pre-pull models ──────────────────────────────

def prepull_models(has_gpu: bool, backend: str) -> None:
    say("Step 7: Pre-pulling model weights (first run will be fast)", "step")
    try:
        from ultralytics import YOLO
        YOLO("yolov8n-seg.pt")  # downloads to ~/.cache or cwd
        say("YOLOv8n-seg cached.", "ok")
    except Exception as e:
        say(f"YOLO cache step skipped: {e}", "warn")
    # MiDaS / vLLM / llama.cpp models pull lazily on first use — too big to force here.
    say("Larger models (MiDaS, local VLM) will pull on first run.", "info")


# ────────────────────────────── main ──────────────────────────────

def main() -> None:
    print("\n" + "=" * 60)
    print("  NOVA Vision Bot — Universal Setup")
    print("=" * 60 + "\n")

    check_python()
    pm = pick_package_manager()
    has_gpu, gpu_name, vram_mb = detect_gpu()
    backend = pick_llm_backend(has_gpu, vram_mb)
    say(f"Selected LLM backend: {backend}", "ok")
    if backend == "vllm" and platform.system() != "Linux":
        say("vLLM not available on this OS — falling back.", "warn")
        backend = "llamacpp" if has_gpu else "groq"

    install_deps(pm, has_gpu, backend)
    camera_idx = pick_camera()
    keys = collect_keys(backend)
    write_env(keys, camera_idx, backend, has_gpu)
    prepull_models(has_gpu, backend)

    print("\n" + "=" * 60)
    say("Setup complete!", "ok")
    print("=" * 60)
    print("\nNext:")
    if pm == "conda":
        print("  conda activate nova")
    print("  nova run         # start the robot")
    print("  nova doctor      # verify everything is wired up\n")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        say("Setup cancelled.", "warn")
        sys.exit(130)
