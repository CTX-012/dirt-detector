"""NOVA Vision Bot."""
__version__ = "0.4.0"
