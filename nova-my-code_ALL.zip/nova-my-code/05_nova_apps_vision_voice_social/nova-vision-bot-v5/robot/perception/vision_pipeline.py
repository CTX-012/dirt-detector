"""
Vision pipeline: YOLO + depth + metric anchoring.

Improvements:
  1. Depth-map cache (reuse when frame is similar).
  2. Calibration-aware metric distances (replaces the v3 magic formula
     `distance = 0.3 + depth * 4.7`).
  3. Per-frame cliff detection using ground-plane geometry.
  4. Adaptive depth-anchor refit when scene changes significantly.
"""
from __future__ import annotations

import time
from typing import Dict, List, Optional

import cv2
import numpy as np

from .calibration import GroundPlaneCalibrator
from .depth_estimator import DepthEstimator
from .yolo_detector import YOLODetector


class VisionPipeline:
    def __init__(self, yolo_model: str = "yolov8n-seg.pt",
                 yolo_engine: Optional[str] = None,
                 depth_engine: Optional[str] = None,
                 calibrator: Optional[GroundPlaneCalibrator] = None,
                 target_ms: float = 60.0,
                 depth_cache_threshold: float = 4.0):
        self.detector = YOLODetector(model_path=yolo_model, engine_path=yolo_engine)
        self.depth = DepthEstimator(engine_path=depth_engine)
        self.calibrator = calibrator  # may be None — falls back to old behavior
        self.target_ms = target_ms
        self.depth_cache_threshold = depth_cache_threshold

        # Caches
        self._last_thumb: np.ndarray | None = None
        self._last_depth: np.ndarray | None = None
        self._cache_hits = 0
        self._cache_misses = 0

        # Scale anchor for converting relative depth → metric
        self._scale: float = 4.7   # fall back to v3 formula if no calibration
        self._offset: float = 0.3
        self._scale_refits = 0
        self._frames_since_refit = 0

        self._last_latency_ms: float = 0.0
        print(f"      ✅ Vision pipeline ready "
              f"(calibrated={'yes' if calibrator else 'no'})")

    def analyze_frame(self, frame: np.ndarray) -> Dict:
        t0 = time.perf_counter()
        obstacles, yolo_results = self.detector.detect(frame)
        depth_map = self._depth_with_cache(frame)

        # Refit scale every 30 frames OR when scene changes (cache miss)
        self._frames_since_refit += 1
        if self.calibrator and (self._frames_since_refit >= 30 or self._cache_misses == 1):
            self._refit_scale(depth_map)
            self._frames_since_refit = 0

        # Metric depth map for downstream consumers
        metric_depth = depth_map * self._scale + self._offset

        # Cliff detection via calibration
        cliff_mask = None
        if self.calibrator:
            cliff_mask = self.calibrator.detect_cliffs(
                depth_map, self._scale, self._offset, tolerance_m=0.05)

        obstacles = self._add_metric_depth(obstacles, depth_map, metric_depth)

        self._last_latency_ms = (time.perf_counter() - t0) * 1000.0
        return {
            "obstacles": obstacles,
            "depth_map": depth_map,         # 0=close, 1=far (legacy convention)
            "metric_depth": metric_depth,    # meters
            "cliff_mask": cliff_mask,        # bool array or None
            "yolo_results": yolo_results,
            "frame": frame,
            "_latency_ms": self._last_latency_ms,
            "_cache_hit_rate": self._cache_hits / max(1, self._cache_hits + self._cache_misses),
            "_scale_offset": (self._scale, self._offset),
        }

    # ──────────────────────── depth cache ────────────────────────

    def _depth_with_cache(self, frame: np.ndarray) -> np.ndarray:
        thumb = cv2.resize(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY), (32, 32),
                           interpolation=cv2.INTER_AREA).astype(np.float32)
        if self._last_thumb is not None and self._last_depth is not None:
            diff = float(np.mean(np.abs(thumb - self._last_thumb)))
            if diff < self.depth_cache_threshold:
                self._cache_hits += 1
                return self._last_depth
        self._cache_misses += 1
        depth = self.depth.estimate(frame)
        self._last_thumb = thumb
        self._last_depth = depth
        return depth

    # ──────────────────────── scale anchoring ────────────────────────

    def _refit_scale(self, depth_map: np.ndarray) -> None:
        try:
            new_scale, new_offset = self.calibrator.compute_depth_scale(depth_map)
            # Sanity-check: don't accept wildly out-of-range values
            if 0.1 < new_scale < 20.0 and -1.0 < new_offset < 5.0:
                # Exponential smoothing — avoid jittery scale per frame
                alpha = 0.3
                self._scale = alpha * new_scale + (1 - alpha) * self._scale
                self._offset = alpha * new_offset + (1 - alpha) * self._offset
                self._scale_refits += 1
        except Exception as e:
            # Silently skip — keep previous scale
            pass

    # ──────────────────────── obstacle metric distance ────────────────────────

    def _add_metric_depth(self, obstacles: List[Dict],
                            depth_map: np.ndarray,
                            metric_depth: np.ndarray) -> List[Dict]:
        """
        Use the calibrated metric depth for obstacles, sampled at the contact
        patch (bottom third of bbox).
        """
        H, W = depth_map.shape
        for obs in obstacles:
            x1, y1, x2, y2 = map(int, obs["bbox"])
            x1, x2 = max(0, x1), min(W, x2)
            y1, y2 = max(0, y1), min(H, y2)
            if x2 <= x1 or y2 <= y1:
                obs["depth_value"] = 1.0
                obs["distance"] = 5.0
                obs["depth_confidence"] = 0.0
                continue

            bbox_h = y2 - y1
            contact_y1 = y1 + (2 * bbox_h) // 3
            contact_rel = depth_map[contact_y1:y2, x1:x2]
            contact_metric = metric_depth[contact_y1:y2, x1:x2]
            if contact_rel.size == 0:
                contact_rel = depth_map[y1:y2, x1:x2]
                contact_metric = metric_depth[y1:y2, x1:x2]

            obs["depth_value"] = float(np.median(contact_rel))
            obs["distance"] = float(np.median(contact_metric))
            obs["depth_confidence"] = float(1.0 - min(1.0, np.std(contact_rel) * 4.0))
        return obstacles

    def cache_stats(self) -> dict:
        total = self._cache_hits + self._cache_misses
        return {
            "hits": self._cache_hits, "misses": self._cache_misses,
            "rate": self._cache_hits / max(1, total),
            "scale": self._scale, "offset": self._offset,
            "refits": self._scale_refits,
        }
