"""
Ground-plane homography calibration for NOVA.

The problem this solves:
    MiDaS / Depth Anything V2 output RELATIVE depth (0=close, 1=far,
    arbitrary scale). The v3/v4 code used `distance_m = 0.3 + depth * 4.7`
    which is a guess — completely wrong for a different camera mount.

The fix:
    Because the camera is rigidly mounted at known (or estimable) height H
    and tilt θ, the ground plane induces a known mapping from image pixel
    (u, v) to floor-plane (X, Y) in metric units. This is the classical
    inverse-perspective mapping (IPM). Once we have it:
      - Every pixel in the bottom of the frame has a known floor distance.
      - "Cliff" = any pixel where measured depth is GREATER than the
        expected floor depth at that pixel — i.e., the floor is missing.
      - Obstacle distances are real centimeters, not 0.3 + depth*4.7 magic.

How to use:
    cal = GroundPlaneCalibrator(camera_height_mm=80.0, camera_tilt_deg=20.0)
    # Either: trust the manual values above (quick start), OR:
    cal.calibrate_from_spin(camera, motor, duration_s=5.0)  # auto-calibrate
    cal.save("config/calibration.json")

    # Later, in the perception pipeline:
    metric_floor_depth = cal.expected_floor_depth_map(image_h=480, image_w=640)
    # metric_floor_depth[v, u] = expected distance to ground at pixel (u, v) in meters
"""
from __future__ import annotations

import json
import math
import time
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional

import cv2
import numpy as np


@dataclass
class CalibrationData:
    """Persisted calibration state. JSON-serializable."""
    camera_height_m: float = 0.08         # 80mm default for a small robot
    camera_tilt_deg: float = 20.0          # downward tilt of optical axis
    # Camera intrinsics (focal length in pixels, principal point)
    # Defaults are reasonable for a 640x480 USB webcam at FOV ~60°
    fx: float = 550.0
    fy: float = 550.0
    cx: float = 320.0
    cy: float = 240.0
    image_w: int = 640
    image_h: int = 480
    # Calibration confidence — set high when auto-calibrated, low for defaults
    confidence: float = 0.0
    timestamp: float = 0.0
    notes: str = "default values — run calibrate_from_spin() for accuracy"


class GroundPlaneCalibrator:
    def __init__(self, camera_height_mm: float = 80.0,
                 camera_tilt_deg: float = 20.0,
                 image_w: int = 640, image_h: int = 480):
        self.data = CalibrationData(
            camera_height_m=camera_height_mm / 1000.0,
            camera_tilt_deg=camera_tilt_deg,
            image_w=image_w, image_h=image_h,
            cx=image_w / 2.0, cy=image_h / 2.0,
        )
        self._expected_depth_cache: Optional[np.ndarray] = None
        self._floor_mask_cache: Optional[np.ndarray] = None

    # ────────────────────────── persistence ──────────────────────────

    def save(self, path: str | Path) -> None:
        path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(asdict(self.data), indent=2))
        print(f"      💾 Calibration saved to {path}")

    @classmethod
    def load(cls, path: str | Path) -> "GroundPlaneCalibrator":
        data = json.loads(Path(path).read_text())
        c = cls(camera_height_mm=data["camera_height_m"] * 1000.0,
                camera_tilt_deg=data["camera_tilt_deg"],
                image_w=data["image_w"], image_h=data["image_h"])
        c.data = CalibrationData(**data)
        return c

    # ────────────────────────── core math ──────────────────────────

    def pixel_to_floor_distance(self, u: float, v: float) -> Optional[float]:
        """
        Ray from camera through pixel (u, v) hits floor at distance d (in meters).
        Returns None if the ray goes above the horizon (won't hit floor).

        Math: in camera frame, ray direction is ((u-cx)/fx, (v-cy)/fy, 1).
        Camera tilted down by θ around X axis. Floor is at world Y = -H.
        Solve for ray length where ray hits Y = -H plane.
        """
        d = self.data
        # Ray direction in camera coordinates (z-forward, y-down, x-right)
        rx = (u - d.cx) / d.fx
        ry = (v - d.cy) / d.fy
        rz = 1.0

        # Rotate ray by tilt to world (robot) frame. Camera tilted DOWN by θ.
        theta = math.radians(d.camera_tilt_deg)
        # Pitch rotation around X axis (positive θ = camera looking down)
        ry_w = ry * math.cos(theta) + rz * math.sin(theta)
        rz_w = -ry * math.sin(theta) + rz * math.cos(theta)

        # Camera is at height H above floor. Floor is at world y = -H below camera.
        # Ray: P(t) = (rx*t, ry_w*t, rz_w*t). Camera y = 0, want world y = -H.
        # World y of point = (camera y) - ry_w * t = -ry_w * t (camera at origin in this frame)
        # We want world y = -H → -ry_w * t = -H → t = H / ry_w
        if ry_w <= 1e-6:
            return None  # ray going up or parallel to floor — no intersection
        t = d.camera_height_m / ry_w
        # Distance along the ray to that point
        ray_len = t * math.sqrt(rx * rx + ry_w * ry_w + rz_w * rz_w)
        return ray_len

    def expected_floor_depth_map(self, image_h: Optional[int] = None,
                                   image_w: Optional[int] = None) -> np.ndarray:
        """
        For each pixel, compute the expected floor distance (meters).
        Pixels above the horizon get np.inf (no floor visible there).

        Cached because intrinsics don't change between frames.
        """
        if self._expected_depth_cache is not None:
            return self._expected_depth_cache

        H = image_h or self.data.image_h
        W = image_w or self.data.image_w
        out = np.full((H, W), np.inf, dtype=np.float32)
        for v in range(H):
            for u in range(W):
                d = self.pixel_to_floor_distance(float(u), float(v))
                if d is not None and d > 0:
                    out[v, u] = d
        self._expected_depth_cache = out
        return out

    def floor_mask(self, image_h: Optional[int] = None,
                   image_w: Optional[int] = None) -> np.ndarray:
        """Boolean mask: True where the floor is theoretically visible."""
        if self._floor_mask_cache is not None:
            return self._floor_mask_cache
        depth = self.expected_floor_depth_map(image_h, image_w)
        self._floor_mask_cache = np.isfinite(depth) & (depth < 50.0)  # within 50m
        return self._floor_mask_cache

    # ────────────────────────── scale anchoring ──────────────────────────

    def compute_depth_scale(self, relative_depth: np.ndarray,
                              floor_mask: Optional[np.ndarray] = None) -> tuple[float, float]:
        """
        Given a relative depth map (output of MiDaS/DA-V2) and the expected
        floor depths, compute (scale, offset) such that:
            metric_depth ≈ relative_depth * scale + offset

        Method: fit linear regression on pixels in the floor mask where we
        know what the metric depth SHOULD be (from ground-plane geometry).

        Returns (scale, offset). Apply with:
            metric = relative * scale + offset
        """
        H, W = relative_depth.shape
        expected = self.expected_floor_depth_map(H, W)
        mask = floor_mask if floor_mask is not None else self.floor_mask(H, W)

        # Keep only finite, in-bounds floor pixels
        valid = mask & np.isfinite(expected)
        if valid.sum() < 1000:
            print("      ⚠️  Too few floor pixels for scale fit — returning identity")
            return 1.0, 0.0

        rel = relative_depth[valid].ravel().astype(np.float64)
        exp = expected[valid].ravel().astype(np.float64)

        # Robust linear fit: median of slopes/intercepts via RANSAC-lite
        # Simple version: least squares on the middle 80% by relative depth
        order = np.argsort(rel)
        keep = order[int(len(order) * 0.1):int(len(order) * 0.9)]
        rel_k, exp_k = rel[keep], exp[keep]

        A = np.vstack([rel_k, np.ones_like(rel_k)]).T
        scale, offset = np.linalg.lstsq(A, exp_k, rcond=None)[0]
        return float(scale), float(offset)

    # ────────────────────────── cliff detection ──────────────────────────

    def detect_cliffs(self, relative_depth: np.ndarray,
                       scale: float, offset: float,
                       tolerance_m: float = 0.05) -> np.ndarray:
        """
        True cliff detection: where the floor SHOULD be at metric distance D,
        but the depth map says it's at distance > D + tolerance (i.e., the
        floor is missing / there's a drop-off).

        Returns: bool mask of cliff pixels.
        """
        H, W = relative_depth.shape
        expected = self.expected_floor_depth_map(H, W)
        metric = relative_depth * scale + offset

        cliff = (
            np.isfinite(expected) &
            (expected < 5.0) &  # only care about floor pixels within 5m
            (metric > expected + tolerance_m)
        )
        return cliff

    # ────────────────────────── auto-calibration ──────────────────────────

    def calibrate_from_spin(self, camera, motor, duration_s: float = 5.0,
                             depth_estimator=None) -> bool:
        """
        Auto-calibration routine: spin in place, observe how the floor moves
        across the image, recover ground-plane homography.

        This refines the (camera_height_m, camera_tilt_deg, intrinsics).
        Falls back gracefully on failure (keeps default values).

        Args:
            camera: a Camera object with .read() returning (ret, frame).
            motor: a MotorController object with .execute_command().
            duration_s: how long to spin.
            depth_estimator: optional DepthEstimator; if provided, also computes
                an initial (scale, offset) for the relative depth.

        Returns:
            True if calibration succeeded with reasonable confidence.
        """
        print("\n🔧 Calibration: spinning to observe floor (5s)...")
        frames = []
        motor.execute_command(action="RIGHT", duration=duration_s, speed="SPEED_LOW")
        t0 = time.time()
        while time.time() - t0 < duration_s:
            ret, frame = camera.read()
            if ret:
                frames.append(frame)
            time.sleep(0.1)
        motor.abort()
        print(f"      📸 Captured {len(frames)} frames")

        if len(frames) < 10:
            print("      ⚠️  Too few frames — keeping default calibration")
            return False

        # Estimate horizon from optical flow on consecutive frames during spin.
        # During pure rotation, distant points move less than near points; the
        # horizon is the row where flow magnitude is minimum.
        flows = []
        for a, b in zip(frames[:-1], frames[1:]):
            ga = cv2.cvtColor(a, cv2.COLOR_BGR2GRAY)
            gb = cv2.cvtColor(b, cv2.COLOR_BGR2GRAY)
            flow = cv2.calcOpticalFlowFarneback(ga, gb, None, 0.5, 3, 15, 3, 5, 1.2, 0)
            flows.append(flow)
        mean_flow = np.mean([np.linalg.norm(f, axis=2) for f in flows], axis=0)
        row_flow = mean_flow.mean(axis=1)  # average flow magnitude per row

        # Horizon row = where row_flow is minimum (in the upper half)
        upper = row_flow[: self.data.image_h // 2]
        horizon_row = int(np.argmin(upper))
        # Map horizon row to a tilt angle: cy is principal point row; if
        # horizon appears at row h, tilt ≈ atan((cy - h) / fy)
        tilt_rad = math.atan2(self.data.cy - horizon_row, self.data.fy)
        new_tilt_deg = math.degrees(tilt_rad)

        # Sanity check: tilt should be 5–45 degrees for a downward-facing camera
        if not (5.0 < new_tilt_deg < 45.0):
            print(f"      ⚠️  Implausible tilt estimate ({new_tilt_deg:.1f}°) — keeping default")
            return False

        self.data.camera_tilt_deg = new_tilt_deg
        self.data.confidence = 0.8
        self.data.timestamp = time.time()
        self.data.notes = f"auto-calibrated from {len(frames)} frames during spin"
        self._expected_depth_cache = None  # invalidate cache
        self._floor_mask_cache = None
        print(f"      ✅ Tilt estimate: {new_tilt_deg:.1f}° (confidence 0.8)")
        return True
