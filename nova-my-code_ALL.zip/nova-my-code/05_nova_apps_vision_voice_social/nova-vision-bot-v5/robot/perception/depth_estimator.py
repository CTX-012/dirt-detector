"""
Depth estimator with auto-selection across three backends.

Selection priority (best → fallback):
  1. TensorRT engine file at config.models.depth_engine_path (RTX, ~10ms)
  2. PyTorch Depth Anything V2-Small via transformers (RTX, ~30ms; CPU, ~400ms)
  3. PyTorch MiDaS-small (legacy fallback, anywhere, slow)

All three return the same shape: normalized float32 depth map where
0 = close, 1 = far (this convention is preserved from v3/v4 so nothing
downstream needs to change).

The metric scale anchor from calibration (see robot.perception.calibration)
is applied OUTSIDE this class — the depth map here is still relative.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import cv2
import numpy as np
import torch


class DepthEstimator:
    def __init__(self, model_name: str = "depth_anything_v2_small",
                 engine_path: Optional[str] = None,
                 force_backend: Optional[str] = None):
        """
        Args:
            model_name: 'depth_anything_v2_small' (preferred) or 'MiDaS_small' (legacy).
            engine_path: optional path to a TensorRT .engine file. If set and
                file exists, use it. If set and missing, warn and fall back.
            force_backend: 'trt' | 'torch_da2' | 'torch_midas' for testing.
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.use_half = self.device.type == "cuda"
        if self.device.type == "cuda":
            # Inputs are a fixed size every frame (518² for DA-V2, 256² for MiDaS),
            # so let cuDNN autotune the fastest conv kernels once and reuse them.
            torch.backends.cudnn.benchmark = True
        self.backend: str = ""
        self._engine = None
        self._torch_model = None
        self._processor = None

        # Resolve backend
        if force_backend:
            self.backend = force_backend
        elif engine_path and Path(engine_path).exists():
            self.backend = "trt"
        else:
            self.backend = "torch_da2"

        # Initialize chosen backend, with fallback if it errors
        try:
            self._init_backend(engine_path, model_name)
        except Exception as e:
            print(f"      ⚠️  Depth backend '{self.backend}' init failed: {e}")
            print(f"      ↪ Falling back to MiDaS_small (legacy)")
            self.backend = "torch_midas"
            self._init_midas()

        print(f"      🏔️  Depth backend: {self.backend} on {self.device} (half={self.use_half})")
        if self.device.type == "cuda":
            self._warmup()

    def _warmup(self, iters: int = 3):
        """Run a few dummy inferences so the first real frame doesn't pay for
        lazy CUDA context init + cuDNN autotuning (otherwise a ~150ms p99 spike)."""
        dummy = np.zeros((480, 640, 3), dtype=np.uint8)
        for _ in range(iters):
            self.estimate(dummy)
        if self.device.type == "cuda":
            torch.cuda.synchronize()

    # ────────────────────────── init paths ──────────────────────────

    def _init_backend(self, engine_path: Optional[str], model_name: str):
        if self.backend == "trt":
            self._init_tensorrt(engine_path)
        elif self.backend == "torch_da2":
            self._init_depth_anything_v2()
        elif self.backend == "torch_midas":
            self._init_midas()
        else:
            raise ValueError(f"Unknown backend: {self.backend}")

    def _init_tensorrt(self, engine_path: str):
        """Load a TensorRT engine produced by scripts/export_depth_trt.py"""
        import tensorrt as trt  # heavy import — only on this path
        import pycuda.driver as cuda
        import pycuda.autoinit  # noqa: F401 — initializes CUDA context

        logger = trt.Logger(trt.Logger.WARNING)
        with open(engine_path, "rb") as f, trt.Runtime(logger) as rt:
            self._engine = rt.deserialize_cuda_engine(f.read())
        self._trt_context = self._engine.create_execution_context()
        # Allocate buffers once
        self._trt_inputs, self._trt_outputs, self._trt_bindings = self._alloc_trt_buffers()
        self._trt_stream = cuda.Stream()
        self._cuda = cuda

    def _alloc_trt_buffers(self):
        import pycuda.driver as cuda
        inputs, outputs, bindings = [], [], []
        for i in range(self._engine.num_io_tensors):
            name = self._engine.get_tensor_name(i)
            shape = self._engine.get_tensor_shape(name)
            dtype = trt_dtype_to_np(self._engine.get_tensor_dtype(name))
            size = int(np.prod(shape))
            host_mem = cuda.pagelocked_empty(size, dtype)
            dev_mem = cuda.mem_alloc(host_mem.nbytes)
            bindings.append(int(dev_mem))
            buf = {"name": name, "host": host_mem, "device": dev_mem, "shape": shape, "dtype": dtype}
            if self._engine.get_tensor_mode(name).name == "INPUT":
                inputs.append(buf)
            else:
                outputs.append(buf)
        return inputs, outputs, bindings

    def _init_depth_anything_v2(self):
        """HuggingFace transformers pipeline — works without manual model download."""
        from transformers import AutoImageProcessor, AutoModelForDepthEstimation
        repo = "depth-anything/Depth-Anything-V2-Small-hf"
        # use_fast=True → torchvision-backed processor (faster preprocessing, no
        # slow-processor warning); harmless on CPU too.
        self._processor = AutoImageProcessor.from_pretrained(repo, use_fast=True)
        self._torch_model = AutoModelForDepthEstimation.from_pretrained(repo)
        self._torch_model.to(self.device).eval()
        if self.use_half:
            self._torch_model.half()

    def _init_midas(self):
        """Legacy fallback — same as v4."""
        self._torch_model = torch.hub.load("intel-isl/MiDaS", "MiDaS_small")
        self._torch_model.to(self.device).eval()
        if self.use_half:
            self._torch_model.half()
        transforms = torch.hub.load("intel-isl/MiDaS", "transforms")
        self._processor = transforms.small_transform

    # ────────────────────────── inference ──────────────────────────

    @torch.inference_mode()
    def estimate(self, frame: np.ndarray) -> np.ndarray:
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        if self.backend == "trt":
            depth = self._estimate_trt(rgb)
        elif self.backend == "torch_da2":
            depth = self._estimate_da2(rgb)
        else:
            depth = self._estimate_midas(rgb)
        return self._normalize(depth)

    def _estimate_trt(self, rgb: np.ndarray) -> np.ndarray:
        """TensorRT path — fastest. Assumes engine was built for 518×518 NCHW float."""
        H, W = rgb.shape[:2]
        # DA-V2's preprocessing: resize to 518, normalize ImageNet
        x = cv2.resize(rgb, (518, 518)).astype(np.float32) / 255.0
        x = (x - np.array([0.485, 0.456, 0.406])) / np.array([0.229, 0.224, 0.225])
        x = x.transpose(2, 0, 1)[np.newaxis].astype(np.float32)

        np.copyto(self._trt_inputs[0]["host"], x.ravel())
        self._cuda.memcpy_htod_async(self._trt_inputs[0]["device"],
                                       self._trt_inputs[0]["host"], self._trt_stream)
        self._trt_context.execute_async_v3(self._trt_stream.handle)
        self._cuda.memcpy_dtoh_async(self._trt_outputs[0]["host"],
                                       self._trt_outputs[0]["device"], self._trt_stream)
        self._trt_stream.synchronize()

        out = self._trt_outputs[0]["host"].reshape(self._trt_outputs[0]["shape"])
        depth_518 = out.squeeze()
        # Upsample back to input resolution
        return cv2.resize(depth_518, (W, H), interpolation=cv2.INTER_CUBIC)

    def _estimate_da2(self, rgb: np.ndarray) -> np.ndarray:
        """HuggingFace transformers path — works out of the box, slower than TRT."""
        inputs = self._processor(images=rgb, return_tensors="pt").to(self.device)
        if self.use_half:
            inputs = {k: v.half() if v.dtype == torch.float32 else v for k, v in inputs.items()}
        out = self._torch_model(**inputs).predicted_depth
        # Resize back to source resolution
        out = torch.nn.functional.interpolate(
            out.unsqueeze(1), size=rgb.shape[:2],
            mode="bicubic", align_corners=False).squeeze()
        return out.float().cpu().numpy()

    def _estimate_midas(self, rgb: np.ndarray) -> np.ndarray:
        batch = self._processor(rgb).to(self.device)
        if self.use_half:
            batch = batch.half()
        out = self._torch_model(batch)
        out = torch.nn.functional.interpolate(
            out.unsqueeze(1), size=rgb.shape[:2],
            mode="bicubic", align_corners=False).squeeze()
        return out.float().cpu().numpy()

    @staticmethod
    def _normalize(depth: np.ndarray) -> np.ndarray:
        """
        Normalize to [0, 1] and invert so 0=close, 1=far.

        IMPORTANT: DA-V2 outputs "inverse depth" where higher = closer.
        MiDaS also outputs higher=closer. After min-max norm, both have
        1=close, 0=far natively → we invert with `1.0 - x` to land on
        0=close, 1=far, which matches the rest of the codebase.
        """
        lo, hi = float(depth.min()), float(depth.max())
        if hi - lo > np.finfo("float").eps:
            depth = (depth - lo) / (hi - lo)
            depth = 1.0 - depth
        else:
            depth = np.zeros_like(depth)
        return depth


def trt_dtype_to_np(trt_dtype):
    import tensorrt as trt
    mapping = {
        trt.float32: np.float32, trt.float16: np.float16,
        trt.int32: np.int32, trt.int8: np.int8,
    }
    return mapping[trt_dtype]
