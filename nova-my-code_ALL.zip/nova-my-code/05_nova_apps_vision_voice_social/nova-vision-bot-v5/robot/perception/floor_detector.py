"""
Floor surface verification and edge/cliff detection.
v3: Advisory only — VLM is the primary safety authority.
Only flags genuinely dangerous conditions (real cliffs, real holes).
"""

from typing import Dict

import numpy as np


class FloorVerifier:

    def __init__(self):
        self.edge_detection_config = {
            'depth_gradient_threshold': 0.30,
            'min_floor_coverage': 0.60,
        }
        self.floor_roi = {
            'top_ratio': 0.6,
            'bottom_ratio': 1.0
        }

    def analyze_floor_region(self, depth_map: np.ndarray, frame: np.ndarray) -> Dict:
        h, w = depth_map.shape
        floor_top = int(h * self.floor_roi['top_ratio'])
        floor_region = depth_map[floor_top:, :]

        edge_analysis = self._detect_depth_edges(floor_region)
        continuity_analysis = self._analyze_floor_continuity(floor_region)
        dropoff_analysis = self._detect_dropoffs(depth_map)

        floor_safety = self._calculate_floor_safety(
            edge_analysis, continuity_analysis, dropoff_analysis
        )

        return {
            'floor_detected': floor_safety['is_safe'],
            'floor_confidence': floor_safety['confidence'],
            'edge_detected': edge_analysis['has_edge'],
            'edge_location': edge_analysis.get('edge_location'),
            'dropoff_detected': dropoff_analysis['has_dropoff'],
            'dropoff_distance': dropoff_analysis.get('distance'),
            'floor_continuity': continuity_analysis['continuity_score'],
            'danger_zones': floor_safety['danger_zones'],
            'safe_to_proceed': floor_safety['safe_to_proceed'],
            'warning_message': floor_safety['warning']
        }

    def _detect_depth_edges(self, floor_region: np.ndarray) -> Dict:
        gradient_y = np.gradient(floor_region, axis=0)
        gradient_x = np.gradient(floor_region, axis=1)
        gradient_mag = np.sqrt(gradient_x**2 + gradient_y**2)

        threshold = self.edge_detection_config['depth_gradient_threshold']
        edge_mask = gradient_mag > threshold
        edge_coverage = np.mean(edge_mask)

        has_edge = edge_coverage > 0.10

        edge_location = None
        if has_edge:
            edge_rows = np.where(np.any(edge_mask, axis=1))[0]
            if len(edge_rows) > 0:
                closest_edge_row = edge_rows[0]
                h, w = floor_region.shape
                edge_location = 1.0 - (closest_edge_row / h)

        return {
            'has_edge': has_edge,
            'edge_coverage': float(edge_coverage),
            'edge_location': edge_location,
            'gradient_map': gradient_mag
        }

    def _analyze_floor_continuity(self, floor_region: np.ndarray) -> Dict:
        h, w = floor_region.shape
        center_strip = floor_region[:, w // 3:2 * w // 3]
        near_region = center_strip[:h // 2, :]

        if near_region.size == 0:
            return {'continuity_score': 0.5, 'has_gaps': False}

        depth_std = np.std(near_region)

        max_acceptable_std = 0.25
        continuity_score = max(0, 1.0 - (depth_std / max_acceptable_std))

        very_close_mask = near_region < 0.05
        hole_coverage = np.mean(very_close_mask)
        has_gaps = hole_coverage > 0.20

        return {
            'continuity_score': float(continuity_score),
            'depth_variance': float(np.var(near_region)),
            'has_gaps': has_gaps,
            'gap_coverage': float(hole_coverage)
        }

    def _detect_dropoffs(self, depth_map: np.ndarray) -> Dict:
        h, w = depth_map.shape
        center_col = depth_map[:, w // 2 - 20:w // 2 + 20]
        depth_profile = np.mean(center_col, axis=1)
        gradient = np.gradient(depth_profile)

        dropoff_threshold = 0.15
        dropoff_locations = np.where(gradient > dropoff_threshold)[0]

        has_dropoff = len(dropoff_locations) > 0
        dropoff_distance = None
        if has_dropoff:
            closest_dropoff = dropoff_locations[-1]
            dropoff_distance = (h - closest_dropoff) / h

        return {
            'has_dropoff': has_dropoff,
            'distance': dropoff_distance,
            'dropoff_count': len(dropoff_locations),
        }

    def _calculate_floor_safety(self, edge_analysis, continuity_analysis, dropoff_analysis):
        danger_zones = []
        warnings = []

        if edge_analysis['has_edge']:
            edge_loc = edge_analysis.get('edge_location')
            if edge_loc is not None:
                if edge_loc > 0.45:
                    danger_zones.append('IMMEDIATE_EDGE')
                    warnings.append(f"🚨 EDGE very close ({edge_loc:.0%})!")
                elif edge_loc > 0.25:
                    danger_zones.append('NEAR_EDGE')
                    warnings.append(f"⚠️ Edge ahead ({edge_loc:.0%})")

        if dropoff_analysis['has_dropoff']:
            drop_dist = dropoff_analysis.get('distance', 1.0)
            if drop_dist is not None:
                if drop_dist < 0.2:
                    danger_zones.append('CLIFF_DANGER')
                    warnings.append("🚨 CLIFF very close!")
                elif drop_dist < 0.35:
                    danger_zones.append('DROPOFF_WARNING')
                    warnings.append("⚠️ Drop-off ahead")

        if continuity_analysis['has_gaps'] and continuity_analysis.get('gap_coverage', 0) > 0.3:
            danger_zones.append('FLOOR_GAPS')
            warnings.append("⚠️ Large gap in surface")

        critical_dangers = [z for z in danger_zones if z in ('CLIFF_DANGER', 'IMMEDIATE_EDGE')]
        is_safe = len(critical_dangers) == 0
        safe_to_proceed = len(danger_zones) == 0 or \
                         all(z in ('NEAR_EDGE', 'DROPOFF_WARNING') for z in danger_zones)

        confidence = continuity_analysis['continuity_score']
        if 'IMMEDIATE_EDGE' in danger_zones:
            confidence *= 0.3
        elif 'NEAR_EDGE' in danger_zones:
            confidence *= 0.7
        if 'CLIFF_DANGER' in danger_zones:
            confidence *= 0.2

        return {
            'is_safe': is_safe,
            'safe_to_proceed': safe_to_proceed,
            'confidence': float(max(confidence, 0.1)),
            'danger_zones': danger_zones,
            'warning': ' | '.join(warnings) if warnings else None
        }
