"""
YOLO obstacle detector with TensorRT engine preference.

Ultralytics natively handles .engine files via `YOLO("path.engine")` — the
same API works whether you pass a .pt or .engine path. We just check which
exists and pick the faster one.

Export the engine once via scripts/export_yolo_trt.py.
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

try:
    import torch
    _CUDA = torch.cuda.is_available()
except ImportError:
    _CUDA = False

from ultralytics import YOLO


class YOLODetector:
    def __init__(self, model_path: str = "yolov8n-seg.pt",
                 engine_path: Optional[str] = None,
                 device: str | None = None, half: bool | None = None,
                 imgsz: int | None = None):
        """
        Args:
            model_path: PyTorch .pt path (used if engine not available).
            engine_path: TensorRT .engine path. If exists, loaded preferentially.
        """
        # Prefer engine if provided and present
        if engine_path and Path(engine_path).exists():
            chosen = engine_path
            self.backend = "tensorrt"
        else:
            if engine_path:
                print(f"      ⚠️  YOLO engine not found at {engine_path} — using PyTorch")
            chosen = model_path
            self.backend = "pytorch"

        self.device = device or ("cuda:0" if _CUDA else "cpu")
        self.half = half if half is not None else _CUDA
        self.imgsz = imgsz or (640 if _CUDA else 480)
        print(f"      🎯 Loading YOLO ({self.backend}, {self.device}, "
              f"fp16={self.half}, imgsz={self.imgsz}): {chosen}")
        self.yolo = YOLO(chosen)
        # Engine files are pre-built for a specific device; only set for .pt
        if self.backend == "pytorch":
            self.yolo.to(self.device)
        if _CUDA and self.device != "cpu":
            self._warmup()

    def _warmup(self, iters: int = 2):
        """Prime CUDA kernels so the first real frame isn't slowed by lazy init."""
        dummy = np.zeros((480, 640, 3), dtype=np.uint8)
        for _ in range(iters):
            self.detect(dummy)

    def detect(self, frame: np.ndarray) -> tuple:
        # Note: half=True is ignored when running TensorRT (engine determines dtype)
        results = self.yolo(
            frame, verbose=False,
            half=(self.half and self.backend == "pytorch"),
            imgsz=self.imgsz, device=self.device,
        )[0]
        return self._extract(results), results

    def _extract(self, results) -> List[Dict]:
        out: list[dict] = []
        if results.boxes is None:
            return out
        for i, box in enumerate(results.boxes):
            x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
            cls = int(box.cls[0])
            conf = float(box.conf[0])
            mask = None
            if results.masks is not None and i < len(results.masks):
                mask = results.masks[i].data.cpu().numpy()[0]
            out.append({
                "class": results.names[cls], "confidence": conf,
                "bbox": [x1, y1, x2, y2], "mask": mask,
                "center": [(x1 + x2) / 2, (y1 + y2) / 2],
                "area": (x2 - x1) * (y2 - y1),
            })
        return out
