#!/usr/bin/env python3
"""
NOVA Vision Bot v4.1 — entry point.

Improvements over v4:
  - Rolling safety monitor: vision thread continuously updates a shared
    state, so user commands get an instant pre-check.
  - Watchdog: if vision goes stale, all movement defaults to deny.
  - Motors are non-blocking and abortable.
  - VLM has a hard timeout; expired calls degrade gracefully.

Run via:  nova run    or    python -m robot.main
"""
from __future__ import annotations

import json
import os
import sys
import threading
import time

import cv2


def _gui_available() -> bool:
    """True if a GUI window can be opened. On Linux a missing DISPLAY/Wayland
    means a headless session — calling cv2.imshow there makes Qt abort() the
    whole process (uncatchable), so we must detect it up front and stay headless.

    If DISPLAY is unset but an X server is actually running (common when the
    robot is launched from a bare shell, cron, or an IDE terminal that didn't
    inherit DISPLAY), auto-pick the live X socket so the window still shows.
    """
    if not sys.platform.startswith("linux"):
        return True  # Windows / macOS have a native window server
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
        return True
    # No DISPLAY in env — look for a running X server (/tmp/.X11-unix/X<N> → :N).
    import glob
    socks = sorted(glob.glob("/tmp/.X11-unix/X*"))
    if socks:
        disp = ":" + os.path.basename(socks[0])[1:]  # X1 -> :1
        os.environ["DISPLAY"] = disp
        # GDM/Wayland keep xauth outside ~; fall back to the classic path if needed.
        if not os.environ.get("XAUTHORITY"):
            xauth = os.path.expanduser("~/.Xauthority")
            if os.path.exists(xauth):
                os.environ["XAUTHORITY"] = xauth
        print(f"   🖥️  DISPLAY was unset — auto-detected X server on {disp}.")
        return True
    return False

from robot.backends import create_backend
from robot.config import load_config
from robot.hardware import Camera, MotorController
from robot.navigation import FreeSpaceDetector
from robot.perception import VisionPipeline
from robot.safety import DecisionFusion, SafetyMonitor, VLMSafetyAdvisor
from robot.telemetry import LatencyTracker, set_tracker
from robot.ui import Display


class NovaVisionBot:
    def __init__(self, cfg):
        self.cfg = cfg
        print("\n" + "=" * 60)
        print("🤖 NOVA VISION BOT v4.1 — UNIVERSAL + ROLLING SAFETY")
        print("=" * 60)

        set_tracker(LatencyTracker(
            log_path=cfg.telemetry.log_path if cfg.telemetry.log_latencies else None
        ))

        self.backend = create_backend(cfg)
        self.chat_backend = self.backend

        # Vision + safety
        self.vision_enabled = False
        self.camera = None
        self.vision_pipeline = None
        self.free_space_detector = None
        self.vlm_advisor = None
        self.calibrator = None    # set in _init_vision
        self.display_renderer = Display()
        # Rolling safety state, written by vision thread, read by main
        self.safety_monitor = SafetyMonitor(stale_after_s=1.0)

        if cfg.hardware.camera_index >= 0:
            self._init_vision()

        self.motor = MotorController(
            port=cfg.hardware.arduino_port, baud_rate=cfg.hardware.arduino_baud
        )
        self.decision_engine = DecisionFusion()

        self.conversation_history = []
        self.system_prompt = self._build_system_prompt()

        self.latest_vision_data = None
        self.latest_frame = None
        self.vision_lock = threading.Lock()
        self.stop_event = threading.Event()
        # Headless-safe: never auto-open a window without a display server,
        # otherwise cv2.imshow → Qt abort() crashes the whole robot.
        self.gui_available = _gui_available()
        self.show_display = self.gui_available
        if not self.gui_available:
            print("   🖥️  No display detected — running headless "
                  "(vision/safety active, camera window off).")

        if self.vision_enabled:
            self.maybe_auto_calibrate()
            self._start_threads()

        print(f"\n✅ NOVA v4.1 ready!")
        print(f"   Backend:   {self.backend.name}")
        print(f"   Vision:    {'ON' if self.vision_enabled else 'OFF'}")
        print(f"   Motor:     {'CONNECTED' if self.motor.is_connected else 'SIMULATION'}")
        print(f"   Watchdog:  1.0s stale-vision threshold (default-deny)")
        print("=" * 60 + "\n")

    def _init_vision(self):
        try:
            print("\n🔧 Initializing vision...")
            self.camera = Camera(index=self.cfg.hardware.camera_index)
            if not self.camera.is_open:
                print("   ⚠️  Camera unavailable — vision disabled")
                return

            # Load or create calibration. Auto-calibration deferred until
            # after motor is also initialized — see _maybe_calibrate().
            calibrator = self._load_or_default_calibration()

            print("   🧠 Loading models...")
            self.vision_pipeline = VisionPipeline(
                yolo_model=self.cfg.models.yolo,
                yolo_engine=self.cfg.models.yolo_engine_path,
                depth_engine=self.cfg.models.depth_engine_path,
                calibrator=calibrator,
            )
            self.free_space_detector = FreeSpaceDetector(
                critical=self.cfg.safety.critical_depth,
                warning=self.cfg.safety.warning_depth,
                safe=self.cfg.safety.safe_depth,
            )
            self.vlm_advisor = VLMSafetyAdvisor(backend=self.backend, timeout_s=3.0)
            self.calibrator = calibrator
            self.vision_enabled = True
            print("   ✅ Vision ready!")
        except Exception as e:
            print(f"   ❌ Vision init failed: {e}")
            self.vision_enabled = False

    def _load_or_default_calibration(self):
        """Load saved calibration, or create default. Auto-cal runs later."""
        from robot.perception import GroundPlaneCalibrator
        from pathlib import Path

        cal_path = Path(self.cfg.calibration.file_path)
        if cal_path.exists():
            try:
                cal = GroundPlaneCalibrator.load(cal_path)
                print(f"   📐 Loaded calibration from {cal_path} "
                      f"(confidence {cal.data.confidence:.2f})")
                return cal
            except Exception as e:
                print(f"   ⚠️  Calibration file corrupt ({e}) — using defaults")
        return GroundPlaneCalibrator(
            camera_height_mm=self.cfg.calibration.camera_height_mm,
            camera_tilt_deg=self.cfg.calibration.camera_tilt_deg,
        )

    def maybe_auto_calibrate(self):
        """Run auto-calibration if enabled and confidence is low. Call once
        after motor is connected."""
        if (self.cfg.calibration.auto_calibrate_on_first_boot
                and self.vision_enabled
                and self.calibrator is not None
                and self.calibrator.data.confidence < 0.5
                and self.motor.is_connected):
            print("\n🔧 First-boot auto-calibration starting...")
            try:
                success = self.calibrator.calibrate_from_spin(
                    self.camera, self.motor, duration_s=5.0)
                if success:
                    self.calibrator.save(self.cfg.calibration.file_path)
            except Exception as e:
                print(f"   ⚠️  Auto-calibration failed: {e}")

    def _start_threads(self):
        threading.Thread(target=self._vision_loop, daemon=True, name="Vision").start()
        threading.Thread(target=self._display_loop, daemon=True, name="Display").start()
        print("   🔄 Vision + display threads started")

    def _vision_loop(self):
        from robot.telemetry import get_tracker
        tracker = get_tracker()
        consecutive_errors = 0
        while not self.stop_event.is_set():
            try:
                ret, frame = self.camera.read()
                if not ret:
                    time.sleep(0.1); continue

                tracker.begin_trace()
                with tracker.stage("vision_pipeline"):
                    vd = self.vision_pipeline.analyze_frame(frame)
                with tracker.stage("freespace"):
                    grid = self.free_space_detector.analyze_all_zones(
                        vd["depth_map"], vd["obstacles"], frame)
                vd["grid_analysis"] = grid
                vd["free_zones"] = self.free_space_detector.get_free_zones(grid)
                tracker.end_trace(kind="vision")

                # Update rolling safety state — this is the key
                # change. Main thread now reads from this in O(1).
                self.safety_monitor.update_from_grid(grid)

                with self.vision_lock:
                    self.latest_vision_data = vd
                    self.latest_frame = frame.copy()
                consecutive_errors = 0
                time.sleep(0.05)
            except Exception as e:
                consecutive_errors += 1
                print(f"Vision error ({consecutive_errors}): {e}")
                # Back off on repeated errors but don't crash the thread
                time.sleep(min(0.5 * consecutive_errors, 5.0))

    def _display_loop(self):
        if not self.gui_available:
            return  # headless — never touch cv2 highgui (Qt would abort the process)
        time.sleep(2.0)
        while not self.stop_event.is_set():
            try:
                if not self.show_display:
                    cv2.destroyAllWindows()
                    time.sleep(0.5); continue
                with self.vision_lock:
                    frame = self.latest_frame
                    vd = self.latest_vision_data
                if frame is None or vd is None:
                    time.sleep(0.1); continue
                disp = self.display_renderer.create_display(frame.copy(), vd)
                cv2.imshow("NOVA v4.1", disp)
                key = cv2.waitKey(30) & 0xFF
                if key == ord("q"):
                    self.show_display = False
            except Exception as e:
                if not self.stop_event.is_set():
                    print(f"Display error: {e}")
                time.sleep(0.5)

    def _build_system_prompt(self):
        vis = "You CAN see" if self.vision_enabled else "You CANNOT see"
        return f"""You are NOVA, a friendly small mobile robot (190x130mm, 1.2kg).
Vision ({vis}). Movement: FORWARD/BACKWARD/LEFT/RIGHT/STOP. Tables/desks are safe surfaces.
Respond with JSON: {{"response": "text", "action": "FORWARD"|null, "duration": 2.0, "speed": "SPEED_MED"|null}}"""

    def _parse_intent(self, user_input: str) -> dict:
        from robot.telemetry import get_tracker
        self.conversation_history.append({"role": "user", "content": user_input})
        try:
            with get_tracker().stage("llm_intent"):
                raw = self.chat_backend.chat(
                    [{"role": "system", "content": self.system_prompt}] + self.conversation_history,
                    max_tokens=300, temperature=0.7, json_mode=True)
            intent = json.loads(raw)
            self.conversation_history.append(
                {"role": "assistant", "content": intent.get("response", "")})
            return intent
        except Exception as e:
            print(f"❌ Intent error: {e}")
            return {"response": "Sorry, I didn't understand.", "action": None,
                    "duration": 0, "speed": None}

    def process_command(self, user_input: str):
        from robot.telemetry import get_tracker
        tracker = get_tracker()
        tracker.begin_trace()
        print(f"\nYou: {user_input}")

        # Stop is always honored, never blocked. Run it before anything else.
        if user_input.strip().lower() in ("stop", "halt", "abort", "wait"):
            self.motor.abort()
            print("🤖 NOVA: Stopped.")
            tracker.end_trace(kind="decision", action="STOP")
            return

        with tracker.stage("intent_parse"):
            intent = self._parse_intent(user_input)

        action = intent.get("action")

        # Fast pre-check from the rolling safety monitor. If we can prove
        # the move is unsafe without calling the VLM, skip the VLM entirely.
        if action and action != "STOP" and self.vision_enabled:
            allowed, reason = self.safety_monitor.quick_check(action)
            if not allowed:
                print(f"🤖 NOVA: Can't {action.lower()} — {reason}")
                tracker.end_trace(kind="decision", action="STOP",
                                   blocked_by="quick_check", reason=reason)
                return

        # VLM full check only if the quick check passed
        vlm = None
        if action and self.vision_enabled:
            with self.vision_lock:
                snap_frame = self.latest_frame.copy() if self.latest_frame is not None else None
                snap_vd = self.latest_vision_data
            if snap_frame is not None:
                with tracker.stage("vlm_assess"):
                    vlm = self.vlm_advisor.assess_safety(snap_frame, snap_vd, action)

        if action and self.vision_enabled and vlm:
            with tracker.stage("fusion"):
                decision = self.decision_engine.fuse_decisions(
                    user_intent=action,
                    vision_data=self.latest_vision_data,
                    vlm_assessment=vlm,
                    requested_duration=intent.get("duration", 2.0),
                    requested_speed=intent.get("speed", "SPEED_MED"))
        else:
            decision = {"action": action, "duration": intent.get("duration", 0),
                        "speed": intent.get("speed"), "response": intent.get("response"),
                        "override": False}

        print(f"🤖 NOVA: {decision.get('response', '')}")
        if decision.get("action") and not decision.get("override"):
            with tracker.stage("motor_dispatch"):
                # NOTE: now non-blocking. Returns immediately; movement runs
                # in a worker thread that can be aborted by safety loop.
                self.motor.execute_command(
                    action=decision["action"],
                    duration=decision.get("duration", 0),
                    speed=decision.get("speed", "SPEED_MED"))
        elif decision.get("override"):
            print(f"   🛑 BLOCKED: {decision.get('reasoning')}")

        trace = tracker.end_trace(kind="decision", action=decision.get("action"))
        print(f"   ⏱️  decision: {trace['total_ms']:.0f}ms  "
              + "  ".join(f"{k}={v:.0f}ms" for k, v in trace["stages"].items()))

    def _safety_supervisor_loop(self):
        """
        Continuously watches the safety monitor while motors are active.
        If something becomes critical mid-movement, abort the motors.
        """
        while not self.stop_event.is_set():
            try:
                if self.motor.is_moving() and self.vision_enabled:
                    s = self.safety_monitor.get()
                    if s.cliff_critical or s.edge_critical:
                        print("\n🚨 CRITICAL EDGE/CLIFF DURING MOVEMENT — ABORTING")
                        self.motor.abort()
                    elif s.forward_danger >= 9 and self.motor.last_command == "F":
                        print("\n🚨 OBSTACLE APPEARED IN PATH — ABORTING")
                        self.motor.abort()
                time.sleep(0.05)   # 20 Hz supervisor
            except Exception:
                time.sleep(0.5)

    def run(self):
        # Start the mid-movement safety supervisor
        if self.vision_enabled:
            threading.Thread(target=self._safety_supervisor_loop,
                              daemon=True, name="Supervisor").start()

        print("NOVA v4.1 ONLINE")
        print("Commands: chat naturally, 'stop' anytime, 'show'/'hide', 'stats', 'exit'\n")
        try:
            while True:
                ui = input("You: ").strip()
                if ui.lower() in ("exit", "quit", "bye"):
                    break
                if ui.lower() in ("show", "show vision"):
                    if self.gui_available:
                        self.show_display = True
                    else:
                        print("🤖 NOVA: No display available — can't show the camera window (headless).")
                    continue
                if ui.lower() in ("hide", "hide vision"):
                    self.show_display = False; continue
                if ui.lower() == "stats":
                    from robot.telemetry import get_tracker
                    print("\n" + get_tracker().render_table())
                    if self.vision_pipeline:
                        c = self.vision_pipeline.cache_stats()
                        print(f"\ndepth cache: {c['hits']} hits / {c['misses']} misses "
                              f"({c['rate']:.0%} hit rate)\n")
                    continue
                if not ui:
                    continue
                self.process_command(ui)
        except KeyboardInterrupt:
            print("\n🛑 Interrupted")
        finally:
            self.shutdown()

    def shutdown(self):
        print("\n🔧 Shutting down...")
        self.stop_event.set()
        self.motor.abort()
        self.motor.close()
        if self.camera:
            self.camera.release()
        if self.gui_available:
            cv2.destroyAllWindows()
        from robot.telemetry import get_tracker
        print("\n" + get_tracker().render_table())
        print("✅ Done.\n")


def main():
    cfg = load_config()

    if cfg.compute.llm_backend == "groq" and not cfg.secrets.groq_api_key:
        print("❌ Groq backend selected but GROQ_API_KEY missing.")
        print("   Run: nova setup")
        sys.exit(1)

    bot = NovaVisionBot(cfg)
    bot.run()


if __name__ == "__main__":
    main()
