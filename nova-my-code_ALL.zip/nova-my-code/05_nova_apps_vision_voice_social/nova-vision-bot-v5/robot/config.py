"""
NOVA config loader.

Reads config/nova.toml (settings) + .env (secrets).
Pydantic models give type-checked access and validation errors at load time.

Usage:
    from robot.config import load_config
    cfg = load_config()
    cfg.compute.device       # 'cuda' | 'cpu'
    cfg.hardware.camera_index
"""
from __future__ import annotations

import os
import sys
import tomllib
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field, field_validator

try:
    from dotenv import load_dotenv
except ImportError:
    load_dotenv = None


class HardwareConfig(BaseModel):
    camera_index: int = -1  # -1 = no camera
    arduino_port: str = "COM6"
    arduino_baud: int = 9600


class ComputeConfig(BaseModel):
    device: Literal["cuda", "cpu"] = "cpu"
    llm_backend: Literal["vllm", "llamacpp", "groq"] = "groq"


class ModelsConfig(BaseModel):
    yolo: str = "yolov8n-seg.pt"
    yolo_engine_path: str | None = None    # if set, use TensorRT engine instead
    depth: str = "depth_anything_v2_small"  # or "MiDaS_small" (legacy)
    depth_engine_path: str | None = None   # if set, use TensorRT engine
    vlm_cloud: str = "meta-llama/llama-4-scout-17b-16e-instruct"
    vlm_local: str = "Qwen/Qwen2-VL-7B-Instruct"
    llm_local: str = "Qwen/Qwen2.5-7B-Instruct"


class CalibrationConfig(BaseModel):
    """Ground-plane calibration parameters. Use scripts/calibrate.py to set."""
    enabled: bool = True
    file_path: str = "config/calibration.json"
    # Defaults — override via auto-calibration on first boot
    camera_height_mm: float = 80.0
    camera_tilt_deg: float = 20.0
    auto_calibrate_on_first_boot: bool = True


class SafetyConfig(BaseModel):
    critical_depth: float = Field(0.15, ge=0.0, le=1.0)
    warning_depth: float = Field(0.40, ge=0.0, le=1.0)
    safe_depth: float = Field(0.70, ge=0.0, le=1.0)
    vlm_required: bool = True

    @field_validator("safe_depth")
    @classmethod
    def _ordered(cls, v, info):
        warn = info.data.get("warning_depth", 0.40)
        crit = info.data.get("critical_depth", 0.15)
        if not (crit < warn < v):
            raise ValueError("Depth thresholds must satisfy critical < warning < safe")
        return v


class TelemetryConfig(BaseModel):
    log_latencies: bool = True
    log_path: str = "logs/nova.jsonl"


class Secrets(BaseModel):
    groq_api_key: str | None = None


class NovaConfig(BaseModel):
    hardware: HardwareConfig = HardwareConfig()
    compute: ComputeConfig = ComputeConfig()
    models: ModelsConfig = ModelsConfig()
    safety: SafetyConfig = SafetyConfig()
    telemetry: TelemetryConfig = TelemetryConfig()
    calibration: CalibrationConfig = CalibrationConfig()
    secrets: Secrets = Secrets()


def _project_root() -> Path:
    return Path(__file__).resolve().parent.parent


def load_config(toml_path: Path | None = None, env_path: Path | None = None) -> NovaConfig:
    root = _project_root()
    toml_path = toml_path or root / "config" / "nova.toml"
    env_path = env_path or root / ".env"

    if load_dotenv and env_path.exists():
        # override=True so a freshly-edited .env wins over a stale shell/User
        # GROQ_API_KEY (e.g. an expired key left in the environment).
        load_dotenv(env_path, override=True)

    data: dict = {}
    if toml_path.exists():
        with open(toml_path, "rb") as f:
            data = tomllib.load(f)
    else:
        print(f"⚠️  No config at {toml_path} — using defaults. Run scripts/setup.py first.",
              file=sys.stderr)

    data["secrets"] = {"groq_api_key": os.environ.get("GROQ_API_KEY")}
    return NovaConfig(**data)
