from robot.ui.display import Display

__all__ = ["Display"]
