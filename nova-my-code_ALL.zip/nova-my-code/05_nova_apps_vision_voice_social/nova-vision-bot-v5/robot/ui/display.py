"""
OpenCV-based HUD display for NOVA robot.
Renders camera feed, depth map, status panel, and zone grid.
"""

import datetime

import cv2
import numpy as np


class Display:
    """Renders the NOVA v3 debug/status display."""

    def create_display(self, frame, vision_data):
        h, w = frame.shape[:2]
        canvas_w = w * 2 + 300
        canvas_h = h + 100
        canvas = np.zeros((canvas_h, canvas_w, 3), dtype=np.uint8)
        canvas[:] = (30, 30, 30)

        grid = vision_data.get('grid_analysis', {})
        floor = grid.get('_floor_analysis', {})
        depth = vision_data.get('depth_map')
        obs = vision_data.get('obstacles', [])

        canvas[0:h, 0:w] = self._draw_camera(frame.copy(), grid, obs)
        if depth is not None:
            canvas[0:h, w:w*2] = self._draw_depth(depth, floor, h, w)
        canvas[0:h, w*2:w*2+300] = self._draw_status(grid, floor, obs, h)
        canvas[h:h+100, 0:canvas_w] = self._draw_bottom(floor, grid, canvas_w)
        return canvas

    def _draw_camera(self, frame, grid, obstacles):
        h, w = frame.shape[:2]
        floor = grid.get('_floor_analysis', {})
        overlay = frame.copy()
        zw, zh = w // 3, h // 3

        for i, row in enumerate(['F', 'M', 'N']):
            for j, col in enumerate(['L', 'C', 'R']):
                zn = f"{col}-{row}"
                zd = grid.get(zn, {})
                x1, y1 = j * zw, i * zh
                x2, y2 = x1 + zw, y1 + zh
                danger = zd.get('danger_score', 0)
                status = zd.get('status', 'CLEAR')
                is_surface = zd.get('is_surface_zone', False)

                if is_surface:
                    color = (255, 200, 0)
                    if danger >= 8:
                        color = (0, 0, 255)
                    alpha = 0.1
                else:
                    if danger >= 8: color = (0, 0, 255)
                    elif danger >= 5: color = (0, 100, 255)
                    elif danger >= 3: color = (0, 200, 255)
                    else: color = (0, 255, 0)
                    alpha = 0.15

                cv2.rectangle(overlay, (x1, y1), (x2, y2), color, -1)
                cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)

                label = f"{zn}"
                if is_surface:
                    label += " [SURFACE]"
                cv2.putText(frame, label, (x1+5, y1+18),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255,255,255), 2)
                cv2.putText(frame, label, (x1+5, y1+18),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 1)

                score = f"{danger}/10"
                ts = cv2.getTextSize(score, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)[0]
                tx = x1 + (zw - ts[0])//2
                ty = y1 + (zh + ts[1])//2
                cv2.putText(frame, score, (tx, ty),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
                cv2.putText(frame, score, (tx, ty),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 1)

                cv2.putText(frame, status, (x1+5, y1+zh-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.35, color, 1)

        frame = cv2.addWeighted(overlay, 0.15, frame, 0.85, 0)

        for obs in obstacles:
            bbox = obs.get('bbox')
            if bbox:
                bx1, by1, bx2, by2 = map(int, bbox)
                dist = obs.get('distance', 0)
                bc = (0,0,255) if dist < 0.5 else (0,165,255) if dist < 1.5 else (0,255,0)
                cv2.rectangle(frame, (bx1,by1), (bx2,by2), bc, 2)
                lbl = f"{obs['class']} {dist:.1f}m"
                ls = cv2.getTextSize(lbl, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)[0]
                cv2.rectangle(frame, (bx1, by1-20), (bx1+ls[0]+4, by1), bc, -1)
                cv2.putText(frame, lbl, (bx1+2, by1-5),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)

        ft = int(h * 0.6)
        cv2.line(frame, (0, ft), (w, ft), (255,255,0), 1)

        surface_top = 2 * zh
        cv2.line(frame, (0, surface_top), (w, surface_top), (255, 200, 0), 2)
        cv2.putText(frame, "^ NAV ZONES  |  SURFACE v", (w//2-100, surface_top-5),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.45, (255, 200, 0), 1)

        if floor.get('edge_detected'):
            el = floor.get('edge_location')
            if el is not None and el > 0.25:
                ey = int(h * (1.0 - el * 0.4))
                cv2.line(frame, (0, ey), (w, ey), (0,0,255), 3)
                cv2.putText(frame, "!! EDGE !!", (w//2-50, ey-10),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255), 2)

        cv2.rectangle(frame, (0,0), (w,28), (50,50,50), -1)
        cv2.putText(frame, "CAMERA — Surface-Aware Grid (v3)", (10,20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255,255,255), 1)
        return frame

    def _draw_depth(self, depth_map, floor, th, tw):
        dn = (depth_map * 255).astype(np.uint8)
        dc = cv2.applyColorMap(dn, cv2.COLORMAP_TURBO)
        dc = cv2.resize(dc, (tw, th))
        h, w = dc.shape[:2]

        ft = int(h * 0.6)
        cv2.rectangle(dc, (0, ft), (w, h), (255,255,255), 2)
        cx = w // 2
        cv2.line(dc, (cx-30, h), (cx, ft), (255,255,0), 2)
        cv2.line(dc, (cx+30, h), (cx, ft), (255,255,0), 2)

        if floor.get('dropoff_detected'):
            dd = floor.get('dropoff_distance', 0.5)
            dy = int(h * (1.0 - dd * 0.4))
            cv2.line(dc, (0, dy), (w, dy), (0,0,255), 3)
            cv2.putText(dc, "DROPOFF!", (w//2-40, dy-5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 2)

        cv2.rectangle(dc, (0,0), (w,28), (50,50,50), -1)
        cv2.putText(dc, "DEPTH MAP", (10,20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255,255,255), 1)
        return dc

    def _draw_status(self, grid, floor, obstacles, ph):
        pw = 300
        p = np.zeros((ph, pw, 3), dtype=np.uint8)
        p[:] = (40,40,40)
        y = 40
        lh = 24

        cv2.rectangle(p, (0,0), (pw,30), (60,60,60), -1)
        cv2.putText(p, "SAFETY STATUS v3", (10,20),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.55, (255,255,255), 1)

        cv2.putText(p, "SURFACE", (10,y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,200), 1)
        y += lh
        if floor:
            fd = floor.get('floor_detected', False)
            c = (0,255,0) if fd else (0,165,255)
            cv2.circle(p, (20,y-5), 8, c, -1)
            cv2.putText(p, "VERIFIED" if fd else "CHECKING", (35,y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.45, c, 1)
            y += lh

            conf = floor.get('floor_confidence', 0)
            bw = int(150 * conf)
            cv2.rectangle(p, (35,y-12), (35+bw,y), (0,255,0), -1)
            cv2.rectangle(p, (35,y-12), (185,y), (100,100,100), 1)
            cv2.putText(p, f"{conf:.0%}", (190,y), cv2.FONT_HERSHEY_SIMPLEX, 0.35, (200,200,200), 1)
            y += lh + 5

        cv2.putText(p, "EDGE DETECTION", (10,y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,200), 1)
        y += lh
        if floor:
            ed = floor.get('edge_detected', False)
            el = floor.get('edge_location')
            if ed and el is not None:
                if el > 0.45: ec, es = (0,0,255), f"CLOSE ({el:.0%})"
                elif el > 0.25: ec, es = (0,165,255), f"Medium ({el:.0%})"
                else: ec, es = (0,255,0), f"Far ({el:.0%})"
            elif ed:
                ec, es = (0,165,255), "Detected"
            else:
                ec, es = (0,255,0), "None"
            cv2.circle(p, (20,y-5), 8, ec, -1)
            cv2.putText(p, es, (35,y), cv2.FONT_HERSHEY_SIMPLEX, 0.42, ec, 1)
            y += lh

            dd = floor.get('dropoff_detected', False)
            dc2 = (0,0,255) if dd else (0,255,0)
            cv2.circle(p, (20,y-5), 8, dc2, -1)
            cv2.putText(p, "DROPOFF!" if dd else "No dropoff", (35,y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.42, dc2, 1)
            y += lh + 5

        cv2.putText(p, "NAV ZONES (MID)", (10,y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,200), 1)
        y += lh
        for zn in ['L-M', 'C-M', 'R-M']:
            zd = grid.get(zn, {})
            d = zd.get('danger_score', 0)
            c = (0,255,0) if d < 4 else (0,165,255) if d < 8 else (0,0,255)
            cv2.putText(p, f"{zn}: {d}/10 {zd.get('status','')}", (25,y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, c, 1)
            y += 18
        y += 5

        cv2.putText(p, f"OBSTACLES ({len(obstacles)})", (10,y),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200,200,200), 1)
        y += lh
        for obs in obstacles[:4]:
            dist = obs.get('distance', 0)
            c = (0,0,255) if dist < 0.5 else (0,165,255) if dist < 1.5 else (0,255,0)
            cv2.putText(p, f"- {obs['class']}: {dist:.1f}m", (25,y),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.4, c, 1)
            y += 18
        if not obstacles:
            cv2.putText(p, "None", (25,y), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (0,255,0), 1)

        safe = True
        if floor:
            safe = not any(z in ('IMMEDIATE_EDGE', 'CLIFF_DANGER')
                          for z in floor.get('danger_zones', []))
        sy = ph - 55
        if safe:
            cv2.rectangle(p, (10,sy), (pw-10,ph-10), (0,150,0), -1)
            cv2.putText(p, "SAFE TO MOVE", (55,sy+30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255,255,255), 2)
        else:
            cv2.rectangle(p, (10,sy), (pw-10,ph-10), (0,0,200), -1)
            cv2.putText(p, "BLOCKED", (80,sy+30),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.75, (255,255,255), 2)
        return p

    def _draw_bottom(self, floor, grid, bw):
        bh = 100
        bar = np.zeros((bh, bw, 3), dtype=np.uint8)
        bar[:] = (50,50,50)
        ms = 28
        mx, my = 15, 15

        cv2.putText(bar, "Zones:", (mx, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200,200,200), 1)
        for i, row in enumerate(['F', 'M', 'N']):
            for j, col in enumerate(['L', 'C', 'R']):
                zn = f"{col}-{row}"
                d = grid.get(zn, {}).get('danger_score', 0)
                is_surf = grid.get(zn, {}).get('is_surface_zone', False)
                x = mx + j * (ms + 4)
                yy = my + i * (ms + 4)

                if is_surf:
                    c = (200, 150, 0) if d < 4 else (0, 0, 200)
                else:
                    if d >= 8: c = (0,0,200)
                    elif d >= 5: c = (0,100,200)
                    elif d >= 3: c = (0,180,200)
                    else: c = (0,180,0)

                cv2.rectangle(bar, (x,yy), (x+ms,yy+ms), c, -1)
                cv2.rectangle(bar, (x,yy), (x+ms,yy+ms), (100,100,100), 1)
                cv2.putText(bar, str(d), (x+9, yy+18),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255,255,255), 1)

        cv2.putText(bar, "L C R", (mx+3, my + 3*(ms+4)+12),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.3, (150,150,150), 1)
        cv2.putText(bar, "F", (mx+3*(ms+4)+5, my+ms//2+5),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.3, (150,150,150), 1)
        cv2.putText(bar, "M", (mx+3*(ms+4)+5, my+ms+ms//2+9),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.3, (150,150,150), 1)
        cv2.putText(bar, "N(surf)", (mx+3*(ms+4)+5, my+2*ms+ms//2+13),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.3, (200,150,0), 1)

        wx = 170
        w = floor.get('warning_message') if floor else None
        cv2.putText(bar, "Warnings:", (wx, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200,200,200), 1)
        if w:
            yoff = 28
            for line in [w[i:i+55] for i in range(0, len(w), 55)][:2]:
                cv2.putText(bar, line, (wx, yoff),
                           cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0,100,255), 1)
                yoff += 16
        else:
            cv2.putText(bar, "All clear", (wx, 28),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.38, (0,255,0), 1)

        lx = bw - 280
        cv2.putText(bar, "Legend:", (lx, 12), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200,200,200), 1)
        for i, (c, l) in enumerate([
            ((0,180,0), "CLEAR (0-2)"), ((0,180,200), "CAUTION (3-4)"),
            ((0,100,200), "HIGH (5-7)"), ((0,0,200), "BLOCKED (8-10)"),
            ((200,150,0), "SURFACE (N-row)")
        ]):
            yo = 28 + i * 16
            cv2.rectangle(bar, (lx, yo-8), (lx+12, yo+4), c, -1)
            cv2.putText(bar, l, (lx+16, yo+2),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.32, (200,200,200), 1)

        ts = datetime.datetime.now().strftime("%H:%M:%S")
        cv2.putText(bar, ts, (bw-70, bh-8),
                   cv2.FONT_HERSHEY_SIMPLEX, 0.35, (150,150,150), 1)
        return bar
