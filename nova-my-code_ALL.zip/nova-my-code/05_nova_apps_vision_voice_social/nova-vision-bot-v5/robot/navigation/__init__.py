from robot.navigation.freespace import FreeSpaceDetector

__all__ = ["FreeSpaceDetector"]
