"""
Free space detection with surface-aware zone scoring (v3).

Near zones (N-row) = driving surface under the robot, NOT obstacles.
Depth-based danger only applies to MID and FAR zones.
"""

from typing import Dict, List

import numpy as np

from robot.perception.floor_detector import FloorVerifier


class FreeSpaceDetector:

    def __init__(self, critical: float = 0.15, warning: float = 0.40, safe: float = 0.70):
        self.thresholds = {
            'CRITICAL': critical,
            'WARNING': warning,
            'SAFE': safe,
        }

        self.zone_names = [
            ['L-F', 'C-F', 'R-F'],
            ['L-M', 'C-M', 'R-M'],
            ['L-N', 'C-N', 'R-N']
        ]

        self.surface_zones = {'L-N', 'C-N', 'R-N'}
        self.floor_verifier = FloorVerifier()

    def get_zone_bounds(self, frame_height, frame_width, zone_name):
        col, row = zone_name.split('-')
        col_idx = {'L': 0, 'C': 1, 'R': 2}[col]
        row_idx = {'F': 0, 'M': 1, 'N': 2}[row]
        zone_width = frame_width // 3
        zone_height = frame_height // 3
        x1 = col_idx * zone_width
        y1 = row_idx * zone_height
        return (x1, y1, x1 + zone_width, y1 + zone_height)

    def analyze_zone(self, zone_name: str, depth_map: np.ndarray,
                     obstacles: List[Dict]) -> Dict:
        h, w = depth_map.shape
        x1, y1, x2, y2 = self.get_zone_bounds(h, w, zone_name)
        zone_depth = depth_map[y1:y2, x1:x2]

        if zone_depth.size == 0:
            return self._empty_zone_result()

        min_depth = float(np.min(zone_depth))
        mean_depth = float(np.mean(zone_depth))

        obstacles_in_zone = []
        for obs in obstacles:
            cx, cy = obs['center']
            if x1 <= cx < x2 and y1 <= cy < y2:
                obstacles_in_zone.append(obs['class'])
        obstacle_count = len(obstacles_in_zone)

        if zone_name in self.surface_zones:
            danger_score = self._calculate_surface_zone_danger(
                obstacle_count, obstacles_in_zone
            )
        else:
            danger_score = self._calculate_navigation_zone_danger(
                min_depth, mean_depth, obstacle_count
            )

        if danger_score >= 8:
            status = 'BLOCKED'
        elif danger_score >= 4:
            status = 'CAUTION'
        else:
            status = 'CLEAR'

        return {
            'min_depth': min_depth,
            'mean_depth': mean_depth,
            'obstacle_count': obstacle_count,
            'danger_score': danger_score,
            'status': status,
            'obstacles_in_zone': obstacles_in_zone,
            'is_surface_zone': zone_name in self.surface_zones
        }

    def _calculate_surface_zone_danger(self, obstacle_count: int,
                                        obstacle_names: List[str]) -> int:
        if obstacle_count == 0:
            return 0

        surface_objects = {
            'dining table', 'desk', 'bench', 'bed', 'couch', 'sofa',
            'table', 'counter', 'shelf', 'floor', 'carpet', 'rug'
        }

        real_obstacles = [
            name for name in obstacle_names
            if name.lower() not in surface_objects
        ]

        if len(real_obstacles) == 0:
            return 0

        high_danger = {'person', 'dog', 'cat', 'bird', 'horse', 'cow', 'sheep'}
        has_living = any(name.lower() in high_danger for name in real_obstacles)

        if has_living:
            return 9

        return min(len(real_obstacles) * 3, 8)

    def _calculate_navigation_zone_danger(self, min_depth: float,
                                           mean_depth: float,
                                           obstacle_count: int) -> int:
        base_danger = 0
        if min_depth < self.thresholds['CRITICAL']:
            base_danger = 10
        elif min_depth < self.thresholds['WARNING']:
            ratio = (self.thresholds['WARNING'] - min_depth) / \
                   (self.thresholds['WARNING'] - self.thresholds['CRITICAL'])
            base_danger = 5 + int(ratio * 3)
        elif min_depth < self.thresholds['SAFE']:
            ratio = (self.thresholds['SAFE'] - min_depth) / \
                   (self.thresholds['SAFE'] - self.thresholds['WARNING'])
            base_danger = 2 + int(ratio * 3)

        obstacle_penalty = min(obstacle_count, 3)
        return min(base_danger + obstacle_penalty, 10)

    def _empty_zone_result(self):
        return {
            'min_depth': 1.0, 'mean_depth': 1.0,
            'obstacle_count': 0, 'danger_score': 0,
            'status': 'CLEAR', 'obstacles_in_zone': [],
            'is_surface_zone': False
        }

    def analyze_all_zones(self, depth_map, obstacles, frame=None):
        results = {}
        for row in self.zone_names:
            for zone_name in row:
                results[zone_name] = self.analyze_zone(zone_name, depth_map, obstacles)

        if frame is not None:
            floor_analysis = self.floor_verifier.analyze_floor_region(depth_map, frame)
            results['_floor_analysis'] = floor_analysis

            if floor_analysis.get('danger_zones'):
                critical = any(
                    z in ('IMMEDIATE_EDGE', 'CLIFF_DANGER')
                    for z in floor_analysis['danger_zones']
                )
                if critical:
                    for zone in ['C-M', 'L-M', 'R-M']:
                        if zone in results:
                            results[zone]['danger_score'] = min(
                                results[zone]['danger_score'] + 5, 10
                            )
                            if results[zone]['danger_score'] >= 8:
                                results[zone]['status'] = 'BLOCKED'

        return results

    def get_free_zones(self, grid_analysis):
        return [
            name for name, data in grid_analysis.items()
            if not name.startswith('_') and data['status'] == 'CLEAR'
        ]

    def suggest_alternative_direction(self, grid_analysis):
        left_danger = grid_analysis.get('L-M', {}).get('danger_score', 10)
        right_danger = grid_analysis.get('R-M', {}).get('danger_score', 10)

        if left_danger < 4 and right_danger < 4:
            return 'LEFT' if left_danger <= right_danger else 'RIGHT'
        if left_danger < 4:
            return 'LEFT'
        if right_danger < 4:
            return 'RIGHT'
        return 'STOP'
