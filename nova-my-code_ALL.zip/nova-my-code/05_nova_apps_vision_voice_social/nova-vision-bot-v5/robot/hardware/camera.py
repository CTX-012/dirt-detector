"""Camera wrapper — opens the configured index, errors out clearly if absent."""
from __future__ import annotations

from typing import Optional, Tuple

import cv2
import numpy as np


class CameraError(RuntimeError):
    """Raised when the configured camera cannot be opened."""


class Camera:
    def __init__(self, index: int = -1, width: int = 640, height: int = 480, fps: int = 30,
                 strict: bool = False):
        """
        Args:
            index: camera index from config; -1 means disabled.
            strict: if True, raise CameraError on failure. If False, mark as not open
                and let the caller fall back to chat-only mode.
        """
        self.width = width
        self.height = height
        self.fps = fps
        self.index = index
        self.cap: Optional[cv2.VideoCapture] = None
        self.is_open = False

        if index < 0:
            print("   📷 Camera disabled in config — chat-only mode")
            return

        self._connect(strict=strict)

    def _connect(self, strict: bool) -> None:
        cap = cv2.VideoCapture(self.index)
        if not cap.isOpened():
            cap.release()
            msg = (
                f"Camera index {self.index} could not be opened.\n"
                f"   → Run `nova setup` to re-detect cameras, or\n"
                f"   → edit config/nova.toml [hardware] camera_index"
            )
            if strict:
                raise CameraError(msg)
            print(f"   ⚠️  {msg}")
            return

        # Verify we actually get a frame, not just an open handle
        ok, _ = cap.read()
        if not ok:
            cap.release()
            msg = f"Camera index {self.index} opens but returns no frames. Check permissions/driver."
            if strict:
                raise CameraError(msg)
            print(f"   ⚠️  {msg}")
            return

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, self.width)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, self.height)
        cap.set(cv2.CAP_PROP_FPS, self.fps)
        self.cap = cap
        self.is_open = True
        print(f"   📷 Camera ready on index {self.index} ({self.width}x{self.height}@{self.fps})")

    def read(self) -> Tuple[bool, Optional[np.ndarray]]:
        if not self.cap or not self.is_open:
            return False, None
        return self.cap.read()

    def release(self) -> None:
        if self.cap:
            self.cap.release()
            self.is_open = False
