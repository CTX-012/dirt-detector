"""
Motor controller for NOVA — non-blocking, abortable.

v3 did time.sleep(duration) on the caller's thread, blocking the safety
loop. If a person stepped in front during a 3s FORWARD, the bot could
not stop until the sleep ended.

This version runs movement in a worker thread driven by an Event. Any
caller can fire .abort() and the wheels stop within one serial write.
"""
from __future__ import annotations

import threading
import time
from typing import Optional

import serial


class MotorController:
    def __init__(self, port: str = "COM6", baud_rate: int = 9600):
        self.port = port
        self.baud_rate = baud_rate
        self.arduino: Optional[serial.Serial] = None
        self.last_command = "S"
        self.is_connected = False

        self.command_map = {
            "FORWARD": "F", "BACKWARD": "B", "LEFT": "L",
            "RIGHT": "R", "STOP": "S",
            "SPEED_LOW": "1", "SPEED_MED": "2", "SPEED_HIGH": "3",
        }
        self._cmd_lock = threading.Lock()
        self._abort_event = threading.Event()
        self._worker: Optional[threading.Thread] = None
        self._connect()

    def _connect(self) -> None:
        try:
            self.arduino = serial.Serial(self.port, self.baud_rate, timeout=0.1)
            time.sleep(2)
            self.is_connected = True
            print(f"      ✅ Motors connected on {self.port}")
        except Exception:
            print(f"      ⚠️  No motor controller on {self.port} → SIMULATION mode")
            self.is_connected = False

    def _send_raw(self, char: str) -> None:
        with self._cmd_lock:
            if not self.arduino:
                print(f"      [SIM] send: {char}")
                self.last_command = char
                return
            if char == self.last_command:
                return
            try:
                if self.last_command == "S" and char not in ("S", "1", "2", "3"):
                    self.arduino.write(b"E")
                    time.sleep(0.005)
                self.arduino.write(char.encode())
                self.last_command = char
            except Exception as e:
                print(f"      ❌ serial write failed: {e}")
                self.is_connected = False

    def execute_command(self, action: str, duration: float = 0,
                        speed: str = "SPEED_MED") -> None:
        """Fire-and-forget. Aborts any in-flight movement before starting."""
        if not action:
            return
        action_char = self.command_map.get(action)
        speed_char = self.command_map.get(speed) if speed else None
        if not action_char:
            return

        self.abort()
        self._abort_event = threading.Event()
        self._worker = threading.Thread(
            target=self._run_movement, daemon=True,
            args=(action_char, speed_char, duration, action),
        )
        self._worker.start()

    def _run_movement(self, action_char: str, speed_char: Optional[str],
                      duration: float, action_name: str) -> None:
        if speed_char and action_char != "S":
            self._send_raw(speed_char)
            time.sleep(0.02)
        self._send_raw(action_char)
        if duration <= 0:
            return
        # Event.wait() is an interruptible sleep — wakes up on .set()
        woke_early = self._abort_event.wait(timeout=duration)
        self._send_raw("S")
        if woke_early:
            print(f"      🛑 {action_name} aborted")
        else:
            print(f"      ⏸️  {action_name} complete ({duration}s)")

    def abort(self) -> None:
        """Stop any movement in flight. Always safe to call."""
        self._abort_event.set()
        w = self._worker
        if w and w.is_alive():
            w.join(timeout=0.5)
        self._send_raw("S")

    def stop(self) -> None:
        self.abort()

    def is_moving(self) -> bool:
        return self.last_command not in ("S", "1", "2", "3")

    def close(self) -> None:
        self.abort()
        if self.arduino:
            self.arduino.close()
