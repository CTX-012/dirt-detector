"""
Pluggable LLM/VLM backends.

The robot's safety and chat code talks to a single Protocol; the backend
is chosen at startup based on config.compute.llm_backend.

  - GroqBackend     : cloud API, works anywhere with an internet connection
  - VLLMBackend     : local serving on Linux + NVIDIA, batched, fast
  - LlamaCppBackend : local GGUF on any OS, CPU or CUDA

All three speak the same OpenAI-style chat-completions interface.
"""
from __future__ import annotations

import base64
import io
from typing import Any, Protocol, runtime_checkable

import numpy as np


# ────────────────────────────── interface ──────────────────────────────

@runtime_checkable
class VLMBackend(Protocol):
    """Vision-language backend protocol."""
    name: str

    def chat_with_image(self, prompt: str, image: np.ndarray,
                        max_tokens: int = 600, temperature: float = 0.2,
                        json_mode: bool = True) -> str: ...

    def chat(self, messages: list[dict], max_tokens: int = 300,
             temperature: float = 0.7, json_mode: bool = True) -> str: ...


def _encode_jpeg_b64(image: np.ndarray, max_side: int = 640, quality: int = 85) -> str:
    import cv2
    h, w = image.shape[:2]
    if max(h, w) > max_side:
        scale = max_side / max(h, w)
        image = cv2.resize(image, None, fx=scale, fy=scale)
    ok, buf = cv2.imencode(".jpg", image, [cv2.IMWRITE_JPEG_QUALITY, quality])
    if not ok:
        raise RuntimeError("JPEG encode failed")
    return base64.b64encode(buf).decode("utf-8")


# ────────────────────────────── Groq cloud ──────────────────────────────

class GroqBackend:
    name = "groq"

    def __init__(self, api_key: str, vlm_model: str, llm_model: str | None = None):
        from groq import Groq
        if not api_key:
            raise ValueError("GROQ_API_KEY required for Groq backend")
        self.client = Groq(api_key=api_key)
        self.vlm_model = vlm_model
        self.llm_model = llm_model or vlm_model
        self.fallback_models = [
            vlm_model,
            "meta-llama/llama-4-maverick-17b-128e-instruct",
        ]

    def chat_with_image(self, prompt, image, max_tokens=600, temperature=0.2, json_mode=True):
        b64 = _encode_jpeg_b64(image)
        msg = [{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url",
                 "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
            ],
        }]
        return self._call(self.fallback_models, msg, max_tokens, temperature, json_mode)

    def chat(self, messages, max_tokens=300, temperature=0.7, json_mode=True):
        return self._call([self.llm_model], messages, max_tokens, temperature, json_mode)

    def _call(self, model_chain, messages, max_tokens, temperature, json_mode):
        kwargs: dict[str, Any] = dict(messages=messages, max_tokens=max_tokens,
                                       temperature=temperature)
        if json_mode:
            kwargs["response_format"] = {"type": "json_object"}
        last_err = None
        for m in model_chain:
            try:
                r = self.client.chat.completions.create(model=m, **kwargs)
                return r.choices[0].message.content
            except Exception as e:
                last_err = e
                continue
        raise RuntimeError(f"All Groq models failed: {last_err}")


# ────────────────────────────── vLLM local ──────────────────────────────

class VLLMBackend:
    """vLLM in-process. Linux + NVIDIA only. Loads once, very fast inference."""
    name = "vllm"

    def __init__(self, vlm_model: str, llm_model: str,
                 gpu_memory_utilization: float = 0.85):
        from vllm import LLM, SamplingParams  # heavy import — only on this backend
        self.SamplingParams = SamplingParams

        # One process can typically host one model at a time without thrashing VRAM.
        # On a 3080 (10GB) we share the VLM for both vision and chat;
        # on a 3090 (24GB) you could split into two engines.
        print(f"  🧠 Loading vLLM engine: {vlm_model}")
        self.engine = LLM(
            model=vlm_model,
            gpu_memory_utilization=gpu_memory_utilization,
            max_model_len=4096,
            trust_remote_code=True,
            dtype="auto",
        )
        self.vlm_model = vlm_model
        self.llm_model = llm_model  # same engine for chat for now

    def chat_with_image(self, prompt, image, max_tokens=600, temperature=0.2, json_mode=True):
        from PIL import Image
        import cv2
        rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pil = Image.fromarray(rgb)

        # vLLM multimodal prompt template — Qwen2-VL style. If the user swaps in
        # a different VLM model, this format string needs adjusting.
        system_hint = "\n\nRespond with valid JSON only." if json_mode else ""
        chat = (
            "<|im_start|>user\n"
            "<|vision_start|><|image_pad|><|vision_end|>"
            f"{prompt}{system_hint}<|im_end|>\n"
            "<|im_start|>assistant\n"
        )
        sp = self.SamplingParams(max_tokens=max_tokens, temperature=temperature)
        out = self.engine.generate(
            {"prompt": chat, "multi_modal_data": {"image": pil}},
            sampling_params=sp,
        )
        return out[0].outputs[0].text

    def chat(self, messages, max_tokens=300, temperature=0.7, json_mode=True):
        # Render OpenAI-style messages into Qwen chat template
        parts = []
        for m in messages:
            role = m["role"]
            content = m["content"] if isinstance(m["content"], str) else str(m["content"])
            parts.append(f"<|im_start|>{role}\n{content}<|im_end|>")
        parts.append("<|im_start|>assistant\n")
        prompt = "\n".join(parts)
        if json_mode:
            prompt += '{"'  # nudge the model into starting valid JSON

        sp = self.SamplingParams(max_tokens=max_tokens, temperature=temperature)
        out = self.engine.generate([prompt], sampling_params=sp)
        text = out[0].outputs[0].text
        return ('{"' + text) if json_mode else text


# ────────────────────────────── llama.cpp (GGUF) ──────────────────────────────

class LlamaCppBackend:
    """Universal local backend. Works on Windows + Linux + macOS, CPU or CUDA build."""
    name = "llamacpp"

    def __init__(self, vlm_model_path: str, llm_model_path: str, n_gpu_layers: int = -1):
        from llama_cpp import Llama
        from llama_cpp.llama_chat_format import Llava15ChatHandler

        # llama-cpp-python expects a local GGUF file. If the path looks like a HF
        # repo, the higher-level loader will resolve it first.
        print(f"  🧠 Loading llama.cpp models...")
        self.llm = Llama(
            model_path=llm_model_path,
            n_gpu_layers=n_gpu_layers,  # -1 = offload all to GPU if available
            n_ctx=4096,
            verbose=False,
        )
        # For VLM, the handler+model pair is required:
        self._vlm_path = vlm_model_path  # lazy init on first vision call
        self._vlm = None
        self._Llama = Llama
        self._Llava = Llava15ChatHandler

    def _ensure_vlm(self):
        if self._vlm is None:
            # Expect a paired projector .gguf next to the VLM weights
            self._vlm = self._Llama(
                model_path=self._vlm_path,
                chat_handler=self._Llava(clip_model_path=self._vlm_path.replace(".gguf", "-mmproj.gguf")),
                n_ctx=4096, n_gpu_layers=-1, verbose=False,
            )

    def chat_with_image(self, prompt, image, max_tokens=600, temperature=0.2, json_mode=True):
        self._ensure_vlm()
        b64 = _encode_jpeg_b64(image)
        msg = [{
            "role": "user",
            "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}},
                {"type": "text", "text": prompt + ("\n\nReturn JSON only." if json_mode else "")},
            ],
        }]
        r = self._vlm.create_chat_completion(messages=msg, max_tokens=max_tokens,
                                              temperature=temperature)
        return r["choices"][0]["message"]["content"]

    def chat(self, messages, max_tokens=300, temperature=0.7, json_mode=True):
        r = self.llm.create_chat_completion(messages=messages, max_tokens=max_tokens,
                                             temperature=temperature)
        return r["choices"][0]["message"]["content"]


# ────────────────────────────── factory ──────────────────────────────

def create_backend(cfg) -> VLMBackend:
    """Pick a backend from config. Falls back to Groq on failure."""
    backend = cfg.compute.llm_backend
    try:
        if backend == "vllm":
            return VLLMBackend(cfg.models.vlm_local, cfg.models.llm_local)
        if backend == "llamacpp":
            return LlamaCppBackend(cfg.models.vlm_local, cfg.models.llm_local)
    except Exception as e:
        print(f"⚠️  {backend} backend failed to init: {e}")
        print("    Falling back to Groq cloud.")
    return GroqBackend(
        api_key=cfg.secrets.groq_api_key or "",
        vlm_model=cfg.models.vlm_cloud,
        llm_model=cfg.models.vlm_cloud,
    )
