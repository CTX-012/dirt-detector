"""
Per-stage latency tracking for NOVA's pipeline.

Usage:
    tracker = LatencyTracker(log_path="logs/nova.jsonl")
    with tracker.stage("yolo"):
        obstacles = yolo.detect(frame)
    with tracker.stage("midas"):
        depth = midas.estimate(frame)

    print(tracker.summary())   # mean / p50 / p95 / p99 per stage

Each decision is one "trace": a group of stages bound to a frame id, written
as a single JSON line so you can grep, awk, or load into pandas later.
"""
from __future__ import annotations

import json
import os
import statistics
import threading
import time
from collections import defaultdict, deque
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator


class LatencyTracker:
    def __init__(self, log_path: str | None = None, window: int = 200):
        self._lock = threading.Lock()
        # Per-stage ring buffer of recent durations (ms)
        self._durations: dict[str, deque[float]] = defaultdict(lambda: deque(maxlen=window))
        # Currently building trace (per decision)
        self._current_trace: dict[str, float] = {}
        self._trace_started_at: float = 0.0

        self.log_path: Path | None = Path(log_path) if log_path else None
        if self.log_path:
            self.log_path.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def stage(self, name: str) -> Iterator[None]:
        t0 = time.perf_counter()
        try:
            yield
        finally:
            dur_ms = (time.perf_counter() - t0) * 1000.0
            with self._lock:
                self._durations[name].append(dur_ms)
                self._current_trace[name] = dur_ms

    def begin_trace(self) -> None:
        with self._lock:
            self._current_trace = {}
            self._trace_started_at = time.perf_counter()

    def end_trace(self, **extra) -> dict:
        with self._lock:
            total_ms = (time.perf_counter() - self._trace_started_at) * 1000.0
            trace = {
                "ts": time.time(),
                "total_ms": round(total_ms, 2),
                "stages": {k: round(v, 2) for k, v in self._current_trace.items()},
                **extra,
            }
            self._current_trace = {}
        if self.log_path:
            try:
                with open(self.log_path, "a") as f:
                    f.write(json.dumps(trace) + "\n")
            except Exception:
                pass  # never let logging crash the robot
        return trace

    def summary(self) -> dict[str, dict[str, float]]:
        """Per-stage mean/p50/p95/p99 over the rolling window."""
        out: dict[str, dict[str, float]] = {}
        with self._lock:
            for name, buf in self._durations.items():
                if not buf:
                    continue
                xs = sorted(buf)
                out[name] = {
                    "n": len(xs),
                    "mean": round(statistics.fmean(xs), 2),
                    "p50": round(_percentile(xs, 50), 2),
                    "p95": round(_percentile(xs, 95), 2),
                    "p99": round(_percentile(xs, 99), 2),
                    "max": round(xs[-1], 2),
                }
        return out

    def render_table(self) -> str:
        rows = self.summary()
        if not rows:
            return "(no measurements yet)"
        header = f"{'stage':<20} {'n':>5} {'mean':>8} {'p50':>8} {'p95':>8} {'p99':>8} {'max':>8}"
        lines = [header, "-" * len(header)]
        for name, s in sorted(rows.items(), key=lambda kv: -kv[1]["mean"]):
            lines.append(
                f"{name:<20} {s['n']:>5} {s['mean']:>7.1f}ms {s['p50']:>7.1f}ms "
                f"{s['p95']:>7.1f}ms {s['p99']:>7.1f}ms {s['max']:>7.1f}ms"
            )
        return "\n".join(lines)


def _percentile(sorted_xs: list[float], p: float) -> float:
    if not sorted_xs:
        return 0.0
    k = (len(sorted_xs) - 1) * (p / 100.0)
    lo, hi = int(k), min(int(k) + 1, len(sorted_xs) - 1)
    return sorted_xs[lo] + (sorted_xs[hi] - sorted_xs[lo]) * (k - lo)


# Module-level default — single tracker for the whole robot
_default: LatencyTracker | None = None


def get_tracker() -> LatencyTracker:
    global _default
    if _default is None:
        _default = LatencyTracker(log_path=os.environ.get("NOVA_LATENCY_LOG"))
    return _default


def set_tracker(t: LatencyTracker) -> None:
    global _default
    _default = t
