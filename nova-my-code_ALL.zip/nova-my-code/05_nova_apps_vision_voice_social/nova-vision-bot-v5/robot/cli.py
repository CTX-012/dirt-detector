"""
NOVA command-line interface.

  nova setup     # interactive install (delegates to scripts/setup.py)
  nova run       # start the robot
  nova doctor    # verify cameras, GPU, models, API keys
  nova bench     # synthetic latency benchmark
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(no_args_is_help=True, add_completion=False, help="NOVA Vision Bot v4")
console = Console()


@app.command()
def calibrate(manual: bool = typer.Option(False, "--manual",
                                            help="Enter height/tilt manually")):
    """Run ground-plane calibration (spin 5s, save to config/calibration.json)."""
    script = Path(__file__).resolve().parent.parent / "scripts" / "calibrate.py"
    cmd = [sys.executable, str(script)]
    if manual:
        cmd.append("--manual")
    subprocess.call(cmd)


@app.command("export-yolo")
def export_yolo(int8: bool = typer.Option(False, "--int8",
                                            help="INT8 quantization"),
                 imgsz: int = typer.Option(640, "--imgsz")):
    """Export YOLO to TensorRT (faster inference on GPU)."""
    script = Path(__file__).resolve().parent.parent / "scripts" / "export_yolo_trt.py"
    cmd = [sys.executable, str(script), "--imgsz", str(imgsz)]
    if int8:
        cmd.append("--int8")
    subprocess.call(cmd)


@app.command("export-depth")
def export_depth(imgsz: int = typer.Option(518, "--imgsz")):
    """Export Depth Anything V2 to TensorRT."""
    script = Path(__file__).resolve().parent.parent / "scripts" / "export_depth_trt.py"
    subprocess.call([sys.executable, str(script), "--imgsz", str(imgsz)])


@app.command()
def setup() -> None:
    """Run the universal setup wizard."""
    script = Path(__file__).resolve().parent.parent / "scripts" / "setup.py"
    subprocess.call([sys.executable, str(script)])


@app.command()
def run() -> None:
    """Start the robot."""
    from robot.main import main as run_main
    run_main()


@app.command()
def doctor() -> None:
    """Check that everything is wired up correctly."""
    from robot.config import load_config
    cfg = load_config()

    table = Table(title="NOVA Doctor", show_header=True)
    table.add_column("Check"); table.add_column("Status"); table.add_column("Detail")

    # Python
    table.add_row("Python", "✓", sys.version.split()[0])

    # GPU
    try:
        import torch
        if torch.cuda.is_available():
            table.add_row("CUDA", "✓", f"{torch.cuda.get_device_name(0)}")
        else:
            table.add_row("CUDA", "—", "CPU mode")
    except ImportError:
        table.add_row("Torch", "✗", "not installed")

    # Camera
    try:
        import cv2
        if cfg.hardware.camera_index >= 0:
            cap = cv2.VideoCapture(cfg.hardware.camera_index)
            ok = cap.isOpened() and cap.read()[0]
            cap.release()
            table.add_row("Camera", "✓" if ok else "✗",
                          f"index {cfg.hardware.camera_index}")
        else:
            table.add_row("Camera", "—", "disabled in config")
    except Exception as e:
        table.add_row("Camera", "✗", str(e))

    # API key
    table.add_row("GROQ_API_KEY", "✓" if cfg.secrets.groq_api_key else "✗",
                  "set" if cfg.secrets.groq_api_key else "missing (run `nova setup`)")

    # Backend
    table.add_row("LLM backend", "✓", cfg.compute.llm_backend)

    # Arduino — non-fatal
    try:
        import serial
        try:
            s = serial.Serial(cfg.hardware.arduino_port, cfg.hardware.arduino_baud, timeout=0.1)
            s.close()
            table.add_row("Arduino", "✓", cfg.hardware.arduino_port)
        except Exception:
            table.add_row("Arduino", "—", "not found (simulation mode)")
    except ImportError:
        table.add_row("Arduino", "✗", "pyserial not installed")

    console.print(table)


@app.command()
def bench(frames: int = 50) -> None:
    """Run a synthetic latency benchmark across the full vision pipeline."""
    import numpy as np
    from robot.config import load_config
    from robot.perception.vision_pipeline import VisionPipeline
    from robot.navigation.freespace import FreeSpaceDetector
    from robot.telemetry import get_tracker

    cfg = load_config()
    console.print(f"[cyan]Loading models...[/]")
    vision = VisionPipeline()
    free = FreeSpaceDetector()
    tracker = get_tracker()

    console.print(f"[cyan]Running {frames} synthetic frames...[/]")
    rng = np.random.default_rng(0)

    # A fresh frame each iteration forces the depth model to run every frame
    # (a single reused frame would hit the depth cache and only measure YOLO).
    def make_frame():
        return rng.integers(0, 255, (480, 640, 3), dtype="uint8")

    # Untimed warmup so steady-state numbers aren't skewed by lazy CUDA/cuDNN init.
    for _ in range(3):
        vision.analyze_frame(make_frame())

    for i in range(frames):
        frame = make_frame()
        tracker.begin_trace()
        with tracker.stage("vision"):
            vd = vision.analyze_frame(frame)
        with tracker.stage("freespace"):
            vd["grid_analysis"] = free.analyze_all_zones(
                vd["depth_map"], vd["obstacles"], frame)
        tracker.end_trace(frame_id=i)

    console.print()
    console.print(tracker.render_table())


if __name__ == "__main__":
    app()
