"""
Decision fusion engine (v3 — VLM-primary).

Priority:
1. Critical floor danger (IMMEDIATE_EDGE, CLIFF) → hard stop
2. VLM says unsafe → stop
3. MID-zone depth shows wall/obstacle → stop
4. VLM says safe → proceed

Near zones are NEVER used for blocking decisions.
"""


class DecisionFusion:

    def __init__(self):
        self.CRITICAL_DANGER = 9
        self.HIGH_DANGER = 6
        self.MODERATE_DANGER = 3
        self.max_duration = 5.0
        self.min_duration = 0.5

    def fuse_decisions(self, user_intent, vision_data, vlm_assessment,
                      requested_duration=2.0, requested_speed='SPEED_MED'):

        if vision_data is None or vlm_assessment is None:
            return self._trust_user(user_intent, requested_duration, requested_speed)

        grid = vision_data.get('grid_analysis', {})
        floor_analysis = grid.get('_floor_analysis', {})

        # RULE 1: Critical edge/cliff from floor verifier
        if floor_analysis:
            critical = any(
                z in ('IMMEDIATE_EDGE', 'CLIFF_DANGER')
                for z in floor_analysis.get('danger_zones', [])
            )
            if critical:
                return self._edge_stop(vlm_assessment, user_intent)

        # RULE 2: VLM detected close edge
        if vlm_assessment.get('edge_danger') and \
           vlm_assessment.get('edge_proximity') == 'close':
            return self._edge_stop(vlm_assessment, user_intent)

        # RULE 3: MID-zone obstacle
        if self._has_mid_zone_obstacle(grid, user_intent):
            return self._obstacle_stop(grid, user_intent)

        # RULE 4: VLM says unsafe
        if not vlm_assessment.get('safe_to_move', False):
            return self._vlm_stop(vlm_assessment, user_intent)

        # RULE 5: High danger → slow proceed
        if vlm_assessment.get('danger_level', 0) >= self.HIGH_DANGER:
            return self._cautious(vlm_assessment, user_intent, requested_duration)

        # RULE 6: Moderate danger → warn
        if vlm_assessment.get('danger_level', 0) >= self.MODERATE_DANGER:
            return self._warn(vlm_assessment, user_intent, requested_duration, requested_speed)

        # ALL CLEAR
        return self._proceed(vlm_assessment, user_intent, requested_duration, requested_speed)

    def _has_mid_zone_obstacle(self, grid, intent):
        zone_map = {
            'FORWARD': ['C-M'],
            'BACKWARD': [],
            'LEFT': ['L-M'],
            'RIGHT': ['R-M']
        }
        for zone in zone_map.get(intent, []):
            if zone in grid and grid[zone].get('danger_score', 0) >= self.CRITICAL_DANGER:
                return True
        return False

    def _edge_stop(self, vlm, intent):
        edge_type = vlm.get('edge_type', 'edge')
        warning = vlm.get('warning', 'Edge detected')
        alt = vlm.get('alternative', '')
        descs = {
            'table_edge': "TABLE EDGE nearby!",
            'stair': "STAIRS ahead!",
            'cliff': "CLIFF detected!",
            'curb': "CURB/STEP ahead!",
            'drop': "DROP-OFF ahead!"
        }
        desc = descs.get(edge_type, f"{edge_type.upper()} detected")
        resp = f"🚨 SAFETY STOP! {desc} {warning}"
        if alt:
            resp += f" Try: {alt}"
        return {'action': 'STOP', 'duration': 0, 'speed': None,
                'response': resp, 'override': True, 'reasoning': f'Edge: {edge_type}'}

    def _obstacle_stop(self, grid, intent):
        blocked = [z for z, d in grid.items()
                   if not z.startswith('_') and z.endswith('-M')
                   and d.get('danger_score', 0) >= self.CRITICAL_DANGER]

        alt = self._suggest_alt(grid)
        if alt and alt != 'STOP':
            resp = f"⚠️ Path blocked in {', '.join(blocked)}. Try {alt.lower()}?"
        else:
            resp = f"⚠️ Path blocked in {', '.join(blocked)}."
        return {'action': 'STOP', 'duration': 0, 'speed': None,
                'response': resp, 'override': True, 'reasoning': f'Obstacle in {blocked}'}

    def _vlm_stop(self, vlm, intent):
        warning = vlm.get('warning', 'Obstacle detected')
        alt = vlm.get('alternative', '')
        resp = f"Can't move {intent.lower()} — {warning}."
        if alt:
            resp += f" {alt}"
        return {'action': 'STOP', 'duration': 0, 'speed': None,
                'response': resp, 'override': True, 'reasoning': f'VLM: {warning}'}

    def _cautious(self, vlm, intent, duration):
        warning = vlm.get('warning', 'Obstacles nearby')
        return {
            'action': vlm.get('recommended_action', intent),
            'duration': min(duration, 1.5), 'speed': 'SPEED_LOW',
            'response': f"⚠️ Moving {intent.lower()} carefully — {warning}",
            'override': False, 'reasoning': f'Danger: {vlm.get("danger_level")}'
        }

    def _warn(self, vlm, intent, duration, speed):
        warning = vlm.get('warning', 'Objects detected')
        if speed == 'SPEED_HIGH':
            speed = 'SPEED_MED'
        return {
            'action': intent, 'duration': min(duration, 3.0), 'speed': speed,
            'response': f"Moving {intent.lower()} — {warning}",
            'override': False, 'reasoning': f'Moderate: {vlm.get("danger_level")}'
        }

    def _proceed(self, vlm, intent, duration, speed):
        vlm_dur = vlm.get('duration', duration)
        vlm_spd = vlm.get('speed', speed)
        final_dur = max(self.min_duration, min(vlm_dur, self.max_duration))
        ft = vlm.get('floor_type', 'surface')
        return {
            'action': intent, 'duration': final_dur, 'speed': vlm_spd,
            'response': f"✅ Moving {intent.lower()}! Surface: {ft}, path clear.",
            'override': False, 'reasoning': 'All clear'
        }

    def _trust_user(self, intent, duration, speed):
        return {
            'action': intent, 'duration': min(duration, self.max_duration),
            'speed': speed or 'SPEED_MED',
            'response': f"Moving {intent.lower()}! (Vision offline — check path manually)",
            'override': False, 'reasoning': 'No vision'
        }

    def _suggest_alt(self, grid):
        l = grid.get('L-M', {}).get('danger_score', 10)
        r = grid.get('R-M', {}).get('danger_score', 10)
        if l < 6 and r < 6:
            return 'LEFT' if l <= r else 'RIGHT'
        if l < 6: return 'LEFT'
        if r < 6: return 'RIGHT'
        return 'STOP'
