"""
VLM-based safety advisor (v4).

Refactor from v3: no longer hardcoded to Groq. Takes a VLMBackend and uses
whatever was selected at startup (vllm / llamacpp / groq).
"""
from __future__ import annotations

import json
import re
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FuturesTimeout
from typing import Any

import numpy as np

from robot.backends import VLMBackend
from robot.telemetry import get_tracker


class VLMSafetyAdvisor:
    def __init__(self, backend: VLMBackend, timeout_s: float = 3.0):
        self.backend = backend
        self.timeout_s = timeout_s
        self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="vlm")
        self._tracker = get_tracker()
        print(f"      🧠 VLM Advisor backend: {backend.name} (timeout {timeout_s}s)")

    def assess_safety(self, frame: np.ndarray, vision_data: dict, user_intent: str) -> dict:
        try:
            prompt = self._build_safety_prompt(vision_data, user_intent)
            with self._tracker.stage("vlm_inference"):
                fut = self._executor.submit(
                    self.backend.chat_with_image, prompt, frame,
                    600, 0.2, True)
                try:
                    raw = fut.result(timeout=self.timeout_s)
                except FuturesTimeout:
                    print(f"      ⏱️  VLM timeout after {self.timeout_s}s → depth-only fallback")
                    fut.cancel()
                    return self._default_assessment(user_intent, reason="timeout")
            assessment = self._parse_response(raw)

            # Floor-detector cliff override stays as a non-negotiable veto.
            floor = vision_data.get("grid_analysis", {}).get("_floor_analysis", {})
            if floor:
                critical = any(z in ("IMMEDIATE_EDGE", "CLIFF_DANGER")
                               for z in floor.get("danger_zones", []))
                if critical:
                    assessment = self._critical_override(assessment, floor)
            return assessment
        except Exception as e:
            print(f"      ⚠️ VLM error: {e}")
            return self._default_assessment(user_intent, reason=str(e))

    def _build_safety_prompt(self, vision_data: dict, user_intent: str) -> str:
        obstacles = vision_data.get("obstacles", [])
        grid = vision_data.get("grid_analysis", {})
        free_zones = vision_data.get("free_zones", [])
        floor = grid.get("_floor_analysis", {})

        obs_text = "\n".join(
            f"- {o['class']}: {o.get('distance', 0):.1f}m, conf {o['confidence']:.2f}"
            for o in obstacles[:5]
        ) or "None"

        grid_text = "\n".join(
            f"- {z}: {grid[z]['status']} (danger {grid[z]['danger_score']}/10)"
            for z in ("C-M", "C-F", "L-M", "R-M") if z in grid
        )

        floor_text = "No analysis"
        if floor:
            floor_text = (
                f"Edge: {floor.get('edge_detected', False)}, "
                f"Dropoff: {floor.get('dropoff_detected', False)}, "
                f"Continuity: {floor.get('floor_continuity', 0):.2f}, "
                f"Dangers: {floor.get('danger_zones', [])}"
            )

        return f"""You are the safety system for a SMALL MOBILE ROBOT (190x130x120mm, 1.2kg).
The robot operates on floors, desks, tables — any flat surface.

USER WANTS TO: {user_intent}

DETECTED OBJECTS:
{obs_text}

NAVIGATION ZONES (mid/far — where the robot would move TO):
{grid_text}

FLOOR ANALYSIS: {floor_text}

Free zones: {', '.join(free_zones) if free_zones else 'None'}

RULES:
1. Robot can drive on ANY flat continuous surface.
2. Object < 0.3m blocking path → STOP; living thing in path → STOP.
3. Table edge / drop CLOSE → STOP; far → OK.
4. "dining table" in bottom of frame = the surface the robot is ON, NOT an obstacle.

Return ONLY valid JSON:
{{"safe_to_move": true/false, "floor_verified": true/false,
  "floor_type": "ground_floor"/"table"/"desk"/"platform"/"unknown",
  "edge_danger": true/false, "edge_type": "none"/"table_edge"/"stair"/"cliff"/"drop",
  "edge_proximity": "far"/"medium"/"close"/"none",
  "recommended_action": "FORWARD"/"LEFT"/"RIGHT"/"STOP",
  "danger_level": 0-10, "obstacles": [], "warning": "", "alternative": "",
  "speed": "SPEED_LOW"/"SPEED_MED"/"SPEED_HIGH", "duration": 0.5-5.0,
  "reasoning": "brief"}}"""

    def _parse_response(self, raw: str) -> dict:
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            m = re.search(r"\{.*\}", raw, re.DOTALL)
            if not m:
                return self._default_assessment("STOP")
            try:
                data = json.loads(m.group(0))
            except json.JSONDecodeError:
                return self._default_assessment("STOP")

        a = {
            "safe_to_move": bool(data.get("safe_to_move", False)),
            "floor_verified": bool(data.get("floor_verified", True)),
            "floor_type": data.get("floor_type", "unknown"),
            "edge_danger": bool(data.get("edge_danger", False)),
            "edge_type": data.get("edge_type", "none"),
            "edge_proximity": data.get("edge_proximity", "none"),
            "recommended_action": data.get("recommended_action", "FORWARD"),
            "danger_level": max(0, min(10, int(data.get("danger_level", 2)))),
            "obstacles": data.get("obstacles", []),
            "warning": data.get("warning", ""),
            "alternative": data.get("alternative", ""),
            "speed": data.get("speed", "SPEED_MED"),
            "duration": float(data.get("duration", 2.0)),
            "reasoning": data.get("reasoning", ""),
        }
        if a["edge_danger"]:
            prox = a["edge_proximity"]
            if prox == "close":
                a["danger_level"] = max(a["danger_level"], 9)
                a["safe_to_move"] = False
            elif prox == "medium":
                a["danger_level"] = max(a["danger_level"], 5)
                a["speed"] = "SPEED_LOW"
        return a

    def _critical_override(self, assessment: dict, floor: dict) -> dict:
        assessment.update(
            safe_to_move=False, recommended_action="STOP", danger_level=10,
            edge_danger=True,
            warning=f"🚨 OVERRIDE: {floor.get('warning_message', 'Edge detected!')}"
        )
        return assessment

    def _default_assessment(self, user_intent: str, reason: str = "VLM unavailable") -> dict:
        return {
            "safe_to_move": True, "floor_verified": True, "floor_type": "unknown",
            "edge_danger": False, "edge_type": "none", "edge_proximity": "none",
            "recommended_action": user_intent if user_intent != "STOP" else "FORWARD",
            "danger_level": 2, "obstacles": [], "warning": f"VLM offline ({reason})",
            "alternative": "", "speed": "SPEED_LOW", "duration": 1.5,
            "reasoning": f"VLM unavailable: {reason} — proceeding cautiously at low speed",
        }
