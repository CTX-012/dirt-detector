"""
Shared safety state and watchdog.

The vision thread updates a SafetyState object continuously. The main thread
reads it when a user command arrives, getting an answer in microseconds
instead of waiting for a fresh VLM call.

The watchdog tracks whether vision data is fresh. If the vision thread
hangs or crashes, is_fresh() returns False and the fusion engine treats
all directions as unsafe (default-deny).
"""
from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SafetyState:
    last_update: float = 0.0
    # Per-direction danger scores from the depth grid (0-10, 10 = blocked)
    forward_danger: int = 10
    left_danger: int = 10
    right_danger: int = 10
    backward_danger: int = 0   # No rear camera → cannot block
    # Critical floor flags
    edge_critical: bool = False
    cliff_critical: bool = False
    # Free-form list of close-range obstacles (for prompts)
    close_obstacles: list = field(default_factory=list)


class SafetyMonitor:
    """Thread-safe view of the latest perception → safety summary."""
    def __init__(self, stale_after_s: float = 1.0):
        self._lock = threading.Lock()
        self._state = SafetyState()
        self.stale_after_s = stale_after_s

    def update_from_grid(self, grid: dict) -> None:
        """Called from the vision thread after each freespace analysis."""
        now = time.time()
        floor = grid.get("_floor_analysis", {}) or {}
        zones = floor.get("danger_zones", [])

        def danger(zone: str) -> int:
            return grid.get(zone, {}).get("danger_score", 10)

        close_obs: list[str] = []
        for zn in ("C-M", "L-M", "R-M", "C-F"):
            z = grid.get(zn, {})
            for c in z.get("obstacles_in_zone", []):
                if c not in close_obs:
                    close_obs.append(c)

        with self._lock:
            self._state = SafetyState(
                last_update=now,
                forward_danger=danger("C-M"),
                left_danger=danger("L-M"),
                right_danger=danger("R-M"),
                backward_danger=0,
                edge_critical="IMMEDIATE_EDGE" in zones,
                cliff_critical="CLIFF_DANGER" in zones,
                close_obstacles=close_obs[:5],
            )

    def get(self) -> SafetyState:
        with self._lock:
            return SafetyState(**self._state.__dict__)  # snapshot copy

    def is_fresh(self) -> bool:
        """Vision data is recent enough to trust."""
        with self._lock:
            return (time.time() - self._state.last_update) < self.stale_after_s

    def quick_check(self, direction: str) -> tuple[bool, str]:
        """
        Cheap go/no-go before the expensive VLM call.
        Returns (allowed, reason).
        """
        if not self.is_fresh():
            return False, "vision stale (watchdog)"
        s = self.get()
        if s.cliff_critical:
            return False, "cliff detected"
        if s.edge_critical:
            return False, "edge detected"

        mapping = {
            "FORWARD": s.forward_danger,
            "LEFT": s.left_danger,
            "RIGHT": s.right_danger,
            "BACKWARD": s.backward_danger,
            "STOP": 0,
        }
        d = mapping.get(direction, 10)
        if d >= 9:
            return False, f"{direction} blocked by obstacle (danger {d}/10)"
        return True, "clear"
