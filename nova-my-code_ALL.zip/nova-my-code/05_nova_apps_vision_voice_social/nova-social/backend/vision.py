"""Scene captioning via Moondream on Ollama's native /api/generate endpoint.

We use the native endpoint (not the OpenAI-compat one) because it has the most
reliable base64-image path for moondream and lets us pass keep_alive directly.
"""
import base64
import os

import requests

OLLAMA_NATIVE = os.environ.get("OLLAMA_NATIVE_URL", "http://localhost:11434")
VISION_MODEL = os.environ.get("NOVA_VISION_MODEL", "moondream")

_CAPTION_PROMPT = "Describe this scene in one concise sentence. Focus on people, setting, and mood."


def _clean_b64(image_b64: str) -> str:
    """Accept either a raw base64 string or a full data: URL."""
    if image_b64.startswith("data:"):
        image_b64 = image_b64.split(",", 1)[-1]
    return image_b64.strip()


def caption_image(image_b64: str, timeout: int = 60) -> str:
    """Return a one-line caption for a base64-encoded image. Raises on failure."""
    payload = {
        "model": VISION_MODEL,
        "prompt": _CAPTION_PROMPT,
        "images": [_clean_b64(image_b64)],
        "stream": False,
        "keep_alive": -1,
        "options": {"temperature": 0.2},
    }
    r = requests.post(f"{OLLAMA_NATIVE}/api/generate", json=payload, timeout=timeout)
    r.raise_for_status()
    return r.json().get("response", "").strip()


def warm(model: str) -> None:
    """Load a model into VRAM without generating (used at startup)."""
    requests.post(
        f"{OLLAMA_NATIVE}/api/generate",
        json={"model": model, "keep_alive": -1},
        timeout=120,
    ).raise_for_status()


def _validate_b64(image_b64: str) -> bool:
    try:
        base64.b64decode(_clean_b64(image_b64), validate=True)
        return True
    except Exception:
        return False
