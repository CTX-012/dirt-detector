"""Host directory: {host_name, telegram_chat_id, role?} persisted to JSON.

Resolver maps an S1 intent.target (a host name spoken by a visitor) to a host
entry via fuzzy match. No confident match -> (None, score), which the FSM turns
into a "host not found, ask visitor to clarify" path.
"""
from __future__ import annotations

import json
import os
import threading
from difflib import SequenceMatcher

HOSTS_PATH = os.environ.get(
    "NOVA_HOSTS_PATH", os.path.join(os.path.dirname(__file__), "hosts.json")
)
MATCH_THRESHOLD = float(os.environ.get("NOVA_HOST_MATCH_THRESHOLD", "0.6"))

_lock = threading.Lock()


def _load() -> list[dict]:
    if not os.path.exists(HOSTS_PATH):
        return []
    try:
        with open(HOSTS_PATH) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return []


def _save(hosts: list[dict]) -> None:
    tmp = HOSTS_PATH + ".tmp"
    with open(tmp, "w") as f:
        json.dump(hosts, f, indent=2)
    os.replace(tmp, HOSTS_PATH)


def list_hosts() -> list[dict]:
    with _lock:
        return _load()


def add_host(host_name: str, telegram_chat_id: int, role: str | None = None) -> dict:
    """Upsert by case-insensitive host_name."""
    with _lock:
        hosts = _load()
        for h in hosts:
            if h["host_name"].lower() == host_name.lower():
                h["telegram_chat_id"] = int(telegram_chat_id)
                h["role"] = role
                _save(hosts)
                return h
        entry = {"host_name": host_name, "telegram_chat_id": int(telegram_chat_id), "role": role}
        hosts.append(entry)
        _save(hosts)
        return entry


def seed_if_empty(host_name: str, telegram_chat_id: int, role: str | None = None) -> dict | None:
    """Seed a single test host only if the directory is currently empty."""
    with _lock:
        if _load():
            return None
    return add_host(host_name, telegram_chat_id, role)


def _norm(s: str) -> str:
    return "".join(c for c in s.lower() if c.isalnum() or c.isspace()).strip()


def resolve(target: str | None) -> tuple[dict | None, float]:
    """Best fuzzy match for a spoken host name. Returns (host|None, score)."""
    if not target:
        return None, 0.0
    hosts = list_hosts()
    if not hosts:
        return None, 0.0
    t = _norm(target)
    t_tokens = set(t.split())
    best, best_score = None, 0.0
    for h in hosts:
        name = _norm(h["host_name"])
        score = SequenceMatcher(None, t, name).ratio()
        # Boost on substring or any shared name token (handles "Faiz" -> "Faiz Khan").
        if t and (t in name or name in t or (t_tokens & set(name.split()))):
            score = max(score, 0.85)
        if score > best_score:
            best, best_score = h, score
    if best_score >= MATCH_THRESHOLD:
        return best, best_score
    return None, best_score
