"""Telegram bridge: send notifications + long-poll getUpdates (no webhook).

- Token from TELEGRAM_BOT_TOKEN (human-provided, from @BotFather).
- send_message(): deliver a host notification.
- A background long-poll loop records every chat that messages the bot, so a
  host's numeric chat_id can be captured by GET /telegram/contacts during
  onboarding ("each host messages the bot once").
- S2 confirms delivery only. Relaying the host's reply (/accept etc.) is S3 —
  we record the updates here so S3 can build on the same offset cursor.
"""
from __future__ import annotations

import logging
import os
import threading
import time

import requests

log = logging.getLogger("nova-social.telegram")

TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN")
API = f"https://api.telegram.org/bot{TOKEN}" if TOKEN else None

_contacts: dict[int, dict] = {}     # chat_id -> {chat_id, name, username, last_text, ts}
_contacts_lock = threading.Lock()
_thread: threading.Thread | None = None
_running = False
_offset = 0
_handler = None                     # optional callback(msg: dict) for inbound messages


def set_message_handler(fn) -> None:
    """Register a callback invoked for every inbound message (S3 reply routing)."""
    global _handler
    _handler = fn


def configured() -> bool:
    return bool(TOKEN)


def send_message(chat_id: int | str, text: str) -> tuple[bool, object]:
    """Send a message. Returns (ok, info-or-error). Never raises."""
    if not API:
        return False, "TELEGRAM_BOT_TOKEN not set"
    try:
        r = requests.post(f"{API}/sendMessage", json={"chat_id": chat_id, "text": text}, timeout=15)
        body = r.json()
        if r.ok and body.get("ok"):
            return True, body.get("result", {})
        return False, body
    except Exception as e:  # noqa: BLE001
        return False, str(e)


def recent_contacts() -> list[dict]:
    with _contacts_lock:
        return sorted(_contacts.values(), key=lambda c: c["ts"], reverse=True)


def _record(msg: dict) -> None:
    chat = msg.get("chat") or {}
    cid = chat.get("id")
    if cid is None:
        return
    name = (
        " ".join(filter(None, [chat.get("first_name"), chat.get("last_name")]))
        or chat.get("title")
        or chat.get("username")
        or str(cid)
    )
    with _contacts_lock:
        _contacts[cid] = {
            "chat_id": cid,
            "name": name,
            "username": chat.get("username"),
            "last_text": msg.get("text"),
            "ts": msg.get("date", 0),
        }
    log.info("telegram contact seen: %s (chat_id=%s)", name, cid)


def _loop() -> None:
    global _offset
    log.info("telegram long-poll started")
    while _running:
        try:
            r = requests.get(
                f"{API}/getUpdates",
                params={"timeout": 25, "offset": _offset},
                timeout=35,
            )
            data = r.json()
            if not data.get("ok"):
                log.warning("getUpdates not ok: %s", data)
                time.sleep(3)
                continue
            for upd in data.get("result", []):
                _offset = upd["update_id"] + 1
                msg = upd.get("message") or upd.get("edited_message")
                if msg:
                    _record(msg)
                    if _handler:
                        try:
                            _handler(msg)
                        except Exception as e:  # noqa: BLE001
                            log.warning("message handler error: %s", e)
        except requests.exceptions.Timeout:
            continue  # normal for long-poll
        except Exception as e:  # noqa: BLE001
            log.warning("getUpdates error: %s", e)
            time.sleep(3)
    log.info("telegram long-poll stopped")


def start_polling() -> bool:
    global _thread, _running
    if not API:
        log.warning("telegram polling NOT started: TELEGRAM_BOT_TOKEN unset")
        return False
    if _running:
        return True
    _running = True
    _thread = threading.Thread(target=_loop, daemon=True)
    _thread.start()
    return True


def stop_polling() -> None:
    global _running
    _running = False
