"""nova-social S1 backend — local chat with scene grounding, intent detection,
outreach drafting, and an approval gate. No external send (that's S2).

Run:
    unset PYTHONPATH; source .venv/bin/activate
    uvicorn main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import logging
import os
import time

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel

import base64
import tempfile

import camera as cam
import db
import fsm
import hosts as hostdir
import llm
import prompts
import replies
import stt
import telegram
import tts
import vision

from fastapi import File, Form, UploadFile

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("nova-social")

app = FastAPI(title="nova-social", version="S1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # local dev only
    allow_methods=["*"],
    allow_headers=["*"],
)

store = db.SessionStore()

# Keep history sent to the model bounded (turns, not messages).
MAX_HISTORY_MSGS = 20


class ChatRequest(BaseModel):
    session_id: str
    message: str
    image: str | None = None      # base64 (raw or data: URL), optional
    use_camera: bool = False      # grab the latest ctx webcam frame for grounding


class ChatResponse(BaseModel):
    reply: str
    state: str
    intent: dict
    draft: str | None = None
    scene: str | None = None
    timings_ms: dict


class ApproveRequest(BaseModel):
    session_id: str
    edited_draft: str | None = None  # if the user edited before approving


class HostIn(BaseModel):
    host_name: str
    telegram_chat_id: int
    role: str | None = None


def _compose_notification(visitor: str | None, purpose: str | None, scene: str | None) -> str:
    """Factual host notification (S4.2): visitor name + stated purpose + live scene.
    No creative writing — only what the visitor actually said."""
    who = visitor or "A visitor"
    why = f" — says: \"{purpose}\"" if purpose else ""
    where = f" [scene: {scene.rstrip('. ')}]" if scene else ""
    return f"\U0001F514 {who} is at reception to see you{why}.{where} Reply /accept /decline /wait"


@app.on_event("startup")
def _warm_models() -> None:
    """Best-effort warm both models into VRAM so the first request is fast and
    `ollama ps` shows both resident. Non-fatal if a model isn't pulled yet."""
    for m in (llm.CHAT_MODEL, vision.VISION_MODEL):
        try:
            vision.warm(m)
            log.info("warmed model %s", m)
        except Exception as e:  # noqa: BLE001
            log.warning("could not warm %s: %s", m, e)

    # S2/S3: route inbound host replies, then start the long-poll loop (no-op if
    # token unset).
    telegram.set_message_handler(handle_host_reply)
    telegram.start_polling()

    # S4: warm the CPU voice models so the first kiosk turn isn't slow. Both run
    # on CPU (0 GPU). Non-fatal if a backend isn't fully configured (e.g. piper
    # without a model path).
    for label, fn in (("STT", stt.warm), ("TTS", tts.warm)):
        try:
            fn()
            log.info("warmed %s (%s)", label, tts.BACKEND_NAME if label == "TTS" else stt.MODEL)
        except Exception as e:  # noqa: BLE001
            log.warning("could not warm %s: %s", label, e)

    # Optionally seed a single test host from env (e.g. Faiz) if directory empty.
    seed_name = os.environ.get("NOVA_SEED_HOST_NAME")
    seed_chat = os.environ.get("NOVA_SEED_HOST_CHAT_ID")
    if seed_name and seed_chat:
        seeded = hostdir.seed_if_empty(seed_name, int(seed_chat), os.environ.get("NOVA_SEED_HOST_ROLE"))
        if seeded:
            log.info("seeded test host: %s", seeded)


@app.on_event("shutdown")
def _release() -> None:
    cam.camera.stop()
    telegram.stop_polling()


@app.get("/health")
def health() -> dict:
    return {"ok": True, "chat_model": llm.CHAT_MODEL, "vision_model": vision.VISION_MODEL}


@app.get("/camera/status")
def camera_status() -> dict:
    started = False if cam.camera.disabled else cam.camera.start()
    return {"started": started, "available": cam.camera.available, "disabled": cam.camera.disabled,
            "device": str(cam.camera.device), "error": cam.camera.error}


@app.post("/camera/stop")
def camera_stop() -> dict:
    """Release the ctx webcam and keep it off (won't auto-restart on stream
    requests) until /camera/start. Use to free /dev/video* or turn the cam LED off."""
    cam.camera.stop(disable=True)
    return {"ok": True, "disabled": True, "available": False}


@app.post("/camera/start")
def camera_start() -> dict:
    """Re-enable the ctx webcam after /camera/stop."""
    cam.camera.enable()
    started = cam.camera.start()
    return {"ok": started, "disabled": cam.camera.disabled, "error": cam.camera.error}


@app.get("/camera/stream")
def camera_stream() -> StreamingResponse:
    """Live MJPEG stream of the ctx webcam (use as <img src=...>)."""
    if not cam.camera.start():
        raise HTTPException(status_code=503, detail=f"camera unavailable: {cam.camera.error}")
    return StreamingResponse(
        cam.camera.mjpeg_frames(),
        media_type="multipart/x-mixed-replace; boundary=frame",
        headers={"Cache-Control": "no-cache, no-store", "Pragma": "no-cache"},
    )


@app.get("/camera/frame")
def camera_frame() -> Response:
    """Single latest JPEG snapshot from the ctx webcam."""
    if not cam.camera.start():
        raise HTTPException(status_code=503, detail=f"camera unavailable: {cam.camera.error}")
    j = cam.camera.latest_jpeg()
    if j is None:
        raise HTTPException(status_code=503, detail="no frame captured yet")
    return Response(content=j, media_type="image/jpeg", headers={"Cache-Control": "no-store"})


def _build_messages(session: fsm.Session, user_message: str, scene: str | None) -> list[dict]:
    msgs: list[dict] = [{"role": "system", "content": prompts.RECEPTIONIST_SYSTEM}]
    if scene:
        msgs.append({"role": "system", "content": f"[scene: {scene}]"})
    # Loop guard: tell the receptionist which slots are already filled so it never
    # re-asks for one. (The model only asks for the missing ones.)
    known = {k: session.slots.get(k) for k in fsm.REQUIRED_SLOTS if session.slots.get(k)}
    if known:
        line = " | ".join(f"{k}={v}" for k, v in known.items())
        msgs.append({"role": "system", "content": f"[known so far] {line} — do not ask for these again."})
    msgs.extend(session.history[-MAX_HISTORY_MSGS:])
    msgs.append({"role": "user", "content": user_message})
    return msgs


def _notify_host(session: fsm.Session, scene: str | None) -> dict:
    """Resolve the host and deliver the factual reception notification, then move
    the session into the AWAIT_HOST_REPLY hold. Returns a small result dict.
    Shared by the auto-notify path. No draft, no approval."""
    target = session.slots.get("target")
    session.state = fsm.RESOLVE_HOST
    host, score = hostdir.resolve(target)
    if host is None:
        session.state = fsm.HOST_NOT_FOUND
        known = ", ".join(h["host_name"] for h in hostdir.list_hosts()) or "no one registered"
        log.info("host not found for target=%r (best %.2f)", target, score)
        return {"ok": False, "host_found": False,
                "reply": f"I'm sorry, I don't have a {target} here. Who did you say you're here to see? (We have: {known}.)"}

    notification = _compose_notification(session.slots.get("visitor_name"),
                                         session.slots.get("purpose"), scene)
    ok, info = telegram.send_message(host["telegram_chat_id"], notification)
    if not ok:
        session.state = fsm.AWAIT_APPROVAL  # collected but couldn't reach host; allow retry
        log.warning("telegram send failed: %s", info)
        return {"ok": False, "host_found": True,
                "reply": f"I'm having trouble reaching {host['host_name']} right now. One moment."}

    session.host_name = host["host_name"]
    session.host_chat_id = host["telegram_chat_id"]
    session.verdict = None
    session.host_message = None
    session.relay_copy = None
    session.state = fsm.AWAIT_HOST_REPLY
    log.info("notified host %s (chat_id=%s); awaiting reply", host["host_name"], host["telegram_chat_id"])
    return {"ok": True, "host_found": True, "host": host["host_name"], "notification": notification}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    t0 = time.perf_counter()
    session = store.get_or_create(req.session_id)
    timings: dict = {}

    # --- Scene grounding: VLM fires on a NEW frame only ---------------------
    # Image source: explicit upload wins; otherwise grab the live ctx webcam frame.
    scene = session.last_scene
    image_b64 = req.image
    if not image_b64 and req.use_camera:
        cam.camera.start()
        image_b64 = cam.camera.latest_b64()
        if image_b64 is None:
            raise HTTPException(status_code=503, detail=f"ctx camera not ready: {cam.camera.error or 'no frame yet'}")
    if image_b64:
        if not vision._validate_b64(image_b64):
            raise HTTPException(status_code=400, detail="image is not valid base64")
        t_v = time.perf_counter()
        try:
            scene = vision.caption_image(image_b64)
            session.last_scene = scene
            timings["caption_ms"] = round((time.perf_counter() - t_v) * 1000)
            log.info("scene caption: %s", scene)
        except Exception as e:  # noqa: BLE001
            log.warning("caption failed: %s", e)
            # Degrade gracefully: keep prior scene (if any), continue chat.

    # --- Coach turn: the LLM's job is SLOT EXTRACTION only ------------------
    messages = _build_messages(session, req.message, scene)
    t_c = time.perf_counter()
    intent = llm.coach_turn(messages)
    timings["coach_ms"] = round((time.perf_counter() - t_c) * 1000)
    session.merge_slots(intent)

    # --- Backend-scripted linear flow (deterministic; the LLM doesn't pick the
    #     next question, so there are no invented hosts, no skipped/repeated
    #     questions, and no premature notify). One question per turn, in order. ---
    name = session.slots.get("visitor_name")
    reply = intent["reply"]  # fallback only

    if not session.already_notified():
        missing = session.missing_slots()  # ordered: visitor_name, target, purpose
        if not missing:
            # Have name + who + purpose -> check with the host now (no draft/approval).
            result = _notify_host(session, scene)
            if result["ok"]:
                reply = f"One moment, {name} — let me check with {result['host']}. Please take a seat."
            elif result.get("host_found") is False:
                session.slots["target"] = None  # re-ask who they're here to see
                reply = result["reply"]
            else:
                reply = result["reply"]
        else:
            session.state = fsm.CHATTING
            if missing[0] == "visitor_name":
                reply = "Hello, welcome to reception. May I have your name, please?"
            elif missing[0] == "target":
                reply = f"Thank you, {name}. Who are you here to see?"
            else:  # purpose
                reply = "And may I ask what it's regarding?"

    # Persist the turn (store the line the receptionist ACTUALLY said).
    session.history.append({"role": "user", "content": req.message})
    session.history.append({"role": "assistant", "content": reply})

    store.save(session)
    timings["total_ms"] = round((time.perf_counter() - t0) * 1000)
    return ChatResponse(
        reply=reply,
        state=session.state,
        intent={
            "target": session.slots.get("target"),
            "purpose": session.slots.get("purpose"),
            "visitor_name": session.slots.get("visitor_name"),
            "ready_to_notify": intent["ready_to_notify"],
        },
        draft=None,
        scene=scene,
        timings_ms=timings,
    )


@app.get("/session/{session_id}")
def get_session(session_id: str) -> dict:
    s = store.get(session_id)
    if s is None:
        raise HTTPException(status_code=404, detail="unknown session")
    return {
        "session_id": s.session_id,
        "state": s.state,
        "slots": s.slots,
        "scene": s.last_scene,
        "draft": s.draft,
        "history": s.history,
        # S3/S4.2: host correlation + relayed verdict + raw host reply
        "host_name": s.host_name,
        "verdict": s.verdict,
        "when": s.when_string,
        "host_message": s.host_message,
        "relay_copy": s.relay_copy,
    }


@app.post("/approve")
def approve(req: ApproveRequest) -> dict:
    """Manual notify trigger (optional human-in-loop). The S4.2 receptionist
    auto-notifies once name+who+purpose are collected, so this is normally not
    needed; it re-runs the notify for a session that hasn't reached the host yet."""
    s = store.get(req.session_id)
    if s is None:
        raise HTTPException(status_code=404, detail="unknown session")
    if s.already_notified() and s.state != fsm.HOST_NOT_FOUND:
        raise HTTPException(status_code=409, detail=f"host already being contacted (state={s.state})")
    result = _notify_host(s, s.last_scene)
    store.save(s)
    if not result["ok"] and not result.get("host_found", True):
        return {"ok": False, "host_found": False, "state": s.state, "reply": result["reply"]}
    if not result["ok"]:
        raise HTTPException(status_code=502, detail="could not reach host")
    return {"ok": True, "host_found": True, "state": s.state,
            "host": result["host"], "notification": result["notification"]}


@app.get("/hosts")
def list_hosts() -> dict:
    return {"hosts": hostdir.list_hosts()}


@app.post("/hosts")
def add_host(req: HostIn) -> dict:
    entry = hostdir.add_host(req.host_name, req.telegram_chat_id, req.role)
    return {"ok": True, "host": entry}


@app.get("/telegram/contacts")
def telegram_contacts() -> dict:
    """Onboarding helper: chats that have messaged the bot, newest first. Use this
    to capture a host's numeric chat_id, then POST it to /hosts."""
    return {"configured": telegram.configured(), "contacts": telegram.recent_contacts()}


# --- S4: voice transport (CPU STT/TTS over the existing /chat FSM) -----------

def _save_upload(upload: UploadFile) -> str:
    suffix = os.path.splitext(upload.filename or "")[1] or ".webm"
    fd, path = tempfile.mkstemp(suffix=suffix)
    with os.fdopen(fd, "wb") as f:
        f.write(upload.file.read())
    return path


@app.post("/voice/stt")
async def voice_stt(audio: UploadFile = File(...), lang: str | None = Form(None)) -> dict:
    """Transcribe an uploaded audio blob. Returns {text, lang, ms}."""
    path = _save_upload(audio)
    try:
        return stt.transcribe(path, language=lang)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


class TTSRequest(BaseModel):
    text: str
    voice: str | None = None
    lang: str | None = None


@app.post("/voice/tts")
def voice_tts(req: TTSRequest) -> Response:
    """Synthesize text -> WAV audio stream."""
    out = tts.synth(req.text, lang=req.lang, voice=req.voice)
    return Response(
        content=out["wav"],
        media_type="audio/wav",
        headers={"X-TTS-Backend": out["backend"], "X-TTS-Ms": str(out["ms"]),
                 "Cache-Control": "no-store"},
    )


@app.post("/voice/turn")
async def voice_turn(
    audio: UploadFile = File(...),
    session_id: str = Form(...),
    use_camera: bool = Form(False),
    image: str | None = Form(None),   # S4.1: laptop-cam still (base64); pure passthrough
    lang: str | None = Form(None),
) -> dict:
    """One kiosk turn: STT -> existing /chat FSM -> TTS. Returns transcript, the
    bot's reply + FSM state, and the spoken reply as base64 WAV (browser autoplays).
    Voice is purely transport here — the FSM/intent/relay logic is unchanged."""
    path = _save_upload(audio)
    timings: dict = {}
    try:
        s = stt.transcribe(path, language=lang)
    finally:
        try:
            os.remove(path)
        except OSError:
            pass
    timings["stt_ms"] = s["ms"]
    transcript = s["text"]

    if not transcript.strip():
        return {"transcript": "", "reply": "Sorry, I didn't catch that.", "state": None,
                "intent": None, "lang": s["lang"], "audio_b64": None, "timings_ms": timings,
                "empty": True}

    # Reuse the EXISTING chat path verbatim (image/use_camera are frame-source
    # routing only — FSM/intent/captioning logic unchanged).
    chat_resp = chat(ChatRequest(session_id=session_id, message=transcript,
                                 use_camera=use_camera, image=image))
    timings.update({f"chat_{k}": v for k, v in chat_resp.timings_ms.items()})

    spoken = tts.synth(chat_resp.reply, lang=lang)
    timings["tts_ms"] = spoken["ms"]
    timings["total_ms"] = sum(v for k, v in timings.items() if k in ("stt_ms", "tts_ms")) + \
        chat_resp.timings_ms.get("total_ms", 0)

    return {
        "transcript": transcript,
        "lang": s["lang"],
        "reply": chat_resp.reply,
        "state": chat_resp.state,
        "intent": chat_resp.intent,
        "draft": chat_resp.draft,
        "scene": chat_resp.scene,
        "tts_backend": spoken["backend"],
        "audio_b64": base64.b64encode(spoken["wav"]).decode(),
        "timings_ms": timings,
    }


@app.get("/voice/config")
def voice_config() -> dict:
    import tts_backends
    return {
        "stt_model": stt.MODEL, "stt_compute": stt.COMPUTE,
        "tts_backend": tts.BACKEND_NAME,
        "tts_backends_available": list(tts_backends._REGISTRY),
    }


def handle_host_reply(msg: dict) -> None:
    """S3 reply router (called by the long-poll loop for every inbound message).

    Matches a reply from a known host chat_id to the most-recent session waiting on
    that host, parses the verdict, and stages the visitor-facing relay copy on the
    session (kiosk picks it up by polling /session). Unrecognized replies re-prompt
    the host. Replies with no pending session are ignored (logged)."""
    t_recv = time.perf_counter()
    chat = msg.get("chat") or {}
    chat_id = chat.get("id")
    text = msg.get("text") or ""
    if chat_id is None:
        return

    session, ambiguous = store.find_pending_by_host(chat_id)
    if session is None:
        log.info("host reply from chat_id=%s with no pending session: %r", chat_id, text)
        return

    parsed = replies.parse_reply(text)
    verdict = parsed["verdict"]

    if verdict == replies.UNKNOWN:
        telegram.send_message(
            chat_id,
            "Sorry, I didn't catch that. Please reply /accept, /decline, or /wait.",
        )
        log.info("unrecognized host reply %r for session %s; re-prompted", text, session.session_id)
        return  # stay in AWAIT_HOST_REPLY

    # RELAY_TO_VISITOR -> DONE. Store the host's RAW words for audit (host_message),
    # but relay a paraphrase in the receptionist's own voice (S4.3 CHANGE B) that
    # preserves every concrete detail. Fall back to deterministic copy if the LLM
    # is unavailable.
    session.state = fsm.RELAY_TO_VISITOR
    session.verdict = verdict
    session.when_string = parsed.get("when")
    session.host_message = text.strip()
    paraphrase = llm.relay_in_receptionist_voice(session.host_name, verdict, text.strip(),
                                                 when=parsed.get("when"))
    session.relay_copy = paraphrase or replies.visitor_copy(
        session.host_name, verdict, parsed.get("when"), host_message=text.strip()
    )
    session.state = fsm.DONE
    store.save(session)

    relay_ms = round((time.perf_counter() - t_recv) * 1000)
    log.info(
        "relayed %s to session %s in %dms%s -> %r",
        verdict, session.session_id, relay_ms,
        " [AMBIGUOUS: multiple sessions waiting on this host]" if ambiguous else "",
        session.relay_copy,
    )
