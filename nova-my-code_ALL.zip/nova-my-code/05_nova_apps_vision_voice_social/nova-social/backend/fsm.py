"""Server-side FSM definitions + the Session record.

States: IDLE -> CHATTING -> INTENT_DETECTED -> CLARIFY -> DRAFT -> AWAIT_APPROVAL
        -> RESOLVE_HOST -> NOTIFY_SENT -> AWAIT_HOST_REPLY -> RELAY_TO_VISITOR -> DONE

The model proposes intent + slots each turn; this module owns the canonical state
transitions and the accumulated slots, so a flaky model turn can't corrupt the FSM.
The session store itself is SQLite-backed in db.py (promoted from in-memory at S3).
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

IDLE = "IDLE"
CHATTING = "CHATTING"
INTENT_DETECTED = "INTENT_DETECTED"
CLARIFY = "CLARIFY"
DRAFT = "DRAFT"
AWAIT_APPROVAL = "AWAIT_APPROVAL"
# S2: host-notification bridge (entered from the approve path)
RESOLVE_HOST = "RESOLVE_HOST"
NOTIFY_SENT = "NOTIFY_SENT"
HOST_NOT_FOUND = "HOST_NOT_FOUND"
# S3: reply relay loop
AWAIT_HOST_REPLY = "AWAIT_HOST_REPLY"
RELAY_TO_VISITOR = "RELAY_TO_VISITOR"
DONE = "DONE"

# S4.2 receptionist: the three slots collected before checking with the host.
REQUIRED_SLOTS = ("visitor_name", "target", "purpose")

# States after the host has been notified — collection is done, don't re-notify.
# (HOST_NOT_FOUND is intentionally excluded so the receptionist re-asks who and retries.)
_POST_NOTIFY = ("RESOLVE_HOST", "NOTIFY_SENT", "AWAIT_HOST_REPLY",
                "RELAY_TO_VISITOR", "DONE")


@dataclass
class Session:
    session_id: str
    state: str = IDLE
    history: list[dict] = field(default_factory=list)  # [{role, content}]
    slots: dict = field(default_factory=lambda: {
        "visitor_name": None,   # who is at reception
        "target": None,         # who they're here to see
        "purpose": None,        # why, in the visitor's own words
    })
    last_scene: str | None = None       # cached caption; VLM fires on new frame only
    draft: str | None = None            # unused in S4.2 receptionist path
    # S3: host-notification correlation + relayed verdict
    host_name: str | None = None
    host_chat_id: int | None = None
    verdict: str | None = None          # ACCEPTED | DECLINED | WAIT
    when_string: str | None = None      # optional "come at 3pm" parsed from ACCEPT
    host_message: str | None = None     # S4.2: host's raw free-text reply (verbatim)
    relay_copy: str | None = None       # visitor-facing copy pushed back to the kiosk
    created_at: float = field(default_factory=time.time)

    def merge_slots(self, intent: dict) -> None:
        """Fold newly-extracted, non-null slots in (never clobber a known value
        with null) — this is the loop guard: a filled slot is never asked again."""
        for k in REQUIRED_SLOTS:
            v = intent.get(k)
            if v:
                self.slots[k] = v

    def missing_slots(self) -> list[str]:
        return [k for k in REQUIRED_SLOTS if not self.slots.get(k)]

    def reception_ready(self) -> bool:
        return not self.missing_slots()

    def already_notified(self) -> bool:
        return self.state in _POST_NOTIFY
