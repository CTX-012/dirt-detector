"""Host reply parser: maps a Telegram reply (slash command OR natural language)
to a verdict, with an optional when-string for acceptances.

Verdicts: ACCEPTED | RESCHEDULE | DECLINED | WAIT | UNKNOWN
- RESCHEDULE (S4.3): a refusal-of-now PLUS a future time/day ("not today,
  tomorrow", "later this week", "after 3pm", "no, Monday"). A plain "no/busy"
  with no future reference stays DECLINE.
- UNKNOWN means "ask the host to clarify" (re-prompt with the 3 options).

Design notes / ambiguity (flagged in README):
- Short tokens (yes/no/ok/sure) match on word boundaries to avoid firing inside
  "now"/"know"/"nope-ish" substrings.
- If BOTH accept and decline signals appear ("yes but not now"), we return UNKNOWN.
- Priority among single-category matches: RESCHEDULE > WAIT > DECLINE > ACCEPT
  (a decline that names a future slot is a reschedule, not a turn-away).
"""
from __future__ import annotations

import re

ACCEPTED = "ACCEPTED"
RESCHEDULE = "RESCHEDULE"
DECLINED = "DECLINED"
WAIT = "WAIT"
UNKNOWN = "UNKNOWN"

# Word-boundary tokens (short / ambiguous).
_ACCEPT_WORDS = r"\b(yes|yeah|yep|yup|sure|ok|okay|k|accept|accepted|absolutely|definitely|cool|great|fine)\b"
_DECLINE_WORDS = r"\b(no|nope|nah|cant|cannot|busy|decline|declined|unavailable|skip)\b"
_WAIT_WORDS = r"\b(wait|hold|sec|secs|second|seconds|moment|minute|minutes|min|mins|hang)\b"

# Multi-word phrases (substring match is safe).
_ACCEPT_PHRASES = [
    "send them", "send em", "send 'em", "send him", "send her", "send up",
    "send them up", "come up", "come at", "come by", "come on", "come down",
    "come through", "go ahead", "let them", "let em", "bring them",
    "on my way", "be right", "right there", "coming down", "i'll come", "ill come",
    "sounds good", "will do", "send through",
]
_DECLINE_PHRASES = [
    "not now", "not right now", "not available", "not today", "in a meeting",
    "tell them no", "turn them away", "can't right now", "cant right now",
]
_WAIT_PHRASES = [
    "hold on", "hold up", "hang on", "give me", "gimme", "one sec", "a sec",
    "one moment", "a moment", "just a", "couple min", "few min", "couple of min",
    "five min", "5 min", "ten min", "10 min", "two min", "2 min", "in a bit",
]
# Explicit "let's do it later" markers — count as both a refusal-of-now and a future.
_RESCHEDULE_PHRASES = [
    "reschedule", "another time", "some other time", "rain check", "raincheck",
    "next time", "later this week", "later today",
]

_WHEN_PATTERNS = [
    re.compile(r"\b(?:at|around|by|after)\s+(\d{1,2}(?::\d{2})?\s*(?:am|pm)?)", re.I),
    re.compile(r"\bin\s+(\d+\s*(?:minutes?|mins?|hours?|hrs?|days?|weeks?))", re.I),
    re.compile(r"\b(\d{1,2}(?::\d{2})?\s*(?:am|pm))\b", re.I),
    re.compile(r"\b(tomorrow|tonight|noon|midday)\b", re.I),
    re.compile(r"\b(monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b", re.I),
    re.compile(r"\b(next week|next month|this week|this weekend|the weekend|later this week)\b", re.I),
]

# A concrete future reference (drives RESCHEDULE). Excludes bare "today"/"now".
_FUTURE_RE = re.compile(
    r"\b(tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|"
    r"next week|next month|this week|this weekend|the weekend|later this week|"
    r"after\s+\d{1,2}|\d{1,2}(?::\d{2})?\s*(?:am|pm)|in\s+\d+\s*(?:hours?|days?|weeks?)|later)\b",
    re.I,
)


def _extract_when(text: str) -> str | None:
    for pat in _WHEN_PATTERNS:
        m = pat.search(text)
        if m:
            return m.group(1).strip()
    return None


def _future_ref(text: str) -> bool:
    return bool(_FUTURE_RE.search(text)) or any(p in text for p in _RESCHEDULE_PHRASES)


def _has(text: str, words_re: str, phrases: list[str]) -> bool:
    if re.search(words_re, text):
        return True
    return any(p in text for p in phrases)


def parse_reply(text: str) -> dict:
    """Return {"verdict": <ACCEPTED|DECLINED|WAIT|UNKNOWN>, "when": str|None}."""
    t = (text or "").strip().lower()
    if not t:
        return {"verdict": UNKNOWN, "when": None}

    # 1) Slash command (optionally /accept@botname). First token only.
    first = t.split()[0].lstrip("/").split("@")[0]
    if first in ("accept", "decline", "wait"):
        verdict = {"accept": ACCEPTED, "decline": DECLINED, "wait": WAIT}[first]
        return {"verdict": verdict, "when": _extract_when(t) if verdict == ACCEPTED else None}

    # 2) Natural language. A strong accept PHRASE ("be right there", "send them
    # up") signals real acceptance; a weak accept WORD ("ok") does not override a
    # wait ("ok give me 5" is WAIT, but "be right there in 5" is ACCEPTED@5min).
    accept_phrase = any(p in t for p in _ACCEPT_PHRASES)
    accept = accept_phrase or bool(re.search(_ACCEPT_WORDS, t))
    decline = _has(t, _DECLINE_WORDS, _DECLINE_PHRASES)
    wait = _has(t, _WAIT_WORDS, _WAIT_PHRASES)
    resched_phrase = any(p in t for p in _RESCHEDULE_PHRASES)
    future = _future_ref(t)

    if accept and decline:
        return {"verdict": UNKNOWN, "when": None}  # genuinely ambiguous
    if accept_phrase and wait:
        return {"verdict": ACCEPTED, "when": _extract_when(t)}  # accept with a delay
    # RESCHEDULE: wants a LATER meeting — a refusal-of-now naming a future slot,
    # an explicit reschedule phrase, or a bare future reference that isn't an accept.
    if not accept and (resched_phrase or (future and (decline or not wait))):
        return {"verdict": RESCHEDULE, "when": _extract_when(t)}
    if wait:
        return {"verdict": WAIT, "when": None}
    if decline:
        return {"verdict": DECLINED, "when": None}
    if accept:
        return {"verdict": ACCEPTED, "when": _extract_when(t)}
    return {"verdict": UNKNOWN, "when": None}


# Bare verdict tokens — if the host's whole reply is just one of these, there's
# no extra instruction to relay verbatim.
_BARE = {
    "yes", "yeah", "yep", "yup", "sure", "ok", "okay", "k", "no", "nope", "nah",
    "accept", "accepted", "decline", "declined", "wait", "busy",
}


def _extra_content(raw: str) -> str | None:
    """Return the host's message verbatim if it carries more than a bare verdict
    (e.g. 'bring cakes', 'tomorrow 10am'), else None. Strips a leading slash command."""
    if not raw:
        return None
    t = raw.strip()
    first = t.split()[0] if t.split() else ""
    if first.startswith("/"):                      # drop the slash command token
        t = t[len(first):].strip()
    if not t:
        return None
    words = [w for w in re.sub(r"[^\w\s]", " ", t.lower()).split() if w]
    if words and all(w in _BARE for w in words):    # purely a bare verdict
        return None
    return t


def visitor_copy(host_name: str, verdict: str, when: str | None = None,
                 host_message: str | None = None) -> str:
    """Visitor-facing relay: verdict line + the host's actual words VERBATIM.

    The host's extra instruction (cakes / tomorrow 10am) is never paraphrased away.
    """
    host = host_name or "The host"
    if verdict == ACCEPTED:
        base = f"{host} will see you. Please go ahead."
    elif verdict == RESCHEDULE:
        base = (f"{host} can't meet right now, but he'd like to meet {when}."
                if when else f"{host} can't meet right now, but he'd like to meet another time.")
    elif verdict == DECLINED:
        base = f"{host} isn't available right now."
    elif verdict == WAIT:
        base = f"{host} asked you to wait a moment."
    else:
        base = f"{host} sent an unclear reply; please hold on."

    extra = _extra_content(host_message or "")
    if extra:
        base += f' {host} says: "{extra}"'
    return base
