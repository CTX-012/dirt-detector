"""Pluggable TTS backends. Swap by env (NOVA_TTS_BACKEND), never by code edit.

Implementations:
  supertonic  (default) — Supertonic v3 ONNX, CPU. Covers en/hi/ar + 28 more.
  piper                  — Piper ONNX, CPU. Per-voice model file.
  elevenlabs             — cloud API, OFF by default (config-only). For langs
                           Supertonic lacks (e.g. Telugu) once a key is set.

Every backend implements synth(text, lang, voice) -> (wav_bytes, sample_rate).
Returning WAV bytes keeps the /voice/tts endpoint engine-agnostic.
"""
from __future__ import annotations

import io
import os
import wave

import numpy as np


def float_to_wav_bytes(audio: np.ndarray, sample_rate: int) -> bytes:
    """float32 mono in [-1, 1] -> 16-bit PCM WAV bytes."""
    a = np.asarray(audio, dtype=np.float32).squeeze()
    a = np.clip(a, -1.0, 1.0)
    pcm = (a * 32767.0).astype("<i2")
    buf = io.BytesIO()
    with wave.open(buf, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(int(sample_rate))
        w.writeframes(pcm.tobytes())
    return buf.getvalue()


class TTSBackend:
    name = "base"

    def warm(self) -> None:
        ...

    def synth(self, text: str, lang: str | None = None, voice: str | None = None) -> tuple[bytes, int]:
        raise NotImplementedError


class SupertonicBackend(TTSBackend):
    name = "supertonic"

    def __init__(self) -> None:
        self._tts = None
        self._styles: dict = {}
        self.default_voice = os.environ.get("NOVA_TTS_VOICE", "M1")
        self.threads = int(os.environ.get("NOVA_TTS_THREADS", "4"))
        self.supported = None

    def _ensure(self):
        if self._tts is None:
            import supertonic
            from supertonic import TTS
            self._tts = TTS(model="supertonic-3", auto_download=True,
                            intra_op_num_threads=self.threads)
            self.supported = set(supertonic.SUPPORTED_LANGUAGES)
        return self._tts

    def _style(self, voice: str):
        if voice not in self._styles:
            self._styles[voice] = self._ensure().get_voice_style(voice)
        return self._styles[voice]

    def warm(self) -> None:
        self._style(self.default_voice)

    def synth(self, text, lang=None, voice=None):
        tts = self._ensure()
        # Supertonic can't speak unsupported langs (e.g. Telugu) — let it fall
        # back to its own UNKNOWN_LANGUAGE handling rather than error.
        if lang and self.supported and lang not in self.supported:
            lang = None
        out = tts.synthesize(text, self._style(voice or self.default_voice), lang=lang)
        audio = out[0] if isinstance(out, tuple) else out
        sr = int(tts.sample_rate)   # the tuple's 2nd element is duration, not SR
        return float_to_wav_bytes(audio, sr), sr


class PiperBackend(TTSBackend):
    name = "piper"

    def __init__(self) -> None:
        self._voice = None
        self.model_path = os.environ.get("NOVA_PIPER_MODEL", "")  # path to a .onnx voice

    def _ensure(self):
        if self._voice is None:
            if not self.model_path or not os.path.exists(self.model_path):
                raise RuntimeError(
                    "piper backend needs NOVA_PIPER_MODEL=<path to a piper .onnx voice>"
                )
            from piper import PiperVoice
            self._voice = PiperVoice.load(self.model_path)
        return self._voice

    def warm(self) -> None:
        self._ensure()

    def synth(self, text, lang=None, voice=None):
        v = self._ensure()
        buf = io.BytesIO()
        with wave.open(buf, "wb") as wf:
            v.synthesize_wav(text, wf)   # sets WAV format + writes 16-bit PCM
        data = buf.getvalue()
        with wave.open(io.BytesIO(data), "rb") as r:
            sr = r.getframerate()
        return data, sr


class ElevenLabsBackend(TTSBackend):
    name = "elevenlabs"

    def __init__(self) -> None:
        self.api_key = os.environ.get("ELEVENLABS_API_KEY", "")
        self.voice_id = os.environ.get("ELEVENLABS_VOICE_ID", "21m00Tcm4TlvDq8ikWAM")
        self.model = os.environ.get("ELEVENLABS_MODEL", "eleven_multilingual_v2")

    def warm(self) -> None:
        ...

    def synth(self, text, lang=None, voice=None):
        if not self.api_key:
            raise RuntimeError("elevenlabs backend needs ELEVENLABS_API_KEY")
        import requests
        r = requests.post(
            f"https://api.elevenlabs.io/v1/text-to-speech/{voice or self.voice_id}",
            headers={"xi-api-key": self.api_key, "accept": "audio/wav"},
            params={"output_format": "pcm_22050"},
            json={"text": text, "model_id": self.model},
            timeout=30,
        )
        r.raise_for_status()
        # ElevenLabs PCM -> wrap as WAV
        pcm = np.frombuffer(r.content, dtype="<i2").astype(np.float32) / 32767.0
        return float_to_wav_bytes(pcm, 22050), 22050


_REGISTRY = {
    "supertonic": SupertonicBackend,
    "piper": PiperBackend,
    "elevenlabs": ElevenLabsBackend,
}


def make_backend(name: str) -> TTSBackend:
    name = (name or "supertonic").lower()
    if name not in _REGISTRY:
        raise ValueError(f"unknown TTS backend {name!r}; choices: {list(_REGISTRY)}")
    return _REGISTRY[name]()
