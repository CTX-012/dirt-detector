"""Server-side webcam capture for the ctx machine's physical camera.

A single background thread owns the V4L2 device and continuously decodes the
latest frame into a shared JPEG buffer. Both the MJPEG live stream and the
"grab a frame for grounding" path read from that buffer, so the device is only
opened once (no contention).
"""
from __future__ import annotations

import base64
import glob
import os
import threading
import time

import cv2

# Device selection (most stable first):
#   NOVA_CAMERA_DEVICE  explicit path/index override (e.g. /dev/video1 or 1)
#   else auto-detect — USB re-enumeration moves /dev/videoN, so we prefer the
#   stable /dev/v4l/by-id/*-index0 symlink, then probe a few indices.
_DEVICE_OVERRIDE = os.environ.get("NOVA_CAMERA_DEVICE", "").strip()
_FPS = float(os.environ.get("NOVA_CAMERA_FPS", "15"))


def _candidates() -> list:
    if _DEVICE_OVERRIDE:
        return [int(_DEVICE_OVERRIDE)] if _DEVICE_OVERRIDE.isdigit() else [_DEVICE_OVERRIDE]
    cands: list = []
    # Stable by-id symlinks survive re-plug; index0 is the capture node.
    cands += sorted(glob.glob("/dev/v4l/by-id/*-index0"))
    # Fall back to whatever /dev/videoN exist, in order.
    cands += sorted(glob.glob("/dev/video*"))
    # Last resort: numeric indices.
    cands += [0, 1, 2, 3]
    # de-dup preserving order
    seen, out = set(), []
    for c in cands:
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def _try_open(dev):
    cap = cv2.VideoCapture(dev, cv2.CAP_V4L2)
    if cap.isOpened():
        ok, _ = cap.read()          # must actually yield a frame (metadata nodes won't)
        if ok:
            return cap
    cap.release()
    return None


class Camera:
    def __init__(self) -> None:
        self.device = None                       # resolved device actually in use
        self._cap: cv2.VideoCapture | None = None
        self._jpeg: bytes | None = None          # latest encoded frame
        self._lock = threading.Lock()
        self._thread: threading.Thread | None = None
        self._running = False
        self.disabled = False                    # durable off-switch (survives stream re-requests)
        self.error: str | None = None

    # -- lifecycle ----------------------------------------------------------
    def start(self) -> bool:
        """Idempotent. Returns True if the capture loop is running. Auto-detects
        the camera device so USB re-enumeration (/dev/video0 -> video1) self-heals.
        Refuses to start while disabled (see stop(disable=True))."""
        with self._lock:
            if self.disabled:
                self.error = "camera disabled"
                return False
            if self._running:
                return True
            cap, used = None, None
            for dev in _candidates():
                cap = _try_open(dev)
                if cap is not None:
                    used = dev
                    break
            if cap is None:
                self.error = "no working camera device found (tried by-id + /dev/video*)"
                return False
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self._cap = cap
            self.device = used
            self._running = True
            self.error = None
            self._thread = threading.Thread(target=self._loop, daemon=True)
            self._thread.start()
            return True

    def stop(self, disable: bool = False) -> None:
        """Release the device. If disable=True, also block auto-restart until a
        subsequent start()/enable() — a durable 'camera off'."""
        with self._lock:
            self._running = False
            if disable:
                self.disabled = True
            t = self._thread
        if t:
            t.join(timeout=2)
        if self._cap:
            self._cap.release()
            self._cap = None
        self._jpeg = None

    def enable(self) -> None:
        with self._lock:
            self.disabled = False

    def _loop(self) -> None:
        interval = 1.0 / _FPS if _FPS > 0 else 0
        fail = 0
        while self._running:
            ok, frame = self._cap.read()
            if not ok:
                fail += 1
                if fail > 30:
                    self.error = "camera read failed repeatedly"
                    break
                time.sleep(0.1)
                continue
            fail = 0
            enc, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            if enc:
                with self._lock:
                    self._jpeg = buf.tobytes()
            if interval:
                time.sleep(interval)
        self._running = False

    # -- accessors ----------------------------------------------------------
    @property
    def available(self) -> bool:
        return self._running and self._jpeg is not None

    def latest_jpeg(self) -> bytes | None:
        with self._lock:
            return self._jpeg

    def latest_b64(self) -> str | None:
        j = self.latest_jpeg()
        return base64.b64encode(j).decode() if j else None

    def mjpeg_frames(self):
        """Generator yielding multipart MJPEG chunks for a streaming response."""
        boundary = b"--frame"
        last = None
        while self._running:
            j = self.latest_jpeg()
            if j is not None and j is not last:
                last = j
                yield boundary + b"\r\nContent-Type: image/jpeg\r\nContent-Length: " \
                    + str(len(j)).encode() + b"\r\n\r\n" + j + b"\r\n"
            time.sleep(1.0 / _FPS if _FPS > 0 else 0.05)


# Module-level singleton.
camera = Camera()
