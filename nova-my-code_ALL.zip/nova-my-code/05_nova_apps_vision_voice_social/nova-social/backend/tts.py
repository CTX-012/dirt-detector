"""TTS facade. Selects the active backend from NOVA_TTS_BACKEND (default
'supertonic') and exposes a single synth() the endpoints call. The backend is a
process singleton, loaded lazily and warmed at startup.

Swap engines with zero code change:
  NOVA_TTS_BACKEND=supertonic   (default)
  NOVA_TTS_BACKEND=piper        NOVA_PIPER_MODEL=/path/voice.onnx
  NOVA_TTS_BACKEND=elevenlabs   ELEVENLABS_API_KEY=...   (cloud; off by default)
"""
from __future__ import annotations

import os
import threading
import time

import tts_backends

BACKEND_NAME = os.environ.get("NOVA_TTS_BACKEND", "supertonic")

_backend: tts_backends.TTSBackend | None = None
_lock = threading.Lock()


def get_backend() -> tts_backends.TTSBackend:
    global _backend
    if _backend is None:
        with _lock:
            if _backend is None:
                _backend = tts_backends.make_backend(BACKEND_NAME)
    return _backend


def warm() -> None:
    get_backend().warm()


def synth(text: str, lang: str | None = None, voice: str | None = None) -> dict:
    """Return {wav: bytes, sample_rate, backend, ms}."""
    b = get_backend()
    t0 = time.perf_counter()
    wav, sr = b.synth(text, lang=lang, voice=voice)
    return {
        "wav": wav,
        "sample_rate": sr,
        "backend": b.name,
        "ms": round((time.perf_counter() - t0) * 1000),
    }
