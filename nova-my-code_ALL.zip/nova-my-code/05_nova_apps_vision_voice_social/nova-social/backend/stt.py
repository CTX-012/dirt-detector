"""Speech-to-text via faster-whisper (CTranslate2), CPU + int8.

Loaded ONCE as a process singleton (model load is the expensive part) and reused
across requests. Runs entirely on CPU — device is hard-pinned to "cpu" so it can
never contend with the GPU LLM/VLM stack. Multilingual (Whisper covers
Hindi/Telugu/Arabic and ~classic Whisper languages).

Swap model/engine via env, never code edit (mirrors the TTS abstraction):
  NOVA_STT_MODEL=small        # tiny|base|small|medium|large-v3 ...
  NOVA_STT_COMPUTE=int8       # int8|int8_float16|float32
  NOVA_STT_THREADS=4
"""
from __future__ import annotations

import os
import threading
import time

MODEL = os.environ.get("NOVA_STT_MODEL", "small")
COMPUTE = os.environ.get("NOVA_STT_COMPUTE", "int8")
THREADS = int(os.environ.get("NOVA_STT_THREADS", "4"))

_model = None
_lock = threading.Lock()


def _get_model():
    global _model
    if _model is None:
        with _lock:
            if _model is None:
                from faster_whisper import WhisperModel
                # device="cpu" is the hard guarantee of 0 GPU usage.
                _model = WhisperModel(
                    MODEL, device="cpu", compute_type=COMPUTE, cpu_threads=THREADS
                )
    return _model


def warm() -> None:
    """Force model load (called at startup so the first turn isn't slow)."""
    _get_model()


def transcribe(audio_path: str, language: str | None = None) -> dict:
    """Transcribe an audio file. `language` optional (auto-detect if None).

    Returns {text, lang, lang_prob, ms}."""
    model = _get_model()
    t0 = time.perf_counter()
    segments, info = model.transcribe(
        audio_path,
        language=language,
        vad_filter=True,          # drop leading/trailing silence
        beam_size=1,              # greedy: fastest, fine for short kiosk utterances
    )
    text = "".join(seg.text for seg in segments).strip()
    return {
        "text": text,
        "lang": info.language,
        "lang_prob": round(float(info.language_probability), 3),
        "ms": round((time.perf_counter() - t0) * 1000),
    }
