"""LLM access via Ollama's OpenAI-compatible endpoint.

- chat model: qwen2.5:7b
- coach_turn(): returns a validated dict (parse-or-retry on bad JSON)
- draft_message(): free-text outreach draft
"""
import json
import os

from openai import OpenAI

OLLAMA_BASE = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434/v1")
CHAT_MODEL = os.environ.get("NOVA_CHAT_MODEL", "qwen2.5:7b")

# Ollama ignores the api key but the client requires one.
client = OpenAI(base_url=OLLAMA_BASE, api_key="ollama")

# Keep the model resident across requests (belt-and-suspenders alongside the
# server-side OLLAMA_KEEP_ALIVE=-1).
_KEEP_ALIVE = {"keep_alive": -1}

_REQUIRED_KEYS = {"reply", "visitor_name", "target", "purpose", "ready_to_notify"}


def _coerce(obj: dict) -> dict:
    """Fill missing keys with safe defaults so downstream code never KeyErrors.

    S4.2 receptionist schema: {reply, visitor_name, target, purpose, ready_to_notify}.
    """
    return {
        "reply": str(obj.get("reply", "") or ""),
        "visitor_name": obj.get("visitor_name") or None,
        "target": obj.get("target") or None,
        "purpose": obj.get("purpose") or None,
        "ready_to_notify": bool(obj.get("ready_to_notify", False)),
    }


def _extract_json(text: str) -> dict:
    """Tolerant JSON extraction: handles fenced blocks and trailing prose."""
    text = text.strip()
    if text.startswith("```"):
        # strip ```json ... ``` fences
        text = text.split("```", 2)[1]
        if text.startswith("json"):
            text = text[4:]
        text = text.strip().rstrip("`").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end != -1 and end > start:
            return json.loads(text[start:end + 1])
        raise


def coach_turn(messages: list[dict]) -> dict:
    """Run one coach turn. `messages` is an OpenAI-style message list (system +
    history + latest user). Returns a validated intent dict. Retries once with a
    stricter nudge if the model emits malformed JSON."""
    def _call(extra_system: str | None = None):
        msgs = list(messages)
        if extra_system:
            msgs = msgs + [{"role": "system", "content": extra_system}]
        resp = client.chat.completions.create(
            model=CHAT_MODEL,
            messages=msgs,
            temperature=0.6,
            response_format={"type": "json_object"},
            extra_body=_KEEP_ALIVE,
        )
        return resp.choices[0].message.content

    raw = _call()
    try:
        return _coerce(_extract_json(raw))
    except (json.JSONDecodeError, ValueError):
        # Parse-or-retry guard: ask again, more forcefully.
        raw2 = _call("Your last reply was not valid JSON. Reply with ONLY the JSON object, nothing else.")
        try:
            return _coerce(_extract_json(raw2))
        except (json.JSONDecodeError, ValueError):
            # Last-ditch: treat the raw text as a plain chat reply.
            return _coerce({"reply": raw2 or raw, "intent": "chat"})


def _relay_lead(host: str, verdict: str, when: str | None) -> str:
    """Deterministic verdict framing (the receptionist's outcome statement). The
    LLM appends only the host's specific extras to this — it never decides the verdict."""
    if verdict == "ACCEPTED":
        return f"{host} will see you — please go ahead"
    if verdict == "RESCHEDULE":
        return f"{host} can't meet right now, but would like to meet {when}" if when \
            else f"{host} can't meet right now, but would like to meet at another time"
    if verdict == "DECLINED":
        return f"{host} isn't available right now"
    if verdict == "WAIT":
        return f"{host} asks you to wait a moment"
    return f"{host} replied"


def relay_in_receptionist_voice(host_name: str, verdict: str, host_raw: str,
                                when: str | None = None) -> str:
    """Restate the host's reply to the visitor AS THE RECEPTIONIST, in one natural
    sentence. The verdict framing is fixed deterministically (the `lead`); the LLM
    only weaves in the host's OWN extra instructions (items, times, conditions),
    preserving them exactly and inventing nothing. Raw text is stored separately."""
    host = host_name or "The host"
    lead = _relay_lead(host, verdict, when)
    sys = (
        "You are a front-desk receptionist talking to a waiting visitor. You will be given "
        "a fixed LEAD sentence (already correct — keep its meaning) and the host's raw message. "
        "Produce ONE natural sentence to the visitor that begins from the LEAD and then adds "
        "ONLY the extra specifics the host actually gave (an item to bring, a place, a "
        "condition; the timing is already in the lead).\n"
        "RULES: Preserve those specifics EXACTLY (e.g. an item or place named by the host). "
        "Invent NOTHING not in the host's message. If the host gave no extra specifics beyond "
        "the lead, output the LEAD unchanged. Do not quote the host. Output only the sentence."
    )
    usr = f'LEAD: "{lead}."\nHOST RAW MESSAGE: "{host_raw}".\nYour one sentence to the visitor:'
    try:
        resp = client.chat.completions.create(
            model=CHAT_MODEL,
            messages=[{"role": "system", "content": sys}, {"role": "user", "content": usr}],
            temperature=0.0,
            extra_body=_KEEP_ALIVE,
        )
        out = (resp.choices[0].message.content or "").strip().strip('"')
        return out or (lead + ".")
    except Exception:  # noqa: BLE001
        return ""  # caller falls back to the deterministic copy
