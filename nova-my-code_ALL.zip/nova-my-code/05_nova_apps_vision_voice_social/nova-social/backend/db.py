"""SQLite-backed session store (promoted from the S1 in-memory dict at S3).

Sessions are the source of truth here so that the long-poll loop (a background
thread) and the request handlers can both reach a waiting session. The key S3
query is find_pending_by_host(chat_id): given an inbound host reply, locate the
visitor session waiting on that host.

A small in-memory cache keyed by session_id returns the SAME Session object to
both the kiosk request thread and the reply-handler thread, so an update from
one is visible to the other immediately (the DB is the durable mirror).
"""
from __future__ import annotations

import json
import os
import sqlite3
import threading
import time

import fsm

DB_PATH = os.environ.get("NOVA_DB_PATH", os.path.join(os.path.dirname(__file__), "nova_social.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    session_id    TEXT PRIMARY KEY,
    state         TEXT NOT NULL,
    visitor_name  TEXT,
    host_name     TEXT,
    host_chat_id  INTEGER,
    slots         TEXT,        -- JSON
    last_scene    TEXT,
    history       TEXT,        -- JSON
    draft         TEXT,
    verdict       TEXT,        -- ACCEPTED | DECLINED | WAIT | NULL
    when_string   TEXT,
    host_message  TEXT,        -- S4.2: host's raw free-text reply (verbatim)
    relay_copy    TEXT,
    created_at    REAL,
    updated_at    REAL
);
CREATE INDEX IF NOT EXISTS idx_sessions_host_state ON sessions(host_chat_id, state);
"""


class SessionStore:
    def __init__(self, path: str = DB_PATH) -> None:
        self.path = path
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.executescript(SCHEMA)
        self._migrate()
        self._conn.commit()
        self._lock = threading.RLock()
        self._cache: dict[str, fsm.Session] = {}

    def _migrate(self) -> None:
        """Add columns introduced after a DB was first created (e.g. host_message)."""
        cols = {r[1] for r in self._conn.execute("PRAGMA table_info(sessions)")}
        if "host_message" not in cols:
            self._conn.execute("ALTER TABLE sessions ADD COLUMN host_message TEXT")

    # -- (de)serialization ---------------------------------------------------
    def _row_to_session(self, row: sqlite3.Row) -> fsm.Session:
        s = fsm.Session(session_id=row["session_id"])
        s.state = row["state"]
        s.slots = json.loads(row["slots"]) if row["slots"] else s.slots
        s.last_scene = row["last_scene"]
        s.history = json.loads(row["history"]) if row["history"] else []
        s.draft = row["draft"]
        s.host_name = row["host_name"]
        s.host_chat_id = row["host_chat_id"]
        s.verdict = row["verdict"]
        s.when_string = row["when_string"]
        s.host_message = row["host_message"] if "host_message" in row.keys() else None
        s.relay_copy = row["relay_copy"]
        s.created_at = row["created_at"] or time.time()
        return s

    def _upsert(self, s: fsm.Session) -> None:
        self._conn.execute(
            """
            INSERT INTO sessions
              (session_id, state, visitor_name, host_name, host_chat_id, slots,
               last_scene, history, draft, verdict, when_string, host_message,
               relay_copy, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(session_id) DO UPDATE SET
              state=excluded.state, visitor_name=excluded.visitor_name,
              host_name=excluded.host_name, host_chat_id=excluded.host_chat_id,
              slots=excluded.slots, last_scene=excluded.last_scene,
              history=excluded.history, draft=excluded.draft, verdict=excluded.verdict,
              when_string=excluded.when_string, host_message=excluded.host_message,
              relay_copy=excluded.relay_copy, updated_at=excluded.updated_at
            """,
            (
                s.session_id, s.state, s.slots.get("visitor_name"), s.host_name,
                s.host_chat_id, json.dumps(s.slots), s.last_scene,
                json.dumps(s.history[-50:]), s.draft, s.verdict, s.when_string,
                s.host_message, s.relay_copy, s.created_at, time.time(),
            ),
        )
        self._conn.commit()

    # -- public API ----------------------------------------------------------
    def get_or_create(self, session_id: str) -> fsm.Session:
        with self._lock:
            if session_id in self._cache:
                return self._cache[session_id]
            row = self._conn.execute(
                "SELECT * FROM sessions WHERE session_id=?", (session_id,)
            ).fetchone()
            s = self._row_to_session(row) if row else fsm.Session(session_id=session_id)
            if not row:
                self._upsert(s)
            self._cache[session_id] = s
            return s

    def get(self, session_id: str) -> fsm.Session | None:
        with self._lock:
            if session_id in self._cache:
                return self._cache[session_id]
            row = self._conn.execute(
                "SELECT * FROM sessions WHERE session_id=?", (session_id,)
            ).fetchone()
            if not row:
                return None
            s = self._row_to_session(row)
            self._cache[session_id] = s
            return s

    def save(self, s: fsm.Session) -> None:
        with self._lock:
            self._cache[s.session_id] = s
            self._upsert(s)

    def find_pending_by_host(self, host_chat_id: int) -> tuple[fsm.Session | None, bool]:
        """Most-recent session in AWAIT_HOST_REPLY for this host chat.

        Returns (session_or_None, ambiguous) where ambiguous=True means more than
        one session is currently waiting on this host (we pick the newest; the
        caller should flag it — see S3 edge cases)."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT session_id FROM sessions WHERE host_chat_id=? AND state=? "
                "ORDER BY updated_at DESC",
                (host_chat_id, fsm.AWAIT_HOST_REPLY),
            ).fetchall()
            if not rows:
                return None, False
            return self.get(rows[0]["session_id"]), len(rows) > 1
