#!/usr/bin/env python3
"""
NOVA metrics sidecar — SQLite persistence for latency and run metrics.

Why a sidecar and not "the browser writes to a database": browsers cannot write
SQLite. IndexedDB exists, but it is per-origin, hard to query, and impossible to
diff across machines. A 120-line Python service gives you a real .db file you can
open with any SQLite tool, commit to the repo, or hand to a colleague.

Why SQLite and not Postgres/Influx: a 30-minute run at 10 Hz produces ~18k rows.
You would need ~500 runs before SQLite noticed. Standing up a Postgres server to
store 18,000 rows is a way of feeling productive without being productive.

When you outgrow it (roughly: you want continuous aggregates, retention policies,
or concurrent writers), the schema below ports to TimescaleDB by changing the
CREATE TABLE and adding `SELECT create_hypertable('samples','at')`. Nothing else
changes.

Run:
    python3 scripts/metrics_server.py                 # serves :8420
    python3 scripts/metrics_server.py --report        # print a run comparison
    python3 scripts/metrics_server.py --report --last 5
"""

import argparse
import json
import sqlite3
import statistics
import sys
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

DB_PATH = Path(__file__).parent.parent / 'experiments' / 'metrics.db'

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    id          INTEGER PRIMARY KEY,
    started_at  REAL    NOT NULL,
    ended_at    REAL,
    label       TEXT,
    -- The config that produced these numbers. Without this, comparing two runs
    -- is meaningless: you cannot tell whether it got faster because you fixed
    -- something or because you changed the map.
    world       TEXT,
    transport   TEXT,           -- 'json' | 'cbor' | 'png'
    git_sha     TEXT,
    notes       TEXT
);

CREATE TABLE IF NOT EXISTS samples (
    run_id      INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    at          REAL    NOT NULL,   -- unix ms, browser clock
    topic       TEXT    NOT NULL,
    stage       TEXT    NOT NULL,   -- transit | decode | render | e2e
    ms          REAL    NOT NULL,
    bytes       INTEGER,
    suspect     INTEGER DEFAULT 0   -- 1 = clock skew made this untrustworthy
);

-- The index that matters. Without it, "p95 decode for /map in run 7" is a full
-- table scan, and at 500 runs that is seconds.
CREATE INDEX IF NOT EXISTS idx_samples_lookup
    ON samples(run_id, topic, stage);

CREATE TABLE IF NOT EXISTS run_reports (
    run_id      INTEGER NOT NULL REFERENCES runs(id) ON DELETE CASCADE,
    at          REAL    NOT NULL,
    verdict     TEXT    NOT NULL,   -- PASS | FAIL | PENDING
    report      TEXT    NOT NULL    -- the full phase3_v1 JSON
);
"""


def connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, check_same_thread=False)
    # WAL: lets the dashboard write while you query the same file from a
    # sqlite3 shell. Without it, your read blocks the robot's metrics.
    con.execute('PRAGMA journal_mode=WAL')
    # NORMAL instead of FULL: we are storing telemetry, not money. An fsync per
    # transaction would make the ingest endpoint the slowest thing in the stack —
    # the exact outcome this whole module exists to avoid.
    con.execute('PRAGMA synchronous=NORMAL')
    con.executescript(SCHEMA)
    return con


class Handler(BaseHTTPRequestHandler):
    con: sqlite3.Connection = None  # set in main()

    def _json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        # The dashboard is on :5173, this is on :8420. Same machine, different
        # origin — so CORS is mandatory or every POST fails silently.
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'POST, GET, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.end_headers()

    def do_POST(self):
        n = int(self.headers.get('Content-Length', 0))
        try:
            payload = json.loads(self.rfile.read(n))
        except json.JSONDecodeError:
            return self._json({'error': 'bad json'}, 400)

        if self.path == '/run/start':
            cur = self.con.execute(
                'INSERT INTO runs (started_at, label, world, transport, git_sha, notes) '
                'VALUES (?,?,?,?,?,?)',
                (time.time(), payload.get('label'), payload.get('world'),
                 payload.get('transport', 'json'), payload.get('git_sha'),
                 payload.get('notes')),
            )
            self.con.commit()
            return self._json({'run_id': cur.lastrowid})

        if self.path == '/run/end':
            self.con.execute('UPDATE runs SET ended_at=? WHERE id=?',
                             (time.time(), payload['run_id']))
            self.con.commit()
            return self._json({'ok': True})

        if self.path == '/samples':
            rid = payload['run_id']
            rows = [
                (rid, s['at'], s['topic'], s['stage'], s['ms'],
                 s.get('bytes'), 1 if s.get('suspect') else 0)
                for s in payload['samples']
            ]
            # executemany + one commit. Per-row commits would fsync 500 times
            # and the flush would take longer than the data it describes.
            self.con.executemany(
                'INSERT INTO samples (run_id, at, topic, stage, ms, bytes, suspect) '
                'VALUES (?,?,?,?,?,?,?)', rows)
            self.con.commit()
            return self._json({'stored': len(rows)})

        if self.path == '/report':
            self.con.execute(
                'INSERT INTO run_reports (run_id, at, verdict, report) VALUES (?,?,?,?)',
                (payload['run_id'], time.time(), payload['verdict'],
                 json.dumps(payload['report'])),
            )
            self.con.commit()
            return self._json({'ok': True})

        return self._json({'error': 'unknown path'}, 404)

    def do_GET(self):
        if self.path == '/health':
            return self._json({'ok': True, 'db': str(DB_PATH)})
        if self.path == '/runs':
            rows = self.con.execute(
                'SELECT id, started_at, ended_at, label, world, transport '
                'FROM runs ORDER BY id DESC LIMIT 50').fetchall()
            return self._json([dict(zip(
                ['id', 'started_at', 'ended_at', 'label', 'world', 'transport'], r))
                for r in rows])
        return self._json({'error': 'unknown path'}, 404)

    def log_message(self, *args):
        pass  # the default handler spams stderr on every request


# ── reporting ────────────────────────────────────────────────────────────

def pct(vals, q):
    if not vals:
        return 0.0
    s = sorted(vals)
    return s[min(len(s) - 1, int(q * len(s)))]


def report(con, last=3):
    runs = con.execute(
        'SELECT id, label, world, transport, started_at FROM runs '
        'ORDER BY id DESC LIMIT ?', (last,)).fetchall()
    if not runs:
        print('No runs recorded yet.')
        return

    print()
    print(f'{"run":>4}  {"transport":<10} {"topic":<20} {"stage":<8} '
          f'{"n":>6} {"p50":>8} {"p95":>8} {"p99":>8} {"max":>8}  {"KB/s":>7}')
    print('-' * 100)

    for rid, label, world, transport, started in reversed(runs):
        keys = con.execute(
            'SELECT DISTINCT topic, stage FROM samples WHERE run_id=? '
            'ORDER BY topic, stage', (rid,)).fetchall()
        for topic, stage in keys:
            rows = con.execute(
                'SELECT ms, bytes FROM samples '
                'WHERE run_id=? AND topic=? AND stage=? AND suspect=0',
                (rid, topic, stage)).fetchall()
            if not rows:
                continue
            ms = [r[0] for r in rows]
            byts = [r[1] for r in rows if r[1]]

            span = con.execute(
                'SELECT (MAX(at)-MIN(at))/1000.0 FROM samples '
                'WHERE run_id=? AND topic=?', (rid, topic)).fetchone()[0] or 1
            kbs = (sum(byts) / 1024 / span) if byts else 0

            print(f'{rid:>4}  {transport or "?":<10} {topic:<20} {stage:<8} '
                  f'{len(ms):>6} {pct(ms,.5):>8.2f} {pct(ms,.95):>8.2f} '
                  f'{pct(ms,.99):>8.2f} {max(ms):>8.2f}  {kbs:>7.1f}')
        print()

    # Regression check — the whole point of persisting this.
    if len(runs) >= 2:
        cur_id, prev_id = runs[0][0], runs[1][0]
        print('Regression check (latest vs previous):')
        keys = con.execute(
            'SELECT DISTINCT topic, stage FROM samples WHERE run_id=?',
            (cur_id,)).fetchall()
        flagged = False
        for topic, stage in keys:
            def p95(rid):
                v = [r[0] for r in con.execute(
                    'SELECT ms FROM samples WHERE run_id=? AND topic=? '
                    'AND stage=? AND suspect=0', (rid, topic, stage))]
                return pct(v, .95) if v else None

            a, b = p95(cur_id), p95(prev_id)
            if a is None or b is None or b == 0:
                continue
            delta = 100 * (a - b) / b
            if abs(delta) > 20:  # 20% is noise-proof; 5% is not
                flagged = True
                arrow = 'WORSE' if delta > 0 else 'better'
                print(f'  {topic:<20} {stage:<8} p95 {b:>7.2f} → {a:>7.2f} ms  '
                      f'({delta:+.0f}%)  {arrow}')
        if not flagged:
            print('  no change > 20% — nothing to see')
    print()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--port', type=int, default=8420)
    ap.add_argument('--report', action='store_true')
    ap.add_argument('--last', type=int, default=3)
    args = ap.parse_args()

    con = connect()

    if args.report:
        report(con, args.last)
        return

    Handler.con = con
    srv = ThreadingHTTPServer(('0.0.0.0', args.port), Handler)
    print(f'metrics sidecar  →  http://localhost:{args.port}')
    print(f'db               →  {DB_PATH}')
    print(f'report           →  python3 {sys.argv[0]} --report')
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nbye')
        con.close()


if __name__ == '__main__':
    main()
