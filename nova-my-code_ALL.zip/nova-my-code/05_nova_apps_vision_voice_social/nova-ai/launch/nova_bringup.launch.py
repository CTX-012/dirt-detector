"""
NOVA bringup — coverage tracker + rosbridge.

Assumes Gazebo, Nav2, AMCL, and map_server are ALREADY running. This launch adds
only the two pieces that aren't:

  1. nova_coverage_tracker  — publishes /coverage/grid + /coverage/stats  (Track A)
  2. rosbridge_websocket    — the ws://:9090 the dashboard subscribes to

Usage:
    ros2 launch nova_bringup.launch.py
    ros2 launch nova_bringup.launch.py rosbridge:=false     # if you run it yourself

Then, in another shell:
    cd dashboard && npm run dev
"""

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    tracker_pkg = get_package_share_directory('nova_coverage_tracker')
    default_params = os.path.join(tracker_pkg, 'config', 'coverage_tracker.yaml')

    return LaunchDescription([
        DeclareLaunchArgument(
            'params_file',
            default_value=default_params,
            description='coverage_tracker parameter YAML',
        ),
        DeclareLaunchArgument(
            'rosbridge',
            default_value='true',
            description='Launch rosbridge_websocket alongside the tracker',
        ),
        DeclareLaunchArgument(
            'port',
            default_value='9090',
            description='rosbridge websocket port',
        ),

        Node(
            package='nova_coverage_tracker',
            executable='coverage_tracker',
            name='nova_coverage_tracker',
            output='screen',
            parameters=[LaunchConfiguration('params_file')],
        ),

        # Launched as a plain Node rather than by including rosbridge's own launch
        # file — the upstream launch file is XML on some distros and Python on
        # others, and IncludeLaunchDescription needs to know which. This works
        # everywhere.
        Node(
            package='rosbridge_server',
            executable='rosbridge_websocket',
            name='rosbridge_websocket',
            output='screen',
            parameters=[{
                'port': LaunchConfiguration('port'),

                # Grids are big. Without a raised cap, rosbridge silently drops
                # /map and /coverage/grid and the dashboard renders an empty
                # canvas with no error anywhere (R2).
                'max_message_size': 100_000_000,

                # Fragmentation MUST be off for CBOR. rosbridge splits oversized
                # messages into fragments, and a fragmented binary frame arrives
                # as pieces the CBOR decoder cannot read — you get silent drops
                # instead of an error. 0 = never fragment.
                'fragment_timeout': 600,

                # Do NOT enable Tornado's per-message deflate alongside CBOR.
                # CBOR is already compact binary; deflating it again costs CPU on
                # both ends for near-zero gain, and it undoes the whole point.
                # It is only worth it for JSON over a real network, not localhost.
                'use_compression': False,

                'unregister_timeout': 86400.0,
            }],
            condition=IfCondition(LaunchConfiguration('rosbridge')),
        ),

        # rosapi is REQUIRED, not optional. The dashboard calls
        # /rosapi/get_time for clock-skew estimation, and without this node
        # that call hangs forever and the skew silently stays 0 — which makes
        # every cross-clock latency number a lie.
        Node(
            package='rosapi',
            executable='rosapi_node',
            name='rosapi',
            output='screen',
            condition=IfCondition(LaunchConfiguration('rosbridge')),
        ),
    ])
