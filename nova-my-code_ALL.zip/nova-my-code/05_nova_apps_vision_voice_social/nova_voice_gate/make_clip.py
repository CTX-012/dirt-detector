"""Build the canned STT input clip for the latency bench.

The laptop's winning CPU STT number (2192 ms p95, small.en int8) was measured on a
3.23 s clip. The exact laptop WAV is NOT present on ctx, so per DISPATCH ABORT/PIVOT
we synthesize a fixed clip of the SAME stated duration (3.23 s) using Piper, so STT
decode work is realistic English speech (not silence/tone) and the GPU-vs-CPU ratio
is a clean apples-to-apples comparison on equal clip length.

Output: audio/clip_3p23s.wav  (16 kHz mono int16, exactly 3.23 s).
"""
from __future__ import annotations
import wave
import numpy as np
from scipy.signal import resample_poly
from piper import PiperVoice

SR_OUT = 16000
DUR_S = 3.23                      # match laptop's stated clip length
N_OUT = int(round(DUR_S * SR_OUT))  # 51680 samples

# ~3 s of natural English; content-realistic so beam-1 decode does real work.
TEXT = ("Nova, move forward two meters and then turn left toward the doorway, "
        "but stop immediately if anyone walks in front of you.")

def main():
    v = PiperVoice.load("models/en_US-lessac-medium.onnx")
    sr_in = v.config.sample_rate
    chunks = [ch.audio_int16_array for ch in v.synthesize(TEXT)]
    audio = np.concatenate(chunks).astype(np.float32) / 32768.0
    # resample to 16 kHz
    audio16 = resample_poly(audio, SR_OUT, sr_in).astype(np.float32)
    # pad or trim to EXACT 3.23 s
    if len(audio16) < N_OUT:
        audio16 = np.concatenate([audio16, np.zeros(N_OUT - len(audio16), np.float32)])
    else:
        audio16 = audio16[:N_OUT]
    pcm = np.clip(audio16 * 32768.0, -32768, 32767).astype(np.int16)
    with wave.open("audio/clip_3p23s.wav", "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR_OUT)
        w.writeframes(pcm.tobytes())
    print(f"wrote audio/clip_3p23s.wav  {len(pcm)} samples = {len(pcm)/SR_OUT:.3f}s @ {SR_OUT}Hz mono")

if __name__ == "__main__":
    main()
