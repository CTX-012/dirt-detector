"""D2: REAL streaming overlapped voice pipeline + ONE-CLOCK wall-clock TTFR.

Extends D1 (does NOT touch gate.py / telemetry.py logic). Replaces the D1 no-overlap
pipeline with three streaming fixes the prototype never had:
  (a) streaming STT  -- partials committed DURING speech; only the tail is transcribed
                        post-endpoint, so stt_final << stt_full (chunked-STT-with-
                        partial-emit; see DISPATCH ABORT/PIVOT fallback).
  (b) sentence-chunked LLM->TTS -- TTS of sentence 1 starts mid-LLM-stream.
  (c) streamed playout -- first PCM chunk is emitted to the sink AS SOON as it exists
                          (no collect-then-play).

THE NUMBER: TTFR = t(first_audio_emitted) - t(turn_start), captured by ONE clock
through the real overlapped pipeline. turn_start = endpoint as DETECTED by the VAD
turn-detector (silence-wait), NOT an oracle 0 ms onset. endpoint-wait is reported
separately; perceived = endpoint-wait + TTFR.

Run:  python bench_d2.py --clip tts|human --turns 50 --silence-wait 0.4
"""
from __future__ import annotations
import argparse, json, re, threading, time, wave, contextlib
import numpy as np
from telemetry import Recorder, now
from backends import WhisperGPU, LocalLLM, PiperTTS, SileroVADOnnx

SR = 16000
FRAME = 512                       # 32 ms Silero frame
PARTIAL_EVERY = 0.8               # commit a partial every 0.8 s of audio
TTS_SR = 22050                    # Piper en_US-lessac-medium
SENT = re.compile(r"(.+?[.!?])(\s|$)", re.S)
# real streamed TTS chunks on PHRASE (clause) boundaries, not whole sentences --
# you can't speak a token (the 349 projection used llm_ttft = first TOKEN), but you
# can speak the first clause. Emit on , ; : . ! ? or after a max-word fallback.
PHRASE = re.compile(r"(.+?[,;:.!?])(\s|$)", re.S)
PHRASE_MAX_WORDS = 8
P = Recorder._pct                 # same percentile semantics as D1/Tester


# --------------------------------------------------------------------------
def load_audio(path, trail_silence_s=0.6):
    """Load 16k mono float32. Append trailing silence so the VAD turn-detector
    has silence to fire on (the TTS clip is trimmed at 3.23s mid-word; without
    this the endpoint never triggers and endpoint-wait collapses to ~0)."""
    with contextlib.closing(wave.open(path, "rb")) as w:
        sr = w.getframerate()
        a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16)
    assert sr == SR, f"{path} not 16k"
    a = a.astype(np.float32) / 32768.0
    return np.concatenate([a, np.zeros(int(trail_silence_s * SR), np.float32)])


class EnergyVAD:
    """Simple RMS turn-detector used for ENDPOINTING in D2.

    HISTORY: this was D2's stopgap because backends.SileroVADOnnx was detection-broken
    (it fed bare 512-sample frames with no context-prepend -> near-constant ~0.001 on
    ALL input). VadFixImpl has since FIXED Silero (context handling); use --vad silero
    for the real detector. EnergyVAD is kept as a dependency-free fallback; it is correct
    on high-SNR clips but (unlike Silero) fires on loud non-speech noise.
    """
    def __init__(self, threshold=0.02):
        self.th = threshold

    def reset(self):
        pass

    def is_speech(self, frame_f32):
        return float(np.sqrt(np.mean(frame_f32 ** 2))) > self.th


class TimedSink:
    """Records the instant the FIRST PCM chunk is emitted to the output layer.
    Best-effort real device playout; headless -> null sink (timestamp only)."""
    def __init__(self):
        self.first = None
        self.dev = None
        try:
            import sounddevice as sd
            self.dev = sd.RawOutputStream(samplerate=TTS_SR, channels=1, dtype="int16")
            self.dev.start()
        except Exception:
            self.dev = None

    def reset(self):
        self.first = None

    def write(self, pcm: bytes):
        if self.first is None:
            self.first = now()
        if self.dev is not None:
            try:
                self.dev.write(pcm)
            except Exception:
                pass


class _StopFirst(Exception):
    pass


# --------------------------------------------------------------------------
def stream_turn(audio, stt, llm, tts, vad, sink, silence_wait, realtime=True,
                break_after_first=True, max_tokens=80):
    """One real streamed turn. Returns dict with the ONE-CLOCK ttfr_ms + parts."""
    vad.reset()
    buf = []                       # list[np.ndarray] frames
    state = {"samps": 0, "committed_end": 0}
    committed_text = []
    lock = threading.Lock()
    stop_worker = threading.Event()

    # (a) streaming-STT partial worker: commits stable prefix DURING speech (overlap)
    def worker():
        while not stop_worker.is_set():
            with lock:
                end = state["samps"]; ce = state["committed_end"]
                tail = np.concatenate(buf)[ce:end] if buf else None
            if tail is not None and (end - ce) >= int(PARTIAL_EVERY * SR):
                segs, _ = stt.m.transcribe(tail, beam_size=1, language="en")
                committed_text.append(" ".join(s.text for s in segs))
                with lock:
                    state["committed_end"] = end
            else:
                time.sleep(0.01)
    wt = threading.Thread(target=worker, daemon=True); wt.start()

    # feed frames at real-time pace; VAD turn-detector finds end-of-speech
    frames = [audio[i:i + FRAME] for i in range(0, len(audio) - FRAME + 1, FRAME)]
    t0 = now(); last_speech = None; started = False
    T_speech_end = T_detect = None
    for idx, fr in enumerate(frames):
        if realtime:
            d = (t0 + (idx + 1) * FRAME / SR) - now()
            if d > 0:
                time.sleep(d)
        with lock:
            buf.append(fr); state["samps"] += len(fr)
        sp = vad.is_speech(fr)
        w = now()
        if sp:
            last_speech = w; started = True
        elif started and last_speech and (w - last_speech) >= silence_wait:
            T_speech_end = last_speech; T_detect = w
            break
    if T_detect is None:                       # never went silent -> end of clip
        T_speech_end = last_speech or now(); T_detect = now()
    stop_worker.set(); wt.join(timeout=2)

    # ===== CLOCK STARTS HERE: turn_start = endpoint detection =====
    # (a) finalize STT: only the tail since the last committed partial
    with lock:
        full = np.concatenate(buf); end = state["samps"]; ce = state["committed_end"]
    t_s = now()
    segs, _ = stt.m.transcribe(full[ce:end], beam_size=1, language="en")
    tail_text = " ".join(s.text for s in segs)
    stt_final_ms = (now() - t_s) * 1000.0
    transcript = (" ".join(committed_text) + " " + tail_text).strip()

    # (b)+(c) stream LLM tokens -> emit each finished sentence to TTS -> sink
    sink.reset()
    prompt = ("You are a service robot. The operator said: '" + transcript[:200] +
              "'. Acknowledge what you will do in two short sentences.")
    stream = llm.c.chat.completions.create(
        model=llm.model, stream=True, max_tokens=max_tokens,
        messages=[{"role": "user", "content": prompt}])
    acc = ""; n_sent = 0

    def emit(sentence):
        nonlocal n_sent
        for pcm in tts.run(sentence):
            if pcm:
                sink.write(pcm)            # first write stamps sink.first
        n_sent += 1

    try:
        for ch in stream:
            tok = ch.choices[0].delta.content or ""
            if not tok:
                continue
            acc += tok
            m = PHRASE.match(acc)
            while m:
                s = m.group(1).strip(); acc = acc[m.end():]
                if s:
                    emit(s)
                    if break_after_first and sink.first is not None:
                        raise _StopFirst()
                m = PHRASE.match(acc)
            # fallback: flush a long delimiter-free run as a phrase
            if len(acc.split()) >= PHRASE_MAX_WORDS:
                emit(acc.strip()); acc = ""
                if break_after_first and sink.first is not None:
                    raise _StopFirst()
        if acc.strip() and (sink.first is None or not break_after_first):
            emit(acc.strip())
    except _StopFirst:
        pass
    finally:
        try:
            stream.close()
        except Exception:
            pass

    first_audio = sink.first if sink.first is not None else now()
    return dict(
        ttfr_ms=(first_audio - T_detect) * 1000.0,          # ONE CLOCK, overlapped
        endpoint_wait_ms=(T_detect - T_speech_end) * 1000.0,
        stt_final_ms=stt_final_ms,
        n_sentences=n_sent,
        transcript=transcript,
        real_device=sink.dev is not None,
    )


# --------------------------------------------------------------------------
def bargein_turn(stt, llm, tts, vad, silence_wait, onset_offset_s=0.203):
    """Measure gate-path barge-in cancel latency: user-onset -> playout stops.
    Reuses gate.step()/Decision (no second decision authority). Excludes acoustic
    wake-word-spotter detection (unbuilt) and device buffer drain."""
    from gate import AttentionGate, FrameEvent, Decision
    # build a full multi-sentence reply to "play out"
    audio = load_audio("audio/clip_3p23s.wav")
    sink = TimedSink()
    r = stream_turn(audio, stt, llm, tts, vad, sink, silence_wait,
                    realtime=False, break_after_first=False)
    # synth a few seconds of playout PCM to stream
    pcm = b"".join(c for c in tts.run("Okay, moving forward two meters now. "
                                      "Then I will turn left toward the doorway. "
                                      "Please stand clear while I move."))
    total_s = (len(pcm) / 2) / TTS_SR
    g = AttentionGate()
    # paced playout loop ticking at FRAME (32ms) cadence. The user starts speaking at
    # a true onset wall `onset`; the system can only react at its next VAD frame -- so
    # cancel = (next frame boundary - onset) + vad + gate.step + flush. onset is phased
    # OFF the tick grid so we sample the 0..32ms reaction phase, not a tick-aligned 0.
    pos = 0.0; t_play0 = now(); onset = t_play0 + onset_offset_s
    t_stop = None
    while pos < total_s:
        w = now()
        spoke = w >= onset
        evt = FrameEvent(t=w, is_speech=spoke, wake=spoke, n_speakers=1,
                         speaker_id="op")          # owner re-addresses -> GRANT
        if g.step(evt) == Decision.GRANT and spoke:
            t_stop = now()                          # cancel + flush playout here
            break
        nxt = t_play0 + (pos + FRAME / SR)
        slp = nxt - now()
        if slp > 0:
            time.sleep(slp)
        pos += FRAME / SR
    if t_stop is None:
        return None
    return (t_stop - onset) * 1000.0               # user-onset -> playout-stops


# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--clip", choices=["tts", "human"], default="tts")
    ap.add_argument("--turns", type=int, default=50)
    ap.add_argument("--warmup", type=int, default=5)
    ap.add_argument("--silence-wait", type=float, default=0.4)   # D1 prototype value
    ap.add_argument("--bargein", type=int, default=20)
    ap.add_argument("--llm-model", default="qwen2.5:0.5b")
    ap.add_argument("--llm-url", default="http://127.0.0.1:11434/v1")
    ap.add_argument("--vad", choices=["silero", "energy"], default="energy",
                    help="endpoint turn-detector (silero now fixed; energy was the D2 stopgap)")
    args = ap.parse_args()

    clip = ("audio/human_cmd_3p23s.wav" if args.clip == "human"
            else "audio/clip_3p23s.wav")
    src = "HUMAN (JFK recording, real human speech, not a domain command, not live-mic)" \
        if args.clip == "human" else "TTS-synthetic (Piper)"
    audio = load_audio(clip)

    print("=" * 68)
    print(f"NOVA D2 streaming pipeline -- MEASURED wall-clock TTFR  (clip={args.clip})")
    print("=" * 68)
    print(f"  input        : {clip}  [{src}]")
    print(f"  silence-wait : {args.silence_wait*1000:.0f} ms (turn-detector; D1 used 400ms, "
          f"Pipecat default 800ms)")

    stt = WhisperGPU(model="small.en", device="auto", compute_type="auto")
    llm = LocalLLM(base_url=args.llm_url, model=args.llm_model)
    tts = PiperTTS("models/en_US-lessac-medium.onnx")
    if args.vad == "silero":
        vad = SileroVADOnnx(num_threads=1)      # fixed (context-prepend) -- passes G1c-detection
        vname = "Silero(CPU, fixed)"
    else:
        vad = EnergyVAD()
        vname = "EnergyVAD(CPU)"
    print(f"  STT={stt.device} fp16 | LLM={args.llm_model}(GPU) | TTS=Piper(CPU) | "
          f"turn-detector={vname}")

    sink = TimedSink()
    print(f"  playout sink : {'REAL device' if sink.dev else 'null/timestamp (headless; no PortAudio)'}")

    for _ in range(args.warmup):
        stream_turn(audio, stt, llm, tts, vad, sink, args.silence_wait,
                    realtime=False, break_after_first=True)

    ttfr, ep, sttf, nsent = [], [], [], []
    rows = []
    for i in range(args.turns):
        # full turn (no early break) so n_sentences + multi-chunk streamed playout are
        # genuine; first_audio is stamped on the first PHRASE either way -> TTFR unchanged
        r = stream_turn(audio, stt, llm, tts, vad, sink, args.silence_wait,
                        realtime=True, break_after_first=False)
        ttfr.append(r["ttfr_ms"]); ep.append(r["endpoint_wait_ms"])
        sttf.append(r["stt_final_ms"]); nsent.append(r["n_sentences"])
        rows.append(dict(i=i, **{k: r[k] for k in
                    ("ttfr_ms", "endpoint_wait_ms", "stt_final_ms", "n_sentences")}))

    with open(f"d2_per_turn_{args.clip}.jsonl", "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")

    def stat(xs):
        return P(xs, .50), P(xs, .95), max(xs)

    t50, t95, tmx = stat(ttfr); e50, _, _ = stat(ep); s50, s95, _ = stat(sttf)
    print(f"\n  --- MEASURED (one clock, real overlapped pipeline; N={args.turns}) ---")
    print(f"  STT-final (post-endpoint tail) p50={s50:.1f}  p95={s95:.1f} ms")
    print(f"  endpoint-wait                  mean~{np_mean(ep):.0f} ms (= silence-wait)")
    print(f"  sentences/reply                median={int(P(nsent,.5))} (streamed playout: "
          f"{'multi-chunk' if P(nsent,.5)>=2 else 'SINGLE-CHUNK caveat'})")
    print(f"\n  >>> TTFR (wall-clock)  p50={t50:.1f} ms   p95={t95:.1f} ms   max={tmx:.1f} ms <<<")
    print(f"      perceived (endpoint-wait + TTFR)  p50~{e50 + t50:.0f} ms   p95~{e50 + t95:.0f} ms")
    print(f"\n  vs D1: streamed-SUM projection ~349ms (p95) | sequential ~574ms (p95, MISS)")
    verdict = "<500 OK" if t95 < 500 else ">=500 MISS"
    print(f"      measured TTFR p95 {t95:.0f}ms  {verdict}   "
          f"(overlap delta vs sequential 574 = {574 - t95:+.0f}ms)")

    if args.bargein > 0:
        # phase the onset across the 32ms frame grid so cancel isn't tick-aligned
        bi = [bargein_turn(stt, llm, tts, vad, args.silence_wait,
                           onset_offset_s=0.200 + (k % 16) * 0.002)
              for k in range(args.bargein)]
        bi = [x for x in bi if x is not None]
        if bi:
            print(f"\n  --- BARGE-IN (own metric; gate-path cancel; N={len(bi)}) ---")
            print(f"  cancel latency user-onset->playout-stops  p50={P(bi,.5):.1f}  "
                  f"p95={P(bi,.95):.1f} ms")
            print(f"  (reuses gate.step()/Decision.GRANT; EXCLUDES acoustic wake-word "
                  f"detect + device drain)")
    print(f"\n  input was {src}.")


def np_mean(xs):
    return float(np.mean(xs)) if xs else 0.0


if __name__ == "__main__":
    main()
