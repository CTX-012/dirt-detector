"""TS-VAD efficacy: does a neural d-vector separate speakers where MFCC failed (-0.013)?

NOTE (provenance): this repo (the ctx re-init) had NO prior test_ts_vad.py and NO MFCC
baseline committed -- they live in a parallel/laptop thread. This is written fresh to
answer the one question that matters: SEPARATION = A.min - B.max with a real d-vector.
The MFCC -0.013 is taken as the given prior to beat.

Embedder: resemblyzer VoiceEncoder (CPU/GPU, bundled GE2E weights, no HF download).
Speakers (REAL humans, recorded -- not live-recorded here):
  A target  = JFK inaugural (audio/human_jfk_full.wav, ~11s, male)
  B impostor= LDC93S1 / TIMIT (audio/spk/LDC93S1.wav, ~2.9s, a DIFFERENT male)
  C impostor= OSR American female (audio/spk/osr_female.wav, ~33s, female)
Protocol: enroll on first 6s of A; score held-out A windows (same-speaker) vs
impostor windows (different-speaker); cosine on L2-normed d-vectors.
"""
from __future__ import annotations
import numpy as np
from resemblyzer import VoiceEncoder, preprocess_wav

SR = 16000
WIN_S, HOP_S = 1.6, 0.8          # 1.6s = resemblyzer partial length
ENROLL_S = 6.0


def windows(wav, win_s=WIN_S, hop_s=HOP_S, min_s=1.0):
    n, w, h = len(wav), int(win_s * SR), int(hop_s * SR)
    out = []
    i = 0
    while i + int(min_s * SR) <= n:
        out.append(wav[i:i + w])
        i += h
    return out


def main():
    enc = VoiceEncoder()                      # auto device; GE2E weights bundled
    A = preprocess_wav("audio/human_jfk_full.wav")     # 16k, VAD-trimmed, normalized
    B = preprocess_wav("audio/spk/LDC93S1.wav")
    C = preprocess_wav("audio/spk/osr_female.wav")

    # enroll on first 6s of A; held-out A = the rest (same speaker, held out)
    cut = int(ENROLL_S * SR)
    enroll = enc.embed_utterance(A[:cut])
    enroll /= np.linalg.norm(enroll)

    def scores(wav):
        out = []
        for seg in windows(wav):
            e = enc.embed_utterance(seg)
            e /= np.linalg.norm(e)
            out.append(float(np.dot(enroll, e)))
        return np.array(out)

    a = scores(A[cut:])           # held-out same-speaker (A)
    b = scores(B)                 # impostor B (primary, per dispatch)
    c = scores(C)                 # impostor C (2nd impostor)
    imp = np.concatenate([b, c])

    print("=" * 64)
    print("TS-VAD d-vector efficacy (resemblyzer GE2E) -- REAL human speakers")
    print("=" * 64)
    print(f"  enroll: first {ENROLL_S:.0f}s of A(JFK).  windows {WIN_S}s/{HOP_S}s hop.")
    print(f"  same-speaker A (held-out)  n={len(a)}  mean={a.mean():.3f}  MIN={a.min():.3f}")
    print(f"  diff-speaker B (LDC93S1)   n={len(b)}  mean={b.mean():.3f}  MAX={b.max():.3f}")
    print(f"  diff-speaker C (OSR fem.)  n={len(c)}  mean={c.mean():.3f}  MAX={c.max():.3f}")
    print(f"  all impostors B+C          n={len(imp)} mean={imp.mean():.3f} MAX={imp.max():.3f}")

    sep_b = a.min() - b.max()
    sep_all = a.min() - imp.max()
    print(f"\n  >>> SEPARATION (A.min - B.max)     = {sep_b:+.3f}   (MFCC baseline: -0.013) <<<")
    print(f"  >>> SEPARATION (A.min - allImp.max)= {sep_all:+.3f}                          <<<")

    # threshold sweep: target-accept (A>=th) vs impostor-reject (imp<th)
    best = None
    for th in np.linspace(0.0, 1.0, 201):
        acc = float((a >= th).mean())
        rej = float((imp < th).mean())
        bal = min(acc, rej)
        if best is None or bal > best[3]:
            best = (th, acc, rej, bal)
    th, acc, rej, _ = best
    print(f"\n  best threshold={th:.3f}: target-accept={acc*100:.0f}%  "
          f"impostor-reject={rej*100:.0f}%  (specificity vs impostors)")
    verdict = "POSITIVE -> TS-VAD is real" if sep_b > 0 else "<=0 -> differentiator FAILS (STOP)"
    print(f"\n  GATE: separation vs B {'>' if sep_b>0 else '<='}0  =>  {verdict}")
    return sep_b


if __name__ == "__main__":
    main()
