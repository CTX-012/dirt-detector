"""Backends: one interface, swap local <-> cloud behind it.

Network boundary rule (from this thread): the local floor (VAD, wake, STOP,
gate) is pinned and always runs; STT/LLM/TTS are swappable and MUST fail safe
-- on timeout, fall back to local result or to UNKNOWN (deny), never block the
gate and never open it.

Only SileroVADOnnx + the Mock stages run in the sandbox (CPU, no torch).
WhisperGPU / LocalLLM / PiperTTS / cloud stages import lazily and are executed
on `ctx` per the dispatch.
"""
from __future__ import annotations
import os
import time
import numpy as np


# --------------------------------------------------------------------------
# VAD (real, CPU, onnxruntime -- no torch)
# --------------------------------------------------------------------------
class SileroVADOnnx:
    """Silero VAD v5 via onnxruntime. 512-sample frames @ 16 kHz (32 ms).

    The v5 model expects each frame PREPENDED with `context` samples (64 @16k, 32 @8k)
    carried from the previous frame -- model input is 512+64 = 576 samples, not 512.
    The original wiring fed bare 512-sample frames with no context, so the model
    silently received the wrong input and returned a near-constant ~0.001 on ALL audio
    (incl. real human speech). That bug masqueraded as "VAD GREEN" because only LATENCY
    was ever tested. Fixed here per the silero-vad OnnxWrapper convention; gated now by
    bench.bench_vad_detection() (G1c-detection)."""
    FRAME = 512

    def __init__(self, path="models/silero_vad.onnx", sr=16000,
                 threshold=0.5, num_threads=None):
        import onnxruntime as ort
        so = ort.SessionOptions()
        so.intra_op_num_threads = num_threads or (os.cpu_count() or 1)
        self.s = ort.InferenceSession(path, sess_options=so,
                                      providers=["CPUExecutionProvider"])
        self._sr = np.array(sr, dtype=np.int64)
        self._ctx_n = 64 if int(sr) == 16000 else 32   # silero v5 context size
        self.th = threshold
        self.reset()

    def reset(self):
        self._state = np.zeros((2, 1, 128), dtype=np.float32)
        self._ctx = np.zeros((1, self._ctx_n), dtype=np.float32)

    def prob(self, frame_f32: np.ndarray) -> float:
        frame = frame_f32.reshape(1, -1).astype(np.float32)
        x = np.concatenate([self._ctx, frame], axis=1)        # prepend carried context
        out, self._state = self.s.run(
            None, {"input": x, "state": self._state, "sr": self._sr})
        self._ctx = x[:, -self._ctx_n:]                        # carry last ctx samples
        return float(out[0, 0])

    def is_speech(self, frame_f32: np.ndarray) -> bool:
        return self.prob(frame_f32) > self.th


class MockVAD:
    def __init__(self, pattern=None):
        self.pattern = pattern or [True]
        self.i = 0

    def reset(self):
        self.i = 0

    def is_speech(self, frame_f32) -> bool:
        v = self.pattern[self.i % len(self.pattern)]
        self.i += 1
        return v


# --------------------------------------------------------------------------
# Stage interface: declared timeout + run().  ttfb_ms models streamed output.
# --------------------------------------------------------------------------
class Stage:
    name = "stage"
    timeout_ms = 1000.0
    ttfb_ms = None  # first-byte latency for streaming stages (TTS/LLM)

    def run(self, *a, **k):
        raise NotImplementedError


class MockStage(Stage):
    """Deterministic latency, for instrumentation validation + budget modelling."""
    def __init__(self, name, total_ms, ttfb_ms=None, result=None, timeout_ms=1000.0):
        self.name = name
        self._total = total_ms / 1000.0
        self.ttfb_ms = ttfb_ms
        self._r = result
        self.timeout_ms = timeout_ms

    def run(self, *a, **k):
        time.sleep(self._total)
        return self._r


# --------------------------------------------------------------------------
# GPU / cloud stages -- run on ctx (lazy imports so this module imports clean)
# --------------------------------------------------------------------------
def _resolve_device(device="auto", compute_type="auto"):
    """auto -> cuda if CTranslate2 sees a GPU, else cpu. CPU uses int8."""
    if device == "auto":
        try:
            import ctranslate2
            device = "cuda" if ctranslate2.get_cuda_device_count() > 0 else "cpu"
        except Exception:
            device = "cpu"
    if compute_type == "auto":
        compute_type = "float16" if device == "cuda" else "int8"
    return device, compute_type


class WhisperSTT(Stage):
    """faster-whisper (CTranslate2). Runs on GPU *or* CPU.
    device='auto' picks cuda if present, else cpu(int8) using all cores.
    Same class on the 3060 and on a CPU-only laptop."""
    name = "stt"
    timeout_ms = 400.0

    def __init__(self, model="small.en", device="auto", compute_type="auto",
                 cpu_threads=None):
        from faster_whisper import WhisperModel
        dev, ct = _resolve_device(device, compute_type)
        self.device = dev
        self.m = WhisperModel(model, device=dev, compute_type=ct,
                              cpu_threads=cpu_threads or (os.cpu_count() or 1))

    def run(self, wav_path):
        segs, _ = self.m.transcribe(wav_path, beam_size=1, language="en")
        return " ".join(s.text for s in segs).strip(), 1.0


# DISPATCH_V1 references WhisperGPU; keep it working.
WhisperGPU = WhisperSTT


class LocalLLM(Stage):
    name = "llm"
    timeout_ms = 600.0
    ttfb_ms = None  # measured = TTFT

    def __init__(self, base_url="http://127.0.0.1:8000/v1", model="local"):
        # GPU: vLLM on the 3060.  CPU laptop: point base_url at a llama.cpp
        # server (GGUF, OpenAI-compatible) -- no code change, just the URL.
        from openai import OpenAI
        self.c = OpenAI(base_url=base_url, api_key="local")
        self.model = model

    def run(self, prompt: str):
        stream = self.c.chat.completions.create(
            model=self.model, stream=True,
            messages=[{"role": "user", "content": prompt}], max_tokens=64)
        first = None
        out = []
        for ch in stream:
            tok = ch.choices[0].delta.content or ""
            if tok and first is None:
                first = time.perf_counter()  # TTFT marker
            out.append(tok)
        return "".join(out), first


class PiperTTS(Stage):
    name = "tts"
    timeout_ms = 400.0

    def __init__(self, model_path):
        from piper import PiperVoice  # local, CPU/GPU
        self.v = PiperVoice.load(model_path)

    def run(self, text: str):
        # yields PCM chunks; caller marks first_audio on first chunk (streamed playout)
        # piper-tts >= 1.3 replaced synthesize_stream_raw() with synthesize(), which
        # yields AudioChunk objects; expose each chunk's raw int16 PCM bytes so the
        # streaming (first-chunk = TTFB) semantics are unchanged. (Backend adapter
        # only -- no gate/telemetry logic touched. ctx has piper-tts 1.4.2.)
        for chunk in self.v.synthesize(text):
            yield chunk.audio_int16_bytes
