"""Gate FSM tests = the Day-1 evil cases. Run: python test_gate.py"""
from gate import AttentionGate, FrameEvent, Decision, GateConfig


def case(desc, got, want):
    ok = got == want
    print(f"  [{'PASS' if ok else 'FAIL'}] {desc:<46} got={got.value:<8} want={want.value}")
    return ok


def run():
    ok = True

    # 1: ambient conversation, no wake word -> DENY
    g = AttentionGate()
    ok &= case("EVIL1 ambient chatter, no wake",
               g.step(FrameEvent(t=0.0, is_speech=True, wake=False, n_speakers=2)),
               Decision.DENY)

    # 2: robot self-talk (handled upstream by half-duplex; here: no wake) -> DENY
    g = AttentionGate()
    ok &= case("EVIL2 robot self-talk (no wake)",
               g.step(FrameEvent(t=0.0, is_speech=True, wake=False)),
               Decision.DENY)

    # 3: overlapping speakers even WITH wake -> DENY
    g = AttentionGate()
    ok &= case("EVIL3 wake but 2 speakers overlapping",
               g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=2)),
               Decision.DENY)

    # 4: mid-turn interruption by a different speaker -> ignored (DENY for B)
    g = AttentionGate()
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL4 different speaker mid-turn",
               g.step(FrameEvent(t=0.3, is_speech=True, speaker_id="B")),
               Decision.DENY)

    # 5: emergency STOP overrides everything, even from a bystander mid-turn
    g = AttentionGate()
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL5 STOP keyword overrides",
               g.step(FrameEvent(t=0.4, stop_kw=True, speaker_id="Z")),
               Decision.STOP)

    # 6: ambiguous command -> UNKNOWN (not a guess)
    g = AttentionGate()
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL6 ambiguous 'yeah maybe go there'",
               g.step(FrameEvent(t=0.2, speaker_id="A", intent="MAYBE", confidence=0.3)),
               Decision.UNKNOWN)

    # 6b: low-confidence MOTION intent -> UNKNOWN
    g = AttentionGate()
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL6b low-confidence MOVE",
               g.step(FrameEvent(t=0.2, speaker_id="A", intent="MOVE", confidence=0.4)),
               Decision.UNKNOWN)

    # 6c: confident MOVE from owner -> GRANT
    g = AttentionGate()
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL6c confident MOVE from owner",
               g.step(FrameEvent(t=0.2, speaker_id="A", intent="MOVE", confidence=0.9)),
               Decision.GRANT)

    # 6d: confident MOVE but vision says not addressed -> UNKNOWN (veto-down)
    g = AttentionGate()
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL6d MOVE but vision not-addressed",
               g.step(FrameEvent(t=0.2, speaker_id="A", intent="MOVE",
                                 confidence=0.9, visual_addressed=False)),
               Decision.UNKNOWN)

    # 7: ownership expires after silence timeout -> back to IDLE -> DENY w/o wake
    g = AttentionGate(GateConfig(ownership_timeout_s=2.5))
    g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A"))
    ok &= case("EVIL7 ownership expiry, then no wake",
               g.step(FrameEvent(t=5.0, is_speech=True, wake=False, speaker_id="A")),
               Decision.DENY)

    # 7b: a valid wake grants normally (sanity)
    g = AttentionGate()
    ok &= case("SANITY wake + single speaker grants",
               g.step(FrameEvent(t=0.0, is_speech=True, wake=True, n_speakers=1, speaker_id="A")),
               Decision.GRANT)

    print(f"\n{'ALL PASS' if ok else 'FAILURES PRESENT'}")
    return ok


if __name__ == "__main__":
    import sys
    sys.exit(0 if run() else 1)
