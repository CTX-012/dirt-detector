"""Latency benchmark harness.

Runs four things:
  1. instrumentation self-check  -- proves measured == known (no timestamp bug)
  2. VAD micro-bench (REAL)       -- Silero on CPU, per-frame ms vs 32 ms budget
  3. gate-decision latency (REAL) -- pure FSM, microsecond-scale
  4. TTFR budget model            -- streamed vs batch playout, vs 500 ms target
                                     (per-stage numbers are PLACEHOLDERS until
                                      measured on ctx -- see dispatch)

On ctx, --mode full swaps in WhisperGPU / LocalLLM / PiperTTS and replaces the
model numbers with measurements.
"""
from __future__ import annotations
import argparse
import statistics
import time
import numpy as np

from telemetry import Recorder
from gate import AttentionGate, FrameEvent, Decision
from backends import SileroVADOnnx, MockVAD


# 1) ----------------------------------------------------------------------
def instrumentation_selfcheck(tol_pct=20.0) -> bool:
    """Drive the recorder with stages of KNOWN duration; assert measured matches."""
    rec = Recorder()
    known = {"stt": 80.0, "llm": 120.0, "tts": 60.0}
    rec.start_turn(1)
    for name, ms in known.items():
        with rec.stage(name):
            time.sleep(ms / 1000.0)
    rec.end_turn()
    ok = True
    print("[1] instrumentation self-check (measured vs known)")
    for name, want in known.items():
        got = rec.summary()[name]["p50"]
        err = abs(got - want) / want * 100.0
        flag = "OK" if err <= tol_pct else "FAIL"
        ok &= err <= tol_pct
        print(f"    {name:<5} known={want:6.1f}ms  measured={got:6.1f}ms  err={err:4.1f}%  {flag}")
    print(f"    => {'PASS' if ok else 'FAIL'}\n")
    return ok


# 2) ----------------------------------------------------------------------
# NOTE: bench_vad() below measures LATENCY ONLY on synthetic tone+noise. A VAD that
# returns a constant (e.g. broken Silero -> ~0.001 on everything) PASSES this and looks
# "GREEN" -- which is exactly how a detection bug survived D1/GpuImpl/Tester-B. "VAD
# GREEN" now requires BOTH bench_vad_detection() (2a, below) AND bench_vad() (2b).
def _vad_score(vad, frame):
    """Probability if the VAD exposes one (Silero), else a 0/1 from is_speech()."""
    if hasattr(vad, "prob"):
        return float(vad.prob(frame))
    return 1.0 if vad.is_speech(frame) else 0.0


def make_vad_labeled_set(speech_wav="audio/human_jfk_full.wav", n_each=150, frame=512):
    """Ground-truth labeled frames: POS = real human speech (high-energy frames of a
    speech recording -- genuinely voiced), NEG = synthetic silence + moderate noise.
    The noise negatives give the test teeth against a pure energy detector (which would
    fire on them), and the speech positives give it teeth against a constant/broken VAD
    (which scores ~0 -> zero recall)."""
    import wave, contextlib
    rng = np.random.default_rng(0)
    with contextlib.closing(wave.open(speech_wav, "rb")) as w:
        sr = w.getframerate()
        a = np.frombuffer(w.readframes(w.getnframes()), np.int16).astype(np.float32) / 32768.0
    assert sr == 16000, f"{speech_wav} not 16k"
    pos = [a[i:i + frame] for i in range(0, len(a) - frame + 1, frame)
           if np.sqrt(np.mean(a[i:i + frame] ** 2)) > 0.04][:n_each]
    half = n_each // 2
    neg = [np.zeros(frame, np.float32) for _ in range(half)]                       # silence
    neg += [(0.05 * rng.standard_normal(frame)).astype(np.float32)                  # noise
            for _ in range(n_each - half)]
    return pos, neg


def bench_vad_detection(vad, pos, neg, th=0.5, recall_bar=0.85, spec_bar=0.85):
    """G1c-DETECTION: assert the VAD DISCRIMINATES speech from non-speech (not just
    that it runs fast). Reports recall (speech caught), specificity (non-speech
    rejected), precision, AUC. PASS = recall>=bar AND specificity>=bar."""
    vad.reset() if hasattr(vad, "reset") else None
    pp = [_vad_score(vad, f) for f in pos]
    vad.reset() if hasattr(vad, "reset") else None
    nps = [_vad_score(vad, f) for f in neg]
    tp = sum(p > th for p in pp); fp = sum(p > th for p in nps)
    recall = tp / max(len(pp), 1)
    spec = (len(nps) - fp) / max(len(nps), 1)
    prec = tp / max(tp + fp, 1)
    auc = (sum(1.0 if a > b else 0.5 if a == b else 0.0 for a in pp for b in nps)
           / max(len(pp) * len(nps), 1))
    ok = recall >= recall_bar and spec >= spec_bar
    print(f"[2a] VAD DETECTION gate (REAL human speech vs silence+noise; "
          f"n_pos={len(pp)} n_neg={len(nps)})")
    print(f"     recall(speech)={recall:.2f} (bar>={recall_bar})  "
          f"specificity(non-speech)={spec:.2f} (bar>={spec_bar})")
    print(f"     precision={prec:.2f}  AUC={auc:.3f}  => {'PASS' if ok else 'FAIL'}\n")
    return dict(recall=recall, specificity=spec, precision=prec, auc=auc, passed=ok)


def bench_vad(vad, n_frames=300, sr=16000, frame=512):
    rng = np.random.default_rng(0)
    # synthetic speech-ish frames: tone + noise (latency is content-independent --
    # this is the LATENCY gate [2b]; detection is gated separately by [2a] above)
    t = np.arange(frame) / sr
    base = 0.3 * np.sin(2 * np.pi * 200 * t).astype(np.float32)
    frames = [(base + 0.05 * rng.standard_normal(frame)).astype(np.float32)
              for _ in range(n_frames)]
    for f in frames[:20]:           # warmup
        vad.is_speech(f)
    rec = Recorder()
    rec.start_turn(1)
    for f in frames:
        with rec.stage("vad_frame"):
            vad.is_speech(f)
    rec.end_turn()
    v = rec.summary()["vad_frame"]
    budget = frame / sr * 1000.0
    print(f"[2b] VAD micro-bench LATENCY (REAL, CPU)  frame={frame}smp = {budget:.1f}ms budget")
    print(f"    per-frame  p50={v['p50']:.3f}ms  p95={v['p95']:.3f}ms  max={v['mx']:.3f}ms")
    print(f"    realtime headroom @p95 = {budget / max(v['p95'],1e-6):.1f}x  "
          f"({'OK' if v['p95'] < budget else 'OVER BUDGET'})\n")
    return v


# 3) ----------------------------------------------------------------------
def bench_gate(n=20000):
    g = AttentionGate()
    e = FrameEvent(t=0.0, wake=True, is_speech=True, speaker_id="op", n_speakers=1)
    rec = Recorder()
    rec.start_turn(1)
    base = time.perf_counter()
    for i in range(n):
        e.t = time.perf_counter() - base
        with rec.stage("gate_decide"):
            g.step(e)
    rec.end_turn()
    v = rec.summary()["gate_decide"]
    print(f"[3] gate-decision latency (REAL, pure FSM)  n={n}")
    print(f"    p50={v['p50']*1000:.2f}us  p95={v['p95']*1000:.2f}us  max={v['mx']*1000:.2f}us\n")
    return v


# 4) ----------------------------------------------------------------------
def ttfr_budget(profile: dict, label: str):
    """TTFR under two playout models from the same per-stage profile.
    streamed: stt_final + llm_TTFT + tts_TTFB
    batch   : stt_full  + llm_full + tts_full   (the prototype's path)
    """
    streamed = profile["stt_final"] + profile["llm_ttft"] + profile["tts_ttfb"]
    batch = profile["stt_full"] + profile["llm_full"] + profile["tts_full"]
    print(f"    [{label}]")
    print(f"      streamed TTFR = {profile['stt_final']:.0f}+{profile['llm_ttft']:.0f}"
          f"+{profile['tts_ttfb']:.0f} = {streamed:.0f}ms  "
          f"{'<500 OK' if streamed < 500 else '>=500 MISS'}")
    print(f"      batch    TTFR = {profile['stt_full']:.0f}+{profile['llm_full']:.0f}"
          f"+{profile['tts_full']:.0f} = {batch:.0f}ms  "
          f"{'<500 OK' if batch < 500 else '>=500 MISS'}")
    return streamed, batch


def budget_models():
    print("[4] TTFR budget model  (MODEL -- per-stage numbers are placeholders "
          "until measured on ctx)")
    # online-fast: streaming STT final ~150, Groq TTFT ~80, Cartesia TTFB ~150
    ttfr_budget(dict(stt_final=150, llm_ttft=80, tts_ttfb=150,
                     stt_full=150, llm_full=400, tts_full=400),
                "online-fast (streaming STT + Groq + Cartesia)")
    # prototype: batch scribe_v1 STT, full LLM, collect-then-play TTS
    ttfr_budget(dict(stt_final=450, llm_ttft=250, tts_ttfb=400,
                     stt_full=450, llm_full=450, tts_full=400),
                "prototype-as-written (batch STT + collect-then-play TTS)")
    print()


# 5) ----------------------------------------------------------------------
# --mode full: the ONE code TODO from DISPATCH_V1 -- swap WhisperGPU/LocalLLM/
# PiperTTS in for the placeholders and report MEASURED per-stage latency + TTFR.
# Adds nothing to gate.py / telemetry.py; reuses Recorder._pct + ttfr_budget so
# the percentile math and TTFR model are identical to the rest of the harness.
class _UtilSampler:
    """Background sampler: aggregate CPU% (/proc/stat) and GPU%/VRAM (nvidia-smi)."""
    def __init__(self, period=0.2):
        import threading
        self.period = period
        self._stop = threading.Event()
        self._t = threading.Thread(target=self._loop, daemon=True)
        self.cpu, self.gpu, self.vram = [], [], []

    @staticmethod
    def _cpu_busy():
        with open("/proc/stat") as f:
            parts = f.readline().split()[1:]
        v = list(map(int, parts))
        idle = v[3] + v[4]            # idle + iowait
        return sum(v), idle

    def _loop(self):
        import subprocess
        tot0, idle0 = self._cpu_busy()
        while not self._stop.wait(self.period):
            tot1, idle1 = self._cpu_busy()
            dt, di = tot1 - tot0, idle1 - idle0
            if dt > 0:
                self.cpu.append(100.0 * (dt - di) / dt)
            tot0, idle0 = tot1, idle1
            try:
                out = subprocess.run(
                    ["nvidia-smi", "--query-gpu=utilization.gpu,memory.used",
                     "--format=csv,noheader,nounits"],
                    capture_output=True, text=True, timeout=2).stdout.strip()
                g, m = out.split(",")
                self.gpu.append(float(g)); self.vram.append(float(m))
            except Exception:
                pass

    def __enter__(self): self._t.start(); return self
    def __exit__(self, *a): self._stop.set(); self._t.join(timeout=2)

    @staticmethod
    def _mp(xs):
        return (statistics.mean(xs) if xs else 0.0, max(xs) if xs else 0.0)


def bench_full(n_trials=60, warmup=10, wav="audio/clip_3p23s.wav",
               llm_url="http://127.0.0.1:11434/v1", llm_model="qwen2.5:0.5b",
               tts_model="models/en_US-lessac-medium.onnx"):
    import json, wave, contextlib
    from telemetry import Recorder, now
    from backends import WhisperGPU, LocalLLM, PiperTTS

    P = Recorder._pct  # identical percentile semantics as the harness

    with contextlib.closing(wave.open(wav, "rb")) as w:
        clip_s = w.getnframes() / float(w.getframerate())

    print("[5] FULL per-stage measurement on ctx (RTX 3060)")
    print(f"    STT clip: {wav}  duration={clip_s:.2f}s   (laptop CPU baseline: "
          f"2192 ms p95 / 3.23 s clip, small.en int8)")

    stt = WhisperGPU(model="small.en", device="auto", compute_type="auto")
    llm = LocalLLM(base_url=llm_url, model=llm_model)
    tts = PiperTTS(tts_model)
    print(f"    STT  : faster-whisper small.en  device={stt.device}  compute_type=float16 (GPU)")
    print(f"    LLM  : {llm_model} via {llm_url}  (GPU)  TTFT=first-token")
    print(f"    TTS  : Piper en_US-lessac-medium (CPU)  TTFB=first-PCM-chunk")

    PROMPT = ("You are a service robot. The operator said: 'move forward two meters "
              "then turn left'. Acknowledge in one short sentence.")
    REPLY = ("Okay, moving forward two meters now. "
             "Then I will turn left toward the doorway.")

    # ---- warmup (cold model-load + CUDA graph capture absorbed here) ----
    for _ in range(warmup):
        stt.run(wav)
        llm.run(PROMPT)
        for _c in tts.run(REPLY):
            pass

    stt_ms, llm_ttft, llm_full, tts_ttfb, tts_full = [], [], [], [], []
    rows = []
    with _UtilSampler() as smp:
        for i in range(n_trials):
            t = now(); stt.run(wav); d_stt = (now() - t) * 1000.0
            t = now(); _, first = llm.run(PROMPT); e = now()
            d_ttft = (first - t) * 1000.0 if first else (e - t) * 1000.0
            d_lful = (e - t) * 1000.0
            t = now(); fb = None
            for j, _chunk in enumerate(tts.run(REPLY)):
                if j == 0:
                    fb = now()
            e = now()
            d_ttfb = (fb - t) * 1000.0 if fb else (e - t) * 1000.0
            d_tful = (e - t) * 1000.0
            stt_ms.append(d_stt); llm_ttft.append(d_ttft); llm_full.append(d_lful)
            tts_ttfb.append(d_ttfb); tts_full.append(d_tful)
            rows.append(dict(i=i, stt=d_stt, llm_ttft=d_ttft, llm_full=d_lful,
                             tts_ttfb=d_ttfb, tts_full=d_tful))

    with open("full_per_inference.jsonl", "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")

    def line(name, data, target=None):
        p50, p95, mx = P(data, .50), P(data, .95), max(data)
        flag, tgs = "", "-"
        if target is not None:
            flag = "OK" if p95 <= target else "MISS"
            tgs = f"<{target:g}"
        print(f"    {name:<10}{len(data):>4}{p50:>11.1f}{p95:>11.1f}{mx:>11.1f}{tgs:>9}{flag:>6}")
        return p50, p95

    print(f"\n    {'stage':<10}{'n':>4}{'p50(ms)':>11}{'p95(ms)':>11}{'max(ms)':>11}"
          f"{'target':>9}{'':>6}")
    print("    " + "-" * 62)
    stt50, stt95 = line("stt", stt_ms, 300)          # G2c
    lt50, lt95 = line("llm_ttft", llm_ttft, 300)     # G2d
    lf50, lf95 = line("llm_full", llm_full)
    tb50, tb95 = line("tts_ttfb", tts_ttfb, 200)     # G2e
    tf50, tf95 = line("tts_full", tts_full)

    # ---- TTFR via the harness's own model (streamed=stt+llm_ttft+tts_ttfb) ----
    # D1 STT is BATCH (no partials -> stt_final == stt_full); STT partials are D2.
    print("\n    [TTFR @ p50]")
    ttfr_budget(dict(stt_final=stt50, llm_ttft=lt50, tts_ttfb=tb50,
                     stt_full=stt50, llm_full=lf50, tts_full=tf50), "ctx GPU (p50)")
    print("    [TTFR @ p95]")
    ttfr_budget(dict(stt_final=stt95, llm_ttft=lt95, tts_ttfb=tb95,
                     stt_full=stt95, llm_full=lf95, tts_full=tf95), "ctx GPU (p95)")

    cpu_mean, cpu_pk = _UtilSampler._mp(smp.cpu)
    gpu_mean, gpu_pk = _UtilSampler._mp(smp.gpu)
    vram_pk = max(smp.vram) if smp.vram else 0.0
    print(f"\n    GPU/CPU split: STT + LLM on GPU (cuda fp16); TTS(Piper) + VAD + gate on CPU.")
    print(f"    under load: CPU mean={cpu_mean:.0f}% peak={cpu_pk:.0f}%  |  "
          f"GPU mean={gpu_mean:.0f}% peak={gpu_pk:.0f}%  VRAM peak={vram_pk:.0f} MiB")

    ratio = 2192.0 / stt95 if stt95 else 0.0
    print(f"\n    STT GPU-vs-CPU (same 3.23s clip, small.en): "
          f"CPU p95 2192 ms -> GPU p95 {stt95:.0f} ms = {ratio:.1f}x faster")
    return dict(stt=(stt50, stt95), llm_ttft=(lt50, lt95), llm_full=(lf50, lf95),
                tts_ttfb=(tb50, tb95), tts_full=(tf50, tf95), ratio=ratio,
                cpu=(cpu_mean, cpu_pk), gpu=(gpu_mean, gpu_pk), vram_pk=vram_pk,
                clip_s=clip_s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["smoke", "full"], default="smoke")
    ap.add_argument("--vad-frames", type=int, default=300)
    ap.add_argument("--trials", type=int, default=60)
    ap.add_argument("--llm-model", default="qwen2.5:0.5b")
    ap.add_argument("--llm-url", default="http://127.0.0.1:11434/v1")
    args = ap.parse_args()

    print("=" * 68)
    print(f"NOVA voice-gate latency benchmark  (mode={args.mode})")
    print("=" * 68)

    ok = instrumentation_selfcheck()

    if args.mode == "smoke":
        try:
            vad = SileroVADOnnx(num_threads=1)
            print("    (real Silero VAD loaded)\n")
        except Exception as ex:
            print(f"    [warn] Silero load failed ({ex!r}); using MockVAD\n")
            vad = MockVAD()
        # G1c-DETECTION (2a): VAD must DISCRIMINATE, not just run fast. Required for
        # "VAD GREEN" alongside the latency gate (2b) -- timing alone is never a pass.
        det = None
        try:
            pos, neg = make_vad_labeled_set()
            det = bench_vad_detection(vad, pos, neg)
        except Exception as ex:
            print(f"[2a] VAD detection gate SKIPPED ({ex!r}); need audio/human_jfk_full.wav\n")
        bench_vad(vad, n_frames=args.vad_frames)
        bench_gate()
        budget_models()
        vad_ok = "PASS" if (det and det["passed"]) else ("FAIL" if det else "UNTESTED")
        print(f"RESULT: instrumentation={'PASS' if ok else 'FAIL'}; "
              f"VAD detection={vad_ok}; VAD+gate measured on CPU; "
              f"TTFR is a budget model pending ctx.")
    else:
        # instrumentation self-check (above) gates the measurement; then run real stages.
        bench_full(n_trials=args.trials, llm_model=args.llm_model, llm_url=args.llm_url)
        print(f"\nRESULT: instrumentation={'PASS' if ok else 'FAIL'}; "
              f"GPU per-stage + TTFR measured on ctx (RTX 3060).")


if __name__ == "__main__":
    main()
