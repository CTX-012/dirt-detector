"""Latency telemetry, done right.

Hard rule (the bug that bit the prototype): we STORE timestamps captured with
perf_counter() at exact moments, and COMPUTE durations as (end - start).
We never print a raw timestamp as if it were a duration.
"""
from __future__ import annotations
import time
import statistics
from contextlib import contextmanager
from collections import defaultdict, deque
from dataclasses import dataclass, field


def now() -> float:
    return time.perf_counter()


@dataclass
class TurnTrace:
    turn_id: int
    t_turn_start: float = 0.0     # user-silence detected -> T=0 for TTFR
    t_first_audio: float = 0.0    # first response audio reaches speaker
    t_stop_detected: float = 0.0  # STOP keyword fires
    t_stop_actuated: float = 0.0  # STOP intent emitted to motion layer
    t_gate_in: float = 0.0
    t_gate_out: float = 0.0
    stages: dict = field(default_factory=dict)  # name -> duration_ms

    @staticmethod
    def _ms(a: float, b: float) -> float:
        return (b - a) * 1000.0 if (a > 0 and b > 0 and b >= a) else 0.0

    @property
    def ttfr_ms(self) -> float:          # voice-to-voice (mouth-to-ear)
        return self._ms(self.t_turn_start, self.t_first_audio)

    @property
    def stop_reaction_ms(self) -> float:  # safety-critical number
        return self._ms(self.t_stop_detected, self.t_stop_actuated)

    @property
    def gate_ms(self) -> float:           # attention-gate decision
        return self._ms(self.t_gate_in, self.t_gate_out)


class Recorder:
    def __init__(self):
        self.traces: list[TurnTrace] = []
        self._cur: TurnTrace | None = None
        self._win: dict[str, deque] = defaultdict(lambda: deque(maxlen=500))

    def start_turn(self, tid: int) -> TurnTrace:
        self._cur = TurnTrace(turn_id=tid, t_turn_start=now())
        return self._cur

    @contextmanager
    def stage(self, name: str):
        t0 = now()
        try:
            yield
        finally:
            d = (now() - t0) * 1000.0
            if self._cur:
                self._cur.stages[name] = self._cur.stages.get(name, 0.0) + d
            self._win[name].append(d)

    def mark(self, attr: str):
        if self._cur:
            setattr(self._cur, attr, now())

    def end_turn(self):
        if not self._cur:
            return
        c = self._cur
        self._win["ttfr"].append(c.ttfr_ms)
        if c.stop_reaction_ms:
            self._win["stop_reaction"].append(c.stop_reaction_ms)
        if c.gate_ms:
            self._win["gate"].append(c.gate_ms)
        self.traces.append(c)
        self._cur = None

    @staticmethod
    def _pct(d: list[float], p: float) -> float:
        if not d:
            return 0.0
        s = sorted(d)
        return s[min(int(len(s) * p), len(s) - 1)]

    def summary(self) -> dict:
        out = {}
        for k, dq in self._win.items():
            d = list(dq)
            out[k] = dict(
                n=len(d),
                p50=self._pct(d, 0.50),
                p95=self._pct(d, 0.95),
                mean=statistics.mean(d) if d else 0.0,
                mx=max(d) if d else 0.0,
            )
        return out

    def print_table(self, targets: dict | None = None):
        targets = targets or {}
        s = self.summary()
        print(f"{'stage':<16}{'n':>5}{'p50(ms)':>10}{'p95(ms)':>10}{'max(ms)':>10}{'target':>10}{'':>7}")
        print("-" * 68)
        for k in sorted(s):
            v = s[k]
            tg = targets.get(k)
            flag = ""
            if tg is not None:
                flag = "OK" if v["p95"] <= tg else "MISS"
                tgs = f"<{tg:g}"
            else:
                tgs = "-"
            print(f"{k:<16}{v['n']:>5}{v['p50']:>10.2f}{v['p95']:>10.2f}{v['mx']:>10.2f}{tgs:>10}{flag:>7}")
