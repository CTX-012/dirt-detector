"""Attention / safety gate — finite state machine.

Design (from the Day-1 doc + this thread):
  - deny-by-default; silence is correct behaviour
  - STOP keyword bypasses EVERYTHING (separate always-on path)
  - one human owns the turn at a time; bystander cross-talk is ignored
  - vision (ASD/orientation) and any LLM signal can only VETO DOWN, never grant
  - ambiguous / low-confidence -> UNKNOWN (a success, not a failure)

This module is pure logic: no audio, no models. It is what makes NOVA's
voice layer different from a conversational framework, and it is fully
unit-testable (see test_gate.py).
"""
from __future__ import annotations
from enum import Enum
from dataclasses import dataclass


class Decision(str, Enum):
    DENY = "DENY"       # not for me / not allowed -> do nothing
    GRANT = "GRANT"     # addressed, listening / accept command
    STOP = "STOP"       # emergency stop, immediate
    UNKNOWN = "UNKNOWN" # addressed but unresolved -> reject, no action


class State(str, Enum):
    IDLE = "IDLE"
    OWNED = "OWNED"


SAFE_INTENTS = {"STOP", "WAIT", "CANCEL"}
MOTION_INTENTS = {"MOVE", "TURN"}


@dataclass
class FrameEvent:
    t: float                         # perf_counter timestamp
    is_speech: bool = False
    wake: bool = False               # wake-word spotter hit ("Nova")
    stop_kw: bool = False            # always-on STOP keyword hit
    speaker_id: str | None = None    # target-speaker VAD / diarization id
    n_speakers: int = 0              # overlap detector
    intent: str | None = None        # resolved only after STT+intent
    confidence: float = 0.0
    visual_addressed: bool | None = None  # ASD/orientation; None=unknown


@dataclass
class GateConfig:
    ownership_timeout_s: float = 2.5
    min_conf: float = 0.6


class AttentionGate:
    def __init__(self, cfg: GateConfig | None = None):
        self.cfg = cfg or GateConfig()
        self.reset()

    def reset(self):
        self.state = State.IDLE
        self.owner: str | None = None
        self._last_owner_speech = 0.0

    def step(self, e: FrameEvent) -> Decision:
        # 1) STOP always wins, bypasses STT/LLM/ownership/vision
        if e.stop_kw or e.intent == "STOP":
            self.reset()
            return Decision.STOP

        # 2) ownership expiry on silence
        if self.state == State.OWNED and (e.t - self._last_owner_speech) > self.cfg.ownership_timeout_s:
            self.reset()

        # 3) IDLE: only wake-word + single speaker grants attention
        if self.state == State.IDLE:
            if not e.wake:
                return Decision.DENY            # ambient / not addressed
            if e.n_speakers > 1:
                return Decision.DENY            # overlapping speakers
            if e.visual_addressed is False:
                return Decision.DENY            # vision says not to me
            self.state = State.OWNED
            self.owner = e.speaker_id
            self._last_owner_speech = e.t
            return Decision.GRANT

        # 4) OWNED: only the owner continues
        if e.speaker_id is not None and e.speaker_id != self.owner:
            return Decision.DENY                # different speaker ignored
        if e.is_speech:
            self._last_owner_speech = e.t
        if e.intent is None:
            return Decision.GRANT               # keep listening

        # 5) intent validation (permission, not reasoning)
        if e.intent in SAFE_INTENTS:
            return Decision.GRANT
        if e.intent in MOTION_INTENTS:
            if e.confidence >= self.cfg.min_conf and e.visual_addressed is not False:
                return Decision.GRANT
            return Decision.UNKNOWN
        return Decision.UNKNOWN                 # ambiguous / unknown intent
