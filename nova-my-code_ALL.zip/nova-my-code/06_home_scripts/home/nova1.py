#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════════════╗
║                          NOVA MASTER v4.0                                             ║
║                    "The Sentient Sovereign Explorer"                                  ║
╠══════════════════════════════════════════════════════════════════════════════════════╣
║  Platform: TurtleBot3 Waffle Pi | World: turtlebot3_house (Gazebo)                   ║
║  Architecture: Hierarchical Deliberative-Reactive Control                             ║
╠══════════════════════════════════════════════════════════════════════════════════════╣
║  FEATURES:                                                                            ║
║    ✓ 8-Sector LiDAR Spatial Analysis                                                 ║
║    ✓ Roomba-Style State Machine (Spiral→Wall→Door→Room→Recovery)                    ║
║    ✓ UHD Tactical HUD with:                                                          ║
║        • Mission Path Memory (2D Trail Map)                                          ║
║        • LiDAR Radar Visualization                                                   ║
║        • VLM Thoughts & Suggested Actions                                            ║
║        • Real-time Pose (X, Y, Yaw)                                                  ║
║        • Object Inventory (>50% confidence)                                          ║
║    ✓ YOLO Detection with 50% Confidence Guard                                        ║
║    ✓ Async VLM Scene Understanding (Llama 4 Maverick)                                ║
║    ✓ Nudge Door Verification (Physical Confirmation)                                 ║
║    ✓ PID Wall Following (Right-Hand Rule)                                            ║
║    ✓ 3-Strike Stuck Detection & Recovery                                             ║
║    ✓ Void Escape Protocol                                                            ║
║    ✓ JSON Memory Persistence                                                         ║
║    ✓ Mission-Critical Terminal Logging                                               ║
╚══════════════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import math
import time
import base64
import threading
from enum import Enum
from dataclasses import dataclass, field
from collections import deque
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

# ROS 2 Imports
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge

# AI Imports
from ultralytics import YOLO
from groq import Groq

# ══════════════════════════════════════════════════════════════════════════════
# HUMBLE COMPATIBILITY FIX
# ══════════════════════════════════════════════════════════════════════════════
np.float_ = float  # Fix NumPy 2.x vs cv_bridge issue


# ══════════════════════════════════════════════════════════════════════════════
# ENUMS & DATA CLASSES
# ══════════════════════════════════════════════════════════════════════════════

class RobotState(Enum):
    """Roomba-inspired hierarchical state machine"""
    SPAWN_SCAN = "SPAWN_RECON"              # Initial 360° reconnaissance
    SPIRAL = "SPIRAL_EXPANSION"              # Outward spiral to find walls
    WALL_FOLLOW = "WALL_PERIMETER"           # Follow wall (right-hand rule)
    DOOR_VERIFY = "DOOR_NUDGE_CHECK"         # Physical nudge verification
    ENTER_ROOM = "ROOM_TRANSITION"           # Enter through doorway
    ROOM_CROSS = "ROOM_COVERAGE"             # Crisscross interior coverage
    RECOVERY = "STUCK_ESCAPE"                # Tactical recovery mode
    VOID_ESCAPE = "VOID_FLIGHT"              # Escaping featureless void


@dataclass
class LidarSectors:
    """8-direction LiDAR spatial awareness"""
    front: float = 10.0
    front_left: float = 10.0
    left: float = 10.0
    back_left: float = 10.0
    back: float = 10.0
    back_right: float = 10.0
    right: float = 10.0
    front_right: float = 10.0
    
    def to_dict(self) -> Dict[str, float]:
        return {
            'F': self.front, 'FL': self.front_left, 'L': self.left,
            'BL': self.back_left, 'B': self.back, 'BR': self.back_right,
            'R': self.right, 'FR': self.front_right
        }
    
    def min_front_arc(self) -> float:
        return min(self.front, self.front_left, self.front_right)
    
    def max_sector(self) -> Tuple[str, float]:
        sectors = self.to_dict()
        best = max(sectors, key=sectors.get)
        return best, sectors[best]
    
    def all_infinite(self, threshold: float = 8.0) -> bool:
        """Check if we're in a void (no walls detected)"""
        return all(v > threshold for v in [
            self.front, self.front_left, self.left, 
            self.right, self.front_right, self.back
        ])


@dataclass
class RobotPose:
    """Robot position and orientation"""
    x: float = 0.0
    y: float = 0.0
    yaw: float = 0.0
    
    def yaw_degrees(self) -> float:
        return math.degrees(self.yaw) % 360
    
    def distance_to(self, other_x: float, other_y: float) -> float:
        return math.sqrt((self.x - other_x)**2 + (self.y - other_y)**2)
    
    def copy(self) -> 'RobotPose':
        return RobotPose(x=self.x, y=self.y, yaw=self.yaw)


@dataclass
class VLMResponse:
    """Parsed VLM analysis response"""
    scene_type: str = "unknown"
    room_guess: str = "unknown"
    density: str = "unknown"
    door_visible: bool = False
    door_direction: str = "NONE"
    wall_visible: bool = True
    floor_clear: bool = True
    suggested_action: str = "FORWARD"
    raw_text: str = ""
    timestamp: float = 0.0


@dataclass
class DetectedObject:
    """YOLO detected object with confidence > 50%"""
    label: str
    confidence: float
    bbox: Tuple[int, int, int, int]
    world_x: float = 0.0
    world_y: float = 0.0
    timestamp: float = 0.0


@dataclass 
class VisitedCell:
    """Grid cell for coverage tracking"""
    x: int
    y: int
    visit_count: int = 1
    first_visit: float = 0.0


# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════

class Config:
    """All tunable parameters - Waffle Pi optimized"""
    
    # ─── Waffle Pi Physical Limits ───
    MAX_LINEAR_SPEED = 0.26      # m/s (Waffle Pi max)
    MAX_ANGULAR_SPEED = 1.82     # rad/s (Waffle Pi max)
    
    # ─── Operational Speeds ───
    SPIRAL_SPEED = 0.20
    WALL_FOLLOW_SPEED = 0.18
    INTERIOR_SPEED = 0.15
    NUDGE_SPEED = 0.10
    RECOVERY_SPEED = 0.12
    
    TURN_SPEED = 0.5
    FAST_TURN_SPEED = 0.8
    SLOW_TURN_SPEED = 0.35
    
    # ─── Wall Following PID ───
    WALL_TARGET_DIST = 0.5
    WALL_PID_KP = 1.2
    WALL_PID_KI = 0.0
    WALL_PID_KD = 0.4
    
    # ─── Door Detection ───
    DOOR_GAP_MIN = 0.7
    DOOR_GAP_MAX = 2.5
    DOOR_DEPTH_MIN = 1.2
    NUDGE_DISTANCE = 0.35
    NUDGE_GAP_INCREASE = 0.4
    
    # ─── Safety Thresholds ───
    EMERGENCY_STOP_DIST = 0.35
    CAUTION_DIST = 0.65
    VOID_THRESHOLD = 8.0
    
    # ─── Stuck Detection ───
    STUCK_CHECK_INTERVAL = 3.0
    STUCK_MOVE_THRESHOLD = 0.08
    STUCK_STRIKES_MAX = 3
    
    # ─── Coverage Grid ───
    CELL_SIZE = 0.25
    
    # ─── VLM Settings ───
    VLM_INTERVAL = 6.0
    VLM_TIMEOUT = 12.0
    VLM_MODEL = "meta-llama/llama-4-maverick-17b-128e-instruct"
    
    # ─── YOLO Settings ───
    YOLO_MODEL = "yolov8n.pt"
    YOLO_CONF_THRESHOLD = 0.50
    
    # ─── Spiral Parameters ───
    SPIRAL_ANGULAR_START = 0.5
    SPIRAL_EXPANSION_RATE = 0.02
    SPIRAL_MAX_TIME = 20.0
    
    # ─── HUD Settings ───
    HUD_WIDTH = 380
    MAP_RADIUS = 100
    MAP_SCALE = 20.0  # pixels per meter
    RADAR_RADIUS = 55
    
    # ─── Colors (BGR) ───
    COLOR_TITLE = (0, 255, 255)      # Yellow
    COLOR_TEXT = (220, 220, 220)     # Light grey
    COLOR_ALERT = (0, 0, 255)        # Red
    COLOR_OK = (0, 255, 0)           # Green
    COLOR_WARN = (0, 165, 255)       # Orange
    COLOR_VOID = (255, 0, 255)       # Magenta
    COLOR_PATH = (0, 200, 0)         # Trail green
    COLOR_ROBOT = (255, 255, 0)      # Cyan
    COLOR_DOOR = (255, 200, 0)       # Light blue


# ══════════════════════════════════════════════════════════════════════════════
# VLM PROMPT
# ══════════════════════════════════════════════════════════════════════════════

VLM_PROMPT = """You are the visual cortex of an autonomous cleaning robot.
Analyze this camera image and return ONLY valid JSON (no markdown):

{
  "scene_type": "room" | "corridor" | "void" | "doorway",
  "room_guess": "bedroom" | "kitchen" | "bathroom" | "living_room" | "hallway" | "unknown",
  "density": "empty" | "sparse" | "medium" | "cluttered",
  "door_visible": true | false,
  "door_direction": "LEFT" | "RIGHT" | "FRONT" | "NONE",
  "wall_visible": true | false,
  "floor_clear": true | false,
  "suggested_action": "FORWARD" | "TURN_LEFT" | "TURN_RIGHT" | "STOP" | "BACKUP"
}

Rules:
- "void" = featureless grey area (simulation artifact)
- "doorway" = visible opening to another space
- Be concise. JSON only."""


# ══════════════════════════════════════════════════════════════════════════════
# MAIN NODE CLASS
# ══════════════════════════════════════════════════════════════════════════════

class NovaMasterV4(Node):
    """
    NOVA MASTER v4.0 - The Sentient Sovereign Explorer
    Combined intelligence from v2 and v3
    """
    
    def __init__(self):
        super().__init__('nova_master_v4')
        self._print_banner()
        
        # ─── Core Components ───
        self.bridge = CvBridge()
        self.yolo = YOLO(Config.YOLO_MODEL)
        self.groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        
        # ─── State Machine ───
        self.state = RobotState.SPAWN_SCAN
        self.previous_state = None
        self.state_start_time = time.time()
        self.spawn_scan_count = 0
        
        # ─── Sensor Data ───
        self.lidar = LidarSectors()
        self.pose = RobotPose()
        self.current_frame: Optional[np.ndarray] = None
        
        # ─── VLM State ───
        self.vlm_response = VLMResponse()
        self.last_vlm_time = 0.0
        self.vlm_lock = threading.Lock()
        self.vlm_thread: Optional[threading.Thread] = None
        
        # ─── YOLO State ───
        self.detected_objects: List[DetectedObject] = []
        self.object_inventory: Dict[str, float] = {}  # label -> max confidence
        self.yolo_annotated_frame: Optional[np.ndarray] = None
        
        # ─── Navigation Memory ───
        self.path_memory: deque = deque(maxlen=3000)  # Mission trail
        self.visited_cells: Dict[Tuple[int, int], VisitedCell] = {}
        self.door_history: List[Tuple[float, float, str]] = []
        
        # ─── Stuck Detection ───
        self.last_pose_check = RobotPose()
        self.last_pose_check_time = time.time()
        self.stuck_counter = 0
        
        # ─── Spiral State ───
        self.spiral_angular = Config.SPIRAL_ANGULAR_START
        
        # ─── Wall Follow PID ───
        self.wall_pid_integral = 0.0
        self.wall_pid_last_error = 0.0
        
        # ─── Door Verification ───
        self.door_verify_start_lidar: Optional[LidarSectors] = None
        self.door_verify_direction = "NONE"
        self.nudge_start_pose: Optional[RobotPose] = None
        
        # ─── Mission Stats ───
        self.mission_start_time = time.time()
        self.rooms_entered = 0
        self.doors_verified = 0
        
        # ─── QoS Profiles ───
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # ─── ROS Subscribers ───
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.lidar_callback, sensor_qos
        )
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10
        )
        self.img_sub = self.create_subscription(
            Image, '/camera/image_raw', self.camera_callback, sensor_qos
        )
        
        # ─── ROS Publisher ───
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # ─── Timers ───
        self.control_timer = self.create_timer(0.1, self.control_loop)  # 10 Hz
        self.stuck_timer = self.create_timer(Config.STUCK_CHECK_INTERVAL, self.check_stuck)
        self.log_timer = self.create_timer(2.0, self.terminal_mission_log)  # 0.5 Hz
        
        self.get_logger().info("✅ All systems initialized!")
        self.get_logger().info(f"   Initial State: {self.state.value}")
    
    def _print_banner(self):
        """Print startup banner"""
        banner = """
╔══════════════════════════════════════════════════════════════════╗
║                    NOVA MASTER v4.0                               ║
║              "The Sentient Sovereign Explorer"                    ║
║                                                                   ║
║   Platform: TurtleBot3 Waffle Pi | World: turtlebot3_house       ║
║   VLM: Llama 4 Maverick | Vision: YOLOv8n                        ║
╚══════════════════════════════════════════════════════════════════╝
        """
        print(banner)
    
    # ══════════════════════════════════════════════════════════════════════════
    # SENSOR CALLBACKS
    # ══════════════════════════════════════════════════════════════════════════
    
    def lidar_callback(self, msg: LaserScan):
        """Process 360° LiDAR into 8 directional sectors"""
        ranges = np.array(msg.ranges)
        ranges = np.where((ranges < 0.1) | (ranges > 100) | np.isnan(ranges), 10.0, ranges)
        n = len(ranges)
        
        def sector_min(start_deg: int, end_deg: int) -> float:
            start_idx = int((start_deg / 360) * n)
            end_idx = int((end_deg / 360) * n)
            if start_idx > end_idx:
                sector = np.concatenate([ranges[start_idx:], ranges[:end_idx]])
            else:
                sector = ranges[start_idx:end_idx]
            valid = sector[(sector > 0.1) & (sector < 50)]
            return float(np.min(valid)) if len(valid) > 0 else 10.0
        
        self.lidar.front = sector_min(350, 10)
        self.lidar.front_right = sector_min(10, 55)
        self.lidar.right = sector_min(55, 125)
        self.lidar.back_right = sector_min(125, 170)
        self.lidar.back = sector_min(170, 190)
        self.lidar.back_left = sector_min(190, 235)
        self.lidar.left = sector_min(235, 305)
        self.lidar.front_left = sector_min(305, 350)
    
    def odom_callback(self, msg: Odometry):
        """Update robot pose from odometry"""
        self.pose.x = msg.pose.pose.position.x
        self.pose.y = msg.pose.pose.position.y
        
        q = msg.pose.pose.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.pose.yaw = math.atan2(siny_cosp, cosy_cosp)
        
        # Store path for visualization
        self.path_memory.append((self.pose.x, self.pose.y))
        
        # Update visited cells
        self._update_visited_cells()
    
    def camera_callback(self, msg: Image):
        """Process camera frame with YOLO and prepare for VLM"""
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            self.current_frame = frame.copy()
            
            # ─── YOLO Detection (50% threshold) ───
            results = self.yolo(frame, conf=Config.YOLO_CONF_THRESHOLD, verbose=False)
            
            self.detected_objects = []
            for box in results[0].boxes:
                conf = float(box.conf[0])
                if conf >= Config.YOLO_CONF_THRESHOLD:
                    label = self.yolo.names[int(box.cls[0])]
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    
                    obj = DetectedObject(
                        label=label,
                        confidence=conf,
                        bbox=(x1, y1, x2, y2),
                        timestamp=time.time()
                    )
                    self.detected_objects.append(obj)
                    
                    # Update inventory with highest confidence
                    if label not in self.object_inventory or conf > self.object_inventory[label]:
                        self.object_inventory[label] = conf
                        self.get_logger().info(
                            f"[YOLO] 🎯 {label.upper()} detected ({conf*100:.0f}%)"
                        )
            
            # Print current detections
            if self.detected_objects:
                obj_str = " | ".join([
                    f"{o.label}({o.confidence*100:.0f}%)" 
                    for o in self.detected_objects[:5]
                ])
                self.get_logger().info(f"[VISION] {obj_str}")
            
            self.yolo_annotated_frame = results[0].plot()
            
            # ─── Trigger VLM (async, rate-limited) ───
            now = time.time()
            if now - self.last_vlm_time > Config.VLM_INTERVAL:
                if self.vlm_thread is None or not self.vlm_thread.is_alive():
                    self.vlm_thread = threading.Thread(
                        target=self._call_vlm_async,
                        args=(frame.copy(),),
                        daemon=True
                    )
                    self.vlm_thread.start()
                    self.last_vlm_time = now
            
            # ─── Render HUD ───
            self._render_tactical_hud()
            
        except Exception as e:
            self.get_logger().error(f"Camera error: {e}")
    
    # ══════════════════════════════════════════════════════════════════════════
    # VLM INTEGRATION
    # ══════════════════════════════════════════════════════════════════════════
    
    def _call_vlm_async(self, frame: np.ndarray):
        """Call VLM in background thread"""
        try:
            _, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
            img_b64 = base64.b64encode(buf).decode('utf-8')
            
            response = self.groq_client.chat.completions.create(
                model=Config.VLM_MODEL,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": VLM_PROMPT},
                        {"type": "image_url", "image_url": {
                            "url": f"data:image/jpeg;base64,{img_b64}"
                        }}
                    ]
                }],
                timeout=Config.VLM_TIMEOUT
            )
            
            raw_text = response.choices[0].message.content.strip()
            parsed = self._parse_vlm_json(raw_text)
            
            with self.vlm_lock:
                self.vlm_response = parsed
                self.vlm_response.raw_text = raw_text
                self.vlm_response.timestamp = time.time()
            
            self.get_logger().info(
                f"[VLM] 🧠 {parsed.scene_type} | {parsed.room_guess} | "
                f"Door:{parsed.door_direction} | Act:{parsed.suggested_action}"
            )
            
        except Exception as e:
            self.get_logger().warn(f"[VLM] Error: {e}")
    
    def _parse_vlm_json(self, raw: str) -> VLMResponse:
        """3-tier JSON extraction with fallbacks"""
        import re
        
        # Tier 1: Direct parse
        try:
            data = json.loads(raw)
            return self._dict_to_vlm(data)
        except:
            pass
        
        # Tier 2: Regex extract
        match = re.search(r'\{[^{}]*\}', raw, re.DOTALL)
        if match:
            try:
                data = json.loads(match.group())
                return self._dict_to_vlm(data)
            except:
                pass
        
        # Tier 3: Brace counting
        start = raw.find('{')
        if start != -1:
            depth = 0
            for i, c in enumerate(raw[start:], start):
                if c == '{': depth += 1
                elif c == '}':
                    depth -= 1
                    if depth == 0:
                        try:
                            data = json.loads(raw[start:i+1])
                            return self._dict_to_vlm(data)
                        except:
                            break
        
        # Fallback: keyword detection
        result = VLMResponse()
        raw_lower = raw.lower()
        if "void" in raw_lower:
            result.scene_type = "void"
        elif "door" in raw_lower:
            result.door_visible = True
            if "left" in raw_lower:
                result.door_direction = "LEFT"
            elif "right" in raw_lower:
                result.door_direction = "RIGHT"
        
        return result
    
    def _dict_to_vlm(self, data: dict) -> VLMResponse:
        return VLMResponse(
            scene_type=data.get("scene_type", "unknown"),
            room_guess=data.get("room_guess", "unknown"),
            density=data.get("density", "unknown"),
            door_visible=data.get("door_visible", False),
            door_direction=data.get("door_direction", "NONE"),
            wall_visible=data.get("wall_visible", True),
            floor_clear=data.get("floor_clear", True),
            suggested_action=data.get("suggested_action", "FORWARD")
        )
    
    # ══════════════════════════════════════════════════════════════════════════
    # TACTICAL HUD RENDERING
    # ══════════════════════════════════════════════════════════════════════════
    
    def _render_tactical_hud(self):
        """Render comprehensive tactical HUD with map and radar"""
        if self.yolo_annotated_frame is None:
            return
        
        frame = self.yolo_annotated_frame.copy()
        h, w = frame.shape[:2]
        
        # Create dark sidebar
        hud = np.zeros((h, Config.HUD_WIDTH, 3), dtype=np.uint8)
        hud[:] = (25, 25, 25)
        
        y = 20
        
        def text(txt: str, color=Config.COLOR_TEXT, scale=0.5, thick=1):
            nonlocal y
            cv2.putText(hud, txt, (12, y), cv2.FONT_HERSHEY_SIMPLEX, scale, color, thick)
            y += 22
        
        def divider():
            nonlocal y
            cv2.line(hud, (10, y), (Config.HUD_WIDTH - 10, y), (60, 60, 60), 1)
            y += 8
        
        # ═══ HEADER ═══
        text("NOVA MASTER v4.0", Config.COLOR_TITLE, 0.6, 2)
        divider()
        
        # ═══ STATE ═══
        state_color = Config.COLOR_ALERT if self.state == RobotState.RECOVERY else Config.COLOR_OK
        text(f"STATE: {self.state.value}", state_color, 0.45, 1)
        elapsed = time.time() - self.state_start_time
        text(f"  Duration: {elapsed:.1f}s", Config.COLOR_TEXT, 0.4)
        divider()
        
        # ═══ MISSION PATH MAP ═══
        map_center = (Config.HUD_WIDTH // 2, y + Config.MAP_RADIUS + 10)
        cv2.circle(hud, map_center, Config.MAP_RADIUS + 5, (40, 40, 40), -1)
        cv2.circle(hud, map_center, Config.MAP_RADIUS + 5, (80, 80, 80), 1)
        
        # Draw path trail
        for px, py in self.path_memory:
            screen_x = int(map_center[0] + px * Config.MAP_SCALE)
            screen_y = int(map_center[1] - py * Config.MAP_SCALE)
            if 0 < screen_x < Config.HUD_WIDTH and map_center[1] - Config.MAP_RADIUS < screen_y < map_center[1] + Config.MAP_RADIUS:
                cv2.circle(hud, (screen_x, screen_y), 1, Config.COLOR_PATH, -1)
        
        # Draw robot position
        robot_x = int(map_center[0] + self.pose.x * Config.MAP_SCALE)
        robot_y = int(map_center[1] - self.pose.y * Config.MAP_SCALE)
        cv2.circle(hud, (robot_x, robot_y), 4, Config.COLOR_ROBOT, -1)
        
        # Draw heading arrow
        arrow_len = 12
        arrow_x = int(robot_x + arrow_len * math.cos(self.pose.yaw))
        arrow_y = int(robot_y - arrow_len * math.sin(self.pose.yaw))
        cv2.arrowedLine(hud, (robot_x, robot_y), (arrow_x, arrow_y), Config.COLOR_ROBOT, 2)
        
        y = map_center[1] + Config.MAP_RADIUS + 20
        text("MISSION PATH MEMORY", Config.COLOR_TEXT, 0.4)
        divider()
        
        # ═══ VLM ANALYSIS ═══
        text("VLM ANALYSIS:", Config.COLOR_TITLE, 0.45)
        with self.vlm_lock:
            vlm = self.vlm_response
        text(f"  Scene: {vlm.scene_type}", Config.COLOR_TEXT, 0.4)
        text(f"  Room: {vlm.room_guess}", Config.COLOR_TEXT, 0.4)
        text(f"  Density: {vlm.density}", Config.COLOR_TEXT, 0.4)
        door_color = Config.COLOR_DOOR if vlm.door_visible else Config.COLOR_TEXT
        text(f"  Door: {vlm.door_direction}", door_color, 0.4)
        text(f"  Action: {vlm.suggested_action}", Config.COLOR_OK, 0.4)
        divider()
        
        # ═══ POSE ═══
        text("ROBOT POSE:", Config.COLOR_TITLE, 0.45)
        text(f"  X: {self.pose.x:+.2f} m", Config.COLOR_TEXT, 0.4)
        text(f"  Y: {self.pose.y:+.2f} m", Config.COLOR_TEXT, 0.4)
        text(f"  Yaw: {self.pose.yaw_degrees():.0f}°", Config.COLOR_TEXT, 0.4)
        divider()
        
        # ═══ LIDAR RADAR ═══
        radar_center = (Config.HUD_WIDTH // 2, y + Config.RADAR_RADIUS + 15)
        cv2.circle(hud, radar_center, Config.RADAR_RADIUS, (50, 50, 50), -1)
        cv2.circle(hud, radar_center, Config.RADAR_RADIUS, (80, 80, 80), 1)
        
        # Draw sector lines
        sectors = self.lidar.to_dict()
        angles = {'F': 90, 'FR': 45, 'R': 0, 'BR': -45, 'B': -90, 'BL': -135, 'L': 180, 'FL': 135}
        
        for name, dist in sectors.items():
            ang_rad = math.radians(angles[name])
            length = min(Config.RADAR_RADIUS - 5, dist * 12)
            end_x = int(radar_center[0] + length * math.cos(ang_rad))
            end_y = int(radar_center[1] - length * math.sin(ang_rad))
            
            color = Config.COLOR_ALERT if dist < Config.CAUTION_DIST else Config.COLOR_OK
            cv2.line(hud, radar_center, (end_x, end_y), color, 2)
            
            # Label
            label_x = int(radar_center[0] + (Config.RADAR_RADIUS + 8) * math.cos(ang_rad))
            label_y = int(radar_center[1] - (Config.RADAR_RADIUS + 8) * math.sin(ang_rad))
            cv2.putText(hud, f"{dist:.1f}", (label_x - 12, label_y + 4), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.3, color, 1)
        
        # Robot marker in center
        cv2.circle(hud, radar_center, 3, Config.COLOR_ROBOT, -1)
        
        y = radar_center[1] + Config.RADAR_RADIUS + 20
        text("LIDAR SPATIAL RADAR", Config.COLOR_TEXT, 0.4)
        divider()
        
        # ═══ COVERAGE STATS ═══
        text("MISSION STATS:", Config.COLOR_TITLE, 0.45)
        text(f"  Cells: {len(self.visited_cells)}", Config.COLOR_TEXT, 0.4)
        text(f"  Rooms: {self.rooms_entered}", Config.COLOR_TEXT, 0.4)
        text(f"  Stuck: {self.stuck_counter}/{Config.STUCK_STRIKES_MAX}", Config.COLOR_TEXT, 0.4)
        mission_time = time.time() - self.mission_start_time
        text(f"  Time: {mission_time:.0f}s", Config.COLOR_TEXT, 0.4)
        divider()
        
        # ═══ OBJECT INVENTORY ═══
        text("OBJECTS (>50%):", Config.COLOR_TITLE, 0.45)
        if self.object_inventory:
            for label, conf in list(self.object_inventory.items())[-5:]:
                conf_color = Config.COLOR_OK if conf > 0.7 else Config.COLOR_TEXT
                text(f"  • {label}: {conf*100:.0f}%", conf_color, 0.4)
        else:
            text("  None detected", Config.COLOR_TEXT, 0.4)
        divider()
        
        # ═══ STATUS INDICATOR ═══
        if self.lidar.front < Config.EMERGENCY_STOP_DIST:
            text("!! EMERGENCY STOP !!", Config.COLOR_ALERT, 0.5, 2)
        elif self.lidar.front < Config.CAUTION_DIST:
            text("! CAUTION - OBSTACLE !", Config.COLOR_WARN, 0.45)
        elif self.lidar.all_infinite():
            text("~ VOID DETECTED ~", Config.COLOR_VOID, 0.45)
        elif self.state == RobotState.RECOVERY:
            text(">> RECOVERY MODE <<", Config.COLOR_WARN, 0.45)
        else:
            text("STATUS: NOMINAL", Config.COLOR_OK, 0.45)
        
        # Combine and display
        combined = np.hstack([frame, hud])
        cv2.imshow("NOVA MASTER v4.0 - Mission Control", combined)
        cv2.waitKey(1)
    
    # ══════════════════════════════════════════════════════════════════════════
    # TERMINAL LOGGING
    # ══════════════════════════════════════════════════════════════════════════
    
    def terminal_mission_log(self):
        """Periodic mission log to terminal"""
        t = time.strftime("%H:%M:%S")
        pos = f"[{self.pose.x:+.2f}, {self.pose.y:+.2f}]"
        yaw = f"{self.pose.yaw_degrees():.0f}°"
        lidar_f = f"F:{self.lidar.front:.2f}"
        
        self.get_logger().info(
            f"📍 {t} | POS:{pos} | YAW:{yaw} | {lidar_f} | "
            f"STATE:{self.state.name} | CELLS:{len(self.visited_cells)}"
        )
    
    # ══════════════════════════════════════════════════════════════════════════
    # CONTROL LOOP (STATE MACHINE)
    # ══════════════════════════════════════════════════════════════════════════
    
    def control_loop(self):
        """Main control loop - 10 Hz"""
        twist = Twist()
        
        # ─── REFLEX LAYER: Emergency Override ───
        if self.lidar.front < Config.EMERGENCY_STOP_DIST:
            self.get_logger().warn("[REFLEX] 🚨 Emergency stop!")
            twist.linear.x = 0.0
            # Turn toward clearer side
            twist.angular.z = Config.TURN_SPEED if self.lidar.left > self.lidar.right else -Config.TURN_SPEED
            self.cmd_pub.publish(twist)
            return
        
        # ─── VOID Detection Override ───
        if self.lidar.all_infinite() and self.state not in [RobotState.VOID_ESCAPE, RobotState.RECOVERY]:
            self.get_logger().warn("[VOID] Entering void escape mode")
            self._change_state(RobotState.VOID_ESCAPE)
        
        # ─── STATE MACHINE ───
        if self.state == RobotState.SPAWN_SCAN:
            twist = self._state_spawn_scan()
        elif self.state == RobotState.SPIRAL:
            twist = self._state_spiral()
        elif self.state == RobotState.WALL_FOLLOW:
            twist = self._state_wall_follow()
        elif self.state == RobotState.DOOR_VERIFY:
            twist = self._state_door_verify()
        elif self.state == RobotState.ENTER_ROOM:
            twist = self._state_enter_room()
        elif self.state == RobotState.ROOM_CROSS:
            twist = self._state_room_cross()
        elif self.state == RobotState.RECOVERY:
            twist = self._state_recovery()
        elif self.state == RobotState.VOID_ESCAPE:
            twist = self._state_void_escape()
        
        self.cmd_pub.publish(twist)
    
    # ══════════════════════════════════════════════════════════════════════════
    # STATE IMPLEMENTATIONS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _state_spawn_scan(self) -> Twist:
        """Initial 360° reconnaissance"""
        twist = Twist()
        
        if self.spawn_scan_count < 4:
            twist.angular.z = Config.SLOW_TURN_SPEED
            
            elapsed = time.time() - self.state_start_time
            rotation_time = (math.pi / 2) / Config.SLOW_TURN_SPEED
            
            if elapsed > rotation_time * (self.spawn_scan_count + 1):
                self.spawn_scan_count += 1
                self.get_logger().info(f"[SPAWN] 🔄 Scan {self.spawn_scan_count}/4 complete")
        else:
            self.get_logger().info("[SPAWN] ✅ 360° recon complete → SPIRAL")
            self._change_state(RobotState.SPIRAL)
        
        return twist
    
    def _state_spiral(self) -> Twist:
        """Outward spiral to find walls"""
        twist = Twist()
        
        # Found wall?
        if self.lidar.min_front_arc() < Config.CAUTION_DIST:
            self.get_logger().info("[SPIRAL] 🧱 Wall detected → WALL_FOLLOW")
            self._change_state(RobotState.WALL_FOLLOW)
            return twist
        
        # Check for doors
        if self._check_door_candidate():
            return twist
        
        # Expanding spiral
        twist.linear.x = Config.SPIRAL_SPEED
        twist.angular.z = self.spiral_angular
        
        # Reduce angular velocity over time for expansion
        self.spiral_angular = max(0.15, self.spiral_angular - Config.SPIRAL_EXPANSION_RATE * 0.1)
        
        # Timeout
        if time.time() - self.state_start_time > Config.SPIRAL_MAX_TIME:
            self.get_logger().info("[SPIRAL] ⏱️ Timeout → WALL_FOLLOW")
            self._change_state(RobotState.WALL_FOLLOW)
        
        return twist
    
    def _state_wall_follow(self) -> Twist:
        """PID wall following (right-hand rule)"""
        twist = Twist()
        
        # Check for doors
        if self._check_door_candidate():
            return twist
        
        # PID control
        error = self.lidar.right - Config.WALL_TARGET_DIST
        self.wall_pid_integral += error * 0.1
        self.wall_pid_integral = max(-1, min(1, self.wall_pid_integral))  # Anti-windup
        derivative = (error - self.wall_pid_last_error) / 0.1
        self.wall_pid_last_error = error
        
        angular = -(
            Config.WALL_PID_KP * error +
            Config.WALL_PID_KI * self.wall_pid_integral +
            Config.WALL_PID_KD * derivative
        )
        angular = max(-Config.TURN_SPEED, min(Config.TURN_SPEED, angular))
        
        if self.lidar.front > Config.CAUTION_DIST:
            twist.linear.x = Config.WALL_FOLLOW_SPEED
            twist.angular.z = angular
        else:
            # Corner - turn left
            twist.angular.z = Config.TURN_SPEED
        
        return twist
    
    def _state_door_verify(self) -> Twist:
        """Nudge verification for doorways"""
        twist = Twist()
        
        if self.nudge_start_pose is None:
            self.nudge_start_pose = self.pose.copy()
            self.door_verify_start_lidar = LidarSectors(
                front=self.lidar.front, left=self.lidar.left,
                right=self.lidar.right, front_left=self.lidar.front_left,
                front_right=self.lidar.front_right
            )
            self.get_logger().info(f"[DOOR] 🚪 Nudge verification ({self.door_verify_direction})")
            self.doors_verified += 1
        
        distance_moved = self.pose.distance_to(self.nudge_start_pose.x, self.nudge_start_pose.y)
        
        if distance_moved < Config.NUDGE_DISTANCE:
            twist.linear.x = Config.NUDGE_SPEED
        else:
            # Check gap increase
            gap_increased = False
            gap_change = 0.0
            
            if self.door_verify_direction == "LEFT":
                gap_change = self.lidar.left - self.door_verify_start_lidar.left
                gap_increased = gap_change > Config.NUDGE_GAP_INCREASE
            elif self.door_verify_direction == "RIGHT":
                gap_change = self.lidar.right - self.door_verify_start_lidar.right
                gap_increased = gap_change > Config.NUDGE_GAP_INCREASE
            
            if gap_increased:
                self.get_logger().info(f"[DOOR] ✅ Confirmed! Gap +{gap_change:.2f}m → ENTER_ROOM")
                self._change_state(RobotState.ENTER_ROOM)
            else:
                self.get_logger().info(f"[DOOR] ❌ False positive (gap {gap_change:+.2f}m) → WALL_FOLLOW")
                self._change_state(RobotState.WALL_FOLLOW)
            
            self.nudge_start_pose = None
        
        return twist
    
    def _state_enter_room(self) -> Twist:
        """Enter through confirmed doorway"""
        twist = Twist()
        
        elapsed = time.time() - self.state_start_time
        turn_time = (math.pi / 2) / Config.TURN_SPEED
        
        if elapsed < turn_time:
            # Turn toward door
            if self.door_verify_direction == "LEFT":
                twist.angular.z = Config.TURN_SPEED
            else:
                twist.angular.z = -Config.TURN_SPEED
        else:
            # Move forward
            if self.lidar.front > Config.CAUTION_DIST:
                twist.linear.x = Config.INTERIOR_SPEED
                
                if elapsed > turn_time + 2.5:
                    self.rooms_entered += 1
                    self.get_logger().info(f"[ENTER] 🏠 Room #{self.rooms_entered} entered → ROOM_CROSS")
                    self._change_state(RobotState.ROOM_CROSS)
            else:
                self.get_logger().warn("[ENTER] ⚠️ Blocked → WALL_FOLLOW")
                self._change_state(RobotState.WALL_FOLLOW)
        
        return twist
    
    def _state_room_cross(self) -> Twist:
        """Crisscross coverage within room"""
        twist = Twist()
        
        if self._check_door_candidate():
            return twist
        
        if self.lidar.front > Config.CAUTION_DIST:
            twist.linear.x = Config.INTERIOR_SPEED
            # Zigzag pattern
            elapsed = time.time() - self.state_start_time
            twist.angular.z = 0.15 * math.sin(elapsed * 0.4)
        else:
            # Turn at obstacles
            twist.angular.z = Config.TURN_SPEED if self.lidar.left > self.lidar.right else -Config.TURN_SPEED
        
        # Room timeout
        if time.time() - self.state_start_time > 35.0:
            self.get_logger().info("[ROOM] ⏱️ Coverage complete → WALL_FOLLOW")
            self._change_state(RobotState.WALL_FOLLOW)
        
        return twist
    
    def _state_recovery(self) -> Twist:
        """Stuck recovery - escape toward largest opening"""
        twist = Twist()
        
        best_dir, best_dist = self.lidar.max_sector()
        self.get_logger().info(f"[RECOVERY] 🆘 Escaping toward {best_dir} ({best_dist:.2f}m)")
        
        # Turn toward best direction
        turn_map = {'F': 0, 'FR': -0.5, 'R': -1.57, 'BR': -2.5,
                    'B': 3.14, 'BL': 2.5, 'L': 1.57, 'FL': 0.5}
        target_turn = turn_map.get(best_dir, 0)
        
        elapsed = time.time() - self.state_start_time
        
        if elapsed < abs(target_turn) / Config.TURN_SPEED + 0.5:
            twist.angular.z = Config.FAST_TURN_SPEED if target_turn > 0 else -Config.FAST_TURN_SPEED
        else:
            if self.lidar.front > Config.CAUTION_DIST:
                twist.linear.x = Config.RECOVERY_SPEED
                
                if elapsed > 4.0:
                    self.get_logger().info("[RECOVERY] ✅ Escaped! → SPIRAL")
                    self.stuck_counter = 0
                    self.spiral_angular = Config.SPIRAL_ANGULAR_START
                    self._change_state(RobotState.SPIRAL)
            else:
                # Still stuck, retry
                self.state_start_time = time.time()
        
        return twist
    
    def _state_void_escape(self) -> Twist:
        """Escape featureless void"""
        twist = Twist()
        
        with self.vlm_lock:
            is_void = self.vlm_response.scene_type == "void"
        
        if not self.lidar.all_infinite() or not is_void:
            self.get_logger().info("[VOID] ✅ Escaped void → SPIRAL")
            self._change_state(RobotState.SPIRAL)
            return twist
        
        twist.angular.z = Config.SLOW_TURN_SPEED
        
        if time.time() - self.state_start_time > 25.0:
            self.get_logger().warn("[VOID] ⏱️ Timeout → SPIRAL")
            self._change_state(RobotState.SPIRAL)
        
        return twist
    
    # ══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _change_state(self, new_state: RobotState):
        """Transition to new state"""
        if new_state != self.state:
            self.previous_state = self.state
            self.state = new_state
            self.state_start_time = time.time()
            self.get_logger().info(f"[STATE] 🔄 {self.previous_state.value} → {new_state.value}")
    
    def _check_door_candidate(self) -> bool:
        """Check for potential doors on sides"""
        
        # LiDAR left gap
        if (Config.DOOR_GAP_MIN < self.lidar.left < Config.DOOR_GAP_MAX and
            self.lidar.front_left > Config.DOOR_DEPTH_MIN):
            self.door_verify_direction = "LEFT"
            self.get_logger().info(f"[DOOR] 👀 Potential LEFT door (gap: {self.lidar.left:.2f}m)")
            self._change_state(RobotState.DOOR_VERIFY)
            return True
        
        # LiDAR right gap
        if (Config.DOOR_GAP_MIN < self.lidar.right < Config.DOOR_GAP_MAX and
            self.lidar.front_right > Config.DOOR_DEPTH_MIN):
            self.door_verify_direction = "RIGHT"
            self.get_logger().info(f"[DOOR] 👀 Potential RIGHT door (gap: {self.lidar.right:.2f}m)")
            self._change_state(RobotState.DOOR_VERIFY)
            return True
        
        # VLM door detection
        with self.vlm_lock:
            if self.vlm_response.door_visible and self.vlm_response.door_direction in ["LEFT", "RIGHT"]:
                self.door_verify_direction = self.vlm_response.door_direction
                self.get_logger().info(f"[VLM] 🚪 Door detected: {self.door_verify_direction}")
                self._change_state(RobotState.DOOR_VERIFY)
                return True
        
        return False
    
    def _update_visited_cells(self):
        """Update coverage grid"""
        cx = int(self.pose.x / Config.CELL_SIZE)
        cy = int(self.pose.y / Config.CELL_SIZE)
        key = (cx, cy)
        
        if key in self.visited_cells:
            self.visited_cells[key].visit_count += 1
        else:
            self.visited_cells[key] = VisitedCell(x=cx, y=cy, first_visit=time.time())
    
    def check_stuck(self):
        """Periodic stuck detection"""
        dist = self.pose.distance_to(self.last_pose_check.x, self.last_pose_check.y)
        
        if dist < Config.STUCK_MOVE_THRESHOLD:
            self.stuck_counter += 1
            self.get_logger().warn(
                f"[STUCK] ⚠️ Strike {self.stuck_counter}/{Config.STUCK_STRIKES_MAX} "
                f"(moved {dist:.3f}m)"
            )
            
            if self.stuck_counter >= Config.STUCK_STRIKES_MAX:
                self.get_logger().error("[STUCK] 🚨 Max strikes! → RECOVERY")
                self._change_state(RobotState.RECOVERY)
        else:
            self.stuck_counter = max(0, self.stuck_counter - 1)
        
        self.last_pose_check = self.pose.copy()
    
    def shutdown(self):
        """Clean shutdown"""
        self.get_logger().info("🛑 Shutting down NOVA MASTER v4.0...")
        self.cmd_pub.publish(Twist())
        cv2.destroyAllWindows()
        self._save_memory()
    
    def _save_memory(self):
        """Persist mission data"""
        memory = {
            "mission_time": time.time() - self.mission_start_time,
            "cells_visited": len(self.visited_cells),
            "rooms_entered": self.rooms_entered,
            "doors_verified": self.doors_verified,
            "object_inventory": self.object_inventory,
            "path": list(self.path_memory)[-500:],  # Last 500 points
            "visited_cells": [
                {"x": c.x, "y": c.y, "visits": c.visit_count}
                for c in self.visited_cells.values()
            ]
        }
        
        try:
            with open("nova_master_memory.json", "w") as f:
                json.dump(memory, f, indent=2)
            self.get_logger().info(f"💾 Memory saved: {len(self.visited_cells)} cells, {self.rooms_entered} rooms")
        except Exception as e:
            self.get_logger().error(f"Failed to save: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def main(args=None):
    rclpy.init(args=args)
    node = NovaMasterV4()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\n[ABORT] Mission terminated by operator")
    finally:
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()
        print("[SHUTDOWN] Complete. Goodbye! 🤖")


if __name__ == '__main__':
    main()