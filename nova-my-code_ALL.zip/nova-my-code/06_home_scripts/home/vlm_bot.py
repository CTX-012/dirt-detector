import os
import base64
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from rclpy.qos import QoSProfile, ReliabilityPolicy
from cv_bridge import CvBridge
from groq import Groq

class VlmObserver(Node):
    def __init__(self):
        super().__init__('vlm_observer_node')
        
        # 1. Setup Groq Client
        api_key = os.environ.get("GROQ_API_KEY")
        if not api_key:
            self.get_logger().error("GROQ_API_KEY not found!")
            exit()
        self.client = Groq(api_key=api_key)

        # 2. Setup Camera Subscriber (Humble QoS)
        qos_profile = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            depth=1
        )
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',
            self.image_callback,
            qos_profile)
        
        self.bridge = CvBridge()
        self.latest_frame = None
        self.last_description_time = 0
        self.description_interval = 5.0 # Describe every 5 seconds to save API limits
        
        self.get_logger().info("👁️ VLM Observer Online. Drive the bot, and I will describe the scene!")

    def encode_image(self, frame):
        # Resize to reduce latency
        resized = cv2.resize(frame, (640, 480))
        _, buffer = cv2.imencode('.jpg', resized)
        return base64.b64encode(buffer).decode('utf-8')

    def image_callback(self, msg):
        # Convert ROS image to OpenCV
        self.latest_frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        cv2.imshow("Robot View", self.latest_frame)
        cv2.waitKey(1)

        # Check if it's time to ask the VLM
        current_time = self.get_clock().now().nanoseconds / 1e9
        if current_time - self.last_description_time > self.description_interval:
            self.describe_scene()
            self.last_description_time = current_time

    def describe_scene(self):
        if self.latest_frame is None:
            return

        try:
            base64_image = self.encode_image(self.latest_frame)
            
            # Using Llama-3.2-11b-vision-preview (Groq's powerful VLM)
            response = self.client.chat.completions.create(
                model="meta-llama/llama-4-maverick-17b-128e-instruct",
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "Describe this Gazebo simulation scene in one short sentence. Focus on objects in front of the robot."},
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/jpeg;base64,{base64_image}"}
                            }
                        ]
                    }
                ],
            )
            print(f"🎙️ ROBOT: {response.choices[0].message.content}")
        except Exception as e:
            self.get_logger().error(f"VLM Error: {e}")

def main():
    rclpy.init()
    node = VlmObserver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
