"""
NOVA Vision Benchmark v2 — Fixed (Wide CSV Export)
==================================================
Single model: Qwen2.5-VL-3B-Instruct
Datasets:     SODA-D (precision/recall/omission) + DASH-B (commission) + ORG
Pipelines:    B, C, D, E_zone

Usage:
  modal run modal_benchmark_v2.py --download-only
  modal run modal_benchmark_v2.py --sample 5
  modal run modal_benchmark_v2.py
"""

import modal
import sys
import csv
from pathlib import Path

# ── App ────────────────────────────────────────────────────────────────────────
app = modal.App("nova-benchmark-v5")

GPU_SMALL = "A10G"
GPU_LARGE = "A100-80GB"
GPU       = GPU_SMALL   # default
MODEL_CACHE = "/cache/models"
DATA_CACHE  = "/cache/data"

model_volume = modal.Volume.from_name("nova-model-cache-v2", create_if_missing=True)
data_volume  = modal.Volume.from_name("nova-data-cache-v3",  create_if_missing=True)

# ── Image ──────────────────────────────────────────────────────────────────────
image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install(["libgl1", "libglib2.0-0"])
    .pip_install([
        "torch==2.5.1",
        "transformers==4.51.3",
        "accelerate>=0.34.0",
        "huggingface_hub>=0.23.0",
        "sentencepiece",
        "pillow",
        "opencv-python-headless",
        "numpy",
        "ultralytics",
        "rapidfuzz",
        "datasets",
        "qwen-vl-utils",
        "einops",
        "timm",
        "pycocotools",
        "num2words",     # required by SmolVLM processor
    ])
)

# ── Config ─────────────────────────────────────────────────────────────────────
MODEL_KEY   = "qwen3b"  # Ensure it uses Qwen locally/remotely
MODEL_REPO  = "Qwen/Qwen2.5-VL-3B-Instruct"
MODEL_NAME  = "Qwen2.5-VL-3B"
MODEL_DIR   = f"{MODEL_CACHE}/{MODEL_KEY}"

PIPELINES       = ["B", "C", "D", "E"]
DEFAULT_SAMPLE       = 100   # DASHB sample size
DEFAULT_SAMPLE_SODAD = 20    # SODA-D: 20 × 24s × 4 pipelines = 32min safe
DEFAULT_SAMPLE_ORG   = 20    # ORG sample
IOU_THRESHOLD   = 0.5
YOLOE_CONF      = 0.30
YOLOE_IMGSZ     = 640
MAX_MARKS       = 20
FUZZY_THRESHOLD = 80


# ==============================================================================
#  METRICS  (paper-locked)
# ==============================================================================

def precision_recall(detected_bboxes: list, gt_bboxes: list,
                     iou_threshold: float = IOU_THRESHOLD) -> dict:
    if not gt_bboxes and not detected_bboxes:
        return {"TP": 0, "FP": 0, "FN": 0, "precision": 1.0, "recall": 1.0}
    if not detected_bboxes:
        return {"TP": 0, "FP": 0, "FN": len(gt_bboxes),
                "precision": 0.0, "recall": 0.0}
    if not gt_bboxes:
        return {"TP": 0, "FP": len(detected_bboxes), "FN": 0,
                "precision": 0.0, "recall": 1.0}

    matched_gt = set()
    TP = 0
    for det in detected_bboxes:
        best_iou, best_j = 0.0, -1
        for j, gt in enumerate(gt_bboxes):
            if j in matched_gt:
                continue
            iou = _iou(det, gt)
            if iou > best_iou:
                best_iou, best_j = iou, j
        if best_iou >= iou_threshold and best_j >= 0:
            TP += 1
            matched_gt.add(best_j)

    FP = len(detected_bboxes) - TP
    FN = len(gt_bboxes) - TP
    return {
        "TP": TP, "FP": FP, "FN": FN,
        "precision": TP / (TP + FP) if (TP + FP) > 0 else 0.0,
        "recall":    TP / (TP + FN) if (TP + FN) > 0 else 0.0,
    }

def commission_rate(vlm_claims: list, gt_object: str,
                    gt_present: bool) -> float:
    if gt_present:
        return 0.0  # object is present, any claim is correct
    return 1.0 if _fuzzy_match(gt_object, vlm_claims) else 0.0

def omission_rate(detected_classes: list, gt_classes: list) -> float:
    if not gt_classes:
        return 0.0
    missed = [g for g in gt_classes if not _fuzzy_match(g, detected_classes)]
    return len(missed) / len(gt_classes)

def _iou(a: list, b: list) -> float:
    xA, yA = max(a[0], b[0]), max(a[1], b[1])
    xB, yB = min(a[2], b[2]), min(a[3], b[3])
    inter  = max(0, xB - xA) * max(0, yB - yA)
    if inter == 0:
        return 0.0
    areaA = (a[2] - a[0]) * (a[3] - a[1])
    areaB = (b[2] - b[0]) * (b[3] - b[1])
    return inter / (areaA + areaB - inter)

def _fuzzy_match(query: str, candidates: list) -> bool:
    q = query.lower().strip()
    try:
        from rapidfuzz import fuzz
        return any(
            fuzz.partial_ratio(q, c.lower().strip()) >= FUZZY_THRESHOLD
            for c in candidates
        )
    except ImportError:
        return any(q in c.lower() or c.lower() in q for c in candidates)


# ==============================================================================
#  DOWNLOAD
# ==============================================================================

@app.function(
    image=image, gpu=None,
    volumes={DATA_CACHE: data_volume},
    secrets=[modal.Secret.from_name("huggingface")],
    timeout=3600,
)
def download_datasets():
    import os
    from huggingface_hub import login
    from datasets import load_dataset

    data_volume.reload()

    token = os.environ.get("HF_TOKEN", "").strip()
    if token:
        login(token=token, add_to_git_credential=False)
        print(f"[HF] Authenticated")

    for sodad_candidate in [
        Path(f"{DATA_CACHE}/sodad"),
        Path(f"{DATA_CACHE}/cache/data/sodad"),
    ]:
        if (sodad_candidate / "annotations" / "val.json").exists():
            sodad_dir = sodad_candidate
            break
    else:
        sodad_dir = Path(f"{DATA_CACHE}/sodad")

    ann_path = sodad_dir / "annotations" / "val.json"
    img_dir  = sodad_dir / "images"

    if ann_path.exists():
        n_imgs = len(list(img_dir.glob("*.jpg"))) if img_dir.exists() else 0
        print(f"[SODA-D] Found at {sodad_dir}: {n_imgs} images")
    else:
        print(f"[SODA-D] not found. Searching /cache/data recursively...")
        found = list(Path("/cache/data").rglob("*val.json"))
        if found:
            print(f"[SODA-D] FOUND at: {found[0]}")
        else:
            print(f"[SODA-D] Not found anywhere under /cache/data")

    dashb_dir     = Path(f"{DATA_CACHE}/dashb")
    dashb_gt_path = Path(f"{DATA_CACHE}/dashb_gt_map.json")

    if dashb_dir.exists() and dashb_gt_path.exists():
        print("[DASH-B] Already cached")
    else:
        print("[DASH-B] Downloading YanNeu/DASH-B ...")
        dashb_dir.mkdir(parents=True, exist_ok=True)
        try:
            ds = load_dataset("YanNeu/DASH-B", split="test", token=token or None)
            ds.save_to_disk(str(dashb_dir))
            
            import json
            gt_map = {}
            gt_map_imgid = {}

            for item in ds:
                img_path = str(item.get("image_path", ""))
                img_id   = str(item.get("img_id", ""))
                obj      = str(item.get("object", "")).lower().strip()
                ans      = str(item.get("answer", "no")).lower().strip()

                if img_path:
                    gt_map.setdefault(img_path, [])
                    if ans == "yes":
                        gt_map[img_path].append(obj)
                if img_id:
                    gt_map_imgid.setdefault(img_id, [])
                    if ans == "yes":
                        gt_map_imgid[img_id].append(obj)

            combined = {"by_path": gt_map, "by_imgid": gt_map_imgid}
            with open(dashb_gt_path, "w") as f:
                json.dump(combined, f)
            print(f"[DASH-B] Cached: {len(ds)} rows.")
        except Exception as e:
            print(f"[DASH-B] FAILED: {e}")

    data_volume.commit()
    print("Dataset download complete.")

@app.function(
    image=image, gpu=None,
    volumes={MODEL_CACHE: model_volume},
    secrets=[modal.Secret.from_name("huggingface")],
    timeout=3600, retries=2,
)
def download_model():
    import os
    from huggingface_hub import snapshot_download, login

    token = os.environ.get("HF_TOKEN", "").strip()
    if token:
        login(token=token, add_to_git_credential=False)

    local_dir = Path(MODEL_DIR)
    if local_dir.exists() and any(local_dir.iterdir()):
        print(f"[{MODEL_KEY}] Already cached")
        return

    print(f"[{MODEL_KEY}] Downloading {MODEL_REPO} ...")
    snapshot_download(
        repo_id=MODEL_REPO, local_dir=str(local_dir),
        token=token or None,
        ignore_patterns=["*.pt", "*.bin", "*.gguf"],
        resume_download=True, max_workers=4,
    )
    model_volume.commit()
    print(f"[{MODEL_KEY}] Download complete")


# ==============================================================================
#  BENCHMARK
# ==============================================================================

@app.function(
    image=image, gpu=GPU,
    volumes={MODEL_CACHE: model_volume, DATA_CACHE: data_volume},
    secrets=[modal.Secret.from_name("huggingface")],
    timeout=7200, memory=32768,
)
def run_benchmark(dry_run: bool = False, sample_n: int = DEFAULT_SAMPLE) -> dict:
    import gc, torch, time

    data_volume.reload()
    model_volume.reload()

    print(f"\n{'='*62}")
    print(f"  NOVA Benchmark v2  --  {MODEL_NAME}")
    print(f"  GPU:  {torch.cuda.get_device_name(0)}")
    print(f"  VRAM: {torch.cuda.get_device_properties(0).total_memory/1e9:.1f}GB")
    print(f"  N:    {sample_n} per dataset | dry_run={dry_run}")
    print(f"{'='*62}\n")

    sodad_samples, dashb_samples, org_samples = _load_datasets(sample_n)
    print(f"  SODA-D: {len(sodad_samples)} images")
    print(f"  DASH-B: {len(dashb_samples)} images")
    print(f"  ORG:    {len(org_samples)} images")

    if dry_run:
        return {"dry_run": True,
                "sodad_n": len(sodad_samples),
                "dashb_n": len(dashb_samples),
                "org_n":   len(org_samples)}

    print("\nLoading YOLOE-pf...")
    yoloe = _load_yoloe()
    print("YOLOE ready")

    if not Path(MODEL_DIR).exists():
        raise RuntimeError(f"Model not found at {MODEL_DIR}. Run --download-only first.")

    print(f"\nLoading {MODEL_NAME}...")
    t0  = time.time()
    vlm = _load_qwen3b()
    print(f"Loaded {time.time()-t0:.1f}s")

    all_results = {}

    for pipeline in PIPELINES:
        print(f"\n{'─'*50} Pipeline {pipeline}")
        sodad_records = _eval_sodad(pipeline, sodad_samples, vlm, yoloe) if sodad_samples else []
        org_records   = _eval_sodad(pipeline, org_samples, vlm, yoloe) if org_samples else []
        dashb_records = _eval_dashb(pipeline, dashb_samples, vlm, yoloe)

        sodad_sum = _summarize_sodad(sodad_records)
        org_sum   = _summarize_sodad(org_records)
        dashb_sum = _summarize_dashb(dashb_records)

        all_results[pipeline] = {
            "sodad": sodad_sum, "org": org_sum, "dashb": dashb_sum,
            "raw": {"sodad": sodad_records, "org": org_records, "dashb": dashb_records},
        }

    del vlm
    gc.collect()
    torch.cuda.empty_cache()
    return all_results

def _eval_sodad(pipeline, samples, vlm, yoloe):
    import time
    records = []
    for sample in samples:
        try:
            t0 = time.perf_counter()
            det_bboxes, det_classes = _run_pipeline(pipeline, sample["image"], vlm, yoloe)
            lat = (time.perf_counter() - t0) * 1000

            pr  = precision_recall(det_bboxes, sample["gt_bboxes"])
            omr = omission_rate(det_classes, sample["gt_classes"])

            records.append({
                "image_id": sample["image_id"], "pipeline": pipeline,
                "TP": pr["TP"], "FP": pr["FP"], "FN": pr["FN"],
                "precision": pr["precision"], "recall": pr["recall"],
                "omission_rate": omr, "latency_ms": lat,
                "det_classes": det_classes, "gt_classes": sample["gt_classes"],
                "n_det_bboxes": len(det_bboxes), "n_gt_bboxes": len(sample["gt_bboxes"]),
            })
        except Exception as e:
            records.append({"image_id": sample["image_id"], "pipeline": pipeline, "error": str(e)})
    return records

def _eval_dashb(pipeline, samples, vlm, yoloe):
    import time
    records = []
    for sample in samples:
        try:
            t0 = time.perf_counter()
            _, det_classes = _run_pipeline(pipeline, sample["image"], vlm, yoloe)
            lat = (time.perf_counter() - t0) * 1000

            comm = commission_rate(det_classes, sample["gt_object"], sample["gt_present"])

            records.append({
                "image_id": sample["image_id"], "pipeline": pipeline,
                "commission_rate": comm, "latency_ms": lat,
                "gt_object": sample["gt_object"], "det_classes": det_classes,
            })
        except Exception as e:
            records.append({"image_id": sample["image_id"], "pipeline": pipeline, "error": str(e)})
    return records

def _run_pipeline(pipeline, frame, vlm, yoloe):
    if pipeline == "B": return [], _pipeline_b(frame, vlm)
    dets, marked = _run_yoloe(frame, yoloe)
    bboxes = [d["bbox"] for d in dets]

    if pipeline in ("C", "D"): return bboxes, _pipeline_cd(marked, dets, vlm)
    if pipeline == "E": return bboxes, _pipeline_e_zone(frame, marked, dets, vlm)
    raise ValueError(f"Unknown pipeline: {pipeline}")

def _pipeline_b(frame, vlm):
    raw = _call_vlm(frame, vlm,
        'List every distinct object visible. Include small and floor-level objects. '
        'Reply ONLY in JSON: {"objects": ["cat1", "cat2", ...]}')
    return _parse_object_list(raw)

def _pipeline_cd(marked, dets, vlm):
    raw = _call_vlm(marked, vlm,
        f"YOLOE detected:\n{_make_inventory(dets)}\n\n"
        "List any additional objects you see NOT in the list above. "
        'Reply ONLY in JSON: {"confirmed": ["c1"], "additional": ["a1"]}')
    return _parse_grounded_classes(raw, dets)

def _pipeline_e_zone(frame, marked, dets, vlm):
    import json
    yoloe_labels = set(d["label"] for d in dets)
    base_classes = [d["label"] for d in dets]
    raw = _call_vlm(marked, vlm,
        f"YOLOE detected:\n{_make_inventory(dets)}\n\n"
        "List any ADDITIONAL objects you see not in the list above. "
        'Reply ONLY in JSON: {"additional": ["obj1", "obj2", ...]}')

    try:
        parsed     = json.loads(_clean_json(raw))
        additional = [str(a).lower().strip() for a in parsed.get("additional", [])]
    except Exception:
        additional = []

    accepted = [claim for claim in additional if claim and _fuzzy_match(claim, list(yoloe_labels))]
    return list(set(base_classes + accepted))

def _load_qwen3b() -> dict:
    import torch
    from transformers import AutoProcessor
    from transformers import Qwen2_5_VLForConditionalGeneration
    processor = AutoProcessor.from_pretrained(MODEL_DIR, min_pixels=256*28*28, max_pixels=1280*28*28)
    model = Qwen2_5_VLForConditionalGeneration.from_pretrained(MODEL_DIR, torch_dtype=torch.bfloat16, device_map="auto")
    return {"model": model, "processor": processor, "type": "qwen"}

def _call_vlm(frame, vlm, prompt, max_new_tokens=512):
    import torch, cv2
    from PIL import Image
    from qwen_vl_utils import process_vision_info
    pil_img   = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    model     = vlm["model"]
    processor = vlm["processor"]
    messages = [{"role": "user", "content": [{"type": "image", "image": pil_img}, {"type": "text", "text": prompt}]}]
    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
    img_inputs, vid_inputs = process_vision_info(messages)
    inputs = processor(text=[text], images=img_inputs, videos=vid_inputs, return_tensors="pt")
    inputs = {k: v.to(model.device) for k, v in inputs.items()}
    model_dtype = next(model.parameters()).dtype
    inputs = {k: v.to(model_dtype) if v.dtype == torch.float32 else v for k, v in inputs.items()}
    with torch.no_grad():
        output = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    generated = output[0][inputs["input_ids"].shape[1]:]
    return processor.decode(generated, skip_special_tokens=True)

def _load_yoloe():
    from ultralytics import YOLO
    return YOLO("yoloe-26n-seg-pf.pt")

def _run_yoloe(frame, yoloe):
    import cv2
    results = yoloe.predict(frame, imgsz=YOLOE_IMGSZ, conf=YOLOE_CONF, verbose=False)
    dets, marked, r = [], frame.copy(), results[0]
    for i, box in enumerate(r.boxes):
        label = r.names[int(box.cls)].lower()
        conf  = float(box.conf)
        x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
        dets.append({"id": i+1, "label": label, "conf": conf, "bbox": [x1, y1, x2, y2]})
        cv2.rectangle(marked, (x1,y1),(x2,y2),(0,200,80),1)
        cv2.putText(marked, f"[{i+1}]", (x1,y1-4), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,200,80), 1)
    return dets[:MAX_MARKS], marked

def _load_datasets(sample_n, sample_n_sodad=None, sample_n_org=None):
    sample_n_sodad = sample_n_sodad or DEFAULT_SAMPLE_SODAD
    sample_n_org   = sample_n_org   or DEFAULT_SAMPLE_ORG
    import random, json, cv2, numpy as np
    rng = random.Random(42)

    sodad_samples = []
    ann_candidates = list(Path("/cache/data").rglob("*val.json"))
    if ann_candidates:
        with open(ann_candidates[0]) as f: coco = json.load(f)
        cat_map    = {c["id"]: c["name"] for c in coco["categories"]}
        ann_by_img = {}
        for ann in coco["annotations"]: ann_by_img.setdefault(ann["image_id"], []).append(ann)
        all_jpgs = {p.name: p for p in Path("/cache/data").rglob("*.jpg")}
        images_on_disk = [img for img in coco["images"] if img["file_name"] in all_jpgs]
        if len(images_on_disk) > sample_n_sodad: images_on_disk = rng.sample(images_on_disk, sample_n_sodad)
        
        for img_info in images_on_disk:
            img_file = all_jpgs.get(img_info["file_name"])
            frame = cv2.imread(str(img_file)) if img_file else None
            if frame is None: continue
            gt_bboxes, gt_classes = [], []
            for ann in ann_by_img.get(img_info["id"], []):
                x, y, w, h = ann["bbox"]
                gt_bboxes.append([int(x), int(y), int(x+w), int(y+h)])
                gt_classes.append(cat_map.get(ann["category_id"], "unknown").lower())
            sodad_samples.append({"image_id": img_info["file_name"], "image": frame, "gt_bboxes": gt_bboxes, "gt_classes": list(set(gt_classes))})

    dashb_samples = []
    dashb_dir = Path(f"{DATA_CACHE}/dashb")
    if dashb_dir.exists():
        from datasets import load_from_disk
        ds = load_from_disk(str(dashb_dir))
        absent_indices = [i for i in range(len(ds)) if str(ds[i].get("answer", "no")).lower().strip() == "no"]
        indices = rng.sample(absent_indices, min(sample_n, len(absent_indices)))
        for i in indices:
            item = ds[i]
            pil_img = item.get("image")
            if pil_img is None: continue
            dashb_samples.append({
                "image_id": f"dashb_{item.get('question_id', i)}",
                "image": cv2.cvtColor(np.array(pil_img), cv2.COLOR_RGB2BGR),
                "gt_object": str(item.get("object", "unknown")).lower().strip(),
                "gt_present": False,
            })

    org_samples = []
    org_img_root, org_ann_root = None, None
    for c in [Path("/cache/data/org/images"), Path("/cache/data/cache/data/org/images")]:
        if c.exists() and any(c.rglob("*_image.png")): org_img_root = c; break
    for c in [Path("/cache/data/org/annotations"), Path("/cache/data/cache/data/org/annotations")]:
        if c.exists() and any(c.rglob("*_obstacles.json")): org_ann_root = c; break

    if org_img_root and org_ann_root:
        ann_files = list(org_ann_root.rglob("*_gtCoarse_obstacles.json"))
        if len(ann_files) > sample_n_org: ann_files = rng.sample(ann_files, sample_n_org)
        for ann_file in ann_files:
            try:
                with open(ann_file) as f: ann = json.load(f)
                name = str(ann.get("objects", {}).get("name", "")).strip()
                if not name or len(ann.get("objects", {}).get("boundingbox", [])) != 4: continue
                x, y, w, h = ann["objects"]["boundingbox"]
                stem = ann_file.stem.replace("_gtCoarse_obstacles", "")
                img_candidates = list(org_img_root.rglob(f"{stem}_image.png"))
                if not img_candidates: continue
                frame = cv2.imread(str(img_candidates[0]))
                if frame is None: continue
                org_samples.append({"image_id": stem, "image": frame, "gt_bboxes": [[int(x), int(y), int(x+w), int(y+h)]], "gt_classes": [name.lower()], "gt_present": True})
            except Exception: pass

    return sodad_samples, dashb_samples, org_samples

def _summarize_sodad(records):
    import statistics
    if not records: return {"n": 0, "precision": 0.0, "recall": 0.0, "omission_rate": 0.0, "mean_latency_ms": 0.0, "std_latency_ms": 0.0, "total_TP": 0, "total_FP": 0, "total_FN": 0}
    t_TP, t_FP, t_FN = sum(r["TP"] for r in records), sum(r["FP"] for r in records), sum(r["FN"] for r in records)
    lats, oms = [r["latency_ms"] for r in records], [r.get("omission_rate", 0) for r in records]
    return {"n": len(records), "precision": round(t_TP/(t_TP+t_FP) if (t_TP+t_FP)>0 else 0.0, 4), "recall": round(t_TP/(t_TP+t_FN) if (t_TP+t_FN)>0 else 0.0, 4), "omission_rate": round(statistics.mean(oms), 4), "mean_latency_ms": round(statistics.mean(lats), 1), "std_latency_ms": round(statistics.stdev(lats) if len(lats)>1 else 0.0, 1), "total_TP": t_TP, "total_FP": t_FP, "total_FN": t_FN}

def _summarize_dashb(records):
    import statistics
    if not records: return {"n": 0, "commission_rate": 0.0, "mean_latency_ms": 0.0, "std_latency_ms": 0.0}
    comms, lats = [r["commission_rate"] for r in records], [r["latency_ms"] for r in records]
    return {"n": len(records), "commission_rate": round(statistics.mean(comms), 4), "mean_latency_ms": round(statistics.mean(lats), 1), "std_latency_ms": round(statistics.stdev(lats) if len(lats)>1 else 0.0, 1)}

def _make_inventory(dets: list) -> str:
    return "  (none)" if not dets else "\n".join(f"  [{d['id']}] {d['label']} conf:{d['conf']:.2f}" for d in dets)

def _clean_json(raw):
    return raw.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()

def _parse_object_list(raw):
    import json, re
    def _normalize(label: str): return re.sub(r'\s*\d+$', '', label.lower().strip())
    try:
        raw_list = [str(o) for o in json.loads(_clean_json(raw)).get("objects", [])]
    except Exception:
        raw_list = [m for m in re.findall(r'"([^"]{2,40})"', raw)]
    seen, result = set(), []
    for obj in raw_list:
        norm = _normalize(obj)
        if norm and norm not in seen:
            seen.add(norm); result.append(norm)
        if len(result) >= 30: break
    return result

def _parse_grounded_classes(raw, dets):
    import json
    base = [d["label"] for d in dets]
    try: return list(set(base + [str(a).lower().strip() for a in json.loads(_clean_json(raw)).get("additional", [])]))
    except Exception: return base


# ==============================================================================
#  LOCAL ENTRYPOINT (Updated with Wide CSV)
# ==============================================================================

@app.local_entrypoint()
def main(
    dry_run:       bool = False,
    download_only: bool = False,
    sample:        int  = DEFAULT_SAMPLE,
):
    import json, csv

    print(f"Model: {MODEL_NAME} | Sample: {sample} | Dry run: {dry_run}")

    print("\n[1/3] Datasets...")
    download_datasets.remote()

    print("\n[2/3] Model...")
    download_model.remote()

    if download_only:
        print("Download complete.")
        return

    print("\n[3/3] Benchmark...")
    results = run_benchmark.remote(dry_run=dry_run, sample_n=sample)

    if dry_run or results.get("dry_run"):
        print("Dry run finished.")
        return

    # Save summary JSON
    with open("results_v2.json", "w") as f:
        json.dump({p: {"sodad": v["sodad"], "dashb": v["dashb"], "org": v["org"]}
                   for p, v in results.items()}, f, indent=2)

    # =====================================================================
    #  NEW "WIDE" CSV EXPORT (Side-by-side comparison & ORG fix)
    # =====================================================================
    print("\nGenerating clean side-by-side CSV...")
    
    image_map = {}
    for pipeline, pdata in results.items():
        # Iterate through ALL datasets, including ORG
        for ds_name in ["sodad", "dashb", "org"]:
            for r in pdata["raw"].get(ds_name, []):
                if "error" in r:
                    continue  # Skip rows that failed inference
                    
                img_id = r["image_id"]
                
                # Initialize the row if we haven't seen this image yet
                if img_id not in image_map:
                    if ds_name == "dashb":
                        gt = [r.get("gt_object", "")]
                    elif ds_name == "sodad":
                        gt = r.get("gt_classes", [])
                    elif ds_name == "org":
                        gt = r.get("gt_classes", [])
                        
                    image_map[img_id] = {
                        "dataset": ds_name,
                        "image_id": img_id,
                        "ground_truth": gt,
                    }
                
                # Add this pipeline's detections
                image_map[img_id][f"Pipe_{pipeline}_Objects"] = r.get("det_classes", [])
                image_map[img_id][f"Pipe_{pipeline}_Lat_ms"] = round(r.get("latency_ms", 0.0), 1)

    # Write the wide CSV
    with open("results_wide_comparison.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        
        # Dynamic headers based on pipelines actually run
        headers = ["Dataset", "Image_ID", "Ground_Truth"]
        for p in PIPELINES:
            if p in results:
                headers.extend([f"Pipe_{p}_Objects", f"Pipe_{p}_Latency_ms"])
        w.writerow(headers)
        
        # Write rows
        for img_id, row in image_map.items():
            out_row = [
                row["dataset"], 
                row["image_id"], 
                " | ".join(row["ground_truth"])
            ]
            for p in PIPELINES:
                if p in results:
                    objs = row.get(f"Pipe_{p}_Objects", [])
                    out_row.append(" | ".join(objs))
                    out_row.append(row.get(f"Pipe_{p}_Lat_ms", ""))
            w.writerow(out_row)

    print(f"Summary JSON: results_v2.json")
    print(f"Wide Format CSV: results_wide_comparison.csv")

