#!/usr/bin/env python3
"""
overlay_grounding.py - Draw Qwen3-VL grounding predictions onto the NOVA frames.

  * 3D boxes: taken from the existing bench_A_3d_flash/per_inference.jsonl run,
    projected to 2D with the cookbook's convert_3dbbox() (verbatim) using pseudo
    camera intrinsics generate_camera_params(fov=60) -- we have no real intrinsics,
    so 3D overlays are indicative geometry only, NOT metric-accurate.
  * 2D boxes: regenerated inline (the benched 2D run truncated at 512 tok), parsed
    with a truncation-tolerant regex so partial lists still draw.

Outputs PNGs + a contact sheet under overlays/.
"""
import json, math, os, re, glob, random
import numpy as np
from PIL import Image, ImageDraw, ImageFont

FRAMES = "/home/faiz/nova_qwen3vl_frames"
OUT = "/home/faiz/overlays"
os.makedirs(OUT, exist_ok=True)
random.seed(0)

try:
    FONT = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 22)
except Exception:
    FONT = ImageFont.load_default()


# ---- cookbook camera params (verbatim logic) -------------------------------
def generate_camera_params(image_path, fov=60):
    w, h = Image.open(image_path).size
    fx = round(w / (2 * np.tan(np.deg2rad(fov) / 2)), 2)
    fy = round(h / (2 * np.tan(np.deg2rad(fov) / 2)), 2)
    return {'fx': fx, 'fy': fy, 'cx': round(w / 2, 2), 'cy': round(h / 2, 2)}


# ---- cookbook 3D->2D projection (convert_3dbbox, verbatim) ------------------
def convert_3dbbox(point, cam_params):
    x, y, z, x_size, y_size, z_size, pitch, yaw, roll = point
    hx, hy, hz = x_size / 2, y_size / 2, z_size / 2
    local_corners = [
        [hx, hy, hz], [hx, hy, -hz], [hx, -hy, hz], [hx, -hy, -hz],
        [-hx, hy, hz], [-hx, hy, -hz], [-hx, -hy, hz], [-hx, -hy, -hz],
    ]

    def rotate_xyz(_p, _pitch, _yaw, _roll):
        x0, y0, z0 = _p
        x1 = x0
        y1 = y0 * math.cos(_pitch) - z0 * math.sin(_pitch)
        z1 = y0 * math.sin(_pitch) + z0 * math.cos(_pitch)
        x2 = x1 * math.cos(_yaw) + z1 * math.sin(_yaw)
        y2 = y1
        z2 = -x1 * math.sin(_yaw) + z1 * math.cos(_yaw)
        x3 = x2 * math.cos(_roll) - y2 * math.sin(_roll)
        y3 = x2 * math.sin(_roll) + y2 * math.cos(_roll)
        z3 = z2
        return [x3, y3, z3]

    out = []
    for corner in local_corners:
        rx, ry, rz = rotate_xyz(corner, np.deg2rad(pitch), np.deg2rad(yaw), np.deg2rad(roll))
        X, Y, Z = rx + x, ry + y, rz + z
        if Z > 0:
            out.append([cam_params['fx'] * (X / Z) + cam_params['cx'],
                        cam_params['fy'] * (Y / Z) + cam_params['cy']])
    return out


EDGES = [[0, 1], [2, 3], [4, 5], [6, 7], [0, 2], [1, 3], [4, 6], [5, 7],
         [0, 4], [1, 5], [2, 6], [3, 7]]
PALETTE = [(255, 64, 64), (64, 160, 255), (64, 220, 120), (255, 180, 40),
           (220, 80, 255), (40, 220, 220)]


def draw_3d(frame_path, boxes, save):
    im = Image.open(frame_path).convert("RGB")
    d = ImageDraw.Draw(im)
    for i, b in enumerate(boxes):
        bbox = list(b["bbox_3d"])
        bbox[-3:] = [_x * 180 for _x in bbox[-3:]]   # cookbook: *180 then deg2rad
        pts = convert_3dbbox(bbox, generate_camera_params(frame_path, fov=60))
        if len(pts) < 8:
            continue
        c = PALETTE[i % len(PALETTE)]
        for s, e in EDGES:
            d.line([tuple(pts[s]), tuple(pts[e])], fill=c, width=3)
        lx, ly = pts[0]
        d.text((lx, ly - 24), b.get("label", "?"), fill=c, font=FONT)
    im.save(save)
    return save


def draw_2d(frame_path, boxes, save):
    im = Image.open(frame_path).convert("RGB")
    W, H = im.size
    d = ImageDraw.Draw(im)
    for i, b in enumerate(boxes):
        x1, y1, x2, y2 = b["bbox_2d"]
        # 0-1000 normalized -> pixels
        x1, x2 = x1 / 1000 * W, x2 / 1000 * W
        y1, y2 = y1 / 1000 * H, y2 / 1000 * H
        c = PALETTE[i % len(PALETTE)]
        d.rectangle([x1, y1, x2, y2], outline=c, width=3)
        d.text((x1 + 2, max(0, y1 - 24)), b.get("label", "?"), fill=c, font=FONT)
    im.save(save)
    return save


# truncation-tolerant 2D parser: grab every complete {...bbox_2d...} object
OBJ_RE = re.compile(r'\{[^{}]*?"bbox_2d"\s*:\s*\[[^\]]*\][^{}]*?\}')
def parse_2d_tolerant(text):
    out = []
    for m in OBJ_RE.finditer(text):
        try:
            out.append(json.loads(m.group(0)))
        except Exception:
            pass
    return out


def main():
    # ---- 3D: reuse benched predictions (already complete/short) ----
    three_d = {}
    for line in open("/home/faiz/bench_A_3d_flash/per_inference.jsonl"):
        r = json.loads(line)
        txt = r["raw_preview"]
        try:
            arr = json.loads(txt[txt.find("["):txt.rfind("]") + 1])
        except Exception:
            arr = []
        three_d[r["file"]] = arr

    # ---- 2D: regenerate inline (benched run truncated at 512 tok) ----
    import torch
    from transformers import AutoProcessor, Qwen3VLForConditionalGeneration
    from qwen_vl_utils import process_vision_info
    PROMPT_2D = ('Detect all objects in the image and return their 2D bounding boxes as '
                 'JSON: a list of {"label": str, "bbox_2d": [x1,y1,x2,y2]} in 0-1000 '
                 'normalized coordinates.')
    m = "Qwen/Qwen3-VL-4B-Instruct"
    print("[load] model for 2D regen ...")
    model = Qwen3VLForConditionalGeneration.from_pretrained(
        m, torch_dtype="auto", attn_implementation="flash_attention_2", device_map="cuda").eval()
    proc = AutoProcessor.from_pretrained(m)

    frames = sorted(glob.glob(os.path.join(FRAMES, "*.jpg")))
    saved = []
    for fp in frames:
        name = os.path.basename(fp)
        # 3D overlay
        if three_d.get(name):
            saved.append(draw_3d(fp, three_d[name], os.path.join(OUT, name.replace(".jpg", "_3d.png"))))
            print(f"[3d] {name}: {len(three_d[name])} boxes -> {saved[-1]}")
        # 2D overlay (regen)
        msgs = [{"role": "user", "content": [{"type": "image", "image": fp},
                                             {"type": "text", "text": PROMPT_2D}]}]
        text = proc.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
        imgs, vids = process_vision_info(msgs)[:2]
        inp = proc(text=[text], images=imgs, videos=vids, return_tensors="pt").to("cuda")
        with torch.no_grad():
            out = model.generate(**inp, max_new_tokens=448, do_sample=False)
        gen = proc.batch_decode(out[:, inp.input_ids.shape[1]:], skip_special_tokens=True)[0]
        boxes2d = parse_2d_tolerant(gen)
        saved.append(draw_2d(fp, boxes2d, os.path.join(OUT, name.replace(".jpg", "_2d.png"))))
        print(f"[2d] {name}: {len(boxes2d)} boxes -> {saved[-1]}")

    # ---- contact sheet (2 rows x 2 cols: 3d | 2d per frame) ----
    cells = []
    for fp in frames:
        n = os.path.basename(fp).replace(".jpg", "")
        cells.append([os.path.join(OUT, n + "_3d.png"), os.path.join(OUT, n + "_2d.png")])
    cw, ch = 640, 480
    sheet = Image.new("RGB", (cw * 2, ch * len(cells)), (20, 20, 20))
    sd = ImageDraw.Draw(sheet)
    for ri, row in enumerate(cells):
        for ci, p in enumerate(row):
            if not os.path.exists(p):
                continue
            tile = Image.open(p).convert("RGB")
            tile.thumbnail((cw - 8, ch - 28))
            sheet.paste(tile, (ci * cw + 4, ri * ch + 24))
            tag = ("3D grounding" if ci == 0 else "2D detect") + " — " + os.path.basename(p)
            sd.text((ci * cw + 6, ri * ch + 2), tag, fill=(230, 230, 230), font=FONT)
    sheet_path = os.path.join(OUT, "contact_sheet.png")
    sheet.save(sheet_path)
    print(f"[sheet] {sheet_path}")
    print("SAVED:", *saved, sheet_path, sep="\n  ")


if __name__ == "__main__":
    main()
