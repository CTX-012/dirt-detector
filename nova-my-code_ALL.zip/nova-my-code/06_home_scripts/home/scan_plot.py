import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import numpy as np
import matplotlib.pyplot as plt

class ScanVisualizer(Node):

    def __init__(self):
        super().__init__('scan_visualizer')
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.listener_callback,
            10)
        self.angles = None

    def listener_callback(self, msg):
        ranges = np.array(msg.ranges)
        angles = np.linspace(msg.angle_min,
                             msg.angle_max,
                             len(ranges))

        plt.clf()
        ax = plt.subplot(111, projection='polar')
        ax.scatter(angles, ranges, s=5)
        ax.set_rmax(msg.range_max)
        ax.set_title("Live Lidar Scan")
        plt.pause(0.001)

def main(args=None):
    rclpy.init(args=args)
    node = ScanVisualizer()
    plt.ion()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
