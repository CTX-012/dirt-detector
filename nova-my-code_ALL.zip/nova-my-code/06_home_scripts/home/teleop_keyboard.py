#!/usr/bin/env python3

import sys
import termios
import tty
import subprocess
import time

def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        key = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return key

def send_velocity(linear, angular):
    cmd = f'gz topic -t "/cmd_vel" -m gz.msgs.Twist -p "linear: {{x: {linear}}}, angular: {{z: {angular}}}"'
    subprocess.run(cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def main():
    print("=" * 60)
    print("        ROBOT KEYBOARD TELEOP CONTROL")
    print("=" * 60)
    print("\n  Movement Controls:")
    print("  ┌─────┬─────┬─────┐")
    print("  │  Q  │  W  │  E  │  Q: Forward + Left")
    print("  │     │  ↑  │     │  W: Forward")
    print("  ├─────┼─────┼─────┤  E: Forward + Right")
    print("  │  A  │  S  │  D  │  A: Turn Left")
    print("  │  ←  │  ↓  │  →  │  S: Backward")
    print("  └─────┴─────┴─────┘  D: Turn Right")
    print("\n  Speed Controls:")
    print("  Z: Decrease speed by 10%")
    print("  C: Increase speed by 10%")
    print("  X: EMERGENCY STOP")
    print("\n  Ctrl+C: Exit")
    print("=" * 60)
    
    linear_speed = 0.2  # m/s
    angular_speed = 1.0  # rad/s
    
    print(f"\n  Current Speed - Linear: {linear_speed:.2f} m/s | Angular: {angular_speed:.2f} rad/s\n")
    
    try:
        while True:
            key = get_key()
            
            # Movement keys
            if key == 'w' or key == 'W':
                send_velocity(linear_speed, 0.0)
                print(f"→ FORWARD (speed: {linear_speed:.2f} m/s)")
                
            elif key == 's' or key == 'S':
                send_velocity(-linear_speed, 0.0)
                print(f"← BACKWARD (speed: {linear_speed:.2f} m/s)")
                
            elif key == 'a' or key == 'A':
                send_velocity(0.0, angular_speed)
                print(f"↺ TURN LEFT (speed: {angular_speed:.2f} rad/s)")
                
            elif key == 'd' or key == 'D':
                send_velocity(0.0, -angular_speed)
                print(f"↻ TURN RIGHT (speed: {angular_speed:.2f} rad/s)")
                
            elif key == 'q' or key == 'Q':
                send_velocity(linear_speed, angular_speed)
                print(f"↖ FORWARD + LEFT")
                
            elif key == 'e' or key == 'E':
                send_velocity(linear_speed, -angular_speed)
                print(f"↗ FORWARD + RIGHT")
                
            elif key == 'x' or key == 'X':
                send_velocity(0.0, 0.0)
                print("■ EMERGENCY STOP")
                
            # Speed adjustment
            elif key == 'z' or key == 'Z':
                linear_speed = max(0.05, linear_speed - 0.02)
                angular_speed = max(0.1, angular_speed - 0.1)
                send_velocity(0.0, 0.0)
                print(f"⬇ SPEED DOWN - Linear: {linear_speed:.2f} | Angular: {angular_speed:.2f}")
                
            elif key == 'c' or key == 'C':
                linear_speed = min(0.5, linear_speed + 0.02)
                angular_speed = min(2.0, angular_speed + 0.1)
                send_velocity(0.0, 0.0)
                print(f"⬆ SPEED UP - Linear: {linear_speed:.2f} | Angular: {angular_speed:.2f}")
                
            elif key == '\x03':  # Ctrl+C
                break
                
            time.sleep(0.05)
            
    except KeyboardInterrupt:
        pass
    finally:
        send_velocity(0.0, 0.0)
        print("\n\n■ Robot stopped. Exiting teleop...\n")

if __name__ == '__main__':
    main()
