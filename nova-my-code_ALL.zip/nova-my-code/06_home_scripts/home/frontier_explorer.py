#!/usr/bin/env python3
"""
Frontier-Based Autonomous Explorer for ROS 2 Humble
====================================================
Detects frontiers (unknown area boundaries) and navigates toward them.
Uses direct cmd_vel control - NO Nav2 required.

Run:
    Terminal 1: ros2 launch turtlebot3_gazebo turtlebot3_house.launch.py
    Terminal 2: ros2 launch slam_toolbox online_async_launch.py use_sim_time:=True
    Terminal 3: python3 frontier_explorer.py
    Terminal 4: ros2 run rviz2 rviz2 (optional - for visualization)
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid, Odometry
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
import numpy as np
import math
import time
from collections import deque
import threading


class FrontierExplorer(Node):
    def __init__(self):
        super().__init__('frontier_explorer')
        
        # Motion parameters
        self.linear_speed = 0.15
        self.angular_speed = 0.6
        self.goal_tolerance = 0.4
        self.obstacle_dist = 0.35
        
        # Publishers
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Subscribers
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_cb, 10)
        
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_cb, 10)
        
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            depth=1)
        self.map_sub = self.create_subscription(
            OccupancyGrid, '/map', self.map_cb, map_qos)
        
        # State
        self.scan = None
        self.pose = None
        self.map_data = None
        self.map_info = None
        self.goal = None
        self.state = 'WAIT'
        self.start_time = time.time()
        self.no_frontier_count = 0
        self.stuck_count = 0
        self.last_pos = None
        
        # Lock for thread safety
        self.lock = threading.Lock()
        
        # Control loop 10Hz
        self.timer = self.create_timer(0.1, self.control_loop)
        
        # Frontier detection 0.5Hz
        self.frontier_timer = self.create_timer(2.0, self.find_frontier)
        
        self.get_logger().info('='*50)
        self.get_logger().info('FRONTIER EXPLORER STARTED')
        self.get_logger().info('='*50)

    def scan_cb(self, msg):
        self.scan = msg

    def odom_cb(self, msg):
        self.pose = msg.pose.pose

    def map_cb(self, msg):
        with self.lock:
            self.map_data = np.array(msg.data).reshape((msg.info.height, msg.info.width))
            self.map_info = msg.info
        
        if self.state == 'WAIT':
            self.state = 'EXPLORE'
            self.get_logger().info('Map received - Starting frontier exploration!')

    def find_frontier(self):
        """Find frontiers and select best one as goal"""
        if self.state == 'WAIT':
            return
        
        with self.lock:
            if self.map_data is None or self.map_info is None:
                return
            map_data = self.map_data.copy()
            map_info = self.map_info
        
        if self.pose is None:
            return
        
        # Get robot position in map coordinates
        robot_x = self.pose.position.x
        robot_y = self.pose.position.y
        
        resolution = map_info.resolution
        origin_x = map_info.origin.position.x
        origin_y = map_info.origin.position.y
        
        height, width = map_data.shape
        
        # Find frontier cells (free cells adjacent to unknown)
        frontiers = []
        
        for y in range(1, height - 1):
            for x in range(1, width - 1):
                if map_data[y, x] == 0:  # Free cell
                    # Check 4-connected neighbors for unknown (-1)
                    neighbors = [
                        map_data[y-1, x],
                        map_data[y+1, x],
                        map_data[y, x-1],
                        map_data[y, x+1]
                    ]
                    if -1 in neighbors:
                        # Convert to world coordinates
                        wx = origin_x + (x + 0.5) * resolution
                        wy = origin_y + (y + 0.5) * resolution
                        
                        # Calculate distance from robot
                        dist = math.sqrt((wx - robot_x)**2 + (wy - robot_y)**2)
                        
                        # Only consider frontiers within reasonable range
                        if 0.5 < dist < 5.0:
                            frontiers.append((wx, wy, dist))
        
        if not frontiers:
            self.no_frontier_count += 1
            if self.no_frontier_count > 5:
                self.get_logger().info('No frontiers found - map may be complete!')
            return
        
        self.no_frontier_count = 0
        
        # Cluster frontiers and find centroids
        # Simple approach: just pick closest frontier
        frontiers.sort(key=lambda f: f[2])  # Sort by distance
        
        # Pick one of the closest frontiers (with some randomness)
        idx = min(len(frontiers) - 1, 2)  # Pick from top 3 closest
        best = frontiers[idx]
        
        self.goal = (best[0], best[1])
        self.get_logger().info(f'New frontier goal: ({best[0]:.2f}, {best[1]:.2f}), dist: {best[2]:.2f}m')

    def get_front_dist(self):
        """Get minimum distance in front of robot"""
        if self.scan is None:
            return 10.0
        
        ranges = self.scan.ranges
        n = len(ranges)
        
        # Front 60 degrees
        front_indices = list(range(0, n//6)) + list(range(5*n//6, n))
        
        min_dist = 10.0
        for i in front_indices:
            r = ranges[i]
            if 0.05 < r < min_dist:
                min_dist = r
        
        return min_dist

    def get_side_dists(self):
        """Get left and right distances"""
        if self.scan is None:
            return 10.0, 10.0
        
        ranges = self.scan.ranges
        n = len(ranges)
        
        # Left (60-120 degrees)
        left_min = 10.0
        for i in range(n//6, n//3):
            r = ranges[i]
            if 0.05 < r < left_min:
                left_min = r
        
        # Right (240-300 degrees)
        right_min = 10.0
        for i in range(2*n//3, 5*n//6):
            r = ranges[i]
            if 0.05 < r < right_min:
                right_min = r
        
        return left_min, right_min

    def control_loop(self):
        if self.state == 'WAIT':
            return
        
        # Timeout check (5 min)
        if time.time() - self.start_time > 300:
            self.get_logger().info('Exploration timeout - stopping')
            self.stop()
            self.timer.cancel()
            self.frontier_timer.cancel()
            return
        
        twist = Twist()
        front_dist = self.get_front_dist()
        
        # Obstacle avoidance takes priority
        if front_dist < self.obstacle_dist:
            # Turn away from obstacle
            left_d, right_d = self.get_side_dists()
            if left_d > right_d:
                twist.angular.z = self.angular_speed
            else:
                twist.angular.z = -self.angular_speed
            twist.linear.x = 0.0
            self.cmd_pub.publish(twist)
            self.stuck_count += 1
            
            # If stuck too long, clear goal
            if self.stuck_count > 30:
                self.goal = None
                self.stuck_count = 0
            return
        
        self.stuck_count = 0
        
        # No goal - wander
        if self.goal is None or self.pose is None:
            twist.linear.x = self.linear_speed
            twist.angular.z = 0.0
            self.cmd_pub.publish(twist)
            return
        
        # Navigate to goal
        robot_x = self.pose.position.x
        robot_y = self.pose.position.y
        
        # Get yaw from quaternion
        q = self.pose.orientation
        yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                         1.0 - 2.0 * (q.y * q.y + q.z * q.z))
        
        # Distance and angle to goal
        dx = self.goal[0] - robot_x
        dy = self.goal[1] - robot_y
        dist = math.sqrt(dx*dx + dy*dy)
        angle_to_goal = math.atan2(dy, dx)
        
        # Angle difference
        angle_diff = angle_to_goal - yaw
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi
        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        
        # Check if reached goal
        if dist < self.goal_tolerance:
            self.get_logger().info('Goal reached!')
            self.goal = None
            return
        
        # Control
        if abs(angle_diff) > 0.4:  # ~23 degrees
            # Rotate toward goal
            twist.angular.z = self.angular_speed * (1.0 if angle_diff > 0 else -1.0)
            twist.linear.x = 0.05
        else:
            # Drive toward goal with proportional steering
            twist.linear.x = self.linear_speed
            twist.angular.z = 2.0 * angle_diff
        
        self.cmd_pub.publish(twist)

    def stop(self):
        twist = Twist()
        self.cmd_pub.publish(twist)
        self.get_logger().info('Robot stopped')


def main():
    rclpy.init()
    node = FrontierExplorer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Stopped by user')
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
