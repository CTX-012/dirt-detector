#!/usr/bin/env python3
import os
import sys
import json
import math
import time
import base64
import threading
from enum import Enum
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

# ROS 2 Imports
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge

# AI Imports (Optional based on your setup)
from ultralytics import YOLO
from groq import Groq

# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION & TOPIC MAPPING
# ═══════════════════════════════════════════════════════════════════════════

class Config:
    # UPDATED: Matching your Gazebo SDF Topics
    CAMERA_TOPIC = '/camera_front'
    LIDAR_TOPIC = '/lidar'
    CMD_VEL_TOPIC = '/cmd_vel'
    
    LINEAR_SPEED = 0.5
    ANGULAR_SPEED = 0.5
    HUD_WIDTH = 300

# ══════════════════════════════════════════════════════════════════════════════
# MAIN COMMANDER NODE
# ══════════════════════════════════════════════════════════════════════════════

class NovaCommander(Node):
    def __init__(self):
        super().__init__('nova_commander')
        self.get_logger().info("🚀 NOVA Commander Initializing...")
        
        self.bridge = CvBridge()
        self.twist = Twist()
        self.current_command = "STOPPED"
        
        # Sensor data
        self.current_frame = None
        self.lidar_min_dist = 10.0
        
        # QoS setup for Gazebo Sim Harmonic
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # Subscribers
        self.img_sub = self.create_subscription(
            Image, Config.CAMERA_TOPIC, self.camera_callback, sensor_qos)
        self.scan_sub = self.create_subscription(
            LaserScan, Config.LIDAR_TOPIC, self.lidar_callback, sensor_qos)
        
        # Publisher
        self.cmd_pub = self.create_publisher(Twist, Config.CMD_VEL_TOPIC, 10)
        
        # Start Terminal Input Thread
        self.input_thread = threading.Thread(target=self.terminal_listener, daemon=True)
        self.input_thread.start()
        
        # Timer for Publishing Velocity (10Hz)
        self.timer = self.create_timer(0.1, self.publish_velocity)

    def lidar_callback(self, msg):
        # Basic safety: get minimum distance from lidar
        valid_ranges = [r for r in msg.ranges if r > 0.05]
        if valid_ranges:
            self.lidar_min_dist = min(valid_ranges)

    def camera_callback(self, msg):
        try:
            self.current_frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            self.render_hud()
        except Exception as e:
            pass

    def terminal_listener(self):
        """Listen for commands in the terminal window"""
        print("\n" + "═"*50)
        print(" NOVA TERMINAL CONTROL ACTIVE")
        print(" Commands: 'forward', 'back', 'left', 'right', 'stop', 'exit'")
        print("═"*50)
        
        while rclpy.ok():
            user_input = input("Enter Command >> ").lower().strip()
            
            new_twist = Twist()
            
            if user_input == 'forward' or user_input == 'f':
                new_twist.linear.x = Config.LINEAR_SPEED
                self.current_command = "MOVING FORWARD"
            elif user_input == 'back' or user_input == 'b':
                new_twist.linear.x = -Config.LINEAR_SPEED
                self.current_command = "MOVING BACKWARD"
            elif user_input == 'left' or user_input == 'l':
                new_twist.angular.z = Config.ANGULAR_SPEED
                self.current_command = "TURNING LEFT"
            elif user_input == 'right' or user_input == 'r':
                new_twist.angular.z = -Config.ANGULAR_SPEED
                self.current_command = "TURNING RIGHT"
            elif user_input == 'stop' or user_input == 's':
                new_twist.linear.x = 0.0
                new_twist.angular.z = 0.0
                self.current_command = "STOPPED"
            elif user_input == 'exit':
                rclpy.shutdown()
                break
            else:
                print("Unknown command. Use: f, b, l, r, s")
                continue
            
            self.twist = new_twist
            print(f"Executing: {self.current_command}")

    def publish_velocity(self):
        # Obstacle Avoidance (Reflex)
        if self.lidar_min_dist < 0.4 and self.twist.linear.x > 0:
            self.get_logger().warn("OBSTACLE DETECTED! Stopping.")
            self.twist.linear.x = 0.0
            self.current_command = "BLOCKED BY OBSTACLE"
            
        self.cmd_pub.publish(self.twist)

    def render_hud(self):
        if self.current_frame is None: return
        
        frame = self.current_frame.copy()
        h, w = frame.shape[:2]
        
        # Create Sidebar
        sidebar = np.zeros((h, Config.HUD_WIDTH, 3), dtype=np.uint8)
        sidebar[:] = (30, 30, 30)
        
        # Add Status Text
        cv2.putText(sidebar, "NOVA COMMANDER", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        cv2.putText(sidebar, f"CMD: {self.current_command}", (10, 80), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Add Lidar Data
        color = (0, 255, 0) if self.lidar_min_dist > 0.5 else (0, 0, 255)
        cv2.putText(sidebar, f"LIDAR: {self.lidar_min_dist:.2f}m", (10, 120), cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        
        # Combine and Show
        combined = np.hstack([frame, sidebar])
        cv2.imshow("NOVA HUD", combined)
        cv2.waitKey(1)

def main():
    rclpy.init()
    node = NovaCommander()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
