import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

class ScanVisualizer(Node):
    def __init__(self):
        super().__init__('scan_visualizer')
        self.subscription = self.create_subscription(
            LaserScan,
            '/scan',
            self.listener_callback,
            10)
        self.xs = []
        self.ys = []
        self.new_data = False

        # --- Figure Setup (RViz-like dark map) ---
        self.fig, self.ax = plt.subplots(figsize=(8, 8))
        self.fig.patch.set_facecolor('#1a1a1a')        # dark background
        self.ax.set_facecolor('#1a1a1a')               # dark plot area

        # Grid lines like RViz
        self.ax.grid(True, color='#333333', linewidth=0.5, linestyle='--')
        self.ax.set_axisbelow(True)

        # Axis labels and ticks
        self.ax.tick_params(colors='#888888')
        self.ax.xaxis.label.set_color('#888888')
        self.ax.yaxis.label.set_color('#888888')
        for spine in self.ax.spines.values():
            spine.set_edgecolor('#444444')

        self.ax.set_title("LiDAR Scan View", color='white', fontsize=13, pad=10)
        self.ax.set_xlabel("X (meters)", color='#888888')
        self.ax.set_ylabel("Y (meters)", color='#888888')

        # Robot marker at origin
        self.ax.plot(0, 0, 'o', color='#00aaff', markersize=8, zorder=5, label='Robot')

        # Cross-hair lines at origin
        self.ax.axhline(0, color='#444444', linewidth=0.8)
        self.ax.axvline(0, color='#444444', linewidth=0.8)

        # Scatter plot for LiDAR points
        self.scatter = self.ax.scatter([], [], s=3, c='#00ff88', zorder=4, label='LiDAR Points')

        self.ax.legend(loc='upper right', facecolor='#2a2a2a', edgecolor='#555555',
                       labelcolor='white', fontsize=9)

        self.ax.set_xlim(-10, 10)
        self.ax.set_ylim(-10, 10)
        self.ax.set_aspect('equal')

        plt.tight_layout()

    def listener_callback(self, msg):
        ranges = np.array(msg.ranges)
        angles = np.linspace(msg.angle_min, msg.angle_max, len(ranges))

        # Filter invalid readings (inf, nan, out of range)
        valid = (
            np.isfinite(ranges) &
            (ranges > msg.range_min) &
            (ranges < msg.range_max)
        )
        ranges = ranges[valid]
        angles = angles[valid]

        # Convert polar → Cartesian (X forward, Y left like ROS convention)
        self.xs = ranges * np.cos(angles)
        self.ys = ranges * np.sin(angles)
        self.new_data = True

    def update_plot(self, frame):
        if self.new_data:
            self.scatter.set_offsets(np.c_[self.xs, self.ys])

            # Auto-scale axes based on scan range
            if len(self.xs) > 0:
                max_range = max(np.max(np.abs(self.xs)), np.max(np.abs(self.ys))) + 1.0
                max_range = max(max_range, 2.0)
                self.ax.set_xlim(-max_range, max_range)
                self.ax.set_ylim(-max_range, max_range)

            self.new_data = False
        return self.scatter,


def main(args=None):
    rclpy.init(args=args)
    node = ScanVisualizer()

    # Use matplotlib animation to drive the plot refresh
    ani = animation.FuncAnimation(
        node.fig,
        node.update_plot,
        interval=50,        # refresh every 50ms (~20 FPS)
        blit=False,
        cache_frame_data=False
    )

    # Spin ROS in a separate thread so callbacks run independently
    import threading
    ros_thread = threading.Thread(target=rclpy.spin, args=(node,), daemon=True)
    ros_thread.start()

    plt.show()

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
