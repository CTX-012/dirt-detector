#!/usr/bin/env python3
"""
qwen3vl_grounding_bench.py - Full per-inference metrics for Qwen3-VL grounding
on images AND videos: latency breakdown (TTFT / decode / total), token counts
(incl. vision tokens), throughput, and peak VRAM. Writes a JSONL of every run
plus an aggregate summary.

These are the numbers that decide the NOVA slot: if the ~170-token safety schema
comes back inside your checkpoint budget, "VLM emits boxes at the checkpoint" is
viable; if not, it's settled. (Still NOT an accuracy eval -- no GT boxes here.)

Run on the RTX 3060 (Linux primary). Not in a sandbox.

Deps:
    pip install "transformers>=4.57.0" accelerate qwen-vl-utils pillow torch
    # optional, for realistic latency:
    pip install flash-attn --no-build-isolation      # then --attn flash_attention_2

Notes:
  * 4B-Instruct fits FP16 in ~9GB on 12GB; 2B is the safe fallback; 8B needs FP8/AWQ.
  * 3D prompt: paste the EXACT string from cookbooks/3d_grounding.ipynb at the TODO.
  * Video API varies across qwen-vl-utils versions; if the video path errors,
    cross-check the video grounding cookbook for the current call signature.
  * 3D-on-video is non-standard -- detect2d is the sane video task; 3D is image-first.
"""
import argparse, glob, json, os, time
from threading import Thread
import torch
from PIL import Image
from transformers import AutoProcessor, TextIteratorStreamer

try:
    from transformers import Qwen3VLForConditionalGeneration as VLModel
except ImportError:
    from transformers import AutoModelForImageTextToText as VLModel

try:
    from qwen_vl_utils import process_vision_info
except ImportError:
    process_vision_info = None

PROMPTS = {
    "detect2d": (
        "Detect all objects in the image and return their 2D bounding boxes as "
        "JSON: a list of {\"label\": str, \"bbox_2d\": [x1,y1,x2,y2]} in 0-1000 "
        "normalized coordinates."
    ),
    # 3D prompt from QwenLM/Qwen3-VL cookbooks/3d_grounding.ipynb (Example 1,
    # autonomous-driving). JSON schema string is VERBATIM from the cookbook; the
    # only change is the object noun cars->objects so it grounds all obstacles on
    # NOVA frames (the verbatim original detects only "cars", which yields ~empty
    # output on car-free frames -> unrealistically optimistic latency). Schema is
    # a flat bbox_3d[9] array + label, matching the cookbook's parse_bbox_3d_from_text.
    "ground3d": (
        "Find all objects in this image. For each object, provide its 3D bounding "
        "box. The output format required is JSON: `[{\"bbox_3d\":[x_center, "
        "y_center, z_center, x_size, y_size, z_size, roll, pitch, yaw],\"label\":"
        "\"category\"}]`."
    ),
}

IMG_EXT = ("*.jpg", "*.jpeg", "*.png", "*.bmp")
VID_EXT = ("*.mp4", "*.mov", "*.mkv", "*.avi", "*.webm")


def collect(d, exts):
    if not d:
        return []
    return sorted(sum([glob.glob(os.path.join(d, e)) for e in exts], []))


def build_messages(path, modality, prompt, fps):
    if modality == "image":
        media = {"type": "image", "image": path}
    else:
        media = {"type": "video", "video": path, "fps": fps}
    return [{"role": "user", "content": [media, {"type": "text", "text": prompt}]}]


def make_inputs(processor, msgs):
    text = processor.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True)
    if process_vision_info is None:                      # image-only fallback
        p = msgs[0]["content"][0].get("image")
        imgs, vids, vkw = [Image.open(p).convert("RGB")], None, {}
    else:
        vis = process_vision_info(msgs)
        if len(vis) == 3:                                # (imgs, vids, video_kwargs)
            imgs, vids, vkw = vis
        else:
            imgs, vids = vis
            vkw = {}
    return processor(text=[text], images=imgs, videos=vids,
                     return_tensors="pt", **vkw).to("cuda")


def run_one(model, processor, inputs, max_new_tokens):
    torch.cuda.reset_peak_memory_stats()
    streamer = TextIteratorStreamer(processor.tokenizer, skip_prompt=True,
                                    skip_special_tokens=True)
    holder = {}

    def _gen():
        with torch.no_grad():
            holder["out"] = model.generate(**inputs, max_new_tokens=max_new_tokens,
                                            do_sample=False, streamer=streamer)

    torch.cuda.synchronize()
    t0 = time.time()
    th = Thread(target=_gen)
    th.start()
    first, pieces = None, []
    for piece in streamer:
        if first is None:
            first = time.time()
        pieces.append(piece)
    th.join()
    torch.cuda.synchronize()
    t1 = time.time()

    out, text = holder["out"], "".join(pieces)
    n_in = inputs.input_ids.shape[1]
    n_out = out.shape[1] - n_in
    ttft = (first - t0) if first else (t1 - t0)
    total = t1 - t0
    decode = max(t1 - first, 1e-6) if first else total
    grid = next((inputs[k].tolist() for k in ("image_grid_thw", "video_grid_thw")
                 if k in inputs), None)
    return {
        "prompt_tokens": int(n_in),               # input_ids length, incl vision tokens
        "vision_grid_thw": grid,                  # resolution driver
        "output_tokens": int(n_out),
        "ttft_s": round(ttft, 4),                 # prefill + first token
        "total_s": round(total, 4),
        "decode_s": round(decode, 4),
        "decode_tok_per_s": round((n_out - 1) / decode, 2) if n_out > 1 else None,
        "peak_vram_gb": round(torch.cuda.max_memory_allocated() / 1e9, 3),
        "text": text,
    }


def parse_signal(text):
    try:
        arr = json.loads(text[text.find("["):text.rfind("]") + 1])
        return True, len(arr), (list(arr[0].keys()) if arr else [])
    except Exception:
        return False, None, None


def pctl(xs, q):
    xs = sorted(xs)
    return xs[min(len(xs) - 1, int(q * len(xs)))] if xs else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="Qwen/Qwen3-VL-4B-Instruct")
    ap.add_argument("--images", default=None, help="dir of image frames")
    ap.add_argument("--videos", default=None, help="dir of video clips")
    ap.add_argument("--task", default="ground3d", choices=list(PROMPTS))
    ap.add_argument("--video-task", default="detect2d", choices=list(PROMPTS),
                    help="task for video items (3D-on-video is non-standard)")
    ap.add_argument("--max-new-tokens", type=int, default=512)
    ap.add_argument("--dtype", default="auto")
    ap.add_argument("--attn", default="sdpa",
                    choices=["sdpa", "flash_attention_2", "eager"])
    ap.add_argument("--video-fps", type=float, default=2.0)
    ap.add_argument("--out", default="bench_out")
    args = ap.parse_args()

    items = [(p, "image", args.task) for p in collect(args.images, IMG_EXT)] + \
            [(p, "video", args.video_task) for p in collect(args.videos, VID_EXT)]
    if not items:
        raise SystemExit("No images or videos found. Pass --images and/or --videos.")
    os.makedirs(args.out, exist_ok=True)

    import transformers
    print(f"[env] torch {torch.__version__} | transformers {transformers.__version__} "
          f"| GPU {torch.cuda.get_device_name(0)}")
    print(f"[load] {args.model} | dtype={args.dtype} | attn={args.attn}")
    t0 = time.time()
    model = VLModel.from_pretrained(args.model, torch_dtype=args.dtype,
                                    attn_implementation=args.attn, device_map="cuda")
    processor = AutoProcessor.from_pretrained(args.model)
    model.eval()
    print(f"[load] {time.time() - t0:.1f}s | {len(items)} items "
          f"({sum(m == 'image' for _, m, _ in items)} img, "
          f"{sum(m == 'video' for _, m, _ in items)} vid)")

    # warmup (excluded from metrics)
    print("[warmup] ...")
    wp, wm, wt = items[0]
    run_one(model, processor,
            make_inputs(processor, build_messages(wp, wm, PROMPTS[wt], args.video_fps)),
            max_new_tokens=64)

    records, rec_path = [], os.path.join(args.out, "per_inference.jsonl")
    with open(rec_path, "w") as f:
        for path, mod, task in items:
            msgs = build_messages(path, mod, PROMPTS[task], args.video_fps)
            r = run_one(model, processor, make_inputs(processor, msgs), args.max_new_tokens)
            ok, n_obj, keys = parse_signal(r["text"])
            r["raw_preview"] = r.pop("text")[:600]
            r.update(file=os.path.basename(path), modality=mod, task=task,
                     parse_ok=ok, parsed_objects=n_obj, schema_keys=keys)
            records.append(r)
            f.write(json.dumps(r) + "\n")
            print(f"  {mod:5} {r['file'][:28]:28} "
                  f"ttft={r['ttft_s']:.2f}s tot={r['total_s']:.2f}s "
                  f"in={r['prompt_tokens']} out={r['output_tokens']} "
                  f"dec={r['decode_tok_per_s']} tok/s vram={r['peak_vram_gb']}GB obj={n_obj}")

    def agg(rs, label):
        if not rs:
            return
        tt = [x["ttft_s"] for x in rs]
        to = [x["total_s"] for x in rs]
        dc = [x["decode_tok_per_s"] for x in rs if x["decode_tok_per_s"]]
        print(f"\n[{label}] n={len(rs)}")
        print(f"  ttft  mean/p50/p95 : {sum(tt)/len(tt):.2f} / {pctl(tt,.5):.2f} / {pctl(tt,.95):.2f} s")
        print(f"  total mean/p50/p95 : {sum(to)/len(to):.2f} / {pctl(to,.5):.2f} / {pctl(to,.95):.2f} s")
        if dc:
            print(f"  decode tok/s mean  : {sum(dc)/len(dc):.1f}")
        print(f"  prompt toks  mean  : {sum(x['prompt_tokens'] for x in rs)/len(rs):.0f}")
        print(f"  output toks  mean  : {sum(x['output_tokens'] for x in rs)/len(rs):.0f}")
        print(f"  peak VRAM     max  : {max(x['peak_vram_gb'] for x in rs):.2f} GB")

    print("\n----- METRICS SUMMARY -----")
    agg([r for r in records if r["modality"] == "image"], "IMAGES")
    agg([r for r in records if r["modality"] == "video"], "VIDEOS")
    agg(records, "ALL")

    with open(os.path.join(args.out, "summary.json"), "w") as f:
        json.dump({"model": args.model, "attn": args.attn, "dtype": args.dtype,
                   "n": len(records), "records": records}, f, indent=2)
    print(f"\n[out] {rec_path}")
    print(f"[out] {os.path.join(args.out, 'summary.json')}")


if __name__ == "__main__":
    main()
