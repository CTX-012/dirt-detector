import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time

class VehicleController(Node):
    def __init__(self):
        super().__init__('vehicle_llm_controller')
        
        # Create a publisher for the bridged cmd_vel topic
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # State variables for the timer
        self.current_twist = Twist()
        
        # Create a timer to publish the current command at 10Hz
        # This prevents the Gazebo plugin from timing out
        self.timer = self.create_timer(0.1, self.timer_callback)
        
        self.get_logger().info('Vehicle Controller Node Started with 10Hz Heartbeat')
        self.get_logger().info('Action: Ensure the ros_gz_bridge is running!')

    def timer_callback(self):
        """Periodically publishes the current command."""
        self.publisher_.publish(self.current_twist)

    def set_velocity(self, linear_x, angular_z):
        """Updates the command that the timer is publishing."""
        self.current_twist.linear.x = float(linear_x)
        self.current_twist.angular.z = float(angular_z)

    def stop(self):
        """Stop the robot."""
        self.set_velocity(0.0, 0.0)
        self.get_logger().info('Robot Stopped')

    def move_forward(self, speed=0.5, duration=2.0):
        """Moves the robot forward for a specific duration."""
        self.get_logger().info(f'Moving forward at {speed} m/s for {duration}s')
        self.set_velocity(speed, 0.0)
        # We need to allow the timer to run while we wait
        start_time = time.time()
        while (time.time() - start_time) < duration:
            rclpy.spin_once(self, timeout_sec=0.1)
        self.stop()

    def turn(self, angular_speed=0.5, duration=1.0):
        """Turns the robot."""
        direction = "left" if angular_speed > 0 else "right"
        self.get_logger().info(f'Turning {direction} for {duration}s')
        self.set_velocity(0.0, angular_speed)
        start_time = time.time()
        while (time.time() - start_time) < duration:
            rclpy.spin_once(self, timeout_sec=0.1)
        self.stop()

def main(args=None):
    rclpy.init(args=args)
    controller = VehicleController()

    try:
        # Give the bridge a moment to connect
        time.sleep(1.0)
        
        # Robot movements
        controller.move_forward(speed=1.0, duration=3.0)
        time.sleep(1.0)
        controller.turn(angular_speed=1.0, duration=2.0)
        time.sleep(1.0)
        controller.move_forward(speed=1.0, duration=3.0)
        
    except KeyboardInterrupt:
        controller.stop()
    finally:
        # Ensure we stop before exiting
        controller.stop()
        controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
