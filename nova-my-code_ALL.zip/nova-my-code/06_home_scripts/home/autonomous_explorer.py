#!/usr/bin/env python3
"""
Autonomous Frontier Explorer for ROS 2 Humble
==============================================
This node autonomously explores unknown environments using frontier-based exploration.
It subscribes to the /map topic from SLAM Toolbox and publishes velocity commands
to drive the robot toward unexplored areas (frontiers).

Compatible with: ROS 2 Humble, TurtleBot3, SLAM Toolbox

Author: Generated for ROS 2 Humble simulation
License: MIT

Usage:
    1. Launch Gazebo with TurtleBot3
    2. Launch SLAM Toolbox
    3. Run this node: python3 autonomous_explorer.py

Requirements:
    - ros-humble-navigation2
    - ros-humble-slam-toolbox
    - ros-humble-turtlebot3*
    - numpy
"""

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
from nav_msgs.msg import OccupancyGrid, Odometry
from geometry_msgs.msg import Twist, PoseStamped
from sensor_msgs.msg import LaserScan
from tf2_ros import Buffer, TransformListener
import numpy as np
import math
from collections import deque
from enum import Enum
import time


class RobotState(Enum):
    """Robot state machine states"""
    IDLE = 0
    EXPLORING = 1
    MOVING_TO_FRONTIER = 2
    ROTATING = 3
    AVOIDING_OBSTACLE = 4
    COMPLETED = 5


class FrontierExplorer(Node):
    """
    Frontier-based autonomous exploration node.
    
    This node:
    1. Subscribes to /map from SLAM Toolbox
    2. Detects frontiers (boundaries between known and unknown space)
    3. Selects the best frontier to explore
    4. Navigates to the frontier using simple control
    5. Repeats until no frontiers remain
    """
    
    def __init__(self):
        super().__init__('frontier_explorer')
        
        # Declare and get parameters
        self.declare_parameter('linear_speed', 0.15)  # m/s - slow for better mapping
        self.declare_parameter('angular_speed', 0.4)  # rad/s
        self.declare_parameter('goal_tolerance', 0.3)  # meters
        self.declare_parameter('obstacle_distance', 0.35)  # meters
        self.declare_parameter('min_frontier_size', 5)  # minimum cells for valid frontier
        self.declare_parameter('exploration_timeout', 300.0)  # seconds
        self.declare_parameter('map_save_path', '~/maps/auto_map')
        
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.goal_tolerance = self.get_parameter('goal_tolerance').value
        self.obstacle_distance = self.get_parameter('obstacle_distance').value
        self.min_frontier_size = self.get_parameter('min_frontier_size').value
        self.exploration_timeout = self.get_parameter('exploration_timeout').value
        
        # QoS for map (transient local durability for SLAM Toolbox compatibility)
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            depth=1
        )
        
        # Subscribers
        self.map_sub = self.create_subscription(
            OccupancyGrid,
            '/map',
            self.map_callback,
            map_qos
        )
        
        self.odom_sub = self.create_subscription(
            Odometry,
            '/odom',
            self.odom_callback,
            10
        )
        
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )
        
        # Publisher
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # TF2 for transforms
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)
        
        # State variables
        self.state = RobotState.IDLE
        self.map_data = None
        self.map_info = None
        self.robot_pose = None
        self.current_goal = None
        self.frontiers = []
        self.scan_ranges = []
        self.start_time = time.time()
        self.last_frontier_time = time.time()
        self.stuck_counter = 0
        self.visited_goals = set()
        
        # Control timer (10 Hz)
        self.control_timer = self.create_timer(0.1, self.control_loop)
        
        # Frontier detection timer (1 Hz - less frequent to reduce CPU)
        self.frontier_timer = self.create_timer(1.0, self.find_frontiers)
        
        self.get_logger().info('Frontier Explorer initialized')
        self.get_logger().info(f'Parameters: linear_speed={self.linear_speed}, angular_speed={self.angular_speed}')
        self.get_logger().info('Waiting for map data...')
    
    def map_callback(self, msg: OccupancyGrid):
        """Process incoming map data from SLAM Toolbox"""
        self.map_data = np.array(msg.data).reshape((msg.info.height, msg.info.width))
        self.map_info = msg.info
        
        if self.state == RobotState.IDLE:
            self.state = RobotState.EXPLORING
            self.get_logger().info('Map received. Starting exploration...')
    
    def odom_callback(self, msg: Odometry):
        """Update robot pose from odometry"""
        self.robot_pose = msg.pose.pose
    
    def scan_callback(self, msg: LaserScan):
        """Process laser scan for obstacle avoidance"""
        self.scan_ranges = list(msg.ranges)
    
    def find_frontiers(self):
        """
        Detect frontiers in the occupancy grid.
        
        Frontiers are cells that are:
        - Free space (value 0)
        - Adjacent to unknown space (value -1)
        """
        if self.map_data is None or self.map_info is None:
            return
        
        if self.state == RobotState.COMPLETED:
            return
        
        height, width = self.map_data.shape
        frontier_cells = []
        
        # Find frontier cells
        for y in range(1, height - 1):
            for x in range(1, width - 1):
                if self.map_data[y, x] == 0:  # Free cell
                    # Check if adjacent to unknown (-1)
                    neighbors = [
                        self.map_data[y-1, x],
                        self.map_data[y+1, x],
                        self.map_data[y, x-1],
                        self.map_data[y, x+1]
                    ]
                    if -1 in neighbors:
                        frontier_cells.append((x, y))
        
        # Cluster frontier cells into groups
        self.frontiers = self.cluster_frontiers(frontier_cells)
        
        # Filter small frontiers
        self.frontiers = [f for f in self.frontiers if len(f) >= self.min_frontier_size]
        
        if len(self.frontiers) == 0:
            elapsed = time.time() - self.start_time
            self.get_logger().info(f'No frontiers found. Exploration may be complete. Time: {elapsed:.1f}s')
            if time.time() - self.last_frontier_time > 10.0:  # No frontiers for 10 seconds
                self.state = RobotState.COMPLETED
                self.stop_robot()
                self.get_logger().info('=== EXPLORATION COMPLETE ===')
                self.get_logger().info('Save map with: ros2 run nav2_map_server map_saver_cli -f ~/maps/house_map')
        else:
            self.last_frontier_time = time.time()
            self.get_logger().debug(f'Found {len(self.frontiers)} frontier clusters')
    
    def cluster_frontiers(self, frontier_cells):
        """
        Cluster frontier cells into connected groups using BFS.
        """
        if not frontier_cells:
            return []
        
        cell_set = set(frontier_cells)
        clusters = []
        visited = set()
        
        for cell in frontier_cells:
            if cell in visited:
                continue
            
            # BFS to find connected cells
            cluster = []
            queue = deque([cell])
            
            while queue:
                current = queue.popleft()
                if current in visited:
                    continue
                if current not in cell_set:
                    continue
                
                visited.add(current)
                cluster.append(current)
                
                # Check 8-connected neighbors
                x, y = current
                neighbors = [
                    (x-1, y), (x+1, y), (x, y-1), (x, y+1),
                    (x-1, y-1), (x-1, y+1), (x+1, y-1), (x+1, y+1)
                ]
                for n in neighbors:
                    if n in cell_set and n not in visited:
                        queue.append(n)
            
            if cluster:
                clusters.append(cluster)
        
        return clusters
    
    def select_best_frontier(self):
        """
        Select the best frontier to explore.
        Strategy: Choose closest frontier centroid that hasn't been visited recently.
        """
        if not self.frontiers or self.robot_pose is None:
            return None
        
        robot_x = self.robot_pose.position.x
        robot_y = self.robot_pose.position.y
        
        best_frontier = None
        best_score = float('inf')
        
        for frontier in self.frontiers:
            # Calculate centroid
            centroid_x = sum(c[0] for c in frontier) / len(frontier)
            centroid_y = sum(c[1] for c in frontier) / len(frontier)
            
            # Convert to world coordinates
            world_x = self.map_info.origin.position.x + centroid_x * self.map_info.resolution
            world_y = self.map_info.origin.position.y + centroid_y * self.map_info.resolution
            
            # Skip if too close to a previously visited goal
            goal_key = (round(world_x, 1), round(world_y, 1))
            if goal_key in self.visited_goals:
                continue
            
            # Calculate distance (score = distance, lower is better)
            distance = math.sqrt((world_x - robot_x)**2 + (world_y - robot_y)**2)
            
            # Prefer larger frontiers (more to explore)
            size_bonus = len(frontier) * 0.01
            score = distance - size_bonus
            
            if score < best_score:
                best_score = score
                best_frontier = (world_x, world_y)
        
        return best_frontier
    
    def control_loop(self):
        """Main control loop - runs at 10 Hz"""
        if self.state == RobotState.IDLE or self.state == RobotState.COMPLETED:
            return
        
        # Check timeout
        if time.time() - self.start_time > self.exploration_timeout:
            self.get_logger().warn('Exploration timeout reached')
            self.state = RobotState.COMPLETED
            self.stop_robot()
            return
        
        # Check for obstacles
        if self.check_obstacle():
            self.avoid_obstacle()
            return
        
        # State machine
        if self.state == RobotState.EXPLORING:
            self.current_goal = self.select_best_frontier()
            if self.current_goal:
                self.state = RobotState.MOVING_TO_FRONTIER
                self.get_logger().info(f'New goal: ({self.current_goal[0]:.2f}, {self.current_goal[1]:.2f})')
            else:
                # No valid frontier, do a scan rotation
                self.rotate_scan()
        
        elif self.state == RobotState.MOVING_TO_FRONTIER:
            if self.current_goal and self.robot_pose:
                if self.reached_goal():
                    self.get_logger().info('Goal reached!')
                    # Mark as visited
                    goal_key = (round(self.current_goal[0], 1), round(self.current_goal[1], 1))
                    self.visited_goals.add(goal_key)
                    self.current_goal = None
                    self.state = RobotState.EXPLORING
                    self.stuck_counter = 0
                else:
                    self.move_to_goal()
        
        elif self.state == RobotState.ROTATING:
            # Handled in rotate_scan()
            pass
    
    def check_obstacle(self):
        """Check if there's an obstacle in front of the robot"""
        if not self.scan_ranges:
            return False
        
        # Check front 60 degrees
        num_ranges = len(self.scan_ranges)
        front_indices = list(range(0, num_ranges // 6)) + list(range(5 * num_ranges // 6, num_ranges))
        
        for i in front_indices:
            if 0 < self.scan_ranges[i] < self.obstacle_distance:
                return True
        return False
    
    def avoid_obstacle(self):
        """Simple obstacle avoidance - turn away from obstacle"""
        if not self.scan_ranges:
            return
        
        twist = Twist()
        
        # Find clearest direction
        num_ranges = len(self.scan_ranges)
        left_sum = sum(r if r > 0 and r < float('inf') else 0 
                       for r in self.scan_ranges[num_ranges//4:num_ranges//2])
        right_sum = sum(r if r > 0 and r < float('inf') else 0 
                        for r in self.scan_ranges[num_ranges//2:3*num_ranges//4])
        
        # Turn toward more open side
        if left_sum > right_sum:
            twist.angular.z = self.angular_speed
        else:
            twist.angular.z = -self.angular_speed
        
        # Small backward motion
        twist.linear.x = -0.05
        
        self.cmd_vel_pub.publish(twist)
        self.stuck_counter += 1
        
        if self.stuck_counter > 50:  # Stuck for 5 seconds
            self.get_logger().warn('Robot appears stuck, selecting new frontier')
            self.current_goal = None
            self.state = RobotState.EXPLORING
            self.stuck_counter = 0
    
    def move_to_goal(self):
        """Move toward the current goal using proportional control"""
        if not self.current_goal or not self.robot_pose:
            return
        
        # Get robot position and orientation
        robot_x = self.robot_pose.position.x
        robot_y = self.robot_pose.position.y
        
        # Get yaw from quaternion
        q = self.robot_pose.orientation
        yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                         1.0 - 2.0 * (q.y * q.y + q.z * q.z))
        
        # Calculate angle to goal
        goal_x, goal_y = self.current_goal
        angle_to_goal = math.atan2(goal_y - robot_y, goal_x - robot_x)
        
        # Calculate angle difference
        angle_diff = angle_to_goal - yaw
        # Normalize to [-pi, pi]
        while angle_diff > math.pi:
            angle_diff -= 2 * math.pi
        while angle_diff < -math.pi:
            angle_diff += 2 * math.pi
        
        twist = Twist()
        
        # If angle difference is large, rotate first
        if abs(angle_diff) > 0.3:  # ~17 degrees
            twist.angular.z = self.angular_speed if angle_diff > 0 else -self.angular_speed
            twist.linear.x = 0.05  # Slight forward motion while turning
        else:
            # Move forward with proportional angular correction
            twist.linear.x = self.linear_speed
            twist.angular.z = 1.0 * angle_diff  # Proportional steering
        
        self.cmd_vel_pub.publish(twist)
    
    def reached_goal(self):
        """Check if robot has reached the current goal"""
        if not self.current_goal or not self.robot_pose:
            return False
        
        robot_x = self.robot_pose.position.x
        robot_y = self.robot_pose.position.y
        goal_x, goal_y = self.current_goal
        
        distance = math.sqrt((goal_x - robot_x)**2 + (goal_y - robot_y)**2)
        return distance < self.goal_tolerance
    
    def rotate_scan(self):
        """Rotate in place to scan surroundings"""
        twist = Twist()
        twist.angular.z = self.angular_speed
        self.cmd_vel_pub.publish(twist)
        
        # After some rotation, go back to exploring
        self.state = RobotState.EXPLORING
    
    def stop_robot(self):
        """Stop all robot motion"""
        twist = Twist()
        self.cmd_vel_pub.publish(twist)


def main(args=None):
    rclpy.init(args=args)
    
    explorer = FrontierExplorer()
    
    try:
        rclpy.spin(explorer)
    except KeyboardInterrupt:
        explorer.get_logger().info('Exploration interrupted by user')
    finally:
        explorer.stop_robot()
        explorer.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
