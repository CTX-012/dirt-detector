import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import time
import os
from groq import Groq

# --- ROS 2 Control Logic ---
class RobotInterface(Node):
    def __init__(self):
        super().__init__('robot_llm_interface')
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.current_twist = Twist()
        # Create a timer for the 10Hz heartbeat Gazebo needs
        self.timer = self.create_timer(0.1, self.timer_callback)

    def timer_callback(self):
        self.publisher.publish(self.current_twist)

    def move_forward(self, duration=2.0, speed=0.5):
        self.get_logger().info(f"Action: Forward {speed}m/s for {duration}s")
        self.current_twist.linear.x = float(speed)
        self.current_twist.angular.z = 0.0
        time.sleep(duration)
        self.stop()

    def turn(self, duration=1.0, direction="left"):
        speed = 0.8 if direction == "left" else -0.8
        self.get_logger().info(f"Action: Turning {direction}")
        self.current_twist.linear.x = 0.0
        self.current_twist.angular.z = float(speed)
        time.sleep(duration)
        self.stop()

    def stop(self):
        self.current_twist.linear.x = 0.0
        self.current_twist.angular.z = 0.0
        self.get_logger().info("Action: Stop")

# --- LLM Logic ---
def get_llm_decision(user_prompt):
    api_key = os.environ.get("GROQ_API_KEY")
    if not api_key:
        raise ValueError("GROQ_API_KEY not found. Please run: export GROQ_API_KEY='your_key_here'")
        
    client = Groq(api_key=api_key)
    
    system_prompt = """
    You are a robot controller. You translate user requests into Python-like function calls.
    You only have these functions:
    - move_forward(duration, speed)
    - turn(duration, direction)  # direction is 'left' or 'right'
    - stop()

    Example:
    User: "Move ahead a bit then turn right"
    Assistant: move_forward(2.0, 0.5); turn(1.5, 'right'); stop()
    
    Respond ONLY with the function calls separated by semicolons.
    """

    completion = client.chat.completions.create(
        model="meta-llama/llama-4-maverick-17b-128e-instruct", 
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.1
    )
    return completion.choices[0].message.content

# --- Main Loop ---
def main():
    rclpy.init()
    robot = RobotInterface()
    
    print("\n=== AI Robot Commander ===")
    print("Type a command for the robot (e.g., 'Move forward then turn left') or 'exit'")

    try:
        while True:
            user_input = input("\nCommander: ")
            if user_input.lower() in ['exit', 'q']:
                break

            print("Thinking...")
            try:
                commands_str = get_llm_decision(user_input)
                print(f"LLM Decided: {commands_str}")

                # Execute the string commands safely
                commands = commands_str.split(';')
                for cmd in commands:
                    cmd = cmd.strip()
                    if not cmd: continue
                    
                    if "move_forward" in cmd:
                        robot.move_forward(duration=2.0)
                    elif "turn" in cmd:
                        direction = "left" if "left" in cmd else "right"
                        robot.turn(duration=1.5, direction=direction)
                    elif "stop" in cmd:
                        robot.stop()
                    
                    time.sleep(0.5)
            except ValueError as ve:
                print(f"\nConfiguration Error: {ve}")
                break # Exit to allow user to set the key
            except Exception as e:
                print(f"LLM Error: {e}")

    except KeyboardInterrupt:
        pass
    finally:
        robot.stop()
        # Brief sleep to ensure stop message is sent before shutdown
        time.sleep(0.2)
        robot.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
