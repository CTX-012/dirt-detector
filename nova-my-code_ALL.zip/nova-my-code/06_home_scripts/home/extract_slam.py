import rosbag2_py
from rclpy.serialization import deserialize_message
from rosidl_runtime_py.utilities import get_message

bag_path = "slam_toolbox_est"
topic = "/tf"

storage_options = rosbag2_py.StorageOptions(uri=bag_path, storage_id='sqlite3')
converter_options = rosbag2_py.ConverterOptions('', '')

reader = rosbag2_py.SequentialReader()
reader.open(storage_options, converter_options)

topic_types = reader.get_all_topics_and_types()
type_map = {t.name: t.type for t in topic_types}
msg_type = get_message(type_map[topic])

with open("est_slam_toolbox.tum", "w") as f:

    while reader.has_next():
        topic_name, data, t = reader.read_next()

        if topic_name != topic:
            continue

        msg = deserialize_message(data, msg_type)

        for tf in msg.transforms:

            if tf.header.frame_id == "odom" and tf.child_frame_id == "base_link":

                ts = t * 1e-9

                x = tf.transform.translation.x
                y = tf.transform.translation.y
                z = tf.transform.translation.z

                qx = tf.transform.rotation.x
                qy = tf.transform.rotation.y
                qz = tf.transform.rotation.z
                qw = tf.transform.rotation.w

                f.write(f"{ts} {x} {y} {z} {qx} {qy} {qz} {qw}\n")

print("SLAM trajectory saved")
