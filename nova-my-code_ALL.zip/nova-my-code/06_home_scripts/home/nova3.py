#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                     NOVA STRATEGIC SEEKER v3.0                                ║
║                  "Autonomous Cognitive Exploration"                            ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Features:                                                                    ║
║    - 8-Sector LiDAR Geometry Analysis                                         ║
║    - Hierarchical State Machine (Spiral, Wall-Follow, Door-Nudge, Recovery)   ║
║    - UHD Tactical HUD (2D Path Mapping, Radar, VLM Thoughts)                 ║
║    - Strict 50% YOLO Confidence Guard                                         ║
║    - Mission-Critical Terminal Logging (Pose, Direction, Objects)             ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import math
import time
import base64
import threading
from enum import Enum
from dataclasses import dataclass, field
from collections import deque
from typing import Dict, List, Optional, Tuple

import cv2
import numpy as np

# ROS 2 Imports
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge

# AI Imports
from ultralytics import YOLO
from groq import Groq

# Humble/NumPy 2.0 Compatibility
np.float_ = float 

# ══════════════════════════════════════════════════════════════════════════════
# DATA ARCHITECTURE
# ═══════════════════════════════════════════════════════════════════════════

class RobotState(Enum):
    INIT_RECON = "INITIALIZING_RECONNAISSANCE"
    SPIRAL_SEARCH = "OUTWARD_EXPANSION_SPIRAL"
    WALL_FOLLOW = "PERIMETER_WALL_FOLLOWING"
    DOOR_VERIFY = "DOORWAY_NUDGE_VERIFICATION"
    ENTER_ROOM = "TRANSITION_TO_NEW_SECTOR"
    ROOM_CLEAN = "INTERIOR_ROOM_CROSSING"
    STUCK_RECOVERY = "TACTICAL_LIDAR_ESCAPE"
    VOID_FLIGHT = "EXIT_FEATURELESS_VOID"

@dataclass
class LidarSectors:
    """8-Zone Spatial Awareness"""
    f: float = 10.0; fl: float = 10.0; l: float = 10.0; bl: float = 10.0
    b: float = 10.0; br: float = 10.0; r: float = 10.0; fr: float = 10.0
    
    def get_dict(self): 
        return {'F':self.f, 'FL':self.fl, 'L':self.l, 'BL':self.bl, 
                'B':self.b, 'BR':self.br, 'R':self.r, 'FR':self.fr}
    
    def min_front_arc(self):
        return min(self.f, self.fl, self.fr)

@dataclass
class RobotPose:
    x: float = 0.0
    y: float = 0.0
    yaw: float = 0.0
    
    def yaw_deg(self): return math.degrees(self.yaw) % 360
    def dist_to(self, ox, oy): return math.sqrt((self.x-ox)**2 + (self.y-oy)**2)

# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION PARAMETERS
# ═══════════════════════════════════════════════════════════════════════════

class Config:
    MAX_LINEAR = 0.22
    MAX_ANGULAR = 1.0
    EMERGENCY_DIST = 0.38
    CAUTION_DIST = 0.70
    WALL_TARGET = 0.50
    CONF_THRESHOLD = 0.50  # Hard filter for YOLO
    VLM_INTERVAL = 12.0
    MAP_SCALE = 15.0       # Pixels per meter
    HUD_WIDTH = 450
    MODEL_VLM = "llama-3.2-11b-vision-preview"

# ══════════════════════════════════════════════════════════════════════════════
# MAIN INTELLIGENCE NODE
# ═══════════════════════════════════════════════════════════════════════════

class NovaStrategicSeeker(Node):
    def __init__(self):
        super().__init__('nova_strategic_seeker_v3')
        
        # 1. AI/Vision Suite
        self.bridge = CvBridge()
        self.yolo = YOLO("yolov8n.pt")
        self.groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        
        # 2. State & Spatial Memory
        self.state = RobotState.INIT_RECON
        self.pose = RobotPose()
        self.lidar = LidarSectors()
        self.path_memory = deque(maxlen=2000)
        self.object_inventory = {}
        
        # 3. VLM Buffers
        self.vlm_thought = "System Standby..."
        self.vlm_action = "CONTINUE"
        self.last_vlm_time = 0.0
        self.vlm_door_found = False
        
        # 4. HUD Assets
        self.annotated_frame = None
        self.hud_canvas = None
        
        # 5. Communication Setup (Best Effort for high-frequency sensors)
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        self.create_subscription(LaserScan, '/scan', self.lidar_callback, sensor_qos)
        self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        self.create_subscription(Image, '/camera/image_raw', self.vision_callback, sensor_qos)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # 6. High-Frequency Decision Timers
        self.create_timer(0.1, self.strategic_engine)
        self.create_timer(1.0, self.terminal_record_keeper)
        
        self.get_logger().info("="*50)
        self.get_logger().info(" NOVA STRATEGIC SEEKER v3.0 - INTELLIGENCE ONLINE")
        self.get_logger().info("="*50)

    # ══════════════════════════════════════════════════════════════════════════
    # SENSOR PROCESSING
    # ══════════════════════════════════════════════════════════════════════════

    def terminal_record_keeper(self):
        """Generates the mission log for terminal records"""
        t = time.strftime("%H:%M:%S")
        pos_str = f"[{self.pose.x:.2f}, {self.pose.y:.2f}]"
        deg_str = f"{self.pose.yaw_deg():.0f}°"
        self.get_logger().info(f"LOG: {t} | POS: {pos_str} | DIR: {deg_str} | STATE: {self.state.name}")

    def odom_callback(self, msg):
        """Update 3D localization to 2D pose"""
        self.pose.x = msg.pose.pose.position.x
        self.pose.y = msg.pose.pose.position.y
        q = msg.pose.pose.orientation
        # Quaternion to Euler Yaw
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.pose.yaw = math.atan2(siny_cosp, cosy_cosp)
        # Store for Brain Mapping
        self.path_memory.append((self.pose.x, self.pose.y))

    def lidar_callback(self, msg):
        """Divide LiDAR into 8 strategic sectors"""
        raw = np.array(msg.ranges)
        raw[raw < 0.1] = 10.0 # Clean sensor noise
        n = len(raw)
        
        def get_sec(start_deg, end_deg):
            sector = raw[int(start_deg/360*n) : int(end_deg/360*n)]
            valid = sector[sector > 0.1]
            return float(np.min(valid)) if len(valid) > 0 else 10.0

        self.lidar.f = get_sec(350, 10)
        self.lidar.fr = get_sec(10, 50)
        self.lidar.r = get_sec(50, 130)
        self.lidar.br = get_sec(130, 170)
        self.lidar.b = get_sec(170, 190)
        self.lidar.bl = get_sec(190, 230)
        self.lidar.l = get_sec(230, 310)
        self.lidar.fl = get_sec(310, 350)

    def vision_callback(self, msg):
        """Process high-conf objects and VLM thoughts"""
        frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        
        # 1. YOLO with 50% Guard
        results = self.yolo(frame, conf=Config.CONF_THRESHOLD, verbose=False)[0]
        
        for box in results.boxes:
            label = self.yolo.names[int(box.cls[0])]
            conf = float(box.conf[0])
            if label not in self.object_inventory or conf > self.object_inventory[label]:
                self.object_inventory[label] = conf
                self.get_logger().info(f"[TACTICAL] HIGH-CONF OBJECT: {label.upper()} ({conf:.2f})")

        self.annotated_frame = results.plot()
        
        # 2. Strategic VLM (Async to prevent control lag)
        now = time.time()
        if now - self.last_vlm_time > Config.VLM_INTERVAL:
            self.last_vlm_time = now
            threading.Thread(target=self.call_vlm_strategic, args=(frame,)).start()

        self.render_tactical_hud()

    def call_vlm_strategic(self, frame):
        """Consult Vision Language Model for scene understanding"""
        try:
            _, buffer = cv2.imencode('.jpg', frame)
            b64 = base64.b64encode(buffer).decode('utf-8')
            
            prompt = "Analyze room layout. Return ONLY valid JSON: {'scene': 'summary', 'door': true/false, 'action': 'forward/left/right'}"
            
            response = self.groq_client.chat.completions.create(
                model=Config.MODEL_VLM,
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}
                ]}]
            )
            
            res_json = json.loads(response.choices[0].message.content)
            self.vlm_thought = res_json.get('scene', 'Analyzing...')
            self.vlm_action = res_json.get('action', 'CONTINUE')
            self.vlm_door_found = res_json.get('door', False)
        except Exception:
            pass

    # ══════════════════════════════════════════════════════════════════════════
    # HUD & MAPPING UI
    # ══════════════════════════════════════════════════════════════════════════

    def render_tactical_hud(self):
        """Renders the UHD Dashboard with Mini-Map and Radar"""
        if self.annotated_frame is None: return
        
        h, w = self.annotated_frame.shape[:2]
        hud = np.zeros((h, Config.HUD_WIDTH, 3), dtype=np.uint8) + 15 # Dark dashboard
        
        # 1. BRAIN MINI-MAP (Odometry Path)
        map_center = (Config.HUD_WIDTH // 2, 130)
        cv2.circle(hud, map_center, 90, (40, 40, 40), -1)
        for p in self.path_memory:
            px = int(map_center[0] + p[0] * Config.MAP_SCALE)
            py = int(map_center[1] - p[1] * Config.MAP_SCALE)
            if 0 < px < Config.HUD_WIDTH:
                cv2.circle(hud, (px, py), 1, (0, 255, 0), -1)
        cv2.putText(hud, "MISSION PATH MEMORY", (map_center[0]-70, map_center[1]+110), 1, 0.8, (255, 255, 255), 1)

        # 2. STATUS DATA
        y_pos = 280
        def draw_kv(k, v, color=(255, 255, 255)):
            nonlocal y_pos
            cv2.putText(hud, f"{k}: {v}", (20, y_pos), 1, 1.1, color, 1)
            y_pos += 30

        draw_kv("TACTICAL STATE", self.state.value, (0, 255, 255))
        draw_kv("VLM THOUGHT", self.vlm_thought[:35], (200, 200, 200))
        draw_kv("TRANSITION DOOR", "DETECTED" if self.vlm_door_found else "SEARCHING", (0, 255, 0) if self.vlm_door_found else (100, 100, 100))
        draw_kv("GLOBAL POSE", f"X:{self.pose.x:.1f} Y:{self.pose.y:.1f} θ:{self.pose.yaw_deg():.0f}°")

        # 3. LIDAR VECTOR RADAR
        radar_c = (Config.HUD_WIDTH // 2, 480)
        cv2.circle(hud, radar_c, 50, (60, 60, 60), 1)
        sectors = self.lidar.get_dict()
        angles = {'F':0, 'FR':45, 'R':90, 'BR':135, 'B':180, 'BL':225, 'L':270, 'FL':315}
        for k, dist in sectors.items():
            ang_rad = math.radians(angles[k] - 90)
            len_px = min(50, dist * 10)
            end_pt = (int(radar_c[0] + len_px * math.cos(ang_rad)), int(radar_c[1] + len_px * math.sin(ang_rad)))
            color = (0, 0, 255) if dist < Config.CAUTION_DIST else (0, 255, 0)
            cv2.line(hud, radar_c, end_pt, color, 2)
        cv2.putText(hud, "LIDAR SPATIAL RADAR", (radar_c[0]-70, radar_c[1]+75), 1, 0.8, (255, 255, 255), 1)

        # 4. YOLO REGISTRY (>50% Confidence)
        y_pos = 600
        cv2.putText(hud, "IDENTIFIED ASSETS (>50%)", (20, y_pos), 1, 1.0, (0, 200, 255), 1)
        y_pos += 25
        for obj, conf in list(self.object_inventory.items())[-5:]:
            draw_kv(f"• {obj.upper()}", f"{conf*100:.0f}%", (255, 255, 255))

        # Horizontal Stack
        combined = np.hstack([self.annotated_frame, hud])
        cv2.imshow("MAVERICK MISSION CONTROL v3.0", combined)
        cv2.waitKey(1)

    # ══════════════════════════════════════════════════════════════════════════
    # STRATEGIC STATE MACHINE
    # ══════════════════════════════════════════════════════════════════════════

    def strategic_engine(self):
        """Primary behavioral logic processor"""
        twist = Twist()
        
        # --- 0. CRITICAL REFLEX LAYER ---
        if self.lidar.f < Config.EMERGENCY_DIST:
            self.state = RobotState.STUCK_RECOVERY
            # Escape toward the sector with most clearance
            twist.angular.z = 0.8 if self.lidar.l > self.lidar.r else -0.8
            self.cmd_pub.publish(twist)
            return

        # --- 1. HIERARCHICAL STATE LOGIC ---
        if self.state == RobotState.INIT_RECON:
            # Perform a slow 360 to build initial map
            twist.angular.z = 0.5
            if len(self.path_memory) > 60: # After approx 6 seconds
                self.state = RobotState.SPIRAL_SEARCH

        elif self.state == RobotState.SPIRAL_SEARCH:
            # Expand until a wall is found
            twist.linear.x = 0.20
            twist.angular.z = 0.35
            if self.lidar.min_front_arc() < Config.CAUTION_DIST:
                self.state = RobotState.WALL_FOLLOW

        elif self.state == RobotState.WALL_FOLLOW:
            # PID-style behavior to track room perimeter
            if self.lidar.f < Config.CAUTION_DIST:
                twist.angular.z = 0.7 # Hard turn for corners
            else:
                twist.linear.x = 0.16
                # Follow Right wall with error correction
                error = self.lidar.r - Config.WALL_TARGET
                twist.angular.z = -error * 1.5 
            
            # Switch to Door Verification if VLM or Lidar detects a gap
            if self.lidar.l > 2.0 or self.vlm_door_found:
                self.state = RobotState.DOOR_VERIFY

        elif self.state == RobotState.DOOR_VERIFY:
            # Slow forward "nudge" to see if gap persists (confirming a door)
            twist.linear.x = 0.10
            if self.lidar.l > 2.0:
                self.state = RobotState.ENTER_ROOM
            elif self.lidar.f < 0.5: # False alarm
                self.state = RobotState.WALL_FOLLOW

        elif self.state == RobotState.ENTER_ROOM:
            # Pivot into the doorway
            twist.angular.z = 0.8 # Pivot Left
            if self.lidar.f > 2.0: # Path is clear
                twist.linear.x = 0.15
                self.state = RobotState.ROOM_CLEAN

        elif self.state == RobotState.ROOM_CLEAN:
            # Move through the center of the new room
            twist.linear.x = 0.18
            # Use VLM suggestions if available
            if self.vlm_action == 'left': twist.angular.z = 0.3
            elif self.vlm_action == 'right': twist.angular.z = -0.3
            
            if self.lidar.f < 0.6: # End of room
                self.state = RobotState.WALL_FOLLOW

        elif self.state == RobotState.STUCK_RECOVERY:
            # Pivot until front is clear
            twist.angular.z = 1.0
            if self.lidar.f > 1.2:
                self.state = RobotState.SPIRAL_SEARCH

        self.cmd_pub.publish(twist)

# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY
# ═══════════════════════════════════════════════════════════════════════════

def main(args=None):
    rclpy.init(args=args)
    node = NovaStrategicSeeker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info("Mission Aborted by Operator. Shutdown initiated.")
    finally:
        # Full stop for safety
        node.cmd_pub.publish(Twist())
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()