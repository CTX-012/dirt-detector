import os, base64, cv2, rclpy, numpy as np, threading, json, re, time
from rclpy.node import Node
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from rclpy.qos import QoSProfile, ReliabilityPolicy
from cv_bridge import CvBridge
from ultralytics import YOLO
from groq import Groq

# Humble Compatibility Fix
np.float_ = float

class NovaExplorer(Node):
    def __init__(self):
        super().__init__('nova_explorer')
        
        # 1. Models & Clients
        self.yolo = YOLO('yolov8n.pt') 
        self.groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        self.bridge = CvBridge()
        
        # 2. Parameters & Simulation Fix
        if not self.has_parameter('use_sim_time'):
            self.declare_parameter('use_sim_time', True)

        # 3. Autonomous Navigation State
        self.VOID_SPEED = 0.4    
        self.INTERIOR_SPEED = 0.15 
        self.turn_speed = 0.6
        
        self.yolo_objects = []
        self.vlm_description = "void" # Default to void
        self.is_void = True 
        self.lidar_min_front = 10.0
        self.auto_move = True # Robot explores by default
        
        # 4. ROS Comms
        qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=1)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10)
        self.img_sub = self.create_subscription(Image, '/camera/image_raw', self.vision_callback, qos)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # 5. Logic Timers
        self.create_timer(0.1, self.decision_engine) # 10Hz Navigation
        self.last_vlm_call = 0
        self.latest_frame = None
        
        self.get_logger().info("🚀 NOVA-INTERIOR ONLINE. Simulation time enabled.")

    def lidar_callback(self, msg):
        front_arc = list(msg.ranges[0:25]) + list(msg.ranges[335:360])
        self.lidar_min_front = min([r for r in front_arc if r > 0.1] or [10.0])

    def vision_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            self.latest_frame = frame
            
            # 1. YOLO (Local Tactical)
            results = self.yolo(frame, conf=0.3, verbose=False)
            self.yolo_objects = [self.yolo.names[int(b.cls[0])] for b in results[0].boxes]
            
            # 2. Strategic VLM Call (Every 10 seconds)
            now = self.get_clock().now().nanoseconds / 1e9
            if now - self.last_vlm_call > 10.0:
                threading.Thread(target=self.call_vlm, args=(frame,)).start()
                self.last_vlm_call = now

            cv2.imshow("NOVA Vision HUD", results[0].plot())
            cv2.waitKey(1)
        except: pass

    def call_vlm(self, frame):
        """Strategic Decision: Interior vs Void"""
        try:
            _, buf = cv2.imencode('.jpg', cv2.resize(frame, (640, 480)))
            img_b64 = base64.b64encode(buf).decode('utf-8')
            
            response = self.groq_client.chat.completions.create(
                model="llama-3.2-11b-vision-preview",
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": "Are we in an interior room or an empty void? Answer ONLY 'Interior' or 'Void'."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}}
                ]}]
            )
            self.vlm_description = response.choices[0].message.content.strip().lower()
        except: pass

    def brain_chat(self, user_text):
        """Interactive Terminal Logic (Maverick/Scout Class)"""
        vision_context = f"Lidar Dist: {self.lidar_dist_msg()}, Objects: {self.yolo_objects}, Mode: {self.vlm_description}"
        
        prompt = f"""You are NOVA. 
        EYES: {vision_context}.
        RULES: Respond in JSON only. {{"reply": "text", "auto": bool}}
        - 'auto' is true if the robot should continue exploring, false if it should stop to listen."""
        
        try:
            resp = self.groq_client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "system", "content": prompt}, {"role": "user", "content": user_text}]
            )
            data = json.loads(re.search(r'\{.*\}', resp.choices[0].message.content, re.DOTALL).group(0))
            print(f"\n🤖 NOVA: {data['reply']}\n")
            self.auto_move = data.get('auto', True)
        except Exception as e:
            print(f"❌ Brain Error: {e}")

    def lidar_dist_msg(self):
        return f"{self.lidar_min_front:.2f}m"

    def decision_engine(self):
        """Final Brain to Command Logic"""
        if not self.auto_move:
            self.cmd_pub.publish(Twist()) # Stop if user wants to chat
            return

        twist = Twist()
        vision_says_void = "void" in self.vlm_description
        
        # 1. EMERGENCY AVOIDANCE
        if self.lidar_min_front < 0.6:
            twist.linear.x = 0.0
            twist.angular.z = self.turn_speed
        # 2. VOID MODE (Speed up to find walls)
        elif vision_says_void and len(self.yolo_objects) == 0:
            self.is_void = True
            twist.linear.x = self.VOID_SPEED
            twist.angular.z = 0.1 # Slight spiral search
        # 3. INTERIOR MODE (Slow mapping)
        else:
            self.is_void = False
            twist.linear.x = self.INTERIOR_SPEED
            twist.angular.z = 0.0
            
        self.cmd_pub.publish(twist)

def main():
    rclpy.init()
    node = NovaExplorer()
    
    # Run ROS in background
    ros_thread = threading.Thread(target=lambda: rclpy.spin(node), daemon=True)
    ros_thread.start()

    print("\n" + "="*50)
    print("🤖 NOVA TRIPLE-CORE EXPLORER ONLINE")
    print("Commands: 'What do you see?', 'Stop', 'Explore', 'exit'")
    print("="*50)

    try:
        while True:
            u = input("YOU: ").strip()
            if u.lower() in ['exit', 'quit']: break
            if not u: continue
            
            # Print decision logs
            print(f"   [LOG] Lidar: {node.lidar_min_front:.2f}m | VLM: {node.vlm_description}")
            node.brain_chat(u)
    except KeyboardInterrupt:
        pass
    finally:
        node.cmd_pub.publish(Twist())
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
