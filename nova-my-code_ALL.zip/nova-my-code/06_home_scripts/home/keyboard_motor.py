import serial
import time
import sys
import tty
import termios
import glob

def get_arduino_port():
    ports = glob.glob('/dev/ttyUSB*') + glob.glob('/dev/ttyACM*')
    return ports[0] if ports else None

def get_key():
    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setraw(sys.stdin.fileno())
        ch = sys.stdin.read(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
    return ch

# 1. Connect to Arduino
port = get_arduino_port()
if not port:
    print("❌ No Arduino found!")
    sys.exit(1)

arduino = serial.Serial(port, 9600, timeout=0.1)
time.sleep(2)
print("✅ Connected to {}".format(port))
print("Controls: W=Forward, S=Stop, A=Left, D=Right, X=Backward, Q=Quit")

# 2. Control Loop
try:
    while True:
        key = get_key().lower()
        if key == 'q': break
        
        cmd = None
        if key == 'w': cmd = b'F' # Forward
        elif key == 'x': cmd = b'B' # Backward
        elif key == 'a': cmd = b'L' # Left
        elif key == 'd': cmd = b'R' # Right
        elif key == 's': cmd = b'S' # Stop
        
        if cmd:
            arduino.write(cmd)
            print("Sent: {}".format(cmd.decode()))

except KeyboardInterrupt:
    print("\nExiting...")
finally:
    arduino.write(b'S')
    arduino.close()
