import os, base64, cv2, rclpy, numpy as np
from rclpy.node import Node
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from rclpy.qos import QoSProfile, ReliabilityPolicy
from cv_bridge import CvBridge
from ultralytics import YOLO
from groq import Groq

# Humble Compatibility
np.float_ = float

class InteriorSeeker(Node):
    def __init__(self):
        super().__init__('interior_seeker')
        
        # 1. Models & Clients
        self.yolo = YOLO('yolov8n.pt') 
        self.groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        self.bridge = CvBridge()
        
        # 2. Speeds
        self.VOID_SPEED = 0.4    # Fast to find walls
        self.INTERIOR_SPEED = 0.15 # Slow for accurate mapping
        self.turn_speed = 0.5
        
        # 3. State
        self.yolo_objects = []
        self.vlm_description = ""
        self.is_void = True 
        self.lidar_min_front = 10.0
        
        # 4. ROS Comms
        qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=1)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10)
        self.img_sub = self.create_subscription(Image, '/camera/image_raw', self.vision_callback, qos)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        self.create_timer(0.1, self.decision_engine)
        self.last_vlm_call = 0
        self.get_logger().info("🤖 Interior Seeker Online. Model: Llama-4-Maverick Strategic Logic.")

    def lidar_callback(self, msg):
        # Check if physical walls are within 3 meters
        front_arc = list(msg.ranges[0:20]) + list(msg.ranges[340:360])
        self.lidar_min_front = min([r for r in front_arc if r > 0.1] or [10.0])

    def vision_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        
        # 1. YOLO Check (Tactical)
        results = self.yolo(frame, conf=0.3, verbose=False)
        self.yolo_objects = [self.yolo.names[int(b.cls[0])] for b in results[0].boxes]
        
        # 2. VLM Strategic Check (Every 8 seconds)
        now = self.get_clock().now().nanoseconds / 1e9
        if now - self.last_vlm_call > 8.0:
            self.call_vlm(frame)
            self.last_vlm_call = now

        # Show AI Visualization
        annotated = results[0].plot()
        cv2.putText(annotated, f"Status: {'VOID' if self.is_void else 'INTERIOR'}", (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255) if self.is_void else (0, 255, 0), 2)
        cv2.imshow("Vision: Maverick Strategy", annotated)
        cv2.waitKey(1)

    def call_vlm(self, frame):
        try:
            _, buf = cv2.imencode('.jpg', frame)
            img_b64 = base64.b64encode(buf).decode('utf-8')
            
            # Using Maverick-class logic via Llama 3.2 Vision for the image
            # Prompt specifically asks for interior features
            response = self.groq_client.chat.completions.create(
                model="meta-llama/llama-4-maverick-17b-128e-instruct",
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": "Analyze for interior mapping. Are there walls, furniture, or structures visible? Answer ONLY 'Interior' or 'Void'."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}}
                ]}]
            )
            res_text = response.choices[0].message.content.strip().lower()
            self.vlm_description = res_text
            self.get_logger().info(f"🧠 Maverick Logic: Scene is {res_text}")
        except Exception as e:
            self.get_logger().error(f"VLM Error: {e}")

    def decision_engine(self):
        twist = Twist()
        
        # Logic: If VLM says Void AND YOLO sees nothing AND LiDAR is clear > 3m
        # We are in a "Void Space"
        vision_says_empty = ("void" in self.vlm_description) and (len(self.yolo_objects) == 0)
        lidar_says_empty = self.lidar_min_front > 3.0
        
        if vision_says_empty and lidar_says_empty:
            self.is_void = True
            # APPROACH: Seek walls. Move fast in a slight spiral to cover ground.
            twist.linear.x = self.VOID_SPEED
            twist.angular.z = 0.15 # Slight curve to find boundaries
        else:
            self.is_void = False
            # APPROACH: Interior Mapping. Slow down for SLAM accuracy.
            if self.lidar_min_front < 0.6: # Obstacle Avoidance
                twist.linear.x = 0.0
                twist.angular.z = self.turn_speed
            else:
                twist.linear.x = self.INTERIOR_SPEED
                twist.angular.z = 0.0

        self.cmd_pub.publish(twist)

def main():
    rclpy.init()
    node = InteriorSeeker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cmd_pub.publish(Twist())
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
