#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                     NOVA INTERIOR SEEKER v2.0                                 ║
║                   "The Sentient Vacuum Bot"                                   ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Platform: TurtleBot3 Waffle Pi (Gazebo House World)                         ║
║  Architecture: Hierarchical Deliberative-Reactive Control                     ║
║  Features:                                                                    ║
║    - Tactical HUD with VLM thoughts, Pose, LiDAR sectors                     ║
║    - Roomba-style State Machine (SPIRAL→WALL_FOLLOW→DOOR→ROOM_CROSS)        ║
║    - YOLO Detection (terminal output only if conf > 50%)                     ║
║    - Rich VLM JSON responses (scene, density, door direction)                ║
║    - Visited Cell Memory for coverage tracking                               ║
║    - 8-Sector LiDAR analysis                                                 ║
║    - Stuck Detection & Recovery                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

import os
import sys
import json
import math
import time
import base64
import threading
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
from collections import deque

import cv2
import numpy as np

# ROS 2 Imports
import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from cv_bridge import CvBridge

# AI Imports
from ultralytics import YOLO
from groq import Groq

# ══════════════════════════════════════════════════════════════════════════════
# HUMBLE COMPATIBILITY FIX
# ══════════════════════════════════════════════════════════════════════════════
np.float_ = float  # Fix NumPy 2.x vs cv_bridge issue


# ══════════════════════════════════════════════════════════════════════════════
# ENUMS & DATA CLASSES
# ══════════════════════════════════════════════════════════════════════════════

class RobotState(Enum):
    """Roomba-inspired state machine states"""
    SPAWN_SCAN = "SPAWN_SCAN"           # Initial 360° reconnaissance
    SPIRAL = "SPIRAL"                    # Outward spiral to find walls
    WALL_FOLLOW = "WALL_FOLLOW"          # Follow wall perimeter
    DOOR_VERIFY = "DOOR_VERIFY"          # Nudge verification for doorways
    ENTER_ROOM = "ENTER_ROOM"            # Transition through doorway
    ROOM_CROSS = "ROOM_CROSS"            # Crisscross coverage within room
    RECOVERY = "RECOVERY"                # Stuck recovery mode
    VOID_ESCAPE = "VOID_ESCAPE"          # Escaping featureless void


@dataclass
class LidarSectors:
    """8-direction LiDAR sector analysis"""
    front: float = 10.0
    front_left: float = 10.0
    left: float = 10.0
    back_left: float = 10.0
    back: float = 10.0
    back_right: float = 10.0
    right: float = 10.0
    front_right: float = 10.0
    
    def to_dict(self) -> Dict[str, float]:
        return {
            'F': self.front, 'FL': self.front_left, 'L': self.left,
            'BL': self.back_left, 'B': self.back, 'BR': self.back_right,
            'R': self.right, 'FR': self.front_right
        }
    
    def min_front_arc(self) -> float:
        return min(self.front, self.front_left, self.front_right)
    
    def has_left_gap(self, threshold: float = 1.5) -> bool:
        return self.left > threshold or self.front_left > threshold
    
    def has_right_gap(self, threshold: float = 1.5) -> bool:
        return self.right > threshold or self.front_right > threshold
    
    def all_infinite(self, threshold: float = 8.0) -> bool:
        """Check if we're in a void (no walls detected)"""
        return all(v > threshold for v in [
            self.front, self.front_left, self.left, self.right, 
            self.front_right, self.back
        ])


@dataclass
class RobotPose:
    """Robot position and orientation"""
    x: float = 0.0
    y: float = 0.0
    yaw: float = 0.0  # Radians
    
    def yaw_degrees(self) -> float:
        return math.degrees(self.yaw) % 360
    
    def distance_to(self, other_x: float, other_y: float) -> float:
        return math.sqrt((self.x - other_x)**2 + (self.y - other_y)**2)


@dataclass
class VLMResponse:
    """Parsed VLM analysis response"""
    scene_type: str = "unknown"
    room_guess: str = "unknown"
    density: str = "unknown"
    door_visible: bool = False
    door_direction: str = "NONE"
    wall_visible: bool = True
    floor_clear: bool = True
    suggested_action: str = "FORWARD"
    raw_text: str = ""
    timestamp: float = 0.0


@dataclass
class DetectedObject:
    """YOLO detected object with confidence > 50%"""
    label: str
    confidence: float
    bbox: Tuple[int, int, int, int]  # x1, y1, x2, y2
    timestamp: float


@dataclass 
class VisitedCell:
    """Grid cell for coverage tracking"""
    x: int
    y: int
    visit_count: int = 1
    first_visit: float = 0.0


# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════

class Config:
    """All tunable parameters in one place"""
    
    # ─── Waffle Pi Physical Limits ───
    MAX_LINEAR_SPEED = 0.26      # m/s (Waffle Pi max)
    MAX_ANGULAR_SPEED = 1.82    # rad/s (Waffle Pi max)
    
    # ─── Operational Speeds ───
    SPIRAL_SPEED = 0.20         # Outward spiral
    WALL_FOLLOW_SPEED = 0.18    # Perimeter following
    INTERIOR_SPEED = 0.15       # Careful room mapping
    NUDGE_SPEED = 0.10          # Door verification
    RECOVERY_SPEED = 0.12       # Escape maneuvers
    
    TURN_SPEED = 0.5            # Normal rotation (VLM-friendly)
    FAST_TURN_SPEED = 0.8       # Emergency only
    SLOW_TURN_SPEED = 0.35      # During VLM capture
    
    # ─── Wall Following PID ───
    WALL_TARGET_DIST = 0.5      # Desired wall distance (m)
    WALL_PID_KP = 1.0
    WALL_PID_KI = 0.0
    WALL_PID_KD = 0.3
    
    # ─── Door Detection ───
    DOOR_GAP_MIN = 0.6          # Minimum gap width for door (m)
    DOOR_GAP_MAX = 2.0          # Maximum (larger = open area)
    DOOR_DEPTH_MIN = 1.5        # Depth behind gap (m)
    NUDGE_DISTANCE = 0.3        # Forward nudge for verification (m)
    NUDGE_GAP_INCREASE = 0.5    # Required gap increase to confirm
    
    # ─── Safety Thresholds ───
    EMERGENCY_STOP_DIST = 0.35  # Immediate stop (m)
    CAUTION_DIST = 0.6          # Slow down zone (m)
    VOID_THRESHOLD = 8.0        # Distance indicating void/infinity (m)
    
    # ─── Stuck Detection ───
    STUCK_CHECK_INTERVAL = 3.0  # Seconds between checks
    STUCK_MOVE_THRESHOLD = 0.1  # Minimum movement to not be stuck (m)
    STUCK_STRIKES_MAX = 3       # Strikes before recovery mode
    
    # ─── Coverage Grid ───
    CELL_SIZE = 0.25            # Grid cell size (m)
    
    # ─── VLM Settings ───
    VLM_INTERVAL = 5.0          # Seconds between VLM calls
    VLM_TIMEOUT = 10.0          # API timeout
    VLM_MODEL = "meta-llama/llama-4-maverick-17b-128e-instruct"
    
    # ─── YOLO Settings ───
    YOLO_MODEL = "yolov8n.pt"
    YOLO_CONF_THRESHOLD = 0.50  # Only show objects above 50%
    
    # ─── Spiral Parameters ───
    SPIRAL_EXPANSION_RATE = 0.15  # Angular reduction per cycle
    SPIRAL_MAX_RADIUS = 3.0       # Switch to wall-follow after this
    
    # ─── HUD Settings ───
    HUD_WIDTH = 300             # Sidebar width in pixels
    HUD_FONT = cv2.FONT_HERSHEY_SIMPLEX
    HUD_FONT_SCALE = 0.45
    HUD_COLOR_TITLE = (0, 255, 255)    # Yellow
    HUD_COLOR_TEXT = (255, 255, 255)   # White
    HUD_COLOR_ALERT = (0, 0, 255)      # Red
    HUD_COLOR_OK = (0, 255, 0)         # Green
    HUD_COLOR_STATE = (255, 200, 0)    # Orange


# ══════════════════════════════════════════════════════════════════════════════
# VLM PROMPT TEMPLATE
# ══════════════════════════════════════════════════════════════════════════════

VLM_PROMPT = """You are the visual cortex of an autonomous cleaning robot navigating indoors.
Analyze this camera image and return ONLY valid JSON (no markdown, no explanation):

{
  "scene_type": "room" or "corridor" or "void" or "doorway",
  "room_guess": "bedroom" or "kitchen" or "bathroom" or "living_room" or "hallway" or "unknown",
  "density": "empty" or "sparse" or "medium" or "cluttered",
  "door_visible": true or false,
  "door_direction": "LEFT" or "RIGHT" or "FRONT" or "NONE",
  "wall_visible": true or false,
  "floor_clear": true or false,
  "suggested_action": "FORWARD" or "TURN_LEFT" or "TURN_RIGHT" or "STOP" or "BACKUP"
}

Rules:
- "void" = featureless grey area with no walls/furniture (simulation artifact)
- "doorway" = you can see through an opening into another space
- door_direction = where an opening/doorway appears in frame
- floor_clear = no obstacles blocking immediate path
- Be concise. Return ONLY the JSON object."""


# ══════════════════════════════════════════════════════════════════════════════
# MAIN NODE CLASS
# ══════════════════════════════════════════════════════════════════════════════

class InteriorSeekerV2(Node):
    """
    NOVA Interior Seeker v2.0
    Autonomous room exploration with Roomba-style coverage
    """
    
    def __init__(self):
        super().__init__('interior_seeker_v2')
        self.get_logger().info("═" * 60)
        self.get_logger().info("   NOVA INTERIOR SEEKER v2.0 - Initializing...")
        self.get_logger().info("═" * 60)
        
        # ─── Core Components ───
        self.bridge = CvBridge()
        self.yolo = YOLO(Config.YOLO_MODEL)
        self.groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        
        # ─── State Machine ───
        self.state = RobotState.SPAWN_SCAN
        self.previous_state = None
        self.state_start_time = time.time()
        self.spawn_scan_count = 0  # Track 360° scan progress
        
        # ─── Sensor Data ───
        self.lidar = LidarSectors()
        self.pose = RobotPose()
        self.current_frame: Optional[np.ndarray] = None
        
        # ─── VLM State ───
        self.vlm_response = VLMResponse()
        self.last_vlm_time = 0.0
        self.vlm_lock = threading.Lock()
        self.vlm_thread: Optional[threading.Thread] = None
        
        # ─── YOLO State ───
        self.detected_objects: List[DetectedObject] = []
        self.yolo_annotated_frame: Optional[np.ndarray] = None
        
        # ─── Navigation Memory ───
        self.visited_cells: Dict[Tuple[int, int], VisitedCell] = {}
        self.obstacle_memory: List[Tuple[float, float]] = []
        self.door_candidates: List[Tuple[float, float, str]] = []  # x, y, direction
        
        # ─── Stuck Detection ───
        self.last_pose_check = RobotPose()
        self.last_pose_check_time = time.time()
        self.stuck_counter = 0
        
        # ─── Spiral State ───
        self.spiral_angle = 0.0
        self.spiral_radius = 0.5
        
        # ─── Wall Follow PID ───
        self.wall_pid_integral = 0.0
        self.wall_pid_last_error = 0.0
        
        # ─── Door Verification ───
        self.door_verify_start_lidar: Optional[LidarSectors] = None
        self.door_verify_direction = "NONE"
        self.nudge_start_pose: Optional[RobotPose] = None
        
        # ─── QoS Profiles ───
        sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=1
        )
        
        # ─── ROS Subscribers ───
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.lidar_callback, 10
        )
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self.odom_callback, 10
        )
        self.img_sub = self.create_subscription(
            Image, '/camera/image_raw', self.camera_callback, sensor_qos
        )
        
        # ─── ROS Publisher ───
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # ─── Main Control Loop Timer (10 Hz) ───
        self.control_timer = self.create_timer(0.1, self.control_loop)
        
        # ─── Stuck Check Timer (3 Hz) ───
        self.stuck_timer = self.create_timer(
            Config.STUCK_CHECK_INTERVAL, self.check_stuck
        )
        
        self.get_logger().info("✅ All systems initialized!")
        self.get_logger().info(f"   State: {self.state.value}")
        self.get_logger().info("═" * 60)
    
    # ══════════════════════════════════════════════════════════════════════════
    # SENSOR CALLBACKS
    # ══════════════════════════════════════════════════════════════════════════
    
    def lidar_callback(self, msg: LaserScan):
        """Process 360° LiDAR into 8 directional sectors"""
        ranges = np.array(msg.ranges)
        n = len(ranges)
        
        # Helper to get sector average (handles inf/nan)
        def sector_avg(start_deg: int, end_deg: int) -> float:
            start_idx = int((start_deg / 360) * n)
            end_idx = int((end_deg / 360) * n)
            if start_idx > end_idx:  # Wrap around
                sector = np.concatenate([ranges[start_idx:], ranges[:end_idx]])
            else:
                sector = ranges[start_idx:end_idx]
            valid = sector[(sector > 0.1) & (sector < 100)]
            return float(np.min(valid)) if len(valid) > 0 else 10.0
        
        # 8-sector analysis (clockwise from front)
        self.lidar.front = sector_avg(350, 10)
        self.lidar.front_right = sector_avg(10, 55)
        self.lidar.right = sector_avg(55, 125)
        self.lidar.back_right = sector_avg(125, 170)
        self.lidar.back = sector_avg(170, 190)
        self.lidar.back_left = sector_avg(190, 235)
        self.lidar.left = sector_avg(235, 305)
        self.lidar.front_left = sector_avg(305, 350)
    
    def odom_callback(self, msg: Odometry):
        """Update robot pose from odometry"""
        self.pose.x = msg.pose.pose.position.x
        self.pose.y = msg.pose.pose.position.y
        
        # Extract yaw from quaternion
        q = msg.pose.pose.orientation
        siny_cosp = 2 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1 - 2 * (q.y * q.y + q.z * q.z)
        self.pose.yaw = math.atan2(siny_cosp, cosy_cosp)
        
        # Update visited cells
        self._update_visited_cells()
    
    def camera_callback(self, msg: Image):
        """Process camera frame with YOLO and prepare for VLM"""
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            self.current_frame = frame.copy()
            
            # ─── YOLO Detection ───
            results = self.yolo(frame, conf=Config.YOLO_CONF_THRESHOLD, verbose=False)
            
            # Filter and store objects with conf > 50%
            self.detected_objects = []
            for box in results[0].boxes:
                conf = float(box.conf[0])
                if conf >= Config.YOLO_CONF_THRESHOLD:
                    label = self.yolo.names[int(box.cls[0])]
                    x1, y1, x2, y2 = map(int, box.xyxy[0])
                    obj = DetectedObject(
                        label=label,
                        confidence=conf,
                        bbox=(x1, y1, x2, y2),
                        timestamp=time.time()
                    )
                    self.detected_objects.append(obj)
            
            # Print detected objects to terminal
            if self.detected_objects:
                obj_str = " | ".join([
                    f"{o.label} ({o.confidence*100:.0f}%)" 
                    for o in self.detected_objects
                ])
                self.get_logger().info(f"[YOLO] {obj_str}")
            
            # Store annotated frame for HUD
            self.yolo_annotated_frame = results[0].plot()
            
            # ─── Trigger VLM (async, rate-limited) ───
            now = time.time()
            if now - self.last_vlm_time > Config.VLM_INTERVAL:
                if self.vlm_thread is None or not self.vlm_thread.is_alive():
                    self.vlm_thread = threading.Thread(
                        target=self._call_vlm_async,
                        args=(frame.copy(),)
                    )
                    self.vlm_thread.start()
                    self.last_vlm_time = now
            
            # ─── Render HUD ───
            self._render_hud()
            
        except Exception as e:
            self.get_logger().error(f"Camera callback error: {e}")
    
    # ══════════════════════════════════════════════════════════════════════════
    # VLM INTEGRATION
    # ══════════════════════════════════════════════════════════════════════════
    
    def _call_vlm_async(self, frame: np.ndarray):
        """Call VLM in background thread"""
        try:
            # Encode frame
            _, buf = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
            img_b64 = base64.b64encode(buf).decode('utf-8')
            
            # API call
            response = self.groq_client.chat.completions.create(
                model=Config.VLM_MODEL,
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": VLM_PROMPT},
                        {"type": "image_url", "image_url": {
                            "url": f"data:image/jpeg;base64,{img_b64}"
                        }}
                    ]
                }],
                timeout=Config.VLM_TIMEOUT
            )
            
            raw_text = response.choices[0].message.content.strip()
            
            # Parse JSON with 3-tier resilience
            parsed = self._parse_vlm_json(raw_text)
            
            with self.vlm_lock:
                self.vlm_response = parsed
                self.vlm_response.raw_text = raw_text
                self.vlm_response.timestamp = time.time()
            
            # Log to terminal
            self.get_logger().info(
                f"[VLM] Scene: {parsed.scene_type} | "
                f"Room: {parsed.room_guess} | "
                f"Density: {parsed.density} | "
                f"Door: {parsed.door_direction} | "
                f"Action: {parsed.suggested_action}"
            )
            
        except Exception as e:
            self.get_logger().warn(f"[VLM] Error: {e}")
    
    def _parse_vlm_json(self, raw: str) -> VLMResponse:
        """3-tier JSON extraction for LLM responses"""
        result = VLMResponse()
        
        # Tier 1: Direct parse
        try:
            data = json.loads(raw)
            return self._dict_to_vlm_response(data)
        except json.JSONDecodeError:
            pass
        
        # Tier 2: Regex search for JSON block
        import re
        json_match = re.search(r'\{[^{}]*\}', raw, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group())
                return self._dict_to_vlm_response(data)
            except json.JSONDecodeError:
                pass
        
        # Tier 3: Brace-counting extraction
        start = raw.find('{')
        if start != -1:
            depth = 0
            for i, c in enumerate(raw[start:], start):
                if c == '{':
                    depth += 1
                elif c == '}':
                    depth -= 1
                    if depth == 0:
                        try:
                            data = json.loads(raw[start:i+1])
                            return self._dict_to_vlm_response(data)
                        except json.JSONDecodeError:
                            break
        
        # Fallback: keyword search
        raw_lower = raw.lower()
        if "void" in raw_lower:
            result.scene_type = "void"
        elif "corridor" in raw_lower:
            result.scene_type = "corridor"
        elif "door" in raw_lower:
            result.door_visible = True
        
        return result
    
    def _dict_to_vlm_response(self, data: dict) -> VLMResponse:
        """Convert dict to VLMResponse with defaults"""
        return VLMResponse(
            scene_type=data.get("scene_type", "unknown"),
            room_guess=data.get("room_guess", "unknown"),
            density=data.get("density", "unknown"),
            door_visible=data.get("door_visible", False),
            door_direction=data.get("door_direction", "NONE"),
            wall_visible=data.get("wall_visible", True),
            floor_clear=data.get("floor_clear", True),
            suggested_action=data.get("suggested_action", "FORWARD")
        )
    
    # ══════════════════════════════════════════════════════════════════════════
    # TACTICAL HUD RENDERING
    # ══════════════════════════════════════════════════════════════════════════
    
    def _render_hud(self):
        """Render tactical HUD overlay on camera feed"""
        if self.yolo_annotated_frame is None:
            return
        
        frame = self.yolo_annotated_frame.copy()
        h, w = frame.shape[:2]
        
        # Create sidebar
        sidebar = np.zeros((h, Config.HUD_WIDTH, 3), dtype=np.uint8)
        sidebar[:] = (40, 40, 40)  # Dark grey background
        
        y = 25
        line_height = 22
        
        def put_text(text: str, color=Config.HUD_COLOR_TEXT, bold=False):
            nonlocal y
            thickness = 2 if bold else 1
            cv2.putText(sidebar, text, (10, y), Config.HUD_FONT,
                       Config.HUD_FONT_SCALE, color, thickness)
            y += line_height
        
        def put_divider():
            nonlocal y
            cv2.line(sidebar, (10, y), (Config.HUD_WIDTH - 10, y),
                    (100, 100, 100), 1)
            y += 10
        
        # ─── Title ───
        put_text("NOVA SEEKER v2.0", Config.HUD_COLOR_TITLE, bold=True)
        put_divider()
        
        # ─── State Machine ───
        state_color = Config.HUD_COLOR_OK if self.state != RobotState.RECOVERY else Config.HUD_COLOR_ALERT
        put_text(f"State: {self.state.value}", state_color, bold=True)
        state_duration = time.time() - self.state_start_time
        put_text(f"  Duration: {state_duration:.1f}s")
        put_divider()
        
        # ─── VLM Analysis ───
        put_text("VLM Analysis:", Config.HUD_COLOR_TITLE)
        with self.vlm_lock:
            vlm = self.vlm_response
        put_text(f"  Scene: {vlm.scene_type}")
        put_text(f"  Room: {vlm.room_guess}")
        put_text(f"  Density: {vlm.density}")
        door_color = Config.HUD_COLOR_OK if vlm.door_visible else Config.HUD_COLOR_TEXT
        put_text(f"  Door: {vlm.door_direction}", door_color)
        put_text(f"  Action: {vlm.suggested_action}")
        put_divider()
        
        # ─── Robot Pose ───
        put_text("Pose:", Config.HUD_COLOR_TITLE)
        put_text(f"  X: {self.pose.x:.2f} m")
        put_text(f"  Y: {self.pose.y:.2f} m")
        put_text(f"  Yaw: {self.pose.yaw_degrees():.0f} deg")
        put_divider()
        
        # ─── LiDAR Sectors ───
        put_text("LiDAR (m):", Config.HUD_COLOR_TITLE)
        sectors = self.lidar.to_dict()
        
        # Front row
        put_text(f"  FL:{sectors['FL']:.1f}  F:{sectors['F']:.1f}  FR:{sectors['FR']:.1f}")
        # Middle row
        put_text(f"  L:{sectors['L']:.1f}          R:{sectors['R']:.1f}")
        # Back row
        put_text(f"  BL:{sectors['BL']:.1f}  B:{sectors['B']:.1f}  BR:{sectors['BR']:.1f}")
        put_divider()
        
        # ─── Coverage Stats ───
        put_text("Coverage:", Config.HUD_COLOR_TITLE)
        total_cells = len(self.visited_cells)
        put_text(f"  Cells: {total_cells}")
        put_text(f"  Stuck: {self.stuck_counter}/3")
        put_divider()
        
        # ─── Detected Objects ───
        put_text("Objects (>50%):", Config.HUD_COLOR_TITLE)
        if self.detected_objects:
            for obj in self.detected_objects[:5]:  # Max 5 on HUD
                conf_color = Config.HUD_COLOR_OK if obj.confidence > 0.7 else Config.HUD_COLOR_TEXT
                put_text(f"  {obj.label}: {obj.confidence*100:.0f}%", conf_color)
        else:
            put_text("  None detected")
        
        # ─── Safety Indicators ───
        put_divider()
        if self.lidar.front < Config.EMERGENCY_STOP_DIST:
            put_text("!! EMERGENCY !!", Config.HUD_COLOR_ALERT, bold=True)
        elif self.lidar.front < Config.CAUTION_DIST:
            put_text("! CAUTION !", (0, 165, 255))  # Orange
        elif self.lidar.all_infinite():
            put_text("~ VOID DETECTED ~", (255, 0, 255))  # Magenta
        else:
            put_text("Status: OK", Config.HUD_COLOR_OK)
        
        # Combine frame and sidebar
        combined = np.hstack([frame, sidebar])
        
        # Display
        cv2.imshow("NOVA Interior Seeker v2", combined)
        cv2.waitKey(1)
    
    # ══════════════════════════════════════════════════════════════════════════
    # CONTROL LOOP (STATE MACHINE)
    # ══════════════════════════════════════════════════════════════════════════
    
    def control_loop(self):
        """Main control loop - executes at 10 Hz"""
        twist = Twist()
        
        # ─── Emergency Override (Reflex Layer) ───
        if self.lidar.front < Config.EMERGENCY_STOP_DIST:
            self.get_logger().warn("[REFLEX] Emergency stop - obstacle ahead!")
            twist.linear.x = 0.0
            twist.angular.z = Config.TURN_SPEED  # Turn away
            self.cmd_pub.publish(twist)
            return
        
        # ─── Void Detection Override ───
        if self.lidar.all_infinite() and self.state not in [RobotState.VOID_ESCAPE, RobotState.RECOVERY]:
            self.get_logger().warn("[VOID] Entering void escape mode")
            self._change_state(RobotState.VOID_ESCAPE)
        
        # ─── State Machine Execution ───
        if self.state == RobotState.SPAWN_SCAN:
            twist = self._state_spawn_scan()
        elif self.state == RobotState.SPIRAL:
            twist = self._state_spiral()
        elif self.state == RobotState.WALL_FOLLOW:
            twist = self._state_wall_follow()
        elif self.state == RobotState.DOOR_VERIFY:
            twist = self._state_door_verify()
        elif self.state == RobotState.ENTER_ROOM:
            twist = self._state_enter_room()
        elif self.state == RobotState.ROOM_CROSS:
            twist = self._state_room_cross()
        elif self.state == RobotState.RECOVERY:
            twist = self._state_recovery()
        elif self.state == RobotState.VOID_ESCAPE:
            twist = self._state_void_escape()
        
        self.cmd_pub.publish(twist)
    
    # ══════════════════════════════════════════════════════════════════════════
    # STATE IMPLEMENTATIONS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _state_spawn_scan(self) -> Twist:
        """Initial 360° reconnaissance scan"""
        twist = Twist()
        
        # Rotate 90° four times
        if self.spawn_scan_count < 4:
            twist.angular.z = Config.SLOW_TURN_SPEED
            
            # Check if we've rotated ~90 degrees
            elapsed = time.time() - self.state_start_time
            rotation_time = (math.pi / 2) / Config.SLOW_TURN_SPEED
            
            if elapsed > rotation_time * (self.spawn_scan_count + 1):
                self.spawn_scan_count += 1
                self.get_logger().info(f"[SPAWN] Scan {self.spawn_scan_count}/4 complete")
        else:
            # Scan complete, transition to SPIRAL
            self.get_logger().info("[SPAWN] 360° scan complete, entering SPIRAL mode")
            self._change_state(RobotState.SPIRAL)
        
        return twist
    
    def _state_spiral(self) -> Twist:
        """Outward spiral to find walls (Roomba pattern)"""
        twist = Twist()
        
        # Check if we've found a wall
        if self.lidar.min_front_arc() < Config.CAUTION_DIST:
            self.get_logger().info("[SPIRAL] Wall detected, switching to WALL_FOLLOW")
            self._change_state(RobotState.WALL_FOLLOW)
            return twist
        
        # Check for door on sides
        if self._check_door_candidate():
            return twist
        
        # Expanding spiral motion
        twist.linear.x = Config.SPIRAL_SPEED
        
        # Decreasing angular velocity creates outward spiral
        self.spiral_angle += 0.1
        angular_component = max(0.1, 0.6 - (self.spiral_angle * Config.SPIRAL_EXPANSION_RATE))
        twist.angular.z = angular_component
        
        # Safety: if spiral too large, go to wall follow
        if self.spiral_angle > Config.SPIRAL_MAX_RADIUS / Config.SPIRAL_EXPANSION_RATE:
            self.get_logger().info("[SPIRAL] Max radius reached, switching to WALL_FOLLOW")
            self._change_state(RobotState.WALL_FOLLOW)
        
        return twist
    
    def _state_wall_follow(self) -> Twist:
        """Follow wall at fixed distance (right-hand rule)"""
        twist = Twist()
        
        # Check for door candidates
        if self._check_door_candidate():
            return twist
        
        # PID wall following (maintain distance to right wall)
        error = self.lidar.right - Config.WALL_TARGET_DIST
        
        # PID calculation
        self.wall_pid_integral += error * 0.1
        derivative = (error - self.wall_pid_last_error) / 0.1
        self.wall_pid_last_error = error
        
        angular_correction = (
            Config.WALL_PID_KP * error +
            Config.WALL_PID_KI * self.wall_pid_integral +
            Config.WALL_PID_KD * derivative
        )
        
        # Clamp correction
        angular_correction = max(-Config.TURN_SPEED, min(Config.TURN_SPEED, angular_correction))
        
        # Forward with correction
        if self.lidar.front > Config.CAUTION_DIST:
            twist.linear.x = Config.WALL_FOLLOW_SPEED
            twist.angular.z = -angular_correction  # Negative because right-hand rule
        else:
            # Corner detected - turn left
            twist.angular.z = Config.TURN_SPEED
        
        return twist
    
    def _state_door_verify(self) -> Twist:
        """Nudge verification for potential doorway"""
        twist = Twist()
        
        if self.nudge_start_pose is None:
            # Start nudge
            self.nudge_start_pose = RobotPose(
                x=self.pose.x, y=self.pose.y, yaw=self.pose.yaw
            )
            self.door_verify_start_lidar = LidarSectors(
                front=self.lidar.front, front_left=self.lidar.front_left,
                left=self.lidar.left, right=self.lidar.right,
                front_right=self.lidar.front_right
            )
            self.get_logger().info(f"[DOOR] Starting nudge verification ({self.door_verify_direction})")
        
        # Move forward slowly
        distance_moved = self.pose.distance_to(
            self.nudge_start_pose.x, self.nudge_start_pose.y
        )
        
        if distance_moved < Config.NUDGE_DISTANCE:
            twist.linear.x = Config.NUDGE_SPEED
        else:
            # Check if gap increased (confirming real door)
            gap_increased = False
            
            if self.door_verify_direction == "LEFT":
                gap_change = self.lidar.left - self.door_verify_start_lidar.left
                gap_increased = gap_change > Config.NUDGE_GAP_INCREASE
            elif self.door_verify_direction == "RIGHT":
                gap_change = self.lidar.right - self.door_verify_start_lidar.right
                gap_increased = gap_change > Config.NUDGE_GAP_INCREASE
            
            if gap_increased:
                self.get_logger().info(f"[DOOR] ✓ Confirmed! Gap increased by {gap_change:.2f}m")
                self._change_state(RobotState.ENTER_ROOM)
            else:
                self.get_logger().info("[DOOR] ✗ False positive, returning to WALL_FOLLOW")
                self._change_state(RobotState.WALL_FOLLOW)
            
            self.nudge_start_pose = None
        
        return twist
    
    def _state_enter_room(self) -> Twist:
        """Enter through confirmed doorway"""
        twist = Twist()
        
        # Turn toward door direction
        if self.door_verify_direction == "LEFT":
            twist.angular.z = Config.TURN_SPEED
        elif self.door_verify_direction == "RIGHT":
            twist.angular.z = -Config.TURN_SPEED
        
        # Check if we're now facing the opening
        elapsed = time.time() - self.state_start_time
        turn_time = (math.pi / 2) / Config.TURN_SPEED
        
        if elapsed > turn_time:
            # Move forward into room
            if self.lidar.front > Config.CAUTION_DIST:
                twist.angular.z = 0.0
                twist.linear.x = Config.INTERIOR_SPEED
                
                # After moving forward a bit, start room crossing
                if elapsed > turn_time + 2.0:
                    self.get_logger().info("[ENTER] Entered new room, starting ROOM_CROSS")
                    self._change_state(RobotState.ROOM_CROSS)
            else:
                # Obstacle ahead, abort
                self.get_logger().warn("[ENTER] Blocked, returning to WALL_FOLLOW")
                self._change_state(RobotState.WALL_FOLLOW)
        
        return twist
    
    def _state_room_cross(self) -> Twist:
        """Crisscross pattern for room coverage"""
        twist = Twist()
        
        # Check for new doors
        if self._check_door_candidate():
            return twist
        
        # Simple coverage: go forward until obstacle, turn, repeat
        if self.lidar.front > Config.CAUTION_DIST:
            twist.linear.x = Config.INTERIOR_SPEED
            
            # Slight zigzag for coverage
            elapsed = time.time() - self.state_start_time
            twist.angular.z = 0.1 * math.sin(elapsed * 0.5)
        else:
            # Hit wall/obstacle - turn
            # Alternate between left and right turns
            turn_direction = 1 if int(time.time()) % 2 == 0 else -1
            twist.angular.z = Config.TURN_SPEED * turn_direction
        
        # Check if room seems complete (visited many cells recently)
        if self._check_room_complete():
            self.get_logger().info("[ROOM] Coverage sufficient, returning to WALL_FOLLOW")
            self._change_state(RobotState.WALL_FOLLOW)
        
        return twist
    
    def _state_recovery(self) -> Twist:
        """Stuck recovery - find largest opening"""
        twist = Twist()
        
        self.get_logger().info("[RECOVERY] Finding escape route...")
        
        # Find direction with most space
        sectors = self.lidar.to_dict()
        best_dir = max(sectors, key=sectors.get)
        best_dist = sectors[best_dir]
        
        self.get_logger().info(f"[RECOVERY] Best direction: {best_dir} ({best_dist:.2f}m)")
        
        # Turn toward best direction
        turn_map = {
            'F': 0, 'FR': -0.5, 'R': -1.57, 'BR': -2.5,
            'B': 3.14, 'BL': 2.5, 'L': 1.57, 'FL': 0.5
        }
        target_turn = turn_map.get(best_dir, 0)
        
        elapsed = time.time() - self.state_start_time
        
        if elapsed < abs(target_turn) / Config.TURN_SPEED:
            twist.angular.z = Config.TURN_SPEED if target_turn > 0 else -Config.TURN_SPEED
        else:
            # Move toward opening
            if self.lidar.front > Config.CAUTION_DIST:
                twist.linear.x = Config.RECOVERY_SPEED
                
                # Exit recovery after moving a bit
                if elapsed > 3.0:
                    self.get_logger().info("[RECOVERY] Escape successful!")
                    self.stuck_counter = 0
                    self._change_state(RobotState.SPIRAL)
            else:
                # Still stuck, try again
                self._change_state(RobotState.RECOVERY)
        
        return twist
    
    def _state_void_escape(self) -> Twist:
        """Escape from featureless void"""
        twist = Twist()
        
        # VLM says void AND lidar confirms no walls
        # Strategy: Turn until we see something
        
        with self.vlm_lock:
            is_still_void = self.vlm_response.scene_type == "void"
        
        if not self.lidar.all_infinite() or not is_still_void:
            self.get_logger().info("[VOID] Escaped! Found features.")
            self._change_state(RobotState.SPIRAL)
            return twist
        
        # Rotate to find features
        twist.angular.z = Config.SLOW_TURN_SPEED
        
        # Timeout protection
        if time.time() - self.state_start_time > 30.0:
            self.get_logger().warn("[VOID] Timeout, forcing SPIRAL")
            self._change_state(RobotState.SPIRAL)
        
        return twist
    
    # ══════════════════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ══════════════════════════════════════════════════════════════════════════
    
    def _change_state(self, new_state: RobotState):
        """Transition to a new state"""
        if new_state != self.state:
            self.previous_state = self.state
            self.state = new_state
            self.state_start_time = time.time()
            self.get_logger().info(f"[STATE] {self.previous_state.value} → {new_state.value}")
    
    def _check_door_candidate(self) -> bool:
        """Check if there's a potential door on either side"""
        
        # Left side gap
        if (self.lidar.left > Config.DOOR_GAP_MIN and 
            self.lidar.left < Config.DOOR_GAP_MAX and
            self.lidar.front_left > Config.DOOR_DEPTH_MIN):
            
            self.door_verify_direction = "LEFT"
            self.get_logger().info(f"[DOOR] Potential door LEFT (gap: {self.lidar.left:.2f}m)")
            self._change_state(RobotState.DOOR_VERIFY)
            return True
        
        # Right side gap
        if (self.lidar.right > Config.DOOR_GAP_MIN and 
            self.lidar.right < Config.DOOR_GAP_MAX and
            self.lidar.front_right > Config.DOOR_DEPTH_MIN):
            
            self.door_verify_direction = "RIGHT"
            self.get_logger().info(f"[DOOR] Potential door RIGHT (gap: {self.lidar.right:.2f}m)")
            self._change_state(RobotState.DOOR_VERIFY)
            return True
        
        # VLM detected door
        with self.vlm_lock:
            if self.vlm_response.door_visible:
                direction = self.vlm_response.door_direction
                if direction in ["LEFT", "RIGHT"]:
                    self.door_verify_direction = direction
                    self.get_logger().info(f"[VLM] Door detected: {direction}")
                    self._change_state(RobotState.DOOR_VERIFY)
                    return True
        
        return False
    
    def _check_room_complete(self) -> bool:
        """Check if current room has sufficient coverage"""
        # Simple heuristic: if we've been in ROOM_CROSS for a while
        # and revisiting cells, room is done
        elapsed = time.time() - self.state_start_time
        return elapsed > 30.0  # 30 seconds per room max
    
    def _update_visited_cells(self):
        """Update the visited cell grid"""
        cell_x = int(self.pose.x / Config.CELL_SIZE)
        cell_y = int(self.pose.y / Config.CELL_SIZE)
        cell_key = (cell_x, cell_y)
        
        if cell_key in self.visited_cells:
            self.visited_cells[cell_key].visit_count += 1
        else:
            self.visited_cells[cell_key] = VisitedCell(
                x=cell_x, y=cell_y,
                visit_count=1,
                first_visit=time.time()
            )
    
    def check_stuck(self):
        """Periodic stuck detection"""
        distance_moved = self.pose.distance_to(
            self.last_pose_check.x, self.last_pose_check.y
        )
        
        if distance_moved < Config.STUCK_MOVE_THRESHOLD:
            self.stuck_counter += 1
            self.get_logger().warn(
                f"[STUCK] Strike {self.stuck_counter}/{Config.STUCK_STRIKES_MAX} "
                f"(moved only {distance_moved:.3f}m)"
            )
            
            if self.stuck_counter >= Config.STUCK_STRIKES_MAX:
                self.get_logger().error("[STUCK] Max strikes! Entering RECOVERY")
                self._change_state(RobotState.RECOVERY)
        else:
            # Reset counter if moving
            if self.stuck_counter > 0:
                self.stuck_counter = max(0, self.stuck_counter - 1)
        
        # Update check position
        self.last_pose_check = RobotPose(
            x=self.pose.x, y=self.pose.y, yaw=self.pose.yaw
        )
        self.last_pose_check_time = time.time()
    
    def shutdown(self):
        """Clean shutdown"""
        self.get_logger().info("Shutting down NOVA Interior Seeker v2...")
        
        # Stop robot
        self.cmd_pub.publish(Twist())
        
        # Close OpenCV windows
        cv2.destroyAllWindows()
        
        # Save memory to JSON
        self._save_memory()
    
    def _save_memory(self):
        """Save visited cells and discoveries to JSON"""
        memory = {
            "visited_cells": [
                {"x": c.x, "y": c.y, "visits": c.visit_count}
                for c in self.visited_cells.values()
            ],
            "total_cells": len(self.visited_cells),
            "obstacles": self.obstacle_memory,
            "doors": self.door_candidates
        }
        
        try:
            with open("nova_memory.json", "w") as f:
                json.dump(memory, f, indent=2)
            self.get_logger().info(f"Memory saved: {len(self.visited_cells)} cells")
        except Exception as e:
            self.get_logger().error(f"Failed to save memory: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def main(args=None):
    print("═" * 70)
    print("   NOVA INTERIOR SEEKER v2.0")
    print("   The Sentient Vacuum Bot")
    print("   Platform: TurtleBot3 Waffle Pi | World: turtlebot3_house")
    print("═" * 70)
    
    rclpy.init(args=args)
    node = InteriorSeekerV2()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        print("\n[SHUTDOWN] Keyboard interrupt received")
    finally:
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()
        print("[SHUTDOWN] Complete. Goodbye!")


if __name__ == '__main__':
    main()