import rclpy
from nav2_simple_commander.robot_navigator import BasicNavigator, TaskResult
from geometry_msgs.msg import PoseStamped
import time

def main():
    rclpy.init()
    navigator = BasicNavigator()

    # 1. Wait for Nav2 to be fully active
    print("Checking if Nav2 is ready...")
    navigator.waitUntilNav2Active()

    # 2. Define our Goal (Destination)
    goal_pose = PoseStamped()
    goal_pose.header.frame_id = 'map'
    goal_pose.header.stamp = navigator.get_clock().now().to_msg()
    
    # Set coordinates: X=2.0 meters, Y=-0.5 meters
    goal_pose.pose.position.x = 2.0
    goal_pose.pose.position.y = -0.5
    # Face forward (Orientation)
    goal_pose.pose.orientation.w = 1.0

    # 3. Send the robot to the goal
    print(f"Sending robot to: {goal_pose.pose.position.x}, {goal_pose.pose.position.y}")
    navigator.goToPose(goal_pose)

    # 4. Monitor the robot's progress
    while not navigator.isTaskComplete():
        feedback = navigator.getFeedback()
        if feedback:
            # Prints distance left to travel
            print(f'Distance remaining: {feedback.distance_remaining:.2f} m')
        time.sleep(1) # Check every second

    # 5. Check if the robot arrived safely
    result = navigator.getResult()
    if result == TaskResult.SUCCEEDED:
        print('Success! Robot reached the destination.')
    elif result == TaskResult.CANCELED:
        print('The goal was canceled!')
    elif result == TaskResult.FAILED:
        print('Robot failed to reach the goal.')

    rclpy.shutdown()

if __name__ == '__main__':
    main()
