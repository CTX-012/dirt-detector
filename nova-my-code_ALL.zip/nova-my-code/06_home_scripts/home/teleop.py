import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist

class Teleop(Node):
    def __init__(self):
        super().__init__('teleop_node')
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.timer = self.create_timer(0.1, self.move)

    def move(self):
        msg = Twist()
        msg.linear.x = 0.3
        msg.angular.z = 0.4
        self.pub.publish(msg)

rclpy.init()
node = Teleop()
rclpy.spin(node)
node.destroy_node()
rclpy.shutdown()
