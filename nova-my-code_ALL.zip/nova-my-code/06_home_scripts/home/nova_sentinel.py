#!/usr/bin/env python3
"""
═══════════════════════════════════════════════════════════════════════════════
NOVA SENTINEL v22 - Main Control Node
═══════════════════════════════════════════════════════════════════════════════

BE SLOW BUT CORRECT:
    STOP → WAIT → CAPTURE → VLM → LLM → MOVE → (repeat)

Usage:
    export GROQ_API_KEY="your-key-here"
    ros2 launch turtlebot3_gazebo turtlebot3_house.launch.py
    python3 nova_sentinel.py

═══════════════════════════════════════════════════════════════════════════════
"""

import os
import sys
import time
import math
import threading
from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List
from collections import deque

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy

from sensor_msgs.msg import LaserScan, Image
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Twist

from cv_bridge import CvBridge
import numpy as np

# Local imports (same directory)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from nova_logger import NovaLogger, LogLevel, LogCategory
from void_detector import VoidDetector
from memory_system import NovaMemory
from vlm_client import VLMClient
from llm_client import LLMClient, Action


# ═══════════════════════════════════════════════════════════════════════════════
# STATE MACHINE DEFINITION
# ═══════════════════════════════════════════════════════════════════════════════

class State(Enum):
    """Robot state machine states."""
    INITIALIZING = "INIT"
    STOP = "STOP"
    WAIT = "WAIT"
    CAPTURE = "CAPTURE"
    ANALYZE = "ANALYZE"
    DECIDE = "DECIDE"
    EXECUTE = "EXECUTE"
    VOID_RECOVERY = "VOID_REC"
    STUCK_RECOVERY = "STUCK_REC"
    COMPLETE = "COMPLETE"


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN NODE
# ═══════════════════════════════════════════════════════════════════════════════

class NovaSentinel(Node):
    """
    NOVA Sentinel v22 - Deliberate Exploration Robot
    
    Core Philosophy: BE SLOW BUT CORRECT
    
    Every decision cycle:
        1. STOP  - Halt all motors
        2. WAIT  - Let sensors stabilize (500ms)
        3. CAPTURE - Grab camera frame
        4. ANALYZE - VLM scene understanding
        5. DECIDE - LLM action selection
        6. EXECUTE - Perform movement
        7. (repeat)
    """
    
    def __init__(self):
        super().__init__('nova_sentinel')
        
        # ─────────────────────────────────────────────────────────────────────
        # LOGGER (First, so we can log everything)
        # ─────────────────────────────────────────────────────────────────────
        
        self.log = NovaLogger(min_level=LogLevel.INFO)
        self.log.system("═" * 50)
        self.log.system("NOVA SENTINEL v22 - Initializing")
        self.log.system("═" * 50)
        
        # ─────────────────────────────────────────────────────────────────────
        # CONFIGURATION
        # ─────────────────────────────────────────────────────────────────────
        
        # Timing (ms)
        self.WAIT_DURATION = 0.5       # Seconds to wait after stop
        self.MOVE_DURATION = 2.0       # Default move duration
        self.TURN_DURATION = 2.5       # Time for 90° turn
        
        # Speeds
        self.LINEAR_SPEED = 0.15       # m/s forward
        self.ANGULAR_SPEED = 0.35      # rad/s turn
        self.RETREAT_SPEED = -0.10     # m/s backward
        
        # Void detection
        self.VOID_THRESHOLD = 3.0      # All directions > this = void
        
        # Stuck detection
        self.STUCK_THRESHOLD = 0.10    # Moved less than this = stuck
        self.STUCK_CHECK_INTERVAL = 3.0
        self.MAX_STUCK_COUNT = 3
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE
        # ─────────────────────────────────────────────────────────────────────
        
        self.state = State.INITIALIZING
        self.state_start_time = time.time()
        
        # Sensor data
        self.lidar_front = float('inf')
        self.lidar_left = float('inf')
        self.lidar_right = float('inf')
        self.lidar_back = float('inf')
        self.lidar_raw = []
        self.lidar_valid = False
        
        # Position
        self.robot_x = 0.0
        self.robot_y = 0.0
        self.robot_yaw = 0.0
        
        # Camera
        self.current_frame = None
        self.frame_valid = False
        self.bridge = CvBridge()
        
        # Void detection
        self.void_detector = VoidDetector(void_threshold_m=self.VOID_THRESHOLD)
        self.is_void = False
        
        # Stuck detection
        self.position_history = deque(maxlen=10)
        self.stuck_counter = 0
        self.last_stuck_check = time.time()
        
        # Decision state
        self.last_vlm_result = None
        self.last_decision = None
        self.cycle_count = 0
        
        # ─────────────────────────────────────────────────────────────────────
        # COMPONENTS
        # ─────────────────────────────────────────────────────────────────────
        
        # Memory
        memory_path = os.path.join(os.path.dirname(__file__), "memory/")
        self.memory = NovaMemory(base_path=memory_path)
        self.log.memory(f"Memory loaded from {memory_path}")
        
        # API Key
        self.api_key = os.environ.get("GROQ_API_KEY", "")
        if not self.api_key:
            self.log.error(LogCategory.SYSTEM, "GROQ_API_KEY not set! VLM/LLM disabled.")
        
        # VLM Client
        self.vlm = VLMClient(
            api_key=self.api_key,
            model="meta-llama/llama-4-maverick-17b-128e-instruct"
        ) if self.api_key else None
        
        # LLM Client
        self.llm = LLMClient(
            api_key=self.api_key,
            model="meta-llama/llama-4-scout-17b-16e-instruct"
        ) if self.api_key else None
        
        # ─────────────────────────────────────────────────────────────────────
        # ROS 2 SETUP
        # ─────────────────────────────────────────────────────────────────────
        
        # QoS for simulation
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            depth=10
        )
        
        # Publishers
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Subscribers
        self.lidar_sub = self.create_subscription(
            LaserScan, '/scan', self._lidar_callback, qos
        )
        self.odom_sub = self.create_subscription(
            Odometry, '/odom', self._odom_callback, qos
        )
        self.camera_sub = self.create_subscription(
            Image, '/camera/image_raw', self._camera_callback, qos
        )
        
        # Main control timer (10 Hz state machine)
        self.control_timer = self.create_timer(0.1, self._control_loop)
        
        # Memory auto-save timer (every 30 seconds)
        self.save_timer = self.create_timer(30.0, self._save_memory)
        
        self.log.system("ROS 2 setup complete")
        self.log.system("Waiting for sensor data...")
        
        # Transition to first state
        self._change_state(State.STOP)
    
    # ═══════════════════════════════════════════════════════════════════════════
    # CALLBACKS
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _lidar_callback(self, msg: LaserScan):
        """Process LiDAR scan."""
        self.lidar_raw = list(msg.ranges)
        
        # Process into sectors
        sectors, void_analysis = self.void_detector.analyze(self.lidar_raw)
        
        self.lidar_front = sectors.front
        self.lidar_left = sectors.left
        self.lidar_right = sectors.right
        self.lidar_back = sectors.back
        self.is_void = void_analysis.is_void
        
        self.lidar_valid = sectors.valid_count > 10
    
    def _odom_callback(self, msg: Odometry):
        """Process odometry."""
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y
        
        # Extract yaw from quaternion
        q = msg.pose.pose.orientation
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        self.robot_yaw = math.atan2(siny_cosp, cosy_cosp)
    
    def _camera_callback(self, msg: Image):
        """Process camera image."""
        try:
            self.current_frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
            self.frame_valid = True
        except Exception as e:
            self.log.error(LogCategory.SENSOR, f"Camera error: {e}")
            self.frame_valid = False
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STATE MACHINE
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _change_state(self, new_state: State, reason: str = ""):
        """Transition to a new state."""
        old_state = self.state
        self.state = new_state
        self.state_start_time = time.time()
        self.log.state_transition(old_state.value, new_state.value, reason)
    
    def _state_elapsed(self) -> float:
        """Time spent in current state."""
        return time.time() - self.state_start_time
    
    def _control_loop(self):
        """
        Main control loop - runs at 10 Hz.
        Implements: STOP → WAIT → CAPTURE → ANALYZE → DECIDE → EXECUTE
        """
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: INITIALIZING
        # ─────────────────────────────────────────────────────────────────────
        if self.state == State.INITIALIZING:
            # Wait for sensors
            if self.lidar_valid and self.frame_valid:
                self.log.system("All sensors online!")
                self._change_state(State.STOP, "sensors ready")
            elif self._state_elapsed() > 10.0:
                self.log.error(LogCategory.SYSTEM, "Sensor timeout - check topics")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: STOP
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.STOP:
            # Ensure motors are stopped
            self._send_velocity(0.0, 0.0)
            self._change_state(State.WAIT, "motors stopped")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: WAIT
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.WAIT:
            # Wait for stabilization
            if self._state_elapsed() >= self.WAIT_DURATION:
                self._change_state(State.CAPTURE, f"{self.WAIT_DURATION}s elapsed")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: CAPTURE
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.CAPTURE:
            # Log sensor state
            self.log.lidar_summary(
                self.lidar_front, self.lidar_left, 
                self.lidar_right, self.lidar_back
            )
            self.log.sensor(f"Position: ({self.robot_x:.2f}, {self.robot_y:.2f})")
            
            # Check for void FIRST
            if self.is_void:
                self.log.void("VOID DETECTED - All directions clear!")
                self._change_state(State.VOID_RECOVERY, "void detected")
                return
            
            # Check for emergency obstacle
            if self.lidar_front < 0.3:
                self.log.safety(f"Obstacle too close: {self.lidar_front:.2f}m")
                self._emergency_turn()
                self._change_state(State.STOP, "emergency avoid")
                return
            
            # Mark cell as visited
            self.memory.mark_visited(self.robot_x, self.robot_y)
            
            # Capture complete, move to analysis
            if self.frame_valid:
                self._change_state(State.ANALYZE, "frame captured")
            else:
                # No camera, skip VLM
                self.log.log(LogCategory.SENSOR, "No camera frame, using LiDAR only", LogLevel.WARN)
                self._change_state(State.DECIDE, "no frame")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: ANALYZE (VLM)
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.ANALYZE:
            if self.vlm and self.current_frame is not None:
                self.log.system("Calling VLM...")
                
                # Analyze scene
                result = self.vlm.analyze_cv2_frame(self.current_frame)
                self.last_vlm_result = result
                
                # Log result
                self.log.vlm_response(
                    result.scene_type,
                    result.object_density,
                    result.door_direction
                )
                self.log.vlm(f"Latency: {result.latency_ms}ms | Conf: {result.confidence:.2f}")
                
                self._change_state(State.DECIDE, "VLM complete")
            else:
                # No VLM available
                self._change_state(State.DECIDE, "VLM unavailable")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: DECIDE (LLM)
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.DECIDE:
            # Get VLM data (or defaults)
            vlm = self.last_vlm_result
            if vlm:
                scene_type = vlm.scene_type
                density = vlm.object_density
                door_detected = vlm.door_detected
                door_dir = vlm.door_direction
                navigable = vlm.navigable_directions
            else:
                scene_type = "unknown"
                density = "unknown"
                door_detected = False
                door_dir = None
                navigable = ["front"]
            
            # Get memory context
            memory_context = self.memory.get_summary_for_llm(self.robot_x, self.robot_y, max_objects=5)
            
            if self.llm:
                self.log.system("Calling LLM...")
                
                decision = self.llm.decide(
                    lidar_front=self.lidar_front,
                    lidar_left=self.lidar_left,
                    lidar_right=self.lidar_right,
                    lidar_back=self.lidar_back,
                    vlm_scene_type=scene_type,
                    vlm_object_density=density,
                    vlm_door_detected=door_detected,
                    vlm_door_direction=door_dir,
                    vlm_navigable=navigable,
                    is_void=self.is_void,
                    robot_x=self.robot_x,
                    robot_y=self.robot_y,
                    memory_context=memory_context
                )
            else:
                # Fallback to rule-based
                decision = self.llm.decide_simple(
                    self.lidar_front, self.lidar_left, self.lidar_right, self.is_void
                ) if self.llm else self._rule_based_decision()
            
            self.last_decision = decision
            
            # Log decision
            self.log.llm_decision(decision.action.value, decision.reason)
            self.log.llm(f"Latency: {decision.latency_ms}ms | Conf: {decision.confidence:.2f}")
            
            self._change_state(State.EXECUTE, "decision made")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: EXECUTE
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.EXECUTE:
            decision = self.last_decision
            
            if decision is None:
                self._change_state(State.STOP, "no decision")
                return
            
            # Execute action
            action = decision.action
            
            if action == Action.MOVE_FORWARD:
                self._execute_forward()
            elif action == Action.TURN_LEFT:
                self._execute_turn_left()
            elif action == Action.TURN_RIGHT:
                self._execute_turn_right()
            elif action == Action.TURN_AROUND:
                self._execute_turn_around()
            elif action == Action.RETREAT:
                self._execute_retreat()
            elif action == Action.APPROACH_DOOR:
                self._execute_forward()  # Same as forward for now
            elif action == Action.ENTER_ROOM:
                self._execute_forward()
            elif action == Action.SCAN:
                self._execute_scan()
            else:  # STOP
                pass
            
            # Cycle complete
            self.cycle_count += 1
            self.log.separator(f"Cycle {self.cycle_count} complete")
            
            # Check if stuck
            self._check_stuck()
            
            # Back to STOP for next cycle
            self._change_state(State.STOP, "execution complete")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: VOID_RECOVERY
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.VOID_RECOVERY:
            self.log.void("Executing void recovery - retreating to find walls")
            
            # Retreat
            self._execute_retreat()
            
            # Turn to find features
            if self.lidar_back < self.VOID_THRESHOLD:
                # Back has something, turn around
                self._execute_turn_around()
            elif self.lidar_left < self.lidar_right:
                self._execute_turn_left()
            else:
                self._execute_turn_right()
            
            self._change_state(State.STOP, "void recovery complete")
        
        # ─────────────────────────────────────────────────────────────────────
        # STATE: STUCK_RECOVERY
        # ─────────────────────────────────────────────────────────────────────
        elif self.state == State.STUCK_RECOVERY:
            self.log.safety("Executing stuck recovery")
            
            # Reverse
            self._send_velocity(self.RETREAT_SPEED, 0.0)
            time.sleep(1.0)
            self._send_velocity(0.0, 0.0)
            
            # Turn toward clearest direction
            if self.lidar_left > self.lidar_right:
                self._execute_turn_left()
            else:
                self._execute_turn_right()
            
            self.stuck_counter = 0
            self._change_state(State.STOP, "stuck recovery complete")
    
    # ═══════════════════════════════════════════════════════════════════════════
    # MOVEMENT EXECUTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _send_velocity(self, linear: float, angular: float):
        """Send velocity command."""
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        self.cmd_vel_pub.publish(msg)
    
    def _execute_forward(self):
        """Move forward for MOVE_DURATION."""
        self.log.movement_command(self.LINEAR_SPEED, 0.0, self.MOVE_DURATION)
        self._send_velocity(self.LINEAR_SPEED, 0.0)
        time.sleep(self.MOVE_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_turn_left(self):
        """Turn 90° left."""
        self.log.movement_command(0.0, self.ANGULAR_SPEED, self.TURN_DURATION)
        self._send_velocity(0.0, self.ANGULAR_SPEED)
        time.sleep(self.TURN_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_turn_right(self):
        """Turn 90° right."""
        self.log.movement_command(0.0, -self.ANGULAR_SPEED, self.TURN_DURATION)
        self._send_velocity(0.0, -self.ANGULAR_SPEED)
        time.sleep(self.TURN_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_turn_around(self):
        """Turn 180°."""
        duration = self.TURN_DURATION * 2
        self.log.movement_command(0.0, self.ANGULAR_SPEED, duration)
        self._send_velocity(0.0, self.ANGULAR_SPEED)
        time.sleep(duration)
        self._send_velocity(0.0, 0.0)
    
    def _execute_retreat(self):
        """Move backward."""
        self.log.movement_command(self.RETREAT_SPEED, 0.0, self.MOVE_DURATION)
        self._send_velocity(self.RETREAT_SPEED, 0.0)
        time.sleep(self.MOVE_DURATION)
        self._send_velocity(0.0, 0.0)
    
    def _execute_scan(self):
        """Rotate 360° to scan surroundings."""
        duration = self.TURN_DURATION * 4
        self.log.movement_command(0.0, self.ANGULAR_SPEED, duration)
        self._send_velocity(0.0, self.ANGULAR_SPEED)
        time.sleep(duration)
        self._send_velocity(0.0, 0.0)
    
    def _emergency_turn(self):
        """Emergency obstacle avoidance."""
        if self.lidar_left > self.lidar_right:
            self._execute_turn_left()
        else:
            self._execute_turn_right()
    
    # ═══════════════════════════════════════════════════════════════════════════
    # STUCK DETECTION
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _check_stuck(self):
        """Check if robot is stuck (not moving despite commands)."""
        now = time.time()
        
        if now - self.last_stuck_check < self.STUCK_CHECK_INTERVAL:
            return
        
        self.last_stuck_check = now
        
        # Add current position
        self.position_history.append((self.robot_x, self.robot_y, now))
        
        if len(self.position_history) < 2:
            return
        
        # Check movement over last few positions
        old_pos = self.position_history[0]
        new_pos = self.position_history[-1]
        
        dx = new_pos[0] - old_pos[0]
        dy = new_pos[1] - old_pos[1]
        distance = math.sqrt(dx*dx + dy*dy)
        
        if distance < self.STUCK_THRESHOLD:
            self.stuck_counter += 1
            self.log.safety(f"Stuck detected ({self.stuck_counter}/{self.MAX_STUCK_COUNT})")
            
            if self.stuck_counter >= self.MAX_STUCK_COUNT:
                self._change_state(State.STUCK_RECOVERY, "stuck threshold reached")
        else:
            self.stuck_counter = 0
    
    # ═══════════════════════════════════════════════════════════════════════════
    # FALLBACK
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _rule_based_decision(self):
        """Simple rule-based decision when no LLM available."""
        from llm_client import Decision, Action
        
        if self.is_void:
            return Decision(
                action=Action.RETREAT,
                reason="Void detected",
                confidence=1.0,
                target_direction="back",
                parameters={},
                raw_response="[RULE]",
                latency_ms=0
            )
        
        if self.lidar_front < 0.5:
            if self.lidar_left > self.lidar_right:
                return Decision(
                    action=Action.TURN_LEFT,
                    reason="Obstacle ahead, left clearer",
                    confidence=0.9,
                    target_direction="left",
                    parameters={},
                    raw_response="[RULE]",
                    latency_ms=0
                )
            else:
                return Decision(
                    action=Action.TURN_RIGHT,
                    reason="Obstacle ahead, right clearer",
                    confidence=0.9,
                    target_direction="right",
                    parameters={},
                    raw_response="[RULE]",
                    latency_ms=0
                )
        
        return Decision(
            action=Action.MOVE_FORWARD,
            reason="Path clear",
            confidence=0.8,
            target_direction="front",
            parameters={},
            raw_response="[RULE]",
            latency_ms=0
        )
    
    # ═══════════════════════════════════════════════════════════════════════════
    # UTILITIES
    # ═══════════════════════════════════════════════════════════════════════════
    
    def _save_memory(self):
        """Periodic memory save."""
        self.memory.save_all()
        stats = self.memory.get_coverage_stats()
        self.log.memory(f"Saved: {stats['visited_cells']} cells, {stats['objects_found']} objects")


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════════

def main(args=None):
    """Main entry point."""
    rclpy.init(args=args)
    
    node = NovaSentinel()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.log.system("Shutdown requested...")
    finally:
        # Stop motors
        node._send_velocity(0.0, 0.0)
        # Save memory
        node.memory.save_all()
        node.log.system("Memory saved. Goodbye!")
        
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
