#!/usr/bin/env python3
"""
Wall-Following Explorer for ROS 2 Humble
=========================================
Uses wall-following algorithm to systematically explore and map.
This is a proven, reliable approach for indoor mapping.

Run:
    Terminal 1: ros2 launch turtlebot3_gazebo turtlebot3_house.launch.py
    Terminal 2: ros2 launch slam_toolbox online_async_launch.py use_sim_time:=True
    Terminal 3: python3 wall_follower.py

Save map when done:
    ros2 run nav2_map_server map_saver_cli -f ~/maps/house_map --ros-args -p map_subscribe_transient_local:=true
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
import math
import time


class WallFollower(Node):
    def __init__(self):
        super().__init__('wall_follower')
        
        # Parameters
        self.linear_speed = 0.15
        self.angular_speed = 0.5
        
        # Wall following parameters
        self.desired_wall_dist = 0.5  # Target distance from wall
        self.front_stop_dist = 0.4    # Stop if obstacle this close
        self.side_threshold = 0.8     # Max distance to detect wall on side
        
        # PID for wall following
        self.kp = 2.0
        
        # Publishers/Subscribers
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_cb, 10)
        
        # State
        self.scan = None
        self.state = 'FIND_WALL'  # FIND_WALL, FOLLOW_WALL, TURN_LEFT
        self.start_time = time.time()
        
        # Control timer
        self.timer = self.create_timer(0.1, self.control)
        
        self.get_logger().info('='*50)
        self.get_logger().info('WALL FOLLOWER STARTED')
        self.get_logger().info('Following right wall')
        self.get_logger().info('='*50)

    def scan_cb(self, msg):
        self.scan = msg

    def get_regions(self):
        """Divide LIDAR into regions"""
        if self.scan is None:
            return None
        
        ranges = list(self.scan.ranges)
        n = len(ranges)
        
        def region_min(start_deg, end_deg):
            start_idx = int(start_deg * n / 360)
            end_idx = int(end_deg * n / 360)
            vals = []
            for i in range(start_idx, end_idx):
                r = ranges[i % n]
                if 0.05 < r < 10.0:
                    vals.append(r)
            return min(vals) if vals else 10.0
        
        return {
            'front': region_min(350, 360) if region_min(350, 360) < region_min(0, 10) else region_min(0, 10),
            'front_right': region_min(300, 350),
            'right': region_min(260, 300),
            'back_right': region_min(220, 260),
            'front_left': region_min(10, 60),
            'left': region_min(60, 100),
        }

    def control(self):
        # Timeout
        elapsed = time.time() - self.start_time
        if elapsed > 300:  # 5 minutes
            self.get_logger().info(f'Exploration complete after {elapsed:.0f}s')
            self.stop()
            self.timer.cancel()
            return
        
        r = self.get_regions()
        if r is None:
            return
        
        # Update front to include narrow front cone
        if self.scan:
            ranges = self.scan.ranges
            n = len(ranges)
            front_vals = []
            for i in list(range(0, 20)) + list(range(n-20, n)):
                if 0.05 < ranges[i] < 10.0:
                    front_vals.append(ranges[i])
            r['front'] = min(front_vals) if front_vals else 10.0
        
        twist = Twist()
        
        # State machine for wall following (right wall)
        if self.state == 'FIND_WALL':
            # Drive forward until we find a wall
            if r['front'] < self.front_stop_dist:
                # Wall ahead, turn left
                self.state = 'TURN_LEFT'
            elif r['right'] < self.side_threshold:
                # Found wall on right, start following
                self.state = 'FOLLOW_WALL'
            else:
                # Keep searching
                twist.linear.x = self.linear_speed
                twist.angular.z = -0.3  # Slight right turn to find wall
        
        elif self.state == 'TURN_LEFT':
            # Turn left until front is clear
            if r['front'] > self.front_stop_dist + 0.1:
                self.state = 'FOLLOW_WALL'
            else:
                twist.angular.z = self.angular_speed
        
        elif self.state == 'FOLLOW_WALL':
            if r['front'] < self.front_stop_dist:
                # Obstacle ahead, turn left
                self.state = 'TURN_LEFT'
            else:
                # Wall following logic
                right_dist = r['right']
                
                if right_dist > self.side_threshold:
                    # Lost wall on right, turn right to find it
                    twist.linear.x = self.linear_speed * 0.5
                    twist.angular.z = -self.angular_speed * 0.5
                else:
                    # Maintain distance from wall using P control
                    error = self.desired_wall_dist - right_dist
                    
                    twist.linear.x = self.linear_speed
                    twist.angular.z = self.kp * error
                    
                    # Clamp angular velocity
                    twist.angular.z = max(-self.angular_speed, 
                                         min(self.angular_speed, twist.angular.z))
        
        self.cmd_pub.publish(twist)
        
        # Log status every 10 seconds
        if int(elapsed) % 10 == 0 and int(elapsed * 10) % 100 == 0:
            self.get_logger().info(f'[{elapsed:.0f}s] State: {self.state}, Front: {r["front"]:.2f}, Right: {r["right"]:.2f}')

    def stop(self):
        twist = Twist()
        self.cmd_pub.publish(twist)


def main():
    rclpy.init()
    node = WallFollower()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Stopped')
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
