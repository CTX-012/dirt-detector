import os, base64, cv2, rclpy, numpy as np
from rclpy.node import Node
from sensor_msgs.msg import Image, LaserScan
from geometry_msgs.msg import Twist
from rclpy.qos import QoSProfile, ReliabilityPolicy
from cv_bridge import CvBridge
from ultralytics import YOLO
from groq import Groq

# Humble Compatibility
try:
    np.float_ = float
    np.int_ = int
except AttributeError: pass

class TerminalBrain(Node):
    def __init__(self):
        super().__init__('terminal_brain')
        
        # Models
        self.yolo = YOLO("yolov8n-seg.pt") 
        self.groq_client = Groq(api_key=os.environ.get("GROQ_API_KEY"))
        self.bridge = CvBridge()
        
        # Params
        if not self.has_parameter('use_sim_time'):
            self.declare_parameter('use_sim_time', True)

        self.speed = 0.15
        self.turn_speed = 0.6
        
        # Data Buffers
        self.lidar_dist = 0.0
        self.yolo_objs = []
        self.seg_hazard = False
        self.vlm_strategy = "None"
        self.last_vlm_call = 0

        # ROS Setup
        qos = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, depth=1)
        self.img_sub = self.create_subscription(Image, '/camera/image_raw', self.vision_callback, qos)
        self.scan_sub = self.create_subscription(LaserScan, '/scan', self.lidar_callback, 10)
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Faster loop for high responsiveness (10Hz)
        self.create_timer(0.1, self.brain_loop)
        
        print("\n" + "="*50)
        print("🧠 ROBOT BRAIN ONLINE - MONITORING TERMINAL")
        print("="*50 + "\n")

    def lidar_callback(self, msg):
        # Intake LiDAR
        ranges = [r for r in msg.ranges[0:20]] + [r for r in msg.ranges[340:360]]
        self.lidar_dist = min([r for r in ranges if r > 0.05] or [10.0])

    def vision_callback(self, msg):
        try:
            frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
            h, w, _ = frame.shape
            results = self.yolo(frame, conf=0.4, imgsz=640, verbose=False)
            
            self.yolo_objs = [self.yolo.names[int(b.cls[0])] for b in results[0].boxes]
            self.seg_hazard = False

            if results[0].masks is not None:
                for mask in results[0].masks.xy:
                    mask_pts = np.array(mask, dtype=np.int32)
                    # Hazard check: Bottom 30% of screen, middle 40% width
                    if any((p[1] > h*0.7 and w*0.3 < p[0] < w*0.7) for p in mask_pts):
                        self.seg_hazard = True

            # Call VLM every 10s
            now = self.get_clock().now().nanoseconds / 1e9
            if now - self.last_vlm_call > 2.0:
                self.call_vlm(frame)
                self.last_vlm_call = now
                
            cv2.imshow("Robot Vision", results[0].plot())
            cv2.waitKey(1)
        except Exception as e: pass

    def call_vlm(self, frame):
        try:
            _, buffer = cv2.imencode('.jpg', frame)
            img_b64 = base64.b64encode(buffer).decode('utf-8')
            response = self.groq_client.chat.completions.create(
                model="llama-3.2-11b-vision-preview",
                messages=[{"role": "user", "content": [
                    {"type": "text", "text": "Describe scene for mapping. 5 words max."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{img_b64}"}}
                ]}]
            )
            self.vlm_strategy = response.choices[0].message.content.strip()
        except: self.vlm_strategy = "VLM Timeout"

    def brain_loop(self):
        twist = Twist()
        decision = ""
        
        # 1. THE DECISION LOGIC (BRAIN)
        if self.lidar_dist < 0.45:
            decision = "🛑 EMERGENCY: Wall Detected by LiDAR"
            twist.linear.x = 0.0
            twist.angular.z = self.turn_speed
        elif self.seg_hazard:
            decision = "⚠️ CAUTION: YOLO Segmentation Mask in Hazard Zone"
            twist.linear.x = 0.04
            twist.angular.z = self.turn_speed
        else:
            decision = "✅ CRUISE: Path is clear, moving forward"
            twist.linear.x = self.speed
            twist.angular.z = 0.0

        # 2. OUTPUT TO TERMINAL (LOGGING EVERYTHING)
        os.system('clear') # Keep terminal clean
        print(f"{'='*50}")
        print(f"🤖 ROBOT STATUS LOG")
        print(f"{'='*50}")
        print(f"[INPUTS]")
        print(f"  • LiDAR Min Dist : {self.lidar_dist:.2f} m")
        print(f"  • YOLO Objects   : {', '.join(self.yolo_objs) if self.yolo_objs else 'None'}")
        print(f"  • Seg. Hazard    : {'DETECTED' if self.seg_hazard else 'Clear'}")
        print(f"\n[STRATEGIC BRAIN (VLM)]")
        print(f"  • Context        : {self.vlm_strategy}")
        print(f"\n[FINAL BRAIN DECISION]")
        print(f"  • Action         : {decision}")
        print(f"  • Command        : Lin_X={twist.linear.x}, Ang_Z={twist.angular.z}")
        print(f"{'='*50}")

        self.cmd_pub.publish(twist)

def main():
    rclpy.init()
    node = TerminalBrain()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally:
        node.cmd_pub.publish(Twist())
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__': main()