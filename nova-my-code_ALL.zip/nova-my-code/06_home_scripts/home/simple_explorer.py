#!/usr/bin/env python3
"""
Simple Random Walk Explorer for ROS 2 Humble
=============================================
A lightweight exploration node that uses LIDAR-based obstacle avoidance
to explore and map an environment without requiring the full Nav2 stack.

This is simpler than frontier exploration and works with just:
- Gazebo + TurtleBot3
- SLAM Toolbox (for mapping)
- This node (for autonomous driving)

Compatible with: ROS 2 Humble, TurtleBot3, SLAM Toolbox

Usage:
    Terminal 1: ros2 launch turtlebot3_gazebo turtlebot3_house.launch.py
    Terminal 2: ros2 launch slam_toolbox online_async_launch.py use_sim_time:=True
    Terminal 3: python3 simple_explorer.py
    Terminal 4: ros2 run rviz2 rviz2 -d /opt/ros/humble/share/nav2_bringup/rviz/nav2_default_view.rviz

When done mapping:
    Terminal 5: ros2 run nav2_map_server map_saver_cli -f ~/maps/house_map --ros-args -p map_subscribe_transient_local:=true
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
import random
import math
import time


class SimpleExplorer(Node):
    """
    Simple exploration using LIDAR-based wall following and obstacle avoidance.
    
    Behavior:
    1. Drive forward while no obstacles
    2. When obstacle detected, turn toward clearest direction
    3. Occasionally make random turns to explore different areas
    4. Track map coverage and stop when mostly mapped
    """
    
    def __init__(self):
        super().__init__('simple_explorer')
        
        # Parameters
        self.declare_parameter('linear_speed', 0.12)  # Slow for better SLAM
        self.declare_parameter('angular_speed', 0.5)
        self.declare_parameter('obstacle_threshold', 0.4)  # meters
        self.declare_parameter('side_obstacle_threshold', 0.25)
        self.declare_parameter('exploration_time', 300)  # seconds
        
        self.linear_speed = self.get_parameter('linear_speed').value
        self.angular_speed = self.get_parameter('angular_speed').value
        self.obstacle_threshold = self.get_parameter('obstacle_threshold').value
        self.side_threshold = self.get_parameter('side_obstacle_threshold').value
        self.max_time = self.get_parameter('exploration_time').value
        
        # Subscribers
        self.scan_sub = self.create_subscription(
            LaserScan,
            '/scan',
            self.scan_callback,
            10
        )
        
        # Map subscriber (for coverage tracking)
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            depth=1
        )
        self.map_sub = self.create_subscription(
            OccupancyGrid,
            '/map',
            self.map_callback,
            map_qos
        )
        
        # Publisher
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # State
        self.scan_data = None
        self.map_received = False
        self.map_coverage = 0.0
        self.start_time = time.time()
        self.last_turn_time = time.time()
        self.turn_direction = 1  # 1 = left, -1 = right
        self.state = 'WAITING'  # WAITING, FORWARD, TURNING, AVOIDING
        self.turn_start_time = 0
        self.turn_duration = 0
        
        # Control timer (10 Hz)
        self.timer = self.create_timer(0.1, self.control_loop)
        
        # Status timer (every 10 seconds)
        self.status_timer = self.create_timer(10.0, self.print_status)
        
        self.get_logger().info('='*50)
        self.get_logger().info('Simple Explorer Started')
        self.get_logger().info('='*50)
        self.get_logger().info(f'Linear speed: {self.linear_speed} m/s')
        self.get_logger().info(f'Angular speed: {self.angular_speed} rad/s')
        self.get_logger().info(f'Obstacle threshold: {self.obstacle_threshold} m')
        self.get_logger().info(f'Max exploration time: {self.max_time} s')
        self.get_logger().info('Waiting for LIDAR data...')
    
    def scan_callback(self, msg: LaserScan):
        """Process LIDAR scan data"""
        self.scan_data = msg
        
        if self.state == 'WAITING':
            self.state = 'FORWARD'
            self.get_logger().info('LIDAR data received. Starting exploration!')
    
    def map_callback(self, msg: OccupancyGrid):
        """Track map coverage"""
        if not self.map_received:
            self.map_received = True
            self.get_logger().info('Map data received from SLAM Toolbox')
        
        # Calculate coverage (percentage of known cells)
        data = list(msg.data)
        total = len(data)
        known = sum(1 for cell in data if cell != -1)  # -1 = unknown
        self.map_coverage = (known / total) * 100 if total > 0 else 0
    
    def get_scan_regions(self):
        """
        Divide LIDAR scan into regions and get minimum distance for each.
        Returns dict with front, front_left, front_right, left, right, back
        """
        if self.scan_data is None:
            return None
        
        ranges = list(self.scan_data.ranges)
        n = len(ranges)
        
        def min_range(start_idx, end_idx):
            """Get minimum valid range in sector"""
            sector = []
            for i in range(start_idx, end_idx):
                idx = i % n
                r = ranges[idx]
                if r > 0.01 and r < float('inf'):
                    sector.append(r)
            return min(sector) if sector else float('inf')
        
        # TurtleBot3 LIDAR: 0° is front, counter-clockwise positive
        # Divide into 6 regions of 60° each
        regions = {
            'front': min_range(n - n//12, n) if n > 12 else min_range(0, n//6),
            'front_left': min_range(n//12, n//4),
            'left': min_range(n//4, 5*n//12),
            'back_left': min_range(5*n//12, 7*n//12),
            'back_right': min_range(7*n//12, 3*n//4),
            'right': min_range(3*n//4, 11*n//12),
            'front_right': min_range(11*n//12, n),
        }
        
        # Combine front region properly
        front_ranges = []
        for i in list(range(0, n//12)) + list(range(11*n//12, n)):
            r = ranges[i]
            if r > 0.01 and r < float('inf'):
                front_ranges.append(r)
        regions['front'] = min(front_ranges) if front_ranges else float('inf')
        
        return regions
    
    def control_loop(self):
        """Main control loop"""
        # Check timeout
        elapsed = time.time() - self.start_time
        if elapsed > self.max_time:
            self.get_logger().info('='*50)
            self.get_logger().info('EXPLORATION TIME COMPLETE!')
            self.get_logger().info(f'Total time: {elapsed:.1f} seconds')
            self.get_logger().info(f'Map coverage: {self.map_coverage:.1f}%')
            self.get_logger().info('='*50)
            self.get_logger().info('Save your map with:')
            self.get_logger().info('ros2 run nav2_map_server map_saver_cli -f ~/maps/house_map --ros-args -p map_subscribe_transient_local:=true')
            self.stop_robot()
            self.timer.cancel()
            return
        
        if self.state == 'WAITING':
            return
        
        regions = self.get_scan_regions()
        if regions is None:
            return
        
        twist = Twist()
        
        # State machine
        if self.state == 'TURNING':
            # Continue turning for set duration
            if time.time() - self.turn_start_time < self.turn_duration:
                twist.angular.z = self.turn_direction * self.angular_speed
                self.cmd_vel_pub.publish(twist)
                return
            else:
                self.state = 'FORWARD'
        
        # Check for obstacles
        front_clear = regions['front'] > self.obstacle_threshold
        front_left_clear = regions['front_left'] > self.side_threshold
        front_right_clear = regions['front_right'] > self.side_threshold
        
        if not front_clear:
            # Obstacle ahead - need to turn
            self.state = 'TURNING'
            self.turn_start_time = time.time()
            
            # Decide turn direction based on which side is clearer
            if regions['left'] > regions['right']:
                self.turn_direction = 1  # Turn left
            else:
                self.turn_direction = -1  # Turn right
            
            # Turn duration based on how close the obstacle is
            self.turn_duration = 0.5 + random.uniform(0.3, 1.0)
            
            self.get_logger().debug(f'Obstacle at {regions["front"]:.2f}m, turning {"left" if self.turn_direction > 0 else "right"}')
            
            twist.angular.z = self.turn_direction * self.angular_speed
            twist.linear.x = 0.0
        
        elif not front_left_clear:
            # Something on the left, veer right slightly
            twist.linear.x = self.linear_speed * 0.8
            twist.angular.z = -self.angular_speed * 0.5
        
        elif not front_right_clear:
            # Something on the right, veer left slightly
            twist.linear.x = self.linear_speed * 0.8
            twist.angular.z = self.angular_speed * 0.5
        
        else:
            # Path is clear - drive forward
            twist.linear.x = self.linear_speed
            
            # Occasional random turns to explore different areas
            if time.time() - self.last_turn_time > random.uniform(8, 15):
                self.last_turn_time = time.time()
                self.state = 'TURNING'
                self.turn_start_time = time.time()
                self.turn_direction = random.choice([-1, 1])
                self.turn_duration = random.uniform(0.5, 2.0)
                self.get_logger().debug('Random exploration turn')
        
        self.cmd_vel_pub.publish(twist)
    
    def print_status(self):
        """Print exploration status periodically"""
        elapsed = time.time() - self.start_time
        remaining = self.max_time - elapsed
        
        self.get_logger().info(f'[Status] Time: {elapsed:.0f}s | Remaining: {remaining:.0f}s | Map coverage: {self.map_coverage:.1f}%')
    
    def stop_robot(self):
        """Stop the robot"""
        twist = Twist()
        self.cmd_vel_pub.publish(twist)
        self.get_logger().info('Robot stopped')


def main(args=None):
    rclpy.init(args=args)
    
    explorer = SimpleExplorer()
    
    try:
        rclpy.spin(explorer)
    except KeyboardInterrupt:
        explorer.get_logger().info('Exploration interrupted by user')
        explorer.stop_robot()
    finally:
        explorer.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
