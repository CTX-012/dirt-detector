#!/usr/bin/env python3
"""
Working Autonomous SLAM Explorer for ROS 2 Humble
==================================================
Drives the robot to explore and map unknown environments.

TESTED WORKING with:
- TurtleBot3 Burger
- SLAM Toolbox
- Gazebo House World

Run:
    Terminal 1: ros2 launch turtlebot3_gazebo turtlebot3_house.launch.py
    Terminal 2: ros2 launch slam_toolbox online_async_launch.py use_sim_time:=True
    Terminal 3: python3 working_explorer.py
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import OccupancyGrid
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy
import math
import random
import time


class WorkingExplorer(Node):
    def __init__(self):
        super().__init__('working_explorer')
        
        # Parameters - tuned for TurtleBot3 burger
        self.linear_speed = 0.15
        self.angular_speed = 0.8
        self.front_dist_threshold = 0.4
        self.side_dist_threshold = 0.3
        
        # Publishers
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        
        # Subscribers
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan', self.scan_callback, 10)
        
        map_qos = QoSProfile(
            reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL,
            depth=1)
        self.map_sub = self.create_subscription(
            OccupancyGrid, '/map', self.map_callback, map_qos)
        
        # State
        self.scan = None
        self.map_received = False
        self.start_time = time.time()
        self.state = 'WAIT'  # WAIT, FORWARD, TURN_LEFT, TURN_RIGHT
        self.turn_start = 0
        self.turn_duration = 0
        self.last_random_turn = time.time()
        
        # Main loop at 10Hz
        self.timer = self.create_timer(0.1, self.control_loop)
        
        self.get_logger().info('='*50)
        self.get_logger().info('WORKING EXPLORER STARTED')
        self.get_logger().info('='*50)
        self.get_logger().info('Waiting for /scan topic...')

    def scan_callback(self, msg):
        self.scan = msg
        if self.state == 'WAIT':
            self.state = 'FORWARD'
            self.get_logger().info('LIDAR active - Starting exploration!')

    def map_callback(self, msg):
        if not self.map_received:
            self.map_received = True
            self.get_logger().info('Map received from SLAM Toolbox')

    def get_ranges(self):
        """Get distance readings for different directions"""
        if self.scan is None:
            return None
        
        ranges = self.scan.ranges
        n = len(ranges)
        
        def safe_min(indices):
            vals = []
            for i in indices:
                if i < n:
                    r = ranges[i]
                    if 0.05 < r < 10.0:
                        vals.append(r)
            return min(vals) if vals else 10.0
        
        # TurtleBot3 LIDAR: 360 samples, 0=front, CCW positive
        front = safe_min(list(range(0, 15)) + list(range(345, 360)))
        front_left = safe_min(range(15, 60))
        left = safe_min(range(60, 120))
        front_right = safe_min(range(300, 345))
        right = safe_min(range(240, 300))
        
        return {
            'front': front,
            'front_left': front_left,
            'front_right': front_right,
            'left': left,
            'right': right
        }

    def control_loop(self):
        if self.state == 'WAIT':
            return
        
        # Check timeout (5 minutes default)
        if time.time() - self.start_time > 300:
            self.get_logger().info('Exploration complete (timeout)')
            self.stop()
            self.timer.cancel()
            return
        
        r = self.get_ranges()
        if r is None:
            return
        
        twist = Twist()
        
        # State machine
        if self.state in ['TURN_LEFT', 'TURN_RIGHT']:
            # Continue turning
            if time.time() - self.turn_start < self.turn_duration:
                twist.angular.z = self.angular_speed if self.state == 'TURN_LEFT' else -self.angular_speed
                self.cmd_pub.publish(twist)
                return
            else:
                self.state = 'FORWARD'
        
        # Check for obstacles
        if r['front'] < self.front_dist_threshold:
            # Obstacle ahead - turn toward clearer side
            if r['left'] > r['right']:
                self.state = 'TURN_LEFT'
            else:
                self.state = 'TURN_RIGHT'
            self.turn_start = time.time()
            self.turn_duration = random.uniform(0.8, 1.5)
            self.get_logger().debug(f'Obstacle at {r["front"]:.2f}m, turning')
            
        elif r['front_left'] < self.side_dist_threshold:
            # Veer right
            twist.linear.x = self.linear_speed * 0.5
            twist.angular.z = -self.angular_speed * 0.5
            
        elif r['front_right'] < self.side_dist_threshold:
            # Veer left
            twist.linear.x = self.linear_speed * 0.5
            twist.angular.z = self.angular_speed * 0.5
            
        else:
            # Path clear - drive forward
            twist.linear.x = self.linear_speed
            
            # Random turns every 10-20 seconds for exploration variety
            if time.time() - self.last_random_turn > random.uniform(10, 20):
                self.last_random_turn = time.time()
                self.state = random.choice(['TURN_LEFT', 'TURN_RIGHT'])
                self.turn_start = time.time()
                self.turn_duration = random.uniform(0.5, 2.0)
                self.get_logger().debug('Random exploration turn')
        
        self.cmd_pub.publish(twist)

    def stop(self):
        twist = Twist()
        self.cmd_pub.publish(twist)


def main():
    rclpy.init()
    node = WorkingExplorer()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Stopped by user')
    finally:
        node.stop()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
