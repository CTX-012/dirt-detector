import os
import json
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from groq import Groq
import time
# --- SYSTEM PROMPT ---
# This is the "Personality & Rules" of the robot
SYSTEM_PROMPT = """
You are a helpful Robot Assistant in a Gazebo simulation.
You must output responses in STRICT JSON format. Do not output any text outside the JSON.
Possible JSON structures:
1. FOR CONVERSATION (Greetings, questions):
   {"type": "chat", "text": "Your friendly response here"}
2. FOR MOVEMENT (Forward, backward, turn):
   {"type": "move", "linear_x": <float -1.0 to 1.0>, "angular_z": <float -1.0 to 1.0>, "duration": <float seconds>}
EXAMPLES:
User: "Hello"
Output: {"type": "chat", "text": "Greetings! I am online and ready to move."}
User: "Come forward"
Output: {"type": "move", "linear_x": 0.5, "angular_z": 0.0, "duration": 2.0}
User: "Turn left"
Output: {"type": "move", "linear_x": 0.0, "angular_z": 0.5, "duration": 1.5}
User: "Back up a bit"
Output: {"type": "move", "linear_x": -0.3, "angular_z": 0.0, "duration": 1.0}
"""
class GroqBrain(Node):
    def __init__(self):
        super().__init__('groq_brain_node')
        # 1. Setup ROS Publisher (The Legs)
        self.publisher_ = self.create_publisher(Twist, '/cmd_vel', 10)
        # 2. Setup Groq Client (The Brain)
        api_key = os.environ.get("GROQ_API_KEY")
        if not api_key:
            self.get_logger().error("❌ GROQ_API_KEY not found! Please export it.")
            exit()
        self.client = Groq(api_key=api_key)
        self.get_logger().info("🧠 Brain Connected (Llama3-8b via Groq)")
    def ask_brain(self, user_input):
        """Sends text to Groq and gets JSON back"""
        try:
            chat_completion = self.client.chat.completions.create(
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": user_input}
                ],
                model="meta-llama/llama-4-scout-17b-16e-instruct", # Very fast model
                temperature=0.0,        # 0.0 means 'be precise', don't be creative
                response_format={"type": "json_object"} # Force JSON mode
            )
            return json.loads(chat_completion.choices[0].message.content)
        except Exception as e:
            print(f"Brain Freeze Error: {e}")
            return None
    def execute_move(self, linear, angular, duration):
        """Moves the robot for X seconds then stops"""
        msg = Twist()
        msg.linear.x = float(linear)
        msg.angular.z = float(angular)
        # Start moving
        print(f"🚙 Executing: Lin={linear}, Ang={angular} for {duration}s")
        self.publisher_.publish(msg)
        # Wait (Blocking for simplicity in this demo)
        time.sleep(duration)
        # Stop
        msg.linear.x = 0.0
        msg.angular.z = 0.0
        self.publisher_.publish(msg)
def main():
    rclpy.init()
    bot = GroqBrain()
    print("\n🤖 ROBOT ONLINE. Talk to me! (Type 'exit' to quit)")
    print("---------------------------------------------------")
    while True:
        user_input = input("\nYOU: ")
        if user_input.lower() in ["exit", "quit"]:
            break
        # 1. THINK
        brain_response = bot.ask_brain(user_input)
        if not brain_response:
            continue
        # 2. DECIDE
        action_type = brain_response.get("type")
        # 3. ACT
        if action_type == "chat":
            print(f"🤖 ROBOT: {brain_response['text']}")
        elif action_type == "move":
            print("🤖 ROBOT: On it!")
            bot.execute_move(
                brain_response.get("linear_x", 0.0),
                brain_response.get("angular_z", 0.0),
                brain_response.get("duration", 1.0)
            )
    bot.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()

