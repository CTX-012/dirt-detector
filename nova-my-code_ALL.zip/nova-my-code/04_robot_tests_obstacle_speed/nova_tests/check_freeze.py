"""Freeze guard: the lazy sim-time detector in BOTH nodes, the _drive re-send
wrapper (incl. resume from remaining poses), and a static check that no chunk
consumer bypasses _drive and that the run deadline excludes frozen time."""
import time, rclpy
from rclpy.parameter import Parameter
import nova.room_cleaner as rcm
import nova.coverage_mapper as cmm

rclpy.init()
fails = []
for cls in (rcm.RoomCleaner, cmm.CoverageMapper):
    n = cls(); nm = cls.__name__
    if abs(n.get_parameter('freeze_timeout').value - 3.0) > 1e-9:
        fails.append(nm + ": freeze_timeout default != 3.0")
    n.set_parameters([Parameter('freeze_timeout', value=0.3)])
    fake = [1000]
    n._sim_now_ns = lambda: fake[0]
    if n._sim_frozen(): fails.append(nm + ": first call reported frozen")
    fake[0] += 1
    if n._sim_frozen(): fails.append(nm + ": advancing sim reported frozen")
    time.sleep(0.1)
    if n._sim_frozen(): fails.append(nm + ": frozen BEFORE the timeout")
    time.sleep(0.35)
    if not n._sim_frozen(): fails.append(nm + ": NOT frozen after timeout with constant sim time")
    fake[0] += 1
    if n._sim_frozen(): fails.append(nm + ": still frozen after sim resumed")
    n.destroy_node()

n = rcm.RoomCleaner()
got = []
def fake_drive(pts, allow_dirt=True):
    got.append(list(pts))
    if len(got) < 3:
        n._chunk_remaining = 3 if len(got) == 1 else None
        return 'frozen'
    return 'ok'
n._drive_through = fake_drive
pts = [(float(i), 0.0) for i in range(10)]
r = n._drive(pts)
if r != 'ok' or len(got) != 3:
    fails.append("_drive: %r after %d sends, want 'ok' after 3" % (r, len(got)))
elif got[1] != pts[-3:]:
    fails.append("_drive did not resume from the 3 remaining poses: %r" % got[1])
for res in ('fail', 'stall', 'dirt', 'ok'):
    calls = []
    n._drive_through = lambda p, allow_dirt=True, res=res: (calls.append(1), res)[1]
    if n._drive(pts) != res or len(calls) != 1:
        fails.append("_drive altered a non-freeze result %r" % res)
n._stop = True
n._drive_through = lambda p, allow_dirt=True: 'frozen'
if n._drive(pts) != 'fail':
    fails.append("_drive does not exit on stop while frozen")
n.destroy_node()

rc_src = open(rcm.__file__).read()
if rc_src.count('self._drive_through(') != 1:
    fails.append("room_cleaner: %d direct _drive_through calls (want 1, inside _drive)" % rc_src.count('self._drive_through('))
if rc_src.count('self._drive(') < 3:
    fails.append("room_cleaner: fewer than 3 call sites use _drive")
cm_src = open(cmm.__file__).read()
if 't_start - self._frozen_total > run_tmax' not in cm_src:
    fails.append("coverage_mapper: run deadline does not exclude frozen time")

rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "FREEZE GUARD PASS")
raise SystemExit(1 if fails else 0)
