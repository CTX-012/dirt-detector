"""Climb guard + PASS 1 speed cap: cliff baseline self-calibration, onset
detection (2 consecutive frames), no trigger on single spikes or carpet-edge
tilt, front-lost signal, blocked spots excluded from plans, nav speed get/set."""
import time, rclpy
from rclpy.parameter import Parameter
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import Range
from rcl_interfaces.msg import ParameterType
import nova.room_cleaner as rcm
import nova.coverage_mapper as cmm

rclpy.init(); fails = []
n = rcm.RoomCleaner()
def frame(fl, fr, rl, rr):
    for k, v in (('rr', rr), ('rl', rl), ('fr', fr), ('fl', fl)):   # fl last: it evaluates
        m = Range(); m.range = float(v); n._cliff_cb(k, m)
for _ in range(29): frame(0.10, 0.10, 0.10, 0.10)
if n._cliff_base is not None: fails.append("baseline set before 30 frames")
frame(0.10, 0.10, 0.10, 0.10)
if n._cliff_base is None or abs(n._cliff_base) > 1e-9: fails.append("baseline not calibrated to 0: %r" % n._cliff_base)
if n._climb_detected(): fails.append("level robot reported climbing")
frame(0.20, 0.20, 0.10, 0.10)                       # one abnormal frame
if n._climb_detected(): fails.append("single-frame spike triggered")
frame(0.10, 0.10, 0.10, 0.10)                       # back to level resets
frame(0.20, 0.20, 0.10, 0.10)
if n._climb_detected(): fails.append("spike after reset triggered")
frame(0.20, 0.20, 0.10, 0.10)                       # second consecutive
if not n._climb_detected(): fails.append("2 consecutive nose-up frames NOT detected")
frame(0.10, 0.10, 0.10, 0.10); frame(0.10, 0.10, 0.10, 0.10)
for _ in range(20): frame(0.12, 0.12, 0.10, 0.10)   # carpet edge: ~2 cm tilt
if n._climb_detected(): fails.append("carpet-edge tilt (2 cm) triggered")
frame(0.10, 0.10, 0.10, 0.10)
frame(0.30, 0.30, 0.04, 0.04); frame(0.30, 0.30, 0.04, 0.04)   # R4 readings
if not n._climb_detected(): fails.append("front-lost + rear-on-floor (the R4 reading) NOT detected")
frame(0.10, 0.10, 0.10, 0.10)
for k in ('fr', 'rl', 'rr'): n._cliff[k] = (0.10, time.time() - 5.0)   # stale sensors
m = Range(); m.range = 0.30; n._cliff_cb('fl', m); n._cliff_cb('fl', m)
if n._climb_detected(): fails.append("acted on stale cliff data")

g = OccupancyGrid(); g.info.resolution = 0.05; g.info.width, g.info.height = 200, 120; g.data = [0] * 24000
n.map = g
if not n._free_at(5.0, 3.0): fails.append("fixture: free cell reported blocked")
n._blocked = [(5.0, 3.0)]
if n._free_at(5.2, 3.0): fails.append("waypoint 0.2 m from a climb spot still planned")
if not n._free_at(6.0, 3.0): fails.append("waypoint 1.0 m from a climb spot wrongly excluded")
if abs(n.get_parameter('climb_delta').value - 0.05) > 1e-9: fails.append("climb_delta default != 0.05")
n.destroy_node()

c = cmm.CoverageMapper()
if abs(c.get_parameter('pass1_speed').value - 0.20) > 1e-9: fails.append("pass1_speed default != 0.20")
cap = {}
class O: pass
def fake_call(srv, cls=None, req=None):
    cap[srv] = req
    r = O()
    if srv.endswith('get_parameters'):
        v = O(); v.type = ParameterType.PARAMETER_DOUBLE; v.double_value = 0.35; r.values = [v]
    else:
        x = O(); x.successful = True; r.results = [x]
    return r
c._call = fake_call
if c._get_nav_speed() != 0.35: fails.append("_get_nav_speed did not read 0.35")
if not c._set_nav_speed(0.20): fails.append("_set_nav_speed reported failure")
sp = cap.get('/controller_server/set_parameters')
if not sp or sp.parameters[0].name != 'FollowPath.desired_linear_vel' or abs(sp.parameters[0].value.double_value - 0.20) > 1e-9:
    fails.append("SetParameters request malformed")
c.destroy_node()

src = open(rcm.__file__).read()
for needle, why in (("if res == 'climb':", "chunk loop does not handle 'climb'"),
                    ("return 'climb'", "_drive_through never returns 'climb'"),
                    ("/range/cliff_", "no cliff subscriptions")):
    if needle not in src: fails.append(why)
rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "CLIMB GUARD + PASS1 CAP PASS")
raise SystemExit(1 if fails else 0)
