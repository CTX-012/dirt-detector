"""Verify the waypoint failure memory: evidence accumulates, driven waypoints are
never penalised, and a proven-unreachable waypoint leaves the plan."""
import rclpy, math
from nova.room_cleaner import RoomCleaner

rclpy.init()
n = RoomCleaner()
fails = []
lim = n.get_parameter('wp_fail_limit').value
if lim != 3:
    fails.append("wp_fail_limit expected 3, got %r" % lim)

# quantisation: two points in the same 0.20m cell share a key
if n._wp_key(1.01, 2.01) != n._wp_key(1.05, 2.05):
    fails.append("nearby points should share a key")
if n._wp_key(1.01, 2.01) == n._wp_key(1.51, 2.01):
    fails.append("distant points should not share a key")

# a fresh waypoint is alive
if n._wp_dead(5.0, 5.0):
    fails.append("fresh waypoint reported dead")

# evidence accumulates to exactly the limit, not before
k = n._wp_key(5.0, 5.0)
for i in range(1, lim + 1):
    n._wp_fail[k] = i
    dead = n._wp_dead(5.0, 5.0)
    if i < lim and dead:
        fails.append("waypoint dead after only %d failures" % i)
    if i == lim and not dead:
        fails.append("waypoint NOT dead after %d failures" % lim)

# the driven guard: a driven waypoint must be skipped when banking evidence
dc = n.get_parameter('driven_cell').value
n._driven.add((int(math.floor(9.0 / dc)), int(math.floor(9.0 / dc))))
if not n._is_driven(9.0, 9.0):
    fails.append("_is_driven false for a marked cell")
if n._is_driven(20.0, 20.0):
    fails.append("_is_driven true for an unmarked cell")

n.destroy_node(); rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "WP-FAIL MEMORY PASS")
raise SystemExit(1 if fails else 0)
