"""Path inflation per NavigateThroughPoses chunk, from a run's nova_nav.log.
inflation = actual seconds / (poses * step / speed). 1.0 = drove the lanes
exactly; 4.0 = drove four times the lane distance (detours, backtracking)."""
import re, sys
log = sys.argv[1]
step = float(sys.argv[2]) if len(sys.argv) > 2 else 0.50
spd = float(sys.argv[3]) if len(sys.argv) > 3 else 0.35
verbose = '-v' in sys.argv
L = open(log).read().splitlines()
ts = lambda l: float(m.group(1)) if (m := re.search(r'\[(\d{10}\.\d+)\]', l)) else None
rows, cur = [], None
for l in L:
    if 'bt_navigator' not in l:
        continue
    t = ts(l)
    m = re.search(r'Begin navigating from current location through (\d+) poses', l)
    if m and t:
        cur = (t, int(m.group(1))); continue
    m = re.search(r'Goal (succeeded|failed|was canceled|canceled|aborted)', l)
    if cur and t and m:
        rows.append((cur[0], cur[1], t - cur[0], m.group(1))); cur = None
ok = [r for r in rows if r[3] == 'succeeded']
if verbose:
    for t0, n, d, o in rows:
        print("  %3d poses %5.0fs  %5.2fx  %s" % (n, d, d / (n * step / spd), o))
if not ok:
    print("%s: no succeeded chunks" % log); sys.exit()
n = sum(r[1] for r in ok); d = sum(r[2] for r in ok)
ideal = n * step / spd
print("chunks %d (%d succeeded) | succeeded: %d poses, %.0fs vs ideal %.0fs -> INFLATION %.2fx | effective %.3f m/s along lane"
      % (len(rows), len(ok), n, d, ideal, d / ideal, n * step / d))
