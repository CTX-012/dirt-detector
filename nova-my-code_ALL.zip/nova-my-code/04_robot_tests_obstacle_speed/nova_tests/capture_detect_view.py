"""Capture /dirt/detect_view frames (plus the raw camera frame and the robot pose)
so the detector's output can actually be LOOKED at instead of inferred from logs.

Saves: every frame where the detector reports >=1 map point (det_*.png), plus a
periodic sample every few seconds (per_*.png), each with the raw camera frame
beside it as *_raw.png. Prints a summary of what was flagged and from where.

usage: capture_detect_view.py VIEW_TOPIC POINTS_TOPIC OUTDIR SECONDS
Run with PYTHONNOUSERSITE=1 so cv_bridge gets the NumPy it was built against.
"""
import json, math, os, sys, time
import numpy as np
import cv2
import rclpy
from rclpy.parameter import Parameter
from sensor_msgs.msg import Image
from std_msgs.msg import String
from cv_bridge import CvBridge
import tf2_ros

view_topic, points_topic, outdir, secs = sys.argv[1], sys.argv[2], sys.argv[3], float(sys.argv[4])
os.makedirs(outdir, exist_ok=True)
rclpy.init()
n = rclpy.create_node('detect_view_capture',
                      parameter_overrides=[Parameter('use_sim_time', value=True)])
bridge = CvBridge()
buf = tf2_ros.Buffer(); tf2_ros.TransformListener(buf, n)
state = {'view': None, 'raw': None, 'pts': [], 'pts_t': 0.0}
saved_det, saved_per, seen_det_sigs = [], [], set()

def pose():
    try:
        tf = buf.lookup_transform('map', 'base_footprint', rclpy.time.Time())
    except Exception:
        return None
    q = tf.transform.rotation
    yaw = math.degrees(math.atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z)))
    return tf.transform.translation.x, tf.transform.translation.y, yaw

def on_view(m):
    try:
        state['view'] = bridge.imgmsg_to_cv2(m, 'bgr8')
    except Exception as e:
        print('view decode failed:', e)

def on_raw(m):
    try:
        state['raw'] = bridge.imgmsg_to_cv2(m, 'bgr8')
    except Exception as e:
        print('raw decode failed:', e)

def on_pts(m):
    try:
        d = json.loads(m.data)
        state['pts'] = d if isinstance(d, list) else d.get('points', d.get('dirt', []))
        state['pts_t'] = time.time()
    except Exception:
        state['pts'] = []

n.create_subscription(Image, view_topic, on_view, 1)
n.create_subscription(Image, '/dirt_cam/image', on_raw, 1)
n.create_subscription(String, points_topic, on_pts, 10)

t0 = time.time(); next_per = t0 + 3.0; i = 0
while time.time() - t0 < secs:
    rclpy.spin_once(n, timeout_sec=0.05)
    if state['view'] is None:
        continue
    p = pose()
    tag = 'nopose' if p is None else 'x%+.2f_y%+.2f_yaw%+.0f' % p
    pts = state['pts'] if time.time() - state['pts_t'] < 3.0 else []
    if pts:
        sig = json.dumps(pts, sort_keys=True)[:200]
        if sig not in seen_det_sigs and len(saved_det) < 200:
            seen_det_sigs.add(sig)
            f = os.path.join(outdir, 'det_%02d_%s.png' % (len(saved_det), tag))
            cv2.imwrite(f, state['view'])
            if state['raw'] is not None:
                cv2.imwrite(f.replace('.png', '_raw.png'), state['raw'])
            saved_det.append((f, p, pts))
            print('DETECTION frame -> %s  robot %s  points %s' % (os.path.basename(f), tag, json.dumps(pts)[:300]))
    if time.time() >= next_per and len(saved_per) < 60:
        next_per = time.time() + 30.0
        f = os.path.join(outdir, 'per_%02d_%s.png' % (len(saved_per), tag))
        cv2.imwrite(f, state['view'])
        if state['raw'] is not None:
            cv2.imwrite(f.replace('.png', '_raw.png'), state['raw'])
        saved_per.append((f, p))
        print('periodic frame -> %s  robot %s' % (os.path.basename(f), tag))
    i += 1

print('\n--- capture summary ---')
print('view frames seen: %s   detection frames saved: %d   periodic saved: %d'
      % ('yes' if state['view'] is not None else 'NONE', len(saved_det), len(saved_per)))
for f, p, pts in saved_det:
    print('  %s  pose=%s  n_points=%d' % (os.path.basename(f), p, len(pts)))
print('outdir:', outdir)
n.destroy_node(); rclpy.shutdown()
