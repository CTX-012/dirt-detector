"""Same-window comparison across runs: PASS 2 start + [A, B] seconds.
Nav2 chunks, BT recoveries/failures, and room_cleaner events in the window."""
import re, sys
D, A, B = sys.argv[1].rstrip('/'), float(sys.argv[2]), float(sys.argv[3])
ts = lambda l: float(m.group(1)) if (m := re.search(r'\[(\d{10}\.\d+)\]', l)) else None
t2 = next(ts(l) for l in open(D + '/nova_covmap.log') if 'PASS 2: re-segment' in l)
a, b = t2 + A, t2 + B
nav = open(D + '/nova_nav.log').read().splitlines()
chunks, cur = [], None
for l in nav:
    if 'bt_navigator' not in l: continue
    t = ts(l)
    if not t or t < t2: continue
    m = re.search(r'Begin navigating from current location through (\d+) poses', l)
    if m: cur = (t, int(m.group(1))); continue
    m = re.search(r'Goal (succeeded|failed|was canceled|canceled|aborted)', l)
    if cur and m:
        chunks.append((cur[0] - t2, cur[1], t - cur[0], m.group(1))); cur = None
win = [c for c in chunks if c[0] < B and c[0] + c[2] > A]
print("%s  (PASS 2 start %.0f, window +%.0f..+%.0fs)" % (D.split('/')[-1], t2, A, B))
print("  chunks in window: %d  succeeded: %d  canceled: %d  failed: %d"
      % (len(win), sum(c[3] == 'succeeded' for c in win),
         sum('cancel' in c[3] for c in win), sum(c[3] in ('failed', 'aborted') for c in win)))
pats = [('spin', r'Running spin'), ('wait', r'Running wait'), ('backup', r'Running backup'),
        ('clear costmap', r'Received request to clear'),
        ('planner fail', r'planner_server.*(Failed|failed|No valid|could not)'),
        ('controller fail', r'controller_server.*(Failed|failed|Aborting|exceeded|stuck)')]
print("  " + "  ".join("%s=%d" % (k, sum(1 for l in nav if (t := ts(l)) and a <= t <= b and re.search(p, l)))
                       for k, p in pats))
ev = {'stall': 0, 'no-motion escape': 0, 'chunk timeout': 0, 'dirt detour': 0}
for l in open(D + '/nova_clean.log'):
    t = ts(l)
    if not t or not (a <= t <= b): continue
    if 'STALL' in l and 'ESCAPE' in l: ev['stall'] += 1
    if 'NO MOTION' in l: ev['no-motion escape'] += 1
    if 'chunk stalled' in l: ev['chunk timeout'] += 1
    if '-> DIRT at' in l: ev['dirt detour'] += 1
print("  room_cleaner: " + "  ".join("%s=%d" % kv for kv in ev.items()))
