"""Chunk failures are handled per WAYPOINT, not per chunk. Drives the REAL
RoomCleaner._run against a scripted Nav2 - poses the planner starts refusing
mid-sweep, a spot the robot cannot get into - and checks what gets driven, what
earns a strike, and what stays 'unattempted' (which blocks the plateau stop)."""
import math, types, rclpy
from rclpy.parameter import Parameter
import nova.room_cleaner as rcm

rclpy.init(); fails = []
LANE = [(round(0.5 * j, 2), 0.0) for j in range(80)]

def run(refused=(), blocked=(), max_plan=0, all_refused=False):
    n = rcm.RoomCleaner()
    srv = types.SimpleNamespace(wait_for_server=lambda timeout_sec=None: True)
    n.nav = n.ntp = n.planner = srv
    n.rooms = [{'id': 1, 'cx': 0.0, 'cy': 0.0, 'area_m2': 40.0}]
    n._room_waypoints = lambda room: list(LANE)
    n._robot_xy = lambda: (0.0, 0.0)
    n._robot_pose = lambda: (0.0, 0.0, 0.0)
    n._cost_at = lambda x, y: 0              # free floor: passes the wp_max_cost gate
    n.set_parameters([Parameter('spiral_lethal', value=0)])  # 0 < 0 is False -> no backup sleep
    n._set_vac = lambda on: None
    n._clean_all_known = n._escape = n._nudge = n._clear_costmaps = lambda: None
    n._max_plan = max_plan
    ref, blk, driving = set(refused), set(blocked), [False]
    # plannable when the plan is made; refusals start once the sweep is driving
    n._plannable = lambda x, y: not (driving[0] and (all_refused or (x, y) in ref))
    sent = []
    dc = n.get_parameter('driven_cell').value
    def drive_through(pts, allow_dirt=True):
        driving[0] = True
        sent.append(list(pts))
        n._chunk_consumed = 0
        if all_refused or any(q in ref for q in pts):
            return 'fail'                    # one refused pose fails the whole path
        for idx, q in enumerate(pts):
            if q in blk:
                return 'fail'
            n._driven.add((int(math.floor(q[0] / dc)), int(math.floor(q[1] / dc))))
            n._chunk_consumed = idx + 1
        return 'ok'
    n._drive_through = drive_through
    n._run()
    out = dict(sent=sent, strikes={k for k, v in n._wp_fail.items() if v > 0},
               driven=[q for q in LANE if n._is_driven(*q)], unatt=n._last_unattempted,
               planned=n._last_planned, key=n._wp_key)
    n.destroy_node()
    return out

# A. main sweep, planner starts refusing pose 5: only that pose is lost, the lane
#    is driven IN ORDER right away (was: 40 poses deferred to the end of the sweep)
R = (2.5, 0.0)
a = run(refused=[R])
if a['driven'] != [q for q in LANE if q != R]: fails.append("A: %d/79 driven around one refused pose" % len(a['driven']))
if a['strikes'] != {a['key'](*R)}: fails.append("A: %d strikes, want only the refused pose" % len(a['strikes']))
if len(a['sent']) != 3 or R in a['sent'][1] or a['sent'][1][:5] != LANE[:5]: fails.append("A: rest of the lane not re-driven at once: %d sends" % len(a['sent']))
if a['unatt'] != 0 or a['planned'] != 80: fails.append("A: unattempted %s planned %s, want 0 / 80" % (a['unatt'], a['planned']))

# B. MOP-UP pass (in-pass retry off), robot cannot get to pose 10: skip that spot
#    only (poses within skip_radius), drive the rest of the chunk this pass
B = (5.0, 0.0)
spot = {(5.0, 0.0), (5.5, 0.0), (6.0, 0.0)}
b = run(blocked=[B], max_plan=1000)
if b['driven'] != [q for q in LANE if q not in spot]: fails.append("B: %d/77 driven, the chunk behind the stuck spot was written off" % len(b['driven']))
if b['strikes'] != {b['key'](*q) for q in spot}: fails.append("B: strikes %d, want the 3 poses of the stuck spot" % len(b['strikes']))
if b['unatt'] != 0: fails.append("B: %d unattempted, want 0" % b['unatt'])

# C. MAIN sweep, same spot: chunk deferred + retried (unchanged), but the poses behind
#    the spot that were never approached get NO strike and stay 'unattempted'
c = run(blocked=[B])
if c['strikes'] != {c['key'](*B)}: fails.append("C: %d strikes, want only the pose it stuck on (never-approached poses struck)" % len(c['strikes']))
if c['unatt'] != 9: fails.append("C: %d unattempted, want 9 (poses 11-19 behind the spot)" % c['unatt'])

# D. robot's own start refused (every pose refused): must NOT prune the plan away
d = run(all_refused=True)
if len(d['strikes']) > 10 or d['unatt'] < 60 or d['planned'] != 80:
    fails.append("D: all-refused mass-pruned the plan: strikes %d unattempted %d planned %d" % (len(d['strikes']), d['unatt'], d['planned']))

# E. _consumed survives a freeze re-send: 7 passed, frozen, then 1 more of the last 3
n = rcm.RoomCleaner(); seq = []
def fdt(pts, allow_dirt=True):
    seq.append(len(pts))
    if len(seq) == 1:
        n._chunk_remaining, n._chunk_consumed = 3, 7
        return 'frozen'
    n._chunk_consumed = 1
    return 'fail'
n._drive_through = fdt
r = n._drive([(float(i), 0.0) for i in range(10)])
if r != 'fail' or seq != [10, 3] or n._consumed != 8: fails.append("E: _drive consumed %s after %r (%s), want 8 after [10, 3]" % (n._consumed, seq, r))
n.destroy_node()

src = open(rcm.__file__).read()
if src.count('if refused and len(refused) < len(rest):') != 2: fails.append("prune guard (not when EVERY pose is refused) missing in main loop or retry")
rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "PER-WAYPOINT CHUNKS PASS (refused pose costs only itself, lane driven in order; mop-up skips only the stuck spot; never-approached poses unstruck + unattempted; no mass prune; consumed survives freeze)")
raise SystemExit(1 if fails else 0)
