"""Report for one run directory: bring-up, per-pass time/coverage/rate,
termination and clean stop, paper, retry/skip/retirement, stalls."""
import re, sys, os, time
D = sys.argv[1].rstrip('/')
ts = lambda l: float(m.group(1)) if (m := re.search(r'\[(\d{10}\.\d+)\]', l)) else None
cov = open(os.path.join(D, 'nova_covmap.log')).read().splitlines()
m = re.search(r'run_(\d{8}_\d{6})', D)
t_launch = time.mktime(time.strptime(m.group(1), '%Y%m%d_%H%M%S')) if m else None
passes, start = [], None
for l in cov:
    t = ts(l)
    mm = re.search(r'--- PASS (\d+): re-segment', l)
    if mm:
        start = t
    mm = re.search(r'PASS (\d+) (completed|DID NOT complete); driven coverage ([\d.]+)% -> ([\d.]+)%', l)
    if mm and start:
        passes.append((int(mm.group(1)), start, t, float(mm.group(3)), float(mm.group(4))))
if t_launch and passes:
    print("bring-up (launch -> PASS 1): %.1f min" % ((passes[0][1] - t_launch) / 60))
print("pass  min    coverage        gain   %/min")
for n, t0, t1, c0, c1 in passes:
    mins = (t1 - t0) / 60
    print("%-4d %5.1f  %5.1f -> %5.1f  %+5.1f  %6.2f" % (n, mins, c0, c1, c1 - c0, (c1 - c0) / mins if mins else 0))
if passes:
    big = max(passes, key=lambda p: p[4] - p[3])
    print("main sweep = PASS %d: %.2f %%/min" % (big[0], (big[4] - big[3]) / ((big[2] - big[1]) / 60)))
    print("coverage time (PASS 1 start -> last pass end): %.1f min | final %.1f%%"
          % ((passes[-1][2] - passes[0][1]) / 60, passes[-1][4]))
    if t_launch:
        print("MISSION time (launch -> last pass end): %.1f min" % ((passes[-1][2] - t_launch) / 60))
print("TERMINATION / STOP:")
for l in cov:
    if re.search(r'ALL REACHABLE FLOOR COVERED|COVERAGE (COMPLETE|INCOMPLETE)|stalled passes in a row|'
                 r'whole-run backstop|WRONG reason|/stop_rooms|confirmed IDLE|COVERAGE RUN ENDED', l):
        print("  " + re.sub(r'^.*\[COVERAGE\] ', '', l))
dc = os.path.join(D, 'nova_dirtclean.log')
pl = [l for l in open(dc).read().splitlines() if 'CLEANED' in l] if os.path.exists(dc) else []
print("PAPER: " + (re.sub(r'^.*\]: ', '', pl[-1]) if pl else "NOT cleaned"))
cl = open(os.path.join(D, 'nova_clean.log')).read()
rec = re.findall(r'recovered (\d+) waypoint\(s\) in (\d+)s', cl)
print("RETRY: %d stages, %d wp recovered, %ds | SKIPPED: %d"
      % (len(rec), sum(int(a) for a, _ in rec), sum(int(b) for _, b in rec), cl.count('deferred retry SKIPPED')))
print("PROVEN UNREACHABLE: %d | PLANS REVERSED: %d | STALLS: %d | CHUNK TIMEOUTS: %d"
      % (sum(int(x) for x in re.findall(r'(\d+) waypoint\(s\) hit \d+ failed passes', cl)),
         cl.count('plan reversed'), len(re.findall(r'STALL \d+s at', cl)), cl.count('chunk stalled')))
