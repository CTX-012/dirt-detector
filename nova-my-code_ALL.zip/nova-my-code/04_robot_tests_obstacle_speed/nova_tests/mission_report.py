"""Acceptance report for one run directory against the MISSION definition:
maps + covers-reachable (achievable bar) + cleans-detection-driven + stops-clean,
plus crash/hang check. Reads logs only; identical logic for every run."""
import re, sys, os, time, math
D = sys.argv[1].rstrip('/')
ts = lambda l: float(m.group(1)) if (m := re.search(r'\[(\d{10}\.\d+)\]', l)) else None
rd = lambda f: open(os.path.join(D, f), errors='replace').read().splitlines() if os.path.exists(os.path.join(D, f)) else []
cov, cl, dc = rd('nova_covmap.log'), rd('nova_clean.log'), rd('nova_dirtclean.log')
m = re.search(r'run_(\d{8}_\d{6})', D)
t_launch = time.mktime(time.strptime(m.group(1), '%Y%m%d_%H%M%S')) if m else None
say = lambda l: re.sub(r'^.*\[COVERAGE\] ', '', l)
print("=" * 72); print("MISSION REPORT  %s" % D.split('/')[-1]); print("=" * 72)

# ---- passes ----
passes, start = [], None
for l in cov:
    mm = re.search(r'--- PASS (\d+): re-segment.*?([\d.]+)% driven|--- PASS (\d+): re-segment', l)
    if '--- PASS' in l: start = ts(l)
    mm = re.search(r'PASS (\d+) (completed|DID NOT complete); driven coverage ([\d.]+)% -> ([\d.]+)%', l)
    if mm and start: passes.append((int(mm.group(1)), start, ts(l), float(mm.group(3)), float(mm.group(4)), mm.group(2)))
print("passes (%d): " % len(passes) + "" + ", ".join("P%d %.0fmin %.1f%%%s" % (n, (t1 - t0) / 60, c1, "" if s == 'completed' else " (aborted)")
                             for n, t0, t1, c0, c1, s in passes))

# ---- 1. MAPS ----
cells = [int(x) for l in cov for x in re.findall(r'(\d+) known cells', l)]
fin = [int(x) for l in cov for x in re.findall(r'final known cells: (\d+)', l)]
area = [float(x) for l in cl for x in re.findall(r'room \d+ \(([\d.]+) m2\)', l)]
c0, c1 = (cells[0] if cells else 0), (fin[-1] if fin else (cells[-1] if cells else 0))
maps_ok = c1 > 5 * max(1, c0) and c1 > 20000
print("\n1. MAPS            %s  known cells %d -> %d%s" % ("PASS" if maps_ok else "FAIL", c0, c1,
      ("; room %.1f -> %.1f m2" % (area[0], max(area))) if area else ""))

# ---- 2. COVERS REACHABLE (achievable bar) ----
ended = any('COVERAGE RUN ENDED' in l for l in cov)
cat = "NOT ENDED (still running, killed, or hung)"
for l in cov:
    if 'ALL REACHABLE FLOOR COVERED' in l: cat = "COMPLETE - plan emptied: all reachable floor covered"
    elif 'REACHABLE FLOOR COVERED (plateau)' in l: cat = "COMPLETE - coverage plateaued, every remaining waypoint attempted and unreachable"
    elif 'STOPPING; NOT covered' in l: cat = "STOPPED CLEANLY but NOT covered - robot blocked or trapped"
    elif 'stalled passes in a row' in l: cat = "HONEST PLATEAU (pre-fix build) - stopped, not claiming full coverage"
    elif re.search(r'whole-run backstop|absolute backstop', l): cat = "BACKSTOP (timeout) - not an acceptable termination"
if ended and cat.startswith("NOT ENDED"): cat = "ENDED via pass backstop (timeout) - not an acceptable termination"
final_cov = [float(x) for l in cov for x in re.findall(r'driven coverage: ([\d.]+)%', l)]
fc = final_cov[-1] if final_cov else (passes[-1][4] if passes else 0.0)
dead = sum(int(x) for l in cl for x in re.findall(r'(\d+) waypoint\(s\) hit \d+ failed passes', l))
lastplan = [l for l in cl if 'waypoints reachable (' in l]
cov_ok = ended and (cat.startswith("COMPLETE") or cat.startswith("HONEST PLATEAU"))
print("2. COVERS REACHABLE %s  %s" % ("PASS" if cov_ok else "FAIL", cat))
print("                    final driven coverage %.1f%% | waypoints proven unreachable & dropped: %d" % (fc, dead))
if lastplan: print("                    final plan: %s" % lastplan[-1].split(']: ', 1)[-1].strip())
for l in cov:
    if re.search(r'REACHABLE FLOOR COVERED|STOPPING; NOT covered|pass stalled|stalled passes in a row|backstop|WRONG reason|FROZEN for', l):
        print("                    > " + say(l)[:110])

# ---- 3. PAPER, detection-driven ----
PX, PY = 6.20, -3.14
near = lambda s: any(math.hypot(float(a) - PX, float(b) - PY) < 0.5
                     for a, b in re.findall(r'\(\s*([+-]?[\d.]+),\s*([+-]?[\d.]+)\)', s))
t_det = next((ts(l) for l in cl if 'NEW dirt at map' in l and near(l)), None)
t_div = next((ts(l) for l in cl if '-> DIRT at' in l and near(l)), None)
t_brush = next((ts(l) for l in dc if 'brush on dirt_paper' in l), None)
t_clean = next((ts(l) for l in dc if 'CLEANED dirt_paper' in l), None)
det_ok = all(x is not None for x in (t_det, t_div, t_brush, t_clean)) and t_det <= t_div <= t_brush <= t_clean
ref = passes[0][1] if passes else 0
f = lambda t: ("+%.0fs" % (t - ref)) if t else "never"
print("3. PAPER            %s  detected %s -> diverted %s -> brush %s -> CLEANED %s%s" % (
      "PASS" if det_ok else "FAIL", f(t_det), f(t_div), f(t_brush), f(t_clean),
      "" if det_ok else ("  (cleaned WITHOUT a prior detection+divert)" if t_clean else "")))

# ---- 4. STOPS CLEAN ----
acc = any('/stop_rooms -> accepted' in l for l in cov)
idle = any('confirmed IDLE' in l for l in cov)
print("4. STOPS CLEAN      %s  /stop_rooms accepted=%s  cleaner idle=%s  run ended=%s  (physical stop: see post-stop check)"
      % ("PASS" if (acc and idle and ended) else "FAIL", acc, idle, ended))

# ---- crash / hang ----
teardown = []
# A death only matters if the run kept WORKING after it. Deaths at teardown
# (after the last real activity) are shutdown artifacts, not crashes.
work = [ts(l) for l in cl + cov if ts(l) and 'FROZEN' not in l and 'resumed after' not in l]
last_work = max(work) if work else 0
died = []
for f_ in ('nova_clean.log', 'nova_covmap.log', 'nova_nav.log', 'nova_slam.log', 'nova_sim.log', 'nova_dirtclean.log'):
    last_t = 0
    for l in rd(f_):
        t = ts(l)
        if t: last_t = t
        if 'process has died' in l and 'rviz2' not in l:
            (died if last_t < last_work - 2 else teardown).append((f_, l.strip()[:120]))
t_end = next((ts(l) for l in cov if 'COVERAGE RUN ENDED' in l), None)
print("CRASH/HANG         %s  %s" % ("PASS" if (not died and ended) else ("FAIL" if died else "N/A"),
      "no node died mid-run; run ended on its own" if (not died and ended) else
      ("MID-RUN DEATH: " + "; ".join(x for _, x in died[:3]) if died else
       "no mid-run death, but the run did not end on its own")))
if teardown:
    print("                   (%d death(s) at teardown only - shutdown artifacts, not crashes)" % len(teardown))
if t_launch and passes:
    end_t = t_end or passes[-1][2]
    print("\nmission time (launch -> run end): %.1f min" % ((end_t - t_launch) / 60))
