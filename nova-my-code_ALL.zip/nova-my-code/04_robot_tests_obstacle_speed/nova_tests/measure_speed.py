"""Decompose achieved speed: is the gap velocity SCALING or DUTY CYCLE?

Subscribes /cmd_vel (what the controller asks for) and /odom (what the robot
actually does) and reports both distributions plus the fraction of wall time
the robot is actually moving. Run during a live sweep.
"""
import sys, time, math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy

DUR = float(sys.argv[1]) if len(sys.argv) > 1 else 480.0
MOVING = 0.02  # m/s

class M(Node):
    def __init__(self):
        super().__init__('speed_measure')
        self.set_parameters([rclpy.parameter.Parameter('use_sim_time', value=True)])
        q = QoSProfile(depth=50, reliability=QoSReliabilityPolicy.BEST_EFFORT,
                       history=QoSHistoryPolicy.KEEP_LAST)
        self.cmd = []
        self.odo = []
        self.create_subscription(Twist, '/cmd_vel', self._c, 10)
        self.create_subscription(Odometry, '/odom', self._o, q)
        self.t0 = time.time()
        self.last = None

    def _c(self, m):
        self.cmd.append(abs(m.linear.x))

    def _o(self, m):
        v = abs(m.twist.twist.linear.x)
        now = time.time()
        dt = 0.0 if self.last is None else now - self.last
        self.last = now
        self.odo.append((v, dt))

def pct(a, p):
    if not a:
        return float('nan')
    a = sorted(a)
    return a[min(len(a) - 1, int(len(a) * p / 100.0))]

rclpy.init()
n = M()
end = time.time() + DUR
while rclpy.ok() and time.time() < end:
    rclpy.spin_once(n, timeout_sec=0.5)

cmd, odo = n.cmd, n.odo
n.destroy_node(); rclpy.shutdown()

if not odo:
    print("NO ODOM SAMPLES - is the stack up?"); raise SystemExit(1)

speeds = [v for v, _ in odo]
t_total = sum(dt for _, dt in odo)
t_move = sum(dt for v, dt in odo if v > MOVING)
moving = [v for v in speeds if v > MOVING]

print("=== samples: cmd=%d odom=%d over %.0fs ===" % (len(cmd), len(odo), DUR))
print("COMMANDED /cmd_vel linear.x   p50=%.3f p90=%.3f p99=%.3f max=%.3f"
      % (pct(cmd, 50), pct(cmd, 90), pct(cmd, 99), max(cmd) if cmd else 0))
print("  cmd samples >0.02:          %.1f%%"
      % (100.0 * len([c for c in cmd if c > MOVING]) / max(1, len(cmd))))
print("ACHIEVED /odom while MOVING   p50=%.3f p90=%.3f p99=%.3f"
      % (pct(moving, 50), pct(moving, 90), pct(moving, 99)))
print("DUTY CYCLE (time moving)      %.1f%%  (%.0fs of %.0fs)"
      % (100.0 * t_move / max(1e-9, t_total), t_move, t_total))
print("MEAN speed incl. stopped      %.3f m/s"
      % (sum(v * dt for v, dt in odo) / max(1e-9, t_total)))
print()
mv = pct(moving, 50)
if mv < 0.15:
    print("VERDICT: controller output IS being scaled down -> RPP tuning justified")
else:
    print("VERDICT: robot achieves ~full speed WHILE MOVING (%.3f m/s)." % mv)
    print("         The runtime cost is DUTY CYCLE (%.1f%% moving), not velocity"
          % (100.0 * t_move / max(1e-9, t_total)))
    print("         scaling. RPP tuning would not address it.")
