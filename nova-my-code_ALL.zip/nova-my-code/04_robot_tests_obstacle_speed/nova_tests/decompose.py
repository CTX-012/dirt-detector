"""Decompose each coverage pass's wall time from a run's nova_clean.log:
validation, retry, chunk-failure timeouts, stalls, dirt detours, and the
remainder (which is driving + inter-chunk overhead)."""
import re, sys
log = open(sys.argv[1]).read().splitlines()
ts = lambda l: float(re.search(r'\[(\d+\.\d+)\]', l).group(1)) if re.search(r'\[(\d+\.\d+)\]', l) else None
passes, cur = [], None
for l in log:
    t = ts(l)
    if t is None:
        continue
    if re.search(r'--- room \d+ \([\d.]+ m2\) : \d+ waypoints', l):
        cur = dict(t0=t, n=int(re.search(r': (\d+) waypoints', l).group(1)), val_end=None,
                   retry=0.0, r_t0=None, fails=0, fails_after_stall=0, stalls=0,
                   dirt=0.0, d_t0=None, last_stall=-1e9, reached=None, end=None)
        passes.append(cur); continue
    if cur is None:
        continue
    if 'waypoints reachable' in l and cur['val_end'] is None:
        cur['val_end'] = t
    elif 'STALL' in l and 'attempting ESCAPE' in l:
        cur['stalls'] += 1; cur['last_stall'] = t
    elif 'chunk stalled' in l:
        cur['fails'] += 1
        if t - cur['last_stall'] < 95:
            cur['fails_after_stall'] += 1
    elif 'retrying' in l and 'deferred' in l:
        cur['r_t0'] = t
    elif 'deferred retry recovered' in l and cur['r_t0']:
        cur['retry'] += t - cur['r_t0']; cur['r_t0'] = None
    elif '-> DIRT at' in l:
        cur['d_t0'] = t
    elif ('cleaned' in l or 'spiral aborted' in l) and cur['d_t0'] and 'cleaning' not in l:
        cur['dirt'] += t - cur['d_t0']; cur['d_t0'] = None
    elif re.search(r'room \d+ (DONE|UNREACHABLE): (\d+)/', l):
        cur['reached'] = int(re.search(r': (\d+)/', l).group(1)); cur['end'] = t
print("%-4s %6s %6s %5s %6s %6s %5s %4s %6s %7s %s" % (
    "pass", "total", "valid", "plan", "reach", "retry", "fails", "stl", "dirt", "other", "fail-after-stall"))
for i, p in enumerate(passes, 1):
    if p['end'] is None:
        print("%-4d  (in progress / run died)" % i); continue
    tot = p['end'] - p['t0']
    val = (p['val_end'] or p['t0']) - p['t0']
    failt = p['fails'] * 90.0
    other = tot - val - p['retry'] - failt - p['dirt']
    print("%-4d %6.0f %6.0f %5d %6d %6.0f %5d %4d %6.0f %7.0f   %d/%d" % (
        i, tot, val, p['n'], p['reached'], p['retry'], p['fails'], p['stalls'],
        p['dirt'], other, p['fails_after_stall'], p['fails']))
