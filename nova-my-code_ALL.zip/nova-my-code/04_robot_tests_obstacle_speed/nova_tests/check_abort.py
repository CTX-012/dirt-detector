"""An ABORTED sweep (the cleaner could not start: Nav2 not up) is NOT a pass.
Run 114053: Nav2 lifecycle bring-up hung, both sweeps aborted in 10 s reporting
planned 0, and the run stopped at 1.4% 'nothing reachable left to plan'.
Drives the REAL CoverageMapper._run with a scripted cleaner, and the real
RoomCleaner._run with Nav2 absent."""
import json, types, rclpy
from rclpy.parameter import Parameter
import nova.coverage_mapper as cmm
import nova.room_cleaner as rcm

rclpy.init(); fails = []
AB = {'aborted': 'Nav2 NavigateToPose action server not available', 'planned': None}

def coord(script, **params):
    n = cmm.CoverageMapper()
    n.set_parameters([Parameter('settle_time', value=0.0), Parameter('abort_retry_s', value=0.0)]
                     + [Parameter(k, value=v) for k, v in params.items()])
    n._map = object()
    n._set_vacuum = lambda on: None
    n._get_nav_speed = lambda: None
    n._stop_cleaner = lambda: True
    said, seq, cur, sweeps = [], list(script), {}, []
    n._say = lambda m: said.append(m)
    def sweep():
        st = seq.pop(0) if seq else dict(AB)
        sweeps.append(st); cur['st'] = st
        if 'cov' in st:
            n._cov_pct, n._cov_seen = st['cov'], True
        return True
    n._do_one_sweep = sweep
    n._cleaner_stats = lambda: cur.get('st', {})
    n._run()
    n.destroy_node()
    return said, sweeps

real = lambda cov, pl, left: {'cov': cov, 'planned': pl, 'unattempted': 0, 'rooms_failed': 0, 'left': left, 'aborted': None}
# 1. two aborts, then Nav2 is up: the aborts are not passes and never reach the decision
said, sw = coord([AB, AB, real(2.0, 17, 0), real(52.0, 300, 100), real(52.5, 100, 98)], nav_wait_timeout=5.0)
txt = "\n".join(said)
if len(sw) != 5: fails.append("1: %d sweeps, want 5 (2 aborted + 3 passes)" % len(sw))
if txt.count("ABORTED before planning") != 2: fails.append("1: aborted sweeps not reported as such")
if sum(1 for m in said if m.startswith('--- PASS 1:')) != 3 or 'PASS 3 completed' not in txt or '--- PASS 4' in txt:
    fails.append("1: pass numbering advanced on an aborted sweep")
if 'nothing reachable left' in txt or 'PASS 1 completed' in txt.split('--- PASS 1:')[1]:
    fails.append("1: an aborted sweep reached the stop decision")
# 2. Nav2 never comes up: stop after nav_wait_timeout, honestly labelled, no pass decided
said, sw = coord([], nav_wait_timeout=0.3, abort_retry_s=0.1)
txt = "\n".join(said)
if 'NOT a coverage result' not in txt or 'completed' in txt or len(sw) < 2 or txt.count('--- PASS 2') or 'stalled' in txt:
    fails.append("2: Nav2 never up -> %d sweeps, last %r" % (len(sw), said[-8:-7]))

# 3. room_cleaner with Nav2 absent: reports the abort, planned stays None
n = rcm.RoomCleaner()
n.nav = types.SimpleNamespace(wait_for_server=lambda timeout_sec=None: False)
n._set_vac = lambda on: None
n._run()
resp = types.SimpleNamespace(); n._on_status(None, resp); st = json.loads(resp.message)
if not st.get('aborted') or st.get('planned') is not None or st.get('sweeps_done') != 1 or not resp.success:
    fails.append("3: cleaner status after a Nav2-less sweep: %r" % st)
n.destroy_node()
src = open(rcm.__file__).read()
if 'self.ntp.wait_for_server(timeout_sec=5.0)\n' in src:
    fails.append("room_cleaner ignores the NavigateThroughPoses server check result")
rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "ABORTED-SWEEP PASS (aborts are not passes, never reach the stop decision, keep the pass number; Nav2 never up -> 'NOT a coverage result'; cleaner reports abort with planned=None)")
raise SystemExit(1 if fails else 0)
