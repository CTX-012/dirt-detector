"""Unit checks for room_cleaner's pass-time changes: waypoint thinning must be
IDENTICAL to the old algorithm at the old spacing and keep every fragment
endpoint when thinned; serpentine orientation; deferred-retry gating."""
import rclpy
from rclpy.parameter import Parameter
from nav_msgs.msg import OccupancyGrid
from nova.room_cleaner import RoomCleaner

rclpy.init()
n = RoomCleaner()
fails = []

# synthetic 10 m x 6 m map @ 5 cm: free, with a 1.5 m x 2 m block mid-room
g = OccupancyGrid()
g.info.resolution = 0.05
g.info.width, g.info.height = 200, 120
data = [0] * (200 * 120)
for gy in range(40, 80):
    for gx in range(85, 115):
        data[gy * 200 + gx] = 100
g.data = data
n.map = g
room = {'min_x': 0.0, 'max_x': 10.0, 'min_y': 0.0, 'max_y': 6.0}

def old_waypoints(node, room, step, lane):
    """verbatim reference of the pre-change algorithm"""
    m = node.get_parameter('room_margin').value
    x0, x1 = room['min_x'] + m, room['max_x'] - m
    y0, y1 = room['min_y'] + m, room['max_y'] - m
    info = node.map.info
    rr = node.get_parameter('robot_radius').value
    x0, y0 = max(x0, info.origin.position.x + rr), max(y0, info.origin.position.y + rr)
    x1 = min(x1, info.origin.position.x + info.width * info.resolution - rr)
    y1 = min(y1, info.origin.position.y + info.height * info.resolution - rr)
    pts, y, flip = [], y0, False
    while y <= y1 + 1e-6:
        row, x = [], x0
        while x <= x1 + 1e-6:
            if node._free_at(x, y) and not node._is_driven(x, y):
                row.append((x, y))
            x += step
        if flip:
            row.reverse()
        pts.extend(row); flip = not flip; y += lane
    return pts

def setp(**kw):
    n.set_parameters([Parameter(k, value=v) for k, v in kw.items()])

lane = n.get_parameter('lane_spacing').value

# 1. new params default to the old behaviour
if n.get_parameter('chunk_poses').value != 40:
    fails.append("chunk_poses default != 40")
if abs(n.get_parameter('lane_scan_res').value - 0.5) > 1e-9:
    fails.append("lane_scan_res default != 0.5")
if n.get_parameter('orient_plans').value is not False:
    fails.append("orient_plans must default to False (R5: reversal regressed the sweep)")

# 2. EXACT equivalence at the old spacing
setp(step_along_lane=0.5, lane_scan_res=0.5)
new05 = n._room_waypoints(room)
ref05 = old_waypoints(n, room, 0.5, lane)
if new05 != ref05:
    fails.append("step=scan=0.5 NOT identical to old algorithm (%d vs %d)" % (len(new05), len(ref05)))

# 3. thinning at 1.0 m keeps every fragment endpoint, adds nothing new
setp(step_along_lane=1.0, lane_scan_res=0.5)
new10 = n._room_waypoints(room)
if not set(new10) <= set(ref05):
    fails.append("thinned plan contains points the old plan did not")
rows = {}
for q in ref05:
    rows.setdefault(round(q[1], 6), []).append(q)
ends = set()
for r in rows.values():
    r = sorted(r); start = r[0]
    for a, b in zip(r, r[1:]):
        if b[0] - a[0] > 0.5 + 1e-6:
            ends.update([start, a]); start = b
    ends.update([start, r[-1]])
missing = ends - set(new10)
if missing:
    fails.append("%d fragment endpoints dropped, e.g. %r" % (len(missing), sorted(missing)[:3]))
ratio = len(new10) / max(1, len(ref05))
if not (0.45 <= ratio <= 0.70):
    fails.append("thinning ratio %.2f outside 0.45-0.70" % ratio)
split = sum(1 for r in rows.values()
            if any(b[0] - a[0] > 0.5 + 1e-6 for a, b in zip(sorted(r), sorted(r)[1:])))
print("  poses: old %d -> thinned %d (%.0f%%); %d fragment endpoints, all kept; %d rows split by the block"
      % (len(ref05), len(new10), 100 * ratio, len(ends), split))
if split == 0:
    fails.append("test map did not split any row - fixture is wrong")

# 4. _thin_run cases
T = RoomCleaner._thin_run
run = [(k * 0.5, 0.0) for k in range(6)]
if T(run, 1.0) != [(0.0, 0.0), (1.0, 0.0), (2.0, 0.0), (2.5, 0.0)]:
    fails.append("thin_run step 1.0 wrong: %r" % T(run, 1.0))
if T(run, 0.5) != run:
    fails.append("thin_run step 0.5 not identity")
if T(run[:2], 1.0) != run[:2] or T(run[:1], 1.0) != run[:1]:
    fails.append("thin_run short runs not identity")

# 5. orientation
O = RoomCleaner._orient_plan
plan = [(0.0, 0.0), (1.0, 0.0), (2.0, 0.0), (9.0, 5.0)]
if O(plan, (8.5, 5.0)) != list(reversed(plan)):
    fails.append("orient: should reverse when robot nearer the end")
if O(plan, (0.1, 0.0)) != plan:
    fails.append("orient: should keep when robot nearer the start")
if O(plan[:1], (8.5, 5.0)) != plan[:1]:
    fails.append("orient: single pose changed")

# 6. retry gating
n._max_plan, n._retry_spent = 362, 0.0
for plan_len, want in ((362, True), (197, True), (181, True), (150, False), (74, False)):
    ok, why = n._retry_allowed(plan_len)
    if ok != want:
        fails.append("retry_allowed(%d)=%s want %s (%s)" % (plan_len, ok, want, why))
n._retry_spent = 1200.0
if n._retry_allowed(362)[0]:
    fails.append("retry allowed after run-wide budget spent")
n._max_plan, n._retry_spent = 0, 0.0
if not n._retry_allowed(5)[0]:
    fails.append("first pass (no max yet) should allow retry")

n.destroy_node(); rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "WAYPOINT/ORIENT/RETRY PASS")
raise SystemExit(1 if fails else 0)
