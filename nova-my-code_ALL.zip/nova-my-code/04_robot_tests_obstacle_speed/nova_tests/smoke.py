"""Construct every nova node. Catches the class of bug where a node attribute
shadows an rclpy Node internal (self._clients was once assigned a dict, which
made create_client raise AttributeError and killed the sweep silently)."""
import rclpy
rclpy.init()
from nova.coverage_mapper import CoverageMapper
from nova.room_cleaner import RoomCleaner
from nova.room_segmenter import RoomSegmenter
from nova.dirt_cleaner import DirtCleaner
from nova.dirt_finder import DirtFinder

fails = []
for name, cls in (('CoverageMapper', CoverageMapper), ('RoomCleaner', RoomCleaner),
                  ('RoomSegmenter', RoomSegmenter), ('DirtCleaner', DirtCleaner),
                  ('DirtFinder', DirtFinder)):
    try:
        n = cls()
        if not isinstance(n._clients, list):
            fails.append("%s: _clients is %s, not list" % (name, type(n._clients).__name__))
        else:
            print("  %-16s OK" % name)
        n.destroy_node()
    except Exception as e:
        fails.append("%s: %s: %s" % (name, type(e).__name__, e))
rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "SMOKE PASS")
raise SystemExit(1 if fails else 0)
