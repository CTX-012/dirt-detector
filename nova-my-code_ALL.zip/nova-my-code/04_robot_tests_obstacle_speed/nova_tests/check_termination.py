"""Replay real run traces through coverage_mapper._decide and check the run
STOPS when it should - and not before. Plus room_cleaner static checks: every
sent waypoint is 'attempted'; 'unattempted' and 'left' are reported."""
import rclpy
import nova.coverage_mapper as cmm
import nova.room_cleaner as rcm
rclpy.init(); fails = []
c = cmm.CoverageMapper()
def run(trace, name):
    """trace: (gain, cov, planned, unatt[, rooms_failed[, left[, known]]]) per pass
    from 1. left = what the pass left for the next one; known = known map cells
    after the pass. -> (stop_pass, covered, msgs)"""
    st, prev_left, prev_known = 0, None, None
    for i, t in enumerate(trace, 1):
        g, cv, pl, ua = t[:4]
        rf = t[4] if len(t) > 4 else 0
        left = t[5] if len(t) > 5 else None
        known = t[6] if len(t) > 6 else None
        stop, cov_ok, st, msgs = c._decide(i, g, cv, pl, ua, st, rf, prev_left, known, prev_known)
        prev_left, prev_known = left, known
        if stop: return i, cov_ok, msgs
    return None, False, []

# R4 as it happened: robot trapped at 2%, reaching nothing (rooms_failed=1); plan
# empty from PASS 4. Below the floor it can only end as FAILED after 5 flat passes.
r4 = [(None, 2.0, 3, 0, 1), (0.0, 2.0, 3, 0, 1), (0.0, 2.0, 3, 0, 1), (0.0, 2.0, 0, 0, 1), (0.7, 2.7, 0, 0, 1), (0.0, 2.7, 0, 0, 1)]
p, ok, m = run(r4, 'R4')
if p != 6 or ok: fails.append("R4 (trapped): stopped at pass %s covered=%s, want pass 6, FAILED" % (p, ok))
elif 'FAILED, NOT covered' not in "\n".join(m): fails.append("R4 stop not labelled FAILED, NOT covered: %r" % m[-1])
# an empty plan BELOW min_coverage is not proof (run 114053 stopped at 1.4% on a sweep
# that never planned; a map that has not grown looks the same): a stall, not a stop
r4b = [(None, 2.0, 3, 0), (0.0, 2.0, 0, 0)]
if run(r4b, 'R4b')[0] is not None: fails.append("empty plan at 2%% on PASS 2 stopped the run at once")
p, ok, m = run(r4b + [(0.0, 2.0, 0, 0)] * 4, 'R4c')
if p != 6 or ok or 'FAILED' not in "\n".join(m): fails.append("trapped robot, empty plans: got pass %s %r, want 6 FAILED" % (p, m[-1:]))
# run 114053 as it ended: 1.4%, 5,108 known cells, empty plan on PASS 2 -> KEEP GOING
if run([(None, 1.4, 17, 0, 0, 0, 5108), (0.0, 1.4, 0, 0, 0, 0, 5108)], '114053')[0] is not None:
    fails.append("run 114053 replay: stopped at 1.4% / 5,108 known cells")
for k in range(2, 6):   # no stop of ANY kind below the floor before 5 flat passes
    if run([(None, 1.4, 17, 0, 0, 0, 5108)] + [(0.0, 1.4, 0, 0, 0, 0, 5108)] * (k - 1), 'low%d' % k)[0] is not None:
        fails.append("stopped at pass %d at 1.4%% (before 5 flat, map-static passes)" % k)
# a FULL-attempt flat pass BELOW the floor is not a completion
if run([(None, 2.0, 17, 0, 0, 0, 5000), (30.0, 32.0, 300, 0, 0, 100, 50000), (0.2, 32.2, 100, 0, 0, 98, 50100)], 'lowfull')[0] is not None:
    fails.append("full-attempt flat pass at 32% (below the 50% floor) stopped the run")
# map still GROWING: neither a plateau nor an empty plan may end the run
grow = [(None, 2.0, 17, 0, 0, 0, 5000), (50.0, 52.0, 300, 0, 0, 100, 50000), (0.5, 52.5, 100, 0, 0, 98, 60000)]
if run(grow, 'grow')[0] is not None: fails.append("flat pass while the map grew 20% stopped the run")
p, ok, m = run(grow + [(0.3, 52.8, 110, 0, 0, 100, 60300)], 'settled')
if p != 4 or not ok: fails.append("map settled (+0.5%%) full-attempt flat pass: got %s covered=%s, want 4 covered" % (p, ok))
if run([(None, 2.0, 17, 0, 0, 0, 5000), (50.0, 52.0, 300, 0, 0, 100, 50000), (0.2, 52.2, 0, 0, 0, 0, 58000)], 'growempty')[0] is not None:
    fails.append("empty plan while the map grew 16% stopped the run")
if run([(None, 2.0, 17, 0), (0.0, 2.0, None, 0)], 'unknown')[0] is not None:
    fails.append("a sweep with an UNKNOWN plan (never planned) counted as a full attempt")

# R1 from nova_logs/run_r1.log: gains, coverage, rooms_failed and the printed
# 'still planned' counts are the log's; unattempted/left did not exist then and
# are reconstructed (PASS 6 planned 111, so ~111 were left when PASS 5 planned 1).
r1 = [(None, 2.2, 346, 0, 0, 300), (8.7, 10.9, 413, 0, 0, 380), (36.7, 47.6, 194, 0, 0, 150),
      (8.2, 55.8, 127, 0, 0, 111),
      (0.1, 55.9, 1, 0, 0, 1),        # PASS 5: plan COLLAPSED (1 vs 111 left) -> then +6.0%
      (6.0, 61.9, 111, 0, 0, 105),
      (0.88, 62.8, 111, 0, 1, 100),   # PASS 7: rooms_failed=1, reached nothing -> then +2.9%
      (2.9, 65.7, 80, 0, 0, 80),
      (0.65, 66.4, 80, 0, 1, 73), (0.07, 66.4, 73, 0, 1, 74),
      (0.2, 66.6, 74, 0, 0, 74)]      # PASS 11: the first FULL attempt that gained < 1%
p, ok, m = run(r1, 'R1')
if p != 11 or not ok: fails.append("R1 trace: stop at pass %s covered=%s, want pass 11 covered (plateau)" % (p, ok))
elif 'REACHABLE FLOOR COVERED (plateau)' not in "\n".join(m): fails.append("R1 plateau message wrong: %r" % m[-1])

# converging run: the first full-attempt pass under 1% ends it - NO further near-zero pass
conv = [(None, 2.3, 17, 0, 0, 0), (44.0, 46.3, 357, 0, 0, 180), (12.0, 58.3, 180, 0, 0, 70),
        (4.0, 62.3, 70, 0, 0, 30), (0.4, 62.7, 30, 0, 0, 28), (0.1, 62.8, 28, 0, 0, 27)]
p, ok, m = run(conv, 'conv')
if '*** COVERAGE COMPLETE' not in "\n".join(m): fails.append("plateau stop does not report COVERAGE COMPLETE: %r" % m[-2:])
if p != 5 or not ok or 'REACHABLE FLOOR COVERED (plateau)' not in "\n".join(m): fails.append("converging run: got pass %s covered=%s %r, want 5 plateau" % (p, ok, m[-1:]))
conv2 = conv[:4] + [(0.4, 62.7, 0, 0, 0, 0)]
p, ok, m = run(conv2, 'conv2')
if '*** COVERAGE COMPLETE' not in "\n".join(m): fails.append("empty-plan stop does not report COVERAGE COMPLETE: %r" % m[-2:])
if p != 5 or not ok or 'ALL REACHABLE FLOOR COVERED' not in "\n".join(m): fails.append("empty plan above 50%%: got pass %s %r" % (p, m[-1:]))
# main sweep then the first mop-up is a full attempt that adds nothing -> stop on THAT pass
ms = [(None, 2.2, 17, 0, 0, 0), (57.0, 59.2, 354, 0, 0, 120), (0.3, 59.5, 120, 0, 0, 118), (0.2, 59.7, 118, 0, 0, 117)]
p, ok, m = run(ms, 'main-sweep')
if p != 3 or not ok: fails.append("flat full-attempt mop-up after the main sweep: stopped at %s, want 3" % p)

# must NOT stop: PASS 1 empty keyhole; untried waypoints; a collapsed plan; a pass
# that reached nothing; slow real progress
if run([(None, 1.0, 0, 0)], 'p1')[0] is not None: fails.append("stopped on an empty PASS 1 keyhole")
untried = [(None, 50.0, 90, 0), (0.1, 60.0, 90, 40), (0.1, 60.1, 90, 40), (0.1, 60.2, 90, 40), (0.1, 60.3, 90, 40)]
if run(untried, 'untried')[0] is not None: fails.append("plateau stop fired while waypoints were never attempted")
untried[-1] = (0.1, 60.3, 90, 0)
if run(untried, 'untried2')[0] != 5: fails.append("plateau stop did not fire once every waypoint was attempted")
if run([(None, 2, 17, 0, 0, 0), (55, 57, 354, 0, 0, 120), (0.1, 57.1, 1, 0, 0, 1)], 'collapse')[0] is not None:
    fails.append("stopped on a COLLAPSED plan (1 planned vs 120 left)")
if run([(None, 2, 17, 0, 0, 0), (55, 57, 354, 0, 0, 120), (0.2, 57.2, 120, 0, 1, 120)], 'noreach')[0] is not None:
    fails.append("stopped on a pass that reached nothing (rooms_failed=1)")
hard = [(None, 50.0, 90, 0)] + [(0.1, 60.0 + 0.1 * k, 90, 40) for k in range(1, 7)]
p, ok, m = run(hard, 'hard')
if p != 6 or ok or 'NOT a proven completion' not in "\n".join(m): fails.append("last-resort stop: got pass %s covered=%s %r, want 6, not covered" % (p, ok, m[-1:]))
prog = [(None, 2.0, 300, 0)] + [(1.2, 2.0 + 1.2 * k, 300, 0) for k in range(1, 12)]
if run(prog, 'progress')[0] is not None: fails.append("stopped while still gaining >= 1%/pass")
c._cleaner_stats = lambda: {'sweeps_done': 5}
if not c._sweep_counted(4): fails.append("_sweep_counted missed an instant (empty-plan) sweep")
if c._sweep_counted(5): fails.append("_sweep_counted true before the counter moved")
if c._sweep_counted(None): fails.append("_sweep_counted true with no baseline")
c.destroy_node()

src = open(rcm.__file__).read()
if 'failed_wps' in src: fails.append("room_cleaner still uses failed_wps")
if 'attempted_wps.update(chunk)\n' in src or 'attempted_wps.update(sub)\n' in src:
    fails.append("a WHOLE chunk/sub-chunk is still marked attempted - never-approached poses get strikes")
if src.count('attempted_wps.update(chunk[:self._consumed + 1])') != 2 or 'attempted_wps.update(sub[:self._consumed + 1])' not in src:
    fails.append("drives do not mark the passed + targeted poses as attempted")
if 'self._last_planned += len(plan0)' not in src:
    fails.append("planned is not counted on the plan as made (pruning could fake 'planned 0')")
if "'unattempted': self._last_unattempted" not in src: fails.append("status does not report unattempted")
if "'left': self._last_left" not in src: fails.append("status does not report left")
csrc = open(cmm.__file__).read()
if 'empty for the WRONG reason' in csrc or 'if not (ok and self._cov_seen' in csrc:
    fails.append("old grind-path CODE still present in coverage_mapper")
if 'self._sweeps_done += 1        # must precede _busy = False\n            self._busy = False' not in src:
    fails.append("sweeps_done is not incremented immediately before busy clears")
if "stalled_passes,\n                failed, prev_left, self._known_cells, prev_known)" not in csrc or "prev_left = st.get('left', None)" not in csrc:
    fails.append("coordinator does not feed rooms_failed / previous 'left' to _decide")
if 'self._sweep_counted(base_sweeps)' not in csrc:
    fails.append("coordinator wait loop does not use the sweep counter")
rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "TERMINATION PASS (every stop needs >= 50% driven AND a settled map: 114053 replay keeps going; below the floor only FAILED after 5 flat map-static passes (R4 -> 6); growing map never stops; R1 -> 11 plateau; full-attempt flat pass stops above the floor; last-resort stop; no premature stops)")
raise SystemExit(1 if fails else 0)
