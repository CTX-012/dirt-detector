"""Save one frame from every sensor_msgs/Image topic as PNG (no cv2/PIL needed)."""
import sys, time, zlib, struct
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from rclpy.qos import qos_profile_sensor_data

def write_png(path, w, h, rgb):
    raw = b''.join(b'\x00' + rgb[y * w * 3:(y + 1) * w * 3] for y in range(h))
    def chunk(t, d):
        return struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 2, 0, 0, 0))
                + chunk(b'IDAT', zlib.compress(raw, 6)) + chunk(b'IEND', b''))

def to_rgb(m):
    d, w, h, e = bytes(m.data), m.width, m.height, m.encoding.lower()
    step = m.step
    out = bytearray()
    for y in range(h):
        row = d[y * step:(y + 1) * step]
        if e in ('rgb8',):            out += row[:w * 3]
        elif e in ('bgr8',):
            for x in range(w): out += bytes((row[3*x+2], row[3*x+1], row[3*x]))
        elif e in ('rgba8',):
            for x in range(w): out += row[4*x:4*x+3]
        elif e in ('bgra8',):
            for x in range(w): out += bytes((row[4*x+2], row[4*x+1], row[4*x]))
        elif e in ('mono8', '8uc1'):
            for x in range(w): out += bytes((row[x],) * 3)
        else:
            return None
    return bytes(out)

rclpy.init()
n = Node('grab_frames')
n.set_parameters([rclpy.parameter.Parameter('use_sim_time', value=True)])
time.sleep(2.0)
topics = [t for t, ty in n.get_topic_names_and_types() if 'sensor_msgs/msg/Image' in ty]
print("image topics:", topics)
got = {}
for t in topics[:4]:
    n.create_subscription(Image, t, lambda m, t=t: got.setdefault(t, m), qos_profile_sensor_data)
end = time.time() + 15
while time.time() < end and len(got) < len(topics[:4]):
    rclpy.spin_once(n, timeout_sec=0.3)
for t, m in got.items():
    rgb = to_rgb(m)
    if rgb is None:
        print("  %s: unsupported encoding %s" % (t, m.encoding)); continue
    p = '/home/faiz/nova_tests/pin%s.png' % t.replace('/', '_')
    write_png(p, m.width, m.height, rgb)
    print("  saved %s  (%dx%d %s)" % (p, m.width, m.height, m.encoding))
n.destroy_node(); rclpy.shutdown()
