"""Break the STOPPED time down: rotating in place vs genuinely idle.
Tells us whether lane-end turns are worth tuning, or whether the robot is
simply parked waiting on planning/recovery."""
import sys, time
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSHistoryPolicy

DUR = float(sys.argv[1]) if len(sys.argv) > 1 else 480.0
V_MOVE, W_MOVE = 0.02, 0.05

class M(Node):
    def __init__(self):
        super().__init__('duty_measure')
        self.set_parameters([rclpy.parameter.Parameter('use_sim_time', value=True)])
        q = QoSProfile(depth=50, reliability=QoSReliabilityPolicy.BEST_EFFORT,
                       history=QoSHistoryPolicy.KEEP_LAST)
        self.s = []
        self.last = None
        self.create_subscription(Odometry, '/odom', self._o, q)

    def _o(self, m):
        v = abs(m.twist.twist.linear.x)
        w = abs(m.twist.twist.angular.z)
        now = time.time()
        dt = 0.0 if self.last is None else now - self.last
        self.last = now
        self.s.append((v, w, dt))

rclpy.init()
n = M()
end = time.time() + DUR
while rclpy.ok() and time.time() < end:
    rclpy.spin_once(n, timeout_sec=0.5)
s = n.s
n.destroy_node(); rclpy.shutdown()

if not s:
    print("NO ODOM"); raise SystemExit(1)

tot = sum(d for _, _, d in s)
drive = sum(d for v, w, d in s if v > V_MOVE)
rot   = sum(d for v, w, d in s if v <= V_MOVE and w > W_MOVE)
idle  = sum(d for v, w, d in s if v <= V_MOVE and w <= W_MOVE)
w_rot = [w for v, w, _ in s if v <= V_MOVE and w > W_MOVE]
w_rot.sort()

def pct(a, p):
    return a[min(len(a) - 1, int(len(a) * p / 100.0))] if a else 0.0

print("=== %.0fs observed ===" % tot)
print("DRIVING           %6.1fs  %5.1f%%" % (drive, 100 * drive / tot))
print("ROTATING in place %6.1fs  %5.1f%%   (|w| p50=%.2f p90=%.2f rad/s)"
      % (rot, 100 * rot / tot, pct(w_rot, 50), pct(w_rot, 90)))
print("IDLE (no motion)  %6.1fs  %5.1f%%" % (idle, 100 * idle / tot))
print()
if rot > idle and rot / tot > 0.10:
    print("-> rotation is the bigger stopped cost: rotate_to_heading_angular_vel")
    print("   is a justified tune (currently 0.6 rad/s)")
else:
    print("-> IDLE dominates the stopped time: the robot is parked waiting on")
    print("   planning/validation/recovery, NOT turning. Angular tuning won't help.")
