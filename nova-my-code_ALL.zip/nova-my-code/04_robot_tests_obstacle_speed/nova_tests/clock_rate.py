"""Sim real-time factor from ROS /clock against wall time: 42 s, reported in 5 s
windows. Lighter and more robust than repeated 'ign topic' CLI calls."""
import time, rclpy
from rosgraph_msgs.msg import Clock
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
rclpy.init(); n = rclpy.create_node('clock_rate_probe')
samples = []
qos = QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT, history=HistoryPolicy.KEEP_LAST)
n.create_subscription(Clock, '/clock', lambda m: samples.append((time.time(), m.clock.sec + m.clock.nanosec * 1e-9)), qos)
t0 = time.time()
while time.time() - t0 < 42:
    rclpy.spin_once(n, timeout_sec=0.05)
n.destroy_node(); rclpy.shutdown()
if len(samples) < 2:
    print('NO /clock samples'); raise SystemExit(1)
w0 = samples[0][0]
k, rates = 0, []
while True:
    a = [x for x in samples if w0 + 5 * k <= x[0] < w0 + 5 * (k + 1)]
    if not a:
        break
    if len(a) > 1:
        rates.append((a[-1][1] - a[0][1]) / (a[-1][0] - a[0][0]))
    k += 1
(w0, s0), (w1, s1) = samples[0], samples[-1]
print('RATE %.2f  (5 s windows min %.2f max %.2f, /clock %.0f Hz, %.0f s wall)'
      % ((s1 - s0) / (w1 - w0), min(rates), max(rates), len(samples) / (w1 - w0), w1 - w0))
