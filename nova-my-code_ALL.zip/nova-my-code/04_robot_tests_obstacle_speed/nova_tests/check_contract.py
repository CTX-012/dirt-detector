"""Verify the /rooms_status JSON contract the completion signal rides on."""
import json, rclpy
from std_srvs.srv import Trigger
from nova.room_cleaner import RoomCleaner

rclpy.init()
n = RoomCleaner()
fails = []

def status():
    return json.loads(n._on_status(Trigger.Request(), Trigger.Response()).message)

n._last_planned = None
if status().get('planned') is not None:
    fails.append("pre-sweep planned should be None")

n._last_planned, n._last_reached, n._busy = 135, 0, False
n._last_unattempted = 7
n._sweeps_done = 4
s = status()
if s.get('sweeps_done') != 4:
    fails.append("sweeps_done not carried: %r" % s)
if s.get('unattempted') != 7:
    fails.append("unattempted not carried: %r" % s)
if s.get('planned') != 135 or s.get('reached') != 0:
    fails.append("planned/reached not carried: %r" % s)

n._last_planned, n._last_reached = 0, 0
if status().get('planned') != 0:
    fails.append("empty-plan signal lost")

n._busy = True
if n._on_status(Trigger.Request(), Trigger.Response()).success:
    fails.append("busy cleaner reported idle")
n._busy = False
if not n._on_status(Trigger.Request(), Trigger.Response()).success:
    fails.append("idle cleaner reported busy")

for planned, expect in ((None, False), (0, True), (1, False), (135, False)):
    if (planned is not None and int(planned) == 0) != expect:
        fails.append("predicate wrong for planned=%r" % planned)

n.destroy_node(); rclpy.shutdown()
print("\n".join("FAIL: " + f for f in fails) if fails else "CONTRACT PASS (5/5)")
raise SystemExit(1 if fails else 0)
