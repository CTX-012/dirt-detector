#!/usr/bin/env python3
"""Render NOVA_PERCEPTION_REPORT.md into the shareable report page — same content, one source.

Edit the .md, then re-run:  python3 build_report_html.py   ->  NOVA_PERCEPTION_REPORT.html
"""
import re
from pathlib import Path

from markdown_it import MarkdownIt

HERE = Path(__file__).resolve().parent
SRC, OUT = HERE / "NOVA_PERCEPTION_REPORT.md", HERE / "NOVA_PERCEPTION_REPORT.html"

text = SRC.read_text()
head, body_md = text.split("\n---\n", 1)                 # H1 + metadata lines become the page header
meta = [line for line in head.splitlines()[1:] if line.strip()]
md = MarkdownIt("commonmark", {"html": False}).enable("table")
body = md.render(body_md)
meta_html = md.render("\n\n".join(meta))

toc = []


def _slug(s):
    return re.sub(r"[^a-z0-9]+", "-", re.sub(r"<[^>]+>", "", s).lower()).strip("-")


def _h2(m):
    inner = m.group(1)
    toc.append((_slug(inner), re.sub(r"<[^>]+>", "", inner)))
    return f'<h2 id="{_slug(inner)}">{inner}</h2>'


body = re.sub(r"<h2>(.*?)</h2>", _h2, body)
body = re.sub(r'<pre><code class="language-mermaid">(.*?)</code></pre>', r'<pre class="mermaid">\1</pre>',
              body, flags=re.S)
body = body.replace("<table>", '<div class="tbl"><table>').replace("</table>", "</table></div>")
assert body.count('<pre class="mermaid">') == 1 and len(toc) >= 15, "report structure changed — check the build"

toc_html = "\n".join(f'<li><a href="#{s}">{t}</a></li>' for s, t in toc)

PAGE = """<title>NOVA Perception Status</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Archivo:wdth,wght@75..100,500..800&family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&display=swap">
<style>
:root{
  --ground:#F3F6F5; --surface:#FFFFFF; --sunk:#EAF0EE;
  --ink:#14201D; --muted:#56655F; --rule:#D5DEDA; --rule-strong:#AFBEB8;
  --accent:#0E6B63; --accent-soft:#DCEEEB; --tape:#F2C230; --tape-bg:#FBF1CB; --tape-ink:#5E4600;
  --f-display:"Archivo","Arial Narrow",system-ui,sans-serif;
  --f-body:"IBM Plex Sans",system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  --f-mono:"IBM Plex Mono",ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;
}
@media (prefers-color-scheme: dark){
  :root:not([data-theme="light"]){
    --ground:#0F1514; --surface:#161E1C; --sunk:#1B2523;
    --ink:#E2EAE7; --muted:#95A49F; --rule:#28332F; --rule-strong:#3C4A45;
    --accent:#5CC4B8; --accent-soft:#17312D; --tape:#F2C94C; --tape-bg:#342A0C; --tape-ink:#F6D873;
  }
}
:root[data-theme="dark"]{
  --ground:#0F1514; --surface:#161E1C; --sunk:#1B2523;
  --ink:#E2EAE7; --muted:#95A49F; --rule:#28332F; --rule-strong:#3C4A45;
  --accent:#5CC4B8; --accent-soft:#17312D; --tape:#F2C94C; --tape-bg:#342A0C; --tape-ink:#F6D873;
}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
@media (prefers-reduced-motion: reduce){html{scroll-behavior:auto}}
body{background:var(--ground);color:var(--ink);font:15.5px/1.6 var(--f-body);padding-inline:clamp(16px,4vw,44px);padding-block:0 80px}
a{color:var(--accent);text-underline-offset:2px}
a:focus-visible{outline:2px solid var(--accent);outline-offset:2px;border-radius:3px}
.wrap{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:210px minmax(0,1fr);gap:48px}
@media (max-width:1020px){.wrap{grid-template-columns:minmax(0,1fr)}.toc{display:none}}
header.top{grid-column:1/-1;padding-block:44px 26px;border-bottom:1px solid var(--rule-strong);display:grid;gap:12px}
.eyebrow{font:500 11.5px/1.2 var(--f-mono);letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
h1{font-family:var(--f-display);font-stretch:85%;font-weight:780;font-size:clamp(30px,4.6vw,46px);line-height:1.04;margin:0;text-wrap:balance;letter-spacing:-.01em}
.meta p{margin:0;color:var(--muted);font-size:14px;max-width:80ch}
.meta strong{color:var(--ink);font-weight:600}
.tiles{grid-column:1/-1;display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:1px;background:var(--rule);border:1px solid var(--rule);border-radius:6px;overflow:hidden;margin-top:24px}
.tile{background:var(--surface);padding:16px 18px;display:grid;gap:6px;align-content:start}
.tile .big{font-family:var(--f-display);font-stretch:88%;font-weight:760;font-size:28px;line-height:1.05;font-variant-numeric:tabular-nums}
.tile .big.hot{color:var(--accent)}
.tile .lbl{font-size:13px;color:var(--muted);line-height:1.4}
.tile.blocked{background:var(--tape-bg)}
.tile.blocked .big{color:var(--tape-ink)}
.toc{position:sticky;top:calc(env(safe-area-inset-top,0px) + 20px);align-self:start;padding-top:34px;font-size:13px;max-height:calc(100vh - 40px);overflow:auto}
.toc .eyebrow{margin-bottom:10px;display:block}
.toc ol{list-style:none;margin:0;padding:0;display:grid;gap:1px;border-left:1px solid var(--rule)}
.toc a{display:block;padding:4px 0 4px 12px;color:var(--muted);text-decoration:none;margin-left:-1px;border-left:2px solid transparent;line-height:1.35}
.toc a:hover{color:var(--ink);border-left-color:var(--accent)}
main{min-width:0;padding-top:30px}
main h2{font-family:var(--f-display);font-stretch:88%;font-weight:730;font-size:26px;line-height:1.15;margin:52px 0 14px;text-wrap:balance;scroll-margin-top:16px}
main h3{font-family:var(--f-display);font-stretch:92%;font-weight:660;font-size:18px;margin:30px 0 10px}
main p,main li{max-width:76ch}
main p{margin:0 0 12px}
main ul,main ol{padding-left:22px;margin:0 0 14px}
main li{margin:4px 0}
main strong{font-weight:600}
main hr{border:0;border-top:1px solid var(--rule);margin:40px 0 0}
main code{font-family:var(--f-mono);font-size:.84em;background:var(--sunk);padding:1px 5px;border-radius:3px;overflow-wrap:anywhere}
main pre{background:var(--surface);border:1px solid var(--rule);border-radius:6px;padding:14px 16px;overflow-x:auto}
pre.mermaid{background:var(--surface);text-align:center}
.tbl{overflow-x:auto;border:1px solid var(--rule);border-radius:6px;background:var(--surface);margin:10px 0 18px}
table{border-collapse:collapse;width:100%;min-width:640px;font-size:13.5px;line-height:1.45}
th{text-align:left;font:600 11px/1.3 var(--f-body);text-transform:uppercase;letter-spacing:.07em;color:var(--muted);background:var(--sunk);padding:10px 12px;border-bottom:1px solid var(--rule-strong);vertical-align:bottom}
td{padding:9px 12px;border-top:1px solid var(--rule);vertical-align:top;font-variant-numeric:tabular-nums}
tr:first-child td{border-top:0}
td code{white-space:nowrap}
footer{grid-column:1/-1;margin-top:60px;padding-top:16px;border-top:1px solid var(--rule);font-size:12.5px;color:var(--muted)}
</style>

<div class="wrap">
  <header class="top">
    <div class="eyebrow">NOVA cleaning robot · perception · status as of 2026-09-19 · tracker E1–E100</div>
    <h1>Where the robot's vision stands, and what it takes to finish</h1>
    <div class="meta">__META__</div>
  </header>

  <div class="tiles" role="list" aria-label="Summary">
    <div class="tile" role="listitem"><span class="big hot">12% → 97.2%</span><span class="lbl">counted recall: a network alone vs the same network inside our arbiter (E34, E35)</span></div>
    <div class="tile" role="listitem"><span class="big">r1 + arbiter</span><span class="lbl">best weights today — ten alternatives tested, none beat it</span></div>
    <div class="tile blocked" role="listitem"><span class="big">0 frames</span><span class="lbl">taken on a real floor at the robot's camera height — why real images aren't accurate yet</span></div>
    <div class="tile" role="listitem"><span class="big">94 tests</span><span class="lbl">pass across the tools built for the next steps; 21 of 21 deliberate faults caught</span></div>
  </div>

  <nav class="toc" aria-label="Sections">
    <span class="eyebrow">Sections</span>
    <ol>
__TOC__
    </ol>
  </nav>

  <main>
__BODY__
  </main>

  <footer>Rendered from <code>NOVA_PERCEPTION_REPORT.md</code> by <code>build_report_html.py</code> — the Markdown file is the source; both live in <code>faiz_work/perception_2026-09-19/</code> on the project HDD.</footer>
</div>
"""
OUT.write_text(PAGE.replace("__META__", meta_html).replace("__TOC__", toc_html).replace("__BODY__", body))
print(f"wrote {OUT.name}: {len(OUT.read_bytes()):,} bytes, {len(toc)} sections, 1 diagram")
