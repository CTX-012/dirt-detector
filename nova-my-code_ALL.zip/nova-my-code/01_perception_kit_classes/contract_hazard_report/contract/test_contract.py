"""Every contract rule is broken once, in isolation, and must be caught with exactly its own code."""
import copy
import json

import pytest

import contract_check as cc

T0 = 1_000_000_000


def good_frame():
    return {
        "contract_version": "0.1",
        "header": {"stamp_ns": T0, "frame_id": "base_footprint"},
        "published_ns": T0 + 12_000_000,
        "clock": "stop", "phase": "dry", "model_sha256": "a" * 64,
        "calibration": {"state": "CALIBRATED", "tol_rel": 0.05, "proxy": False,
                        "pitch_unverified": False, "rig_geometry": True},
        "objects": [
            {"id": 1, "class_name": "loose_debris", "sub_class": "hair", "action": "CLEAN_SUCTION",
             "confidence": 0.8, "position_m": [0.25, 0.02], "range_m": 0.25,
             "range_uncertainty_m": 0.0125, "length_m": 0.042, "flags": []},
            {"id": 2, "class_name": "cable_cord", "sub_class": "cable", "action": "AVOID",
             "confidence": 0.9, "position_m": [0.13, -0.05], "range_m": 0.14,
             "range_uncertainty_m": 0.01, "length_m": None, "flags": []},
            {"id": 3, "class_name": "spill_coloured", "sub_class": "", "action": "AVOID",
             "confidence": 0.7, "position_m": [0.40, 0.10], "range_m": 0.41,
             "range_uncertainty_m": 0.03, "length_m": None, "flags": []},
        ],
        "avoid_ids": [2, 3], "clean_ids": [1], "status": "OK",
    }


def codes(f):
    return {c for c, _ in cc.check(f)}


def obj(f, oid):
    return next(o for o in f["objects"] if o["id"] == oid)


def test_the_good_frame_is_compliant():
    assert cc.check(good_frame()) == []


def test_uncal_frame_with_fail_closed_uncertainty_is_compliant():
    f = good_frame()
    f["calibration"] = {"state": "UNCAL", "tol_rel": None, "proxy": False,
                        "pitch_unverified": True, "rig_geometry": True}
    obj(f, 1)["length_m"] = None
    for o in f["objects"]:
        o["range_uncertainty_m"] = round(o["range_m"] * 1.05, 6)
    assert cc.check(f) == []


def test_cadence_frame_may_be_older_than_the_stop_budget():
    f = good_frame()
    f["clock"], f["published_ns"] = "cadence", T0 + 400_000_000     # 400 ms: fine for cadence
    assert cc.check(f) == []


def _m(fn):
    f = good_frame()
    fn(f)
    return f


BREAKS = [
    ("K1", "missing field", lambda f: f.pop("status")),
    ("K1", "unknown major version", lambda f: f.update(contract_version="1.0")),
    ("K2", "detections in camera_link", lambda f: f["header"].update(frame_id="camera_link")),
    ("K3", "stamp after publish (stamped 'now' late)", lambda f: f["header"].update(stamp_ns=T0 + 20_000_000)),
    ("K3", "stop-clock result 300 ms old", lambda f: f.update(published_ns=T0 + 300_000_000)),
    ("K4", "IGNORE published", lambda f: f["objects"].append(
        {"id": 9, "class_name": "loose_debris", "action": "IGNORE", "confidence": 0.9})),
    ("K5", "CLEAN target in the obstacle layer", lambda f: f.update(avoid_ids=[1, 2, 3])),
    ("K5", "AVOID object missing from avoid_ids", lambda f: f.update(avoid_ids=[3])),
    ("K6", "shadow published", lambda f: (f["objects"].append(
        {"id": 5, "class_name": "shadow", "action": "AVOID", "confidence": 0.9, "position_m": [0.3, 0],
         "range_m": 0.3, "range_uncertainty_m": 0.02, "length_m": None}), f["avoid_ids"].append(5))),
    ("K7", "unknown class cleaned", lambda f: obj(f, 1).update(class_name="unknown")),
    ("K7", "below-floor confidence cleaned", lambda f: obj(f, 1).update(confidence=0.2)),
    ("K8", "pet waste only AVOID", lambda f: obj(f, 2).update(class_name="pet_waste")),
    ("K8", "cable cleaned", lambda f: (obj(f, 2).update(action="CLEAN_SUCTION"),
                                      f.update(avoid_ids=[3], clean_ids=[1, 2]))),
    ("K9", "mopping in the dry phase", lambda f: obj(f, 1).update(action="CLEAN_MOP")),
    ("K9", "spill cleaned in the dry phase", lambda f: (obj(f, 3).update(action="CLEAN_SUCTION"),
                                                       f.update(avoid_ids=[2], clean_ids=[1, 3]))),
    ("K10", "millimetres on the wire", lambda f: obj(f, 1).update(length_mm=42.0)),
    ("K11", "metric fields on a NOT-RIG-GEOMETRY frame", lambda f: f["calibration"].update(rig_geometry=False)),
    ("K11", "UNCAL without inflated avoid uncertainty",
     lambda f: (f["calibration"].update(state="UNCAL", tol_rel=None, pitch_unverified=True),
                obj(f, 1).update(length_m=None))),
    ("K11", "CALIBRATED from a proxy camera", lambda f: f["calibration"].update(proxy=True)),
    ("K11", "avoid uncertainty below the calibrated band", lambda f: obj(f, 3).update(range_uncertainty_m=0.001)),
    ("K12", "cleaning while SAFE_STOP", lambda f: f.update(status="SAFE_STOP")),
    ("K14", "no model sha", lambda f: f.update(model_sha256="unknown")),
]


@pytest.mark.parametrize("code, what, breaker", BREAKS, ids=[f"{c}-{w}" for c, w, _ in BREAKS])
def test_each_break_is_caught_with_its_own_code(code, what, breaker):
    assert codes(_m(breaker)) == {code}


@pytest.mark.parametrize("avoid, clean", [([1, 2, 3], [1]), ([1, 2, 3], [])],
                         ids=["listed-in-both", "listed-only-as-obstacle"])
def test_a_clean_target_in_the_obstacle_layer_is_named_as_that_bug(avoid, clean):
    f = good_frame()
    f.update(avoid_ids=avoid, clean_ids=clean)
    msgs = [m for c, m in cc.check(f) if c == "K5"]
    assert any("avoid what it should clean" in m for m in msgs), msgs


def test_cli_exit_codes(tmp_path, capsys):
    good, bad = tmp_path / "good.json", tmp_path / "bad.jsonl"
    good.write_text(json.dumps(good_frame()))
    broken = copy.deepcopy(good_frame())
    broken["avoid_ids"] = [1, 2, 3]
    bad.write_text(json.dumps(good_frame()) + "\n" + json.dumps(broken) + "\n")
    assert cc.main([str(good)]) == 0
    assert cc.main([str(bad)]) == 1
    assert "frame 1: K5" in capsys.readouterr().out
