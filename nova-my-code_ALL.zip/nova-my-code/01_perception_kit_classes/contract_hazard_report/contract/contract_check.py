#!/usr/bin/env python3
"""Check PerceptionFrame messages (JSON form) against perception interface contract v0.1.

Every rule has a code; check(frame) returns [(code, message), ...] and an empty list means compliant.
Run it on the emitter's output before it crosses the ROS boundary, or on a JSONL log of frames:

  python3 contract_check.py frames.jsonl

  K1  structure + contract version         K8  hazard classes: pet waste ALERT, cable/soft/paper AVOID
  K2  frame_id = base_footprint             K9  phase: no CLEAN_MOP / liquid cleaning in the dry phase
  K3  capture stamp, max age per clock      K10 SI units only — no *_mm fields on the wire
  K4  action vocabulary, IGNORE never sent  K11 calibration flags + fail-closed avoid uncertainty
  K5  routing: CLEAN never in obstacle layer K12 SAFE_STOP never carries clean targets
  K6  shadow / glare never published        K14 model sha256 present
  K7  unknown / no-claim / low-conf -> AVOID
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

CONTRACT_MAJOR = "0"
FRAMES = {"base_footprint"}
MAX_AGE_MS = {"stop": 250, "cadence": 1000}   # stop = E53's stopping budget
PHASES = {"dry", "wet", "mop"}
ACTIONS = {"CLEAN_SUCTION", "CLEAN_MOP", "AVOID", "ALERT"}
CLEAN = {"CLEAN_SUCTION", "CLEAN_MOP"}
RESTRICT = {"AVOID", "ALERT"}
STATUSES = {"OK", "DEGRADED", "STUCK", "SAFE_STOP"}
CAL_STATES = {"UNCAL", "CAL_DERIVED", "CALIBRATED"}
NEVER_PUBLISHED = {"shadow", "glare"}
DEFAULT_SAFE = {"unknown", "filament", "clear_water"}
MUST_ALERT = {"pet_waste", "poop"}
MUST_AVOID = {"cable_cord", "soft_object", "paper_flat", "cable", "wire", "paper", "textile", "sock", "person"}
LIQUID = {"spill_coloured", "spill"}
CONF_FLOOR = 0.4            # E47's operating point — provisional: chosen on the 7 images it was scored on (B3)
UNCAL_RANGE_FACTOR = 1.05   # 105% median distance error from an unverified pitch
METRIC_FIELDS = ("position_m", "range_m", "range_uncertainty_m", "length_m")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
REQUIRED = ("contract_version", "header", "published_ns", "clock", "phase", "model_sha256",
            "calibration", "objects", "avoid_ids", "clean_ids", "status")


def _keys(obj, path=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{path}.{k}" if path else k
            yield p, k
            yield from _keys(v, p)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _keys(v, f"{path}[{i}]")


def check(f: dict) -> list[tuple[str, str]]:
    v: list[tuple[str, str]] = []

    def bad(code, msg):
        v.append((code, msg))

    missing = [k for k in REQUIRED if k not in f]
    if missing:
        bad("K1", f"missing fields {missing}")
        return v
    if str(f["contract_version"]).split(".")[0] != CONTRACT_MAJOR:
        bad("K1", f"contract_version {f['contract_version']}: consumers refuse an unknown major version")

    if f["header"].get("frame_id") not in FRAMES:
        bad("K2", f"frame_id {f['header'].get('frame_id')!r}: floor detections are published in base_footprint")

    stamp, pub = f["header"].get("stamp_ns"), f["published_ns"]
    if f["clock"] not in MAX_AGE_MS:
        bad("K3", f"clock {f['clock']!r} not in {sorted(MAX_AGE_MS)}")
    elif stamp is None or pub is None:
        bad("K3", "header.stamp_ns (capture) and published_ns are both required")
    elif stamp > pub:
        bad("K3", "capture stamp is later than the publish time: the stamp must be the camera's capture time")
    elif (pub - stamp) / 1e6 > MAX_AGE_MS[f["clock"]]:
        bad("K3", f"{(pub - stamp) / 1e6:.0f} ms old > {MAX_AGE_MS[f['clock']]} ms for the {f['clock']} "
                  f"clock: drop it, never re-stamp it")
    if f["phase"] not in PHASES:
        bad("K9", f"phase {f['phase']!r} not in {sorted(PHASES)}")
    if not SHA_RE.match(str(f["model_sha256"])):
        bad("K14", "model_sha256 must be the 64-hex sha of the deployed weights, as verified at boot")
    if f["status"] not in STATUSES:
        bad("K12", f"status {f['status']!r} not in {sorted(STATUSES)}")

    for path, key in _keys(f):
        if key.endswith("_mm") or key.endswith("_mm2"):
            bad("K10", f"{path}: millimetres on the wire — SI only (REP-103); mm belong in human reports")

    cal = f["calibration"]
    state = cal.get("state")
    if state not in CAL_STATES:
        bad("K11", f"calibration.state {state!r} not in {sorted(CAL_STATES)}")
    if state == "UNCAL" and not cal.get("pitch_unverified"):
        bad("K11", "UNCAL implies pitch_unverified = true")
    if state == "CALIBRATED" and (cal.get("pitch_unverified") or cal.get("proxy")):
        bad("K11", "CALIBRATED cannot carry pitch_unverified or proxy")
    if state in ("CAL_DERIVED", "CALIBRATED") and cal.get("tol_rel") is None:
        bad("K11", f"{state} needs tol_rel")

    ids = [o.get("id") for o in f["objects"]]
    if len(set(ids)) != len(ids):
        bad("K5", "object ids are not unique")
    avoid, clean = set(f["avoid_ids"]), set(f["clean_ids"])
    if avoid & clean:
        bad("K5", f"ids {sorted(avoid & clean)} routed to both the obstacle layer and coverage")
    stray = (avoid | clean) - set(ids)
    if stray:
        bad("K5", f"routed ids {sorted(stray)} have no object")
    if f["status"] == "SAFE_STOP" and clean:
        bad("K12", "SAFE_STOP with clean targets: never clean while safe-stopped")

    for o in f["objects"]:
        oid, cls, act = o.get("id"), str(o.get("class_name", "")).lower(), o.get("action")
        tag = f"object {oid} ({cls})"
        if cls in NEVER_PUBLISHED:
            bad("K6", f"{tag}: shadow and glare are rejections, never published")
        if act == "IGNORE":
            bad("K4", f"{tag}: IGNORE is never published")
        elif act not in ACTIONS:
            bad("K4", f"{tag}: action {act!r} not in {sorted(ACTIONS)}")

        if act in CLEAN and oid in avoid:
            bad("K5", f"{tag}: a CLEAN target in the obstacle layer — the robot would avoid what it should clean")
        if act in CLEAN and oid not in clean:
            bad("K5", f"{tag}: {act} must be listed in clean_ids")
        if act in RESTRICT and oid not in avoid:
            bad("K5", f"{tag}: {act} must be listed in avoid_ids")

        conf = o.get("confidence")
        if (cls in DEFAULT_SAFE or (conf is not None and conf < CONF_FLOOR)) and act not in RESTRICT:
            bad("K7", f"{tag}: unknown / no-claim / below-floor (conf {conf}) must route AVOID, got {act}")
        if cls in MUST_ALERT and act != "ALERT":
            bad("K8", f"{tag}: pet waste must be ALERT, got {act}")
        if cls in MUST_AVOID and act not in RESTRICT:
            bad("K8", f"{tag}: hazard class must be AVOID, got {act}")

        if f["phase"] == "dry" and act == "CLEAN_MOP":
            bad("K9", f"{tag}: CLEAN_MOP in the dry phase")
        if f["phase"] == "dry" and cls in LIQUID and act not in RESTRICT:
            bad("K9", f"{tag}: liquid in the dry phase must AVOID — never dry-vac liquid")

        metric = [k for k in METRIC_FIELDS if o.get(k) is not None]
        if not cal.get("rig_geometry") and metric:
            bad("K11", f"{tag}: NOT-RIG-GEOMETRY frame carries metric fields {metric}")
        if state == "UNCAL" and o.get("length_m") is not None:
            bad("K11", f"{tag}: length_m while UNCAL")
        if act in RESTRICT and cal.get("rig_geometry") and o.get("range_m") is not None:
            r, u = o["range_m"], o.get("range_uncertainty_m")
            need = r * (UNCAL_RANGE_FACTOR if state == "UNCAL" else (cal.get("tol_rel") or 0.0))
            if u is None or u + 1e-9 < need:
                bad("K11", f"{tag}: range_uncertainty_m {u} < {need:.3f} m required at {state} — "
                           f"avoid footprints fail closed")
    return v


def main(argv=None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    if len(argv) != 1:
        print(__doc__)
        return 1
    text = Path(argv[0]).read_text()
    frames = [json.loads(line) for line in text.splitlines() if line.strip()] \
        if argv[0].endswith(".jsonl") else [json.loads(text)]
    n_bad = 0
    for i, fr in enumerate(frames):
        for code, msg in check(fr):
            n_bad += 1
            print(f"frame {i}: {code} {msg}")
    print(f"{len(frames)} frame(s), {n_bad} violation(s)")
    return 1 if n_bad else 0


if __name__ == "__main__":
    sys.exit(main())
