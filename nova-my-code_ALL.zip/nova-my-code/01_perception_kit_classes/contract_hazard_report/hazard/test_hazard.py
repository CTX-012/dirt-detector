from pathlib import Path

import pytest
import yaml

import hazard_plr as hp

HERE = Path(__file__).resolve().parent


@pytest.mark.parametrize("s, f, p, plr", [
    ("S1", "F1", "P1", "a"), ("S1", "F1", "P2", "b"), ("S1", "F2", "P1", "b"), ("S1", "F2", "P2", "c"),
    ("S2", "F1", "P1", "c"), ("S2", "F1", "P2", "d"), ("S2", "F2", "P1", "d"), ("S2", "F2", "P2", "e"),
])
def test_risk_graph(s, f, p, plr):
    h = {"id": "X", "S": s, "F": f, "P": p, "mitigations": []}
    assert hp.assess(h)["plr"] == plr


def test_blank_scores_stay_to_assess_and_are_never_filled():
    r = hp.assess({"id": "X", "S": "S2", "F": None, "P": "P2", "mitigations": []})
    assert r["plr"] is None


def test_ai_only_and_none_built_flags():
    ai = hp.assess({"id": "A", "mitigations": [{"what": "cnn", "type": "AI", "status": "built"},
                                               {"what": "ir", "type": "deterministic", "status": "planned"}]})
    assert ai["flags"] == ["AI-ONLY"]                  # planned hardware doesn't count yet
    mixed = hp.assess({"id": "B", "mitigations": [{"what": "cnn", "type": "AI", "status": "built"},
                                                  {"what": "bumper", "type": "deterministic", "status": "specified"}]})
    assert mixed["flags"] == []
    assert hp.assess({"id": "C", "mitigations": []})["flags"] == ["NONE-BUILT"]


def test_invalid_values_fail_loudly():
    with pytest.raises(hp.HazardError):
        hp.assess({"id": "X", "S": "S3", "mitigations": []})
    with pytest.raises(hp.HazardError):
        hp.assess({"id": "X", "mitigations": [{"what": "m", "type": "magic", "status": "built"}]})


def test_the_starter_log_parses_scores_nothing_and_flags_the_cable_gap():
    doc = yaml.safe_load((HERE / "hazard_log.yaml").read_text())
    rows = {r["id"]: r for r in (hp.assess(h) for h in doc["hazards"])}
    assert all(r["plr"] is None for r in rows.values())          # S/F/P left for the safety owner
    assert "AI-ONLY" in rows["H1"]["flags"]                       # cable: the named functional-safety gap
    assert "NONE-BUILT" in rows["H4"]["flags"]                    # pet waste: class untrained
    assert "NONE-BUILT" in rows["H2"]["flags"]                    # cliff: hardware only planned
