#!/usr/bin/env python3
"""Hazard log -> required Performance Level (ISO 13849-1 risk graph), plus the gaps that matter.

Reads hazard_log.yaml. For each hazard: PLr from S/F/P via the standard risk graph, or TO ASSESS
while any of them is blank. It never fills S/F/P itself. Flags:
  AI-ONLY    every built or specified mitigation is AI — a neural net can't carry a PL
  NONE-BUILT no mitigation is built or specified yet

  python3 hazard_plr.py hazard_log.yaml [--out hazard_log.md]
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import yaml

RISK_GRAPH = {  # ISO 13849-1, Annex A risk graph
    ("S1", "F1", "P1"): "a", ("S1", "F1", "P2"): "b", ("S1", "F2", "P1"): "b", ("S1", "F2", "P2"): "c",
    ("S2", "F1", "P1"): "c", ("S2", "F1", "P2"): "d", ("S2", "F2", "P1"): "d", ("S2", "F2", "P2"): "e",
}
VALID = {"S": {"S1", "S2"}, "F": {"F1", "F2"}, "P": {"P1", "P2"}}
TYPES = {"AI", "deterministic", "mechanical", "procedural"}
STATUSES = {"built", "specified", "planned", "missing"}


class HazardError(Exception):
    pass


def assess(h: dict) -> dict:
    hid = h.get("id", "?")
    for k in ("S", "F", "P"):
        if h.get(k) is not None and h[k] not in VALID[k]:
            raise HazardError(f"{hid}: {k} = {h[k]!r}, expected one of {sorted(VALID[k])}")
    for m in h.get("mitigations") or []:
        if m.get("type") not in TYPES or m.get("status") not in STATUSES:
            raise HazardError(f"{hid}: mitigation {m.get('what')!r} needs type in {sorted(TYPES)} "
                              f"and status in {sorted(STATUSES)}")
    key = (h.get("S"), h.get("F"), h.get("P"))
    plr = RISK_GRAPH.get(key) if None not in key else None
    live = [m for m in h.get("mitigations") or [] if m["status"] in ("built", "specified")]
    flags = []
    if not live:
        flags.append("NONE-BUILT")
    elif all(m["type"] == "AI" for m in live):
        flags.append("AI-ONLY")
    return {"id": hid, "hazard": h.get("hazard", ""), "plr": plr, "flags": flags,
            "live": [f"{m['what']} ({m['type']}, {m['status']})" for m in live]}


def render(rows: list[dict]) -> str:
    out = ["| id | hazard | PLr | flags | mitigations built or specified |", "|---|---|---|---|---|"]
    for r in rows:
        plr = f"**PL {r['plr']}**" if r["plr"] else "TO ASSESS"
        out.append(f"| {r['id']} | {r['hazard']} | {plr} | {', '.join(r['flags']) or '—'} | "
                   f"{'; '.join(r['live']) or '—'} |")
    todo = sum(r["plr"] is None for r in rows)
    ai = [r["id"] for r in rows if "AI-ONLY" in r["flags"]]
    none = [r["id"] for r in rows if "NONE-BUILT" in r["flags"]]
    out += ["", f"{len(rows)} hazards · {todo} still to assess (S/F/P blank) · "
                f"AI-only: {', '.join(ai) or 'none'} · nothing built: {', '.join(none) or 'none'}",
            "AI-only hazards need a deterministic channel or an IFU restriction: a neural net can't carry a PL."]
    return "\n".join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("log")
    ap.add_argument("--out")
    args = ap.parse_args(argv)
    try:
        doc = yaml.safe_load(Path(args.log).read_text()) or {}
        rows = [assess(h) for h in doc.get("hazards", [])]
    except HazardError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    text = render(rows)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
