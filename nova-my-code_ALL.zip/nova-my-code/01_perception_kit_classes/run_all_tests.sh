#!/usr/bin/env bash
# Run every test in the NOVA perception benchmark: the kit (data pipeline, SSL, scoring, calibration)
# plus the interface-contract and hazard checkers. Works from any folder.
#   bash run_all_tests.sh            -> summary per suite
#   bash run_all_tests.sh -v         -> every test name, PASSED/FAILED
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTEST_DISABLE_PLUGIN_AUTOLOAD=1
fail=0
run() {  # $1 = label, $2 = folder, rest = test targets
  local label=$1 dir=$2; shift 2
  echo "=== $label ($dir)"
  (cd "$ROOT/$dir" && python3 -m pytest -p no:randomly -p no:cacheprovider -q "$@" ${VERBOSE:+-v}) || fail=1
}
[ "${1:-}" = "-v" ] && VERBOSE=1
run "kit: data pipeline, SSL, scoring, calibration" perception_2026-09-18/kit
run "interface contract + hazard log"                perception_2026-09-19 contract hazard
echo
[ $fail -eq 0 ] && echo "ALL TEST SUITES PASSED" || { echo "SOME TESTS FAILED (see above)"; exit 1; }
