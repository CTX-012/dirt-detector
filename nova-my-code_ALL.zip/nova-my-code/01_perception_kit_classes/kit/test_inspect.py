"""Tests for inspect_dataset.py — each of the five traps this project already hit must be flagged."""
import json

import pytest
import yaml
from PIL import Image

import inspect_dataset as ins

BOX = "0.5 0.5 0.2 0.2"
GOOD_MANIFEST = {"source_url": "https://example.org/set", "licence": "CC-BY-4.0",
                 "retrieval_date": "2026-10-01", "viewpoint": "eye_level", "benchmark_only": True}


def build(root, names, labels=(), images=1, manifest=GOOD_MANIFEST, with_labels_dir=True):
    (root / "images/train").mkdir(parents=True)
    for i in range(images):
        (root / f"images/train/{i}.jpg").write_bytes(b"\xff\xd8")
    if with_labels_dir:
        (root / "labels/train").mkdir(parents=True)
        for i, lines in enumerate(labels):
            (root / f"labels/train/{i}.txt").write_text("\n".join(lines) + ("\n" if lines else ""))
    (root / "data.yaml").write_text(yaml.safe_dump({"names": list(names), "nc": len(names)}))
    if manifest is not None:
        (root / "DATASET_MANIFEST.json").write_text(json.dumps(manifest))
    return root


def flags_of(r):
    return " | ".join(r["flags"])


def test_trap_poop_set_is_veterinary_chicken_disease(tmp_path):
    root = build(tmp_path / "poop_set", ["coccidiosis", "salmonella", "healthy"],
                 [[f"0 {BOX}"], [f"1 {BOX}"], [f"2 {BOX}"]], images=3)
    r = ins.inspect(root)
    assert "UNMAPPED CLASSES" in flags_of(r) and "NOTHING MAPS" in flags_of(r)
    assert r["ready"] is False


def test_trap_hair_set_has_no_label_directories(tmp_path):
    root = build(tmp_path / "hair_set", ["hair"], images=5, with_labels_dir=False)
    r = ins.inspect(root)
    assert "NO LABEL FILES: 5 images, 0 labels" in flags_of(r) and r["ready"] is False


def test_trap_spill_set_has_boilerplate_class_names(tmp_path):
    root = build(tmp_path / "spill_set", ["0", "class", "spill"],
                 [[f"2 {BOX}"] * 4], images=1)
    r = ins.inspect(root)
    assert "SUSPECT CLASS NAMES" in flags_of(r)
    assert r["mapped"] == {"spill": "spill_coloured"}


def test_trap_wire_set_is_one_variant_only(tmp_path):
    root = build(tmp_path / "wire_set", ["Red wire"], [[f"0 {BOX}"]], images=1)
    r = ins.inspect(root)
    assert "SINGLE CLASS" in flags_of(r) and "UNMAPPED CLASSES" in flags_of(r)


def test_trap_paper_is_one_of_six_classes(tmp_path):
    labels = [[f"{c} {BOX}"] * 10 for c in range(5)] + [[f"5 {BOX}"] * 2]
    root = build(tmp_path / "waste_set", ["glass", "metal", "organic", "plastic", "trash", "paper"],
                 labels, images=6)
    r = ins.inspect(root)
    assert "TARGET CLASS IS A MINORITY" in flags_of(r) and "paper 4%" in flags_of(r)
    assert r["ready"] is True          # a warning, not a blocker


def test_boxes_only_and_obb_and_mixed_formats(tmp_path):
    poly = "0 " + " ".join(["0.4 0.4", "0.6 0.4", "0.6 0.6", "0.4 0.6", "0.45 0.5"])   # 11 tokens
    obb = "0 0.4 0.4 0.6 0.4 0.6 0.6 0.4 0.6"                                          # 9 tokens
    box_only = ins.inspect(build(tmp_path / "a", ["hair"], [[f"0 {BOX}"]], images=1))
    assert "BOXES ONLY" in flags_of(box_only)
    obb_set = ins.inspect(build(tmp_path / "b", ["hair"], [[obb]], images=1))
    assert "OBB OR 4-POINT POLYGON" in flags_of(obb_set)
    mixed = ins.inspect(build(tmp_path / "c", ["hair"], [[f"0 {BOX}", poly]], images=1))
    assert "MIXED LABEL FORMATS" in flags_of(mixed)


def test_provenance_is_required_and_a_template_is_written(tmp_path):
    root = build(tmp_path / "no_manifest", ["hair"], [[f"0 {BOX}"]], images=1, manifest=None)
    r = ins.inspect(root)
    assert "MANIFEST INCOMPLETE" in flags_of(r) and r["ready"] is False
    written = json.loads((root / "DATASET_MANIFEST.json").read_text())
    assert set(written) == set(ins.REQUIRED_MANIFEST) and written["benchmark_only"] is True
    bad_view = {**GOOD_MANIFEST, "viewpoint": "from_above"}
    r2 = ins.inspect(build(tmp_path / "bad_view", ["hair"], [[f"0 {BOX}"]], images=1, manifest=bad_view))
    assert "viewpoint must be one of" in flags_of(r2) and r2["ready"] is False


@pytest.mark.parametrize("blank", ["licence", "source_url", "retrieval_date", "viewpoint"])
def test_an_existing_manifest_with_a_blank_field_still_blocks(tmp_path, blank):
    manifest = {**GOOD_MANIFEST, blank: ""}
    root = build(tmp_path / f"blank_{blank}", ["hair"], [[f"0 {BOX}"]], images=1, manifest=manifest)
    r = ins.inspect(root)
    assert "MANIFEST INCOMPLETE" in flags_of(r) and blank in flags_of(r)
    assert r["ready"] is False


def test_bad_label_lines_block(tmp_path):
    root = build(tmp_path / "broken", ["hair"], [["x 0.5 0.5 0.1 0.1"], ["7 0.5 0.5 0.1 0.1"]], images=2)
    r = ins.inspect(root)
    assert "BAD LABEL LINES: 2" in flags_of(r) and r["ready"] is False


def test_a_clean_mappable_set_is_ready(tmp_path):
    poly = "0 " + " ".join(["0.4 0.4", "0.6 0.4", "0.6 0.6", "0.4 0.6", "0.45 0.5"])
    root = build(tmp_path / "clean", ["hair", "spill"], [[poly], [poly.replace("0 ", "1 ", 1)]], images=2)
    r = ins.inspect(root)
    assert r["ready"] is True
    assert r["mapped"] == {"hair": "loose_debris", "spill": "spill_coloured"}
    assert r["formats"] == ["polygon"]


def test_the_sources_sidecar_is_not_counted_as_labels(tmp_path):
    """relabel_locked6 writes sources/<same path>/x.txt; counting it doubles every instance total."""
    root = build(tmp_path / "remapped", ["loose_debris"], [[f"0 {BOX}", f"0 {BOX}"]], images=1)
    side = root / "sources/labels/train"
    side.mkdir(parents=True)
    (side / "0.txt").write_text("hair\nhair\n")
    r = ins.inspect(root)
    assert sum(r["instances"].values()) == 2


def test_an_obb_dataset_is_flagged_and_still_counted(tmp_path):
    root = tmp_path / "obb_set"
    (root / "train/labelTxt").mkdir(parents=True)
    (root / "train/images").mkdir(parents=True)
    (root / "train/labelTxt/a.txt").write_text("10 5 30 5 30 15 10 15 dirt 0\n40 5 60 5 60 15 40 15 spill 0\n")
    Image.new("RGB", (100, 50)).save(root / "train/images/a.jpg")
    (root / "data.yaml").write_text(yaml.safe_dump({"names": ["dirt", "spill"]}))
    (root / "DATASET_MANIFEST.json").write_text(json.dumps(GOOD_MANIFEST))
    r = ins.inspect(root)
    assert "OBB LAYOUT" in flags_of(r)
    assert r["instances"] == {"dirt": 1, "spill": 1} and r["formats"] == ["obb(dota, pixels)"]


def test_images_behind_a_symlinked_directory_are_counted(tmp_path):
    real = tmp_path / "real_images"
    real.mkdir()
    for i in range(3):
        Image.new("RGB", (40, 40)).save(real / f"{i}.jpg")
    root = tmp_path / "linked"
    (root / "labels/train").mkdir(parents=True)
    (root / "labels/train/0.txt").write_text(f"0 {BOX}\n")
    (root / "images").symlink_to(real, target_is_directory=True)
    (root / "data.yaml").write_text(yaml.safe_dump({"names": ["hair"]}))
    (root / "DATASET_MANIFEST.json").write_text(json.dumps(GOOD_MANIFEST))
    assert ins.inspect(root)["images"] == 3


def test_cli_returns_1_when_any_set_is_not_ready(tmp_path, capsys):
    ok = build(tmp_path / "ok", ["hair"], [["0 " + " ".join(["0.4 0.4", "0.6 0.4", "0.6 0.6", "0.4 0.6", "0.45 0.5"])]], images=1)
    bad = build(tmp_path / "bad", ["coccidiosis"], [["0 " + BOX]], images=1)
    assert ins.main([str(ok)]) == 0
    assert ins.main([str(ok), str(bad)]) == 1
    assert "NOT READY" in capsys.readouterr().err
