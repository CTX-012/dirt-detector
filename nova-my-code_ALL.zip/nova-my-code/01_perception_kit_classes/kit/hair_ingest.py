#!/usr/bin/env python3
"""Turn human hair masks (labelme JSON) into YOLO-seg labels, refusing anything that breaks the rules (2026-10-07).

Reads the workspace that hair_split.py built. For every image there must be a labelme JSON next to it
(an image with no hair gets a JSON with an empty `shapes` list — "looked, found none" is a label; a
missing file is not). Rules enforced:
  - the only label is `hair` (shadow / glare are physics rejections, never labels — refused);
  - every shape is a polygon of >= 3 points (masks, not boxes: rectangles are refused);
  - the image must be one the split manifest knows, with the same sha256 (no swapped files);
  - guard images are never written out.

  python3 -I hair_ingest.py WORKSPACE OUT_DATASET

OUT_DATASET gets images/{train,heldout}/ (symlinks), labels/{train,heldout}/, data.yaml with the
locked-6 names (hair -> loose_debris, index 4) and sources/ marking every line as `hair`, so the
hair sub-class stays countable after the merge.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path

import yaml

from relabel_locked6 import LOCKED6, MERGE, NEVER_LABELS

HAIR_ID = LOCKED6.index(MERGE["hair"])
SPLIT_OUT = {"label_pool": "train", "heldout": "heldout"}


class IngestError(Exception):
    pass


def polygon_lines(js: dict, where: str) -> list[str]:
    w, h = float(js["imageWidth"]), float(js["imageHeight"])
    out = []
    for i, s in enumerate(js.get("shapes", []), 1):
        label = str(s.get("label", "")).strip().lower()
        if label in NEVER_LABELS:
            raise IngestError(f"{where} shape {i}: '{label}' is {NEVER_LABELS[label]}")
        if label != "hair":
            raise IngestError(f"{where} shape {i}: label '{label}' — the only label in this set is 'hair'")
        if s.get("shape_type", "polygon") != "polygon":
            raise IngestError(f"{where} shape {i}: {s.get('shape_type')} — masks, not boxes: draw a polygon")
        pts = s.get("points", [])
        if len(pts) < 3:
            raise IngestError(f"{where} shape {i}: {len(pts)} points — a mask needs at least 3")
        xy = [f"{min(max(x / w, 0.0), 1.0):.6f} {min(max(y / h, 0.0), 1.0):.6f}" for x, y in pts]
        out.append(f"{HAIR_ID} " + " ".join(xy))
    return out


def ingest(ws: Path, dst: Path) -> dict:
    ws, dst = Path(ws), Path(dst)
    if dst.exists() and any(dst.iterdir()):
        raise IngestError(f"{dst} exists and is not empty")
    manifest = json.loads((ws / "split_manifest.json").read_text())
    missing, counts = [], {"train": [0, 0], "heldout": [0, 0]}          # [images, instances]
    jobs = []
    for r in manifest["images"]:
        if r["split"] == "guard":
            continue
        img = ws / r["file"]
        if hashlib.sha256(img.read_bytes()).hexdigest() != r["sha256"]:
            raise IngestError(f"{r['file']}: sha256 differs from the split manifest — the image was swapped")
        lj = img.with_suffix(".json")
        if not lj.exists():
            missing.append(r["file"])
            continue
        jobs.append((r, img, polygon_lines(json.loads(lj.read_text()), r["file"])))
    if missing:
        raise IngestError(f"{len(missing)} images have no label file (e.g. {missing[0]}) — "
                          "an image with no hair still needs a JSON with empty shapes")
    for r, img, lines in jobs:
        split = SPLIT_OUT[r["split"]]
        for sub, body in (("labels", lines), ("sources/labels", ["hair"] * len(lines))):
            p = dst / sub / split / (img.stem + ".txt")
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text("\n".join(body) + ("\n" if body else ""))
        link = dst / "images" / split / img.name
        link.parent.mkdir(parents=True, exist_ok=True)
        os.symlink(img.resolve(), link)
        counts[split][0] += 1
        counts[split][1] += len(lines)
    (dst / "data.yaml").write_text(yaml.safe_dump(
        {"path": str(dst.resolve()), "train": "images/train", "val": "images/heldout",
         "names": list(LOCKED6), "nc": len(LOCKED6)}, sort_keys=False))
    return {"split_manifest_sha256": hashlib.sha256((ws / "split_manifest.json").read_bytes()).hexdigest(),
            "images": {k: v[0] for k, v in counts.items()}, "hair_instances": {k: v[1] for k, v in counts.items()}}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("workspace")
    ap.add_argument("out")
    a = ap.parse_args(argv)
    try:
        print(json.dumps(ingest(Path(a.workspace), Path(a.out)), indent=2))
    except IngestError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
