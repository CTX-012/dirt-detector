import sync_pending_to_hdd as s


def make(tmp_path):
    pending, work = tmp_path / "pending", tmp_path / "hdd" / "faiz_work"
    (pending / "2026-09-17").mkdir(parents=True)
    (pending / "2026-09-17" / "PLAN.md").write_text("plan\n")
    (pending / "2026-09-17" / "STATUS_APPEND.md").write_text("\n## 2026-09-17 — thing one\n- a\n")
    (pending / "2026-09-18" / "kit" / "__pycache__").mkdir(parents=True)
    (pending / "2026-09-18" / "kit" / "tool.py").write_text("print(1)\n")
    (pending / "2026-09-18" / "kit" / "__pycache__" / "tool.pyc").write_text("x")
    (pending / "2026-09-18" / "STATUS_APPEND.md").write_text("\n## 2026-09-18 — thing two\n- b\n")
    (pending / "notes").mkdir()                        # not a dated folder: ignored
    work.mkdir(parents=True)
    (work / "STATUS.md").write_text("# Work Status\n\n## 2026-09-11 — first\n")
    return pending, work


def test_first_run_copies_and_appends(tmp_path):
    pending, work = make(tmp_path)
    s.sync(pending, work)
    assert (work / "perception_2026-09-17" / "PLAN.md").read_text() == "plan\n"
    assert (work / "perception_2026-09-18" / "kit" / "tool.py").exists()
    assert not (work / "perception_2026-09-18" / "kit" / "__pycache__").exists()
    status = (work / "STATUS.md").read_text()
    assert "## 2026-09-17 — thing one" in status and "## 2026-09-18 — thing two" in status


def test_rerun_is_idempotent(tmp_path):
    pending, work = make(tmp_path)
    s.sync(pending, work)
    before = (work / "STATUS.md").read_text()
    assert s.sync(pending, work) == []
    assert (work / "STATUS.md").read_text() == before


def test_a_different_existing_file_is_kept(tmp_path):
    pending, work = make(tmp_path)
    (work / "perception_2026-09-17").mkdir()
    (work / "perception_2026-09-17" / "PLAN.md").write_text("someone else's edit\n")
    log = s.sync(pending, work)
    assert (work / "perception_2026-09-17" / "PLAN.md").read_text() == "someone else's edit\n"
    assert (work / "perception_2026-09-17" / "PLAN.md.from-pending").read_text() == "plan\n"
    assert any("KEPT" in line for line in log)


def test_dry_run_writes_nothing(tmp_path):
    pending, work = make(tmp_path)
    log = s.sync(pending, work, dry_run=True)
    assert log and not (work / "perception_2026-09-17").exists()


def test_missing_target_is_an_error(tmp_path):
    pending, _ = make(tmp_path)
    assert s.main(["--pending", str(pending), "--hdd-root", str(tmp_path / "nope")]) == 1
