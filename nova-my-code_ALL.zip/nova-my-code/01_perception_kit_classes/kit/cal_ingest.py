#!/usr/bin/env python3
"""CAL2 ingest: land the tape + clinometer reading and turn it into bounded millimetres.

In order:
  1. validate cal2.json against cal2.schema.json
  2. derive ground sample distance, um/px = height_mm / f_px * 1000, with a per-axis
     tilt correction above 5 deg from nadir (along-axis 1/cos^2, across-axis 1/cos)
     and every tolerance propagated in quadrature
  3. decide the flag: UNCAL / CAL-DERIVED +-X% / CALIBRATED. Nothing promotes
     silently: CALIBRATED needs a measured height AND pitch with tolerances, f_px with
     RMS <= 0.5 px, a non-proxy camera, and a passing independent cross-check
  4. cross-check against a known part measured in-frame (within 10%, or STOP)
  5. retro-recompute stored mm / mm^2 figures and flag shifts over 20%

It never invents a value. A missing reading keeps the output UNCAL and says what it
is blocked on.

  python3 cal_ingest.py status     cal2.json [--known-mm 50 --px 312 --axis across]
  python3 cal_ingest.py crosscheck cal2.json  --known-mm 50 --px 312 --axis across
  python3 cal_ingest.py retro      cal2.json stored.jsonl --known-mm 50 --px 312 --axis across --out retro.md
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parent / "cal2.schema.json"

UNCAL, DERIVED, CALIBRATED = "UNCAL", "CAL-DERIVED", "CALIBRATED"
_RANK = {UNCAL: 0, DERIVED: 1, CALIBRATED: 2}

TILT_THRESHOLD_DEG = 5.0   # per-axis tilt correction applies above this tilt from nadir
MAX_RMS_PX = 0.5           # CAL1 acceptance
CROSSCHECK_TOL = 0.10      # implied vs derived um/px
RETRO_FLAG_SHIFT = 0.20    # old-vs-new change that gets flagged
MEASURED_HEIGHT = {"tape", "laser", "fiducial"}
MEASURED_PITCH = {"clinometer", "fiducial"}


class CalError(Exception):
    """A reading or request the ingest refuses. The message says what to fix."""


def validate(doc: dict) -> dict:
    import jsonschema

    schema = json.loads(SCHEMA_PATH.read_text())
    errors = sorted(jsonschema.Draft202012Validator(schema).iter_errors(doc),
                    key=lambda e: [str(p) for p in e.path])
    if errors:
        lines = [f"{'/'.join(map(str, e.path)) or '<root>'}: {e.message}" for e in errors]
        raise CalError("cal2.json fails the schema:\n  " + "\n  ".join(lines))
    return doc


def load(path) -> dict:
    return validate(json.loads(Path(path).read_text()))


def tilt_from_nadir_deg(doc: dict) -> float | None:
    """The clinometer reading converted to tilt away from straight down.

    The 1/cos^2 correction needs tilt FROM NADIR. A clinometer laid on a camera body reads
    against gravity, so the face it sat on decides the reference. Read 13 deg against the
    wrong one and along-axis GSD is off by ~18x, so the reference is a required field.
    """
    p = doc["pitch_deg"]
    if p is None:
        return None
    return float(p) if doc["pitch_reference"] == "from_nadir" else 90.0 - float(p)


@dataclass
class CalState:
    flag: str                                     # UNCAL / CAL-DERIVED / CALIBRATED
    reasons: list = field(default_factory=list)
    carried: list = field(default_factory=list)   # flags every emitted number must carry
    gsd_um: dict | None = None                    # {"along": .., "across": ..} um per px
    tol_rel: dict | None = None                   # {"along": .., "across": ..} relative

    @property
    def tol_pct(self) -> float | None:
        if not self.tol_rel:
            return None
        return math.ceil(max(self.tol_rel.values()) * 1000) / 10   # rounded UP to 0.1 %

    @property
    def label(self) -> str:
        if self.flag == UNCAL:
            return UNCAL
        return f"{self.flag} ±{self.tol_pct:.1f}%"


def _derive(doc: dict, crosscheck_passed: bool) -> CalState:
    intr = doc["intrinsics"] or {}
    h, h_tol = doc["height_mm"], doc["height_tol_mm"]
    fx, fx_std, rms = intr.get("fx_px"), intr.get("fx_std_px"), intr.get("rms_px")

    blocked = []
    if h is None or doc["method"]["height"] not in MEASURED_HEIGHT:
        blocked.append("the height reading (tape, lens centre to floor)")
    elif h_tol is None:
        blocked.append("height_tol_mm (a reading without a tolerance can't be bounded)")
    if fx is None:
        blocked.append("f_px (CAL1 intrinsics, or ruler_solve.py on 20 ruler frames)")
    if blocked:
        return CalState(UNCAL, [f"blocked on {b}" for b in blocked], [UNCAL])

    theta = tilt_from_nadir_deg(doc)
    pitch_measured = theta is not None and doc["method"]["pitch"] in MEASURED_PITCH
    carried, reasons = [], []

    rel_h = h_tol / h
    rel_f = (fx_std / fx) if fx_std is not None else 0.0
    if fx_std is None:
        reasons.append("fx_std_px not supplied: the ± excludes intrinsics error")

    gsd = h / fx * 1000.0
    if pitch_measured:
        t = math.radians(theta)
        if theta > TILT_THRESHOLD_DEG:
            along, across = gsd / math.cos(t) ** 2, gsd / math.cos(t)
            skip_along = skip_across = 0.0
        else:  # correction skipped below the threshold: carry what was skipped as tolerance
            along = across = gsd
            skip_along, skip_across = 1 / math.cos(t) ** 2 - 1, 1 / math.cos(t) - 1
        dth = doc["pitch_tol_deg"]
        if dth is None:
            reasons.append("pitch_tol_deg missing: pitch error can't be bounded")
            tilt_along = tilt_across = 0.0
        else:
            d = math.radians(dth)
            tilt_along, tilt_across = 2 * math.tan(t) * d, math.tan(t) * d
        tol = {"along": math.sqrt(rel_h**2 + rel_f**2 + tilt_along**2 + skip_along**2),
               "across": math.sqrt(rel_h**2 + rel_f**2 + tilt_across**2 + skip_across**2)}
    else:
        along = across = gsd
        base = math.sqrt(rel_h**2 + rel_f**2)
        tol = {"along": base, "across": base}
        carried.append("PITCH-UNVERIFIED")
        reasons.append("pitch not measured: GSD assumes a straight-down camera; the ± excludes tilt")

    gate = []
    if not pitch_measured:
        gate.append("pitch not measured with a clinometer or fiducial")
    elif doc["pitch_tol_deg"] is None:
        gate.append("pitch tolerance missing")
    if doc["proxy"]:
        gate.append("PROXY camera")
        carried.append("PROXY")
    if rms is None:
        gate.append("intrinsics RMS not recorded")
    elif rms > MAX_RMS_PX:
        gate.append(f"intrinsics RMS {rms} px > {MAX_RMS_PX} px")
    if not crosscheck_passed:
        gate.append("independent cross-check not passed (required before publishing any number)")

    flag = DERIVED if gate else CALIBRATED
    return CalState(flag, reasons + [f"not CALIBRATED: {g}" for g in gate], carried,
                    {"along": along, "across": across}, tol)


def derive(doc: dict, crosscheck_passed: bool = False) -> CalState:
    state = _derive(doc, crosscheck_passed)
    claimed = doc.get("status_claimed")
    if claimed and _RANK[claimed] > _RANK[state.flag]:
        raise CalError(f"refused: cal2.json claims {claimed}; the ingest computes {state.label}:\n  "
                       + "\n  ".join(state.reasons))
    return state


def cross_check(state: CalState, known_mm: float, measured_px: float, axis: str) -> dict:
    """Implied um/px from a known part in-frame vs the derived value. Within 10% -> PASS."""
    if state.flag == UNCAL:
        raise CalError("cross-check needs a derived GSD first: " + "; ".join(state.reasons))
    if axis not in ("along", "across"):
        raise CalError("axis must be 'along' or 'across': the image axis the part lies along")
    if measured_px <= 0 or known_mm <= 0:
        raise CalError("known_mm and measured_px must be positive")
    implied = known_mm * 1000.0 / measured_px
    derived_v = state.gsd_um[axis]
    dev = implied / derived_v - 1.0
    out = {"verdict": "PASS" if abs(dev) <= CROSSCHECK_TOL else "STOP", "axis": axis,
           "implied_um_per_px": implied, "derived_um_per_px": derived_v, "deviation": dev}
    if out["verdict"] == "STOP":
        out["likely_causes"] = [
            "intrinsics belong to a different camera, or were solved at a different resolution",
            "height measured to the housing instead of the lens centre",
            "pitch reference confused (from_nadir vs from_horizontal)",
            "the part is foreshortened, or not lying flat on the floor",
        ]
    return out


def retro(state: CalState, records: list[dict]) -> list[dict]:
    """Recompute stored figures. Off-rig frames never receive a millimetre."""
    if state.flag == UNCAL:
        raise CalError("retro-recompute blocked: " + "; ".join(state.reasons))
    rows = []
    for r in records:
        rid = r.get("id", "?")
        if r.get("geometry") != "rig":
            rows.append({"id": rid, "kind": r.get("kind"), "old": r.get("old_mm"), "new": None,
                         "shift": None, "flag_shift": False, "label": "NOT-RIG-GEOMETRY: no mm emitted"})
            continue
        kind, px = r.get("kind"), float(r["px"])
        if kind == "length":
            axis = r.get("axis", "mixed")
            if axis in ("along", "across"):
                g, tol = state.gsd_um[axis], state.tol_rel[axis]
            else:  # orientation unknown: mean of the two axes, widened by half their spread
                ga, gc = state.gsd_um["along"], state.gsd_um["across"]
                g = (ga + gc) / 2
                tol = math.hypot(max(state.tol_rel.values()), abs(ga - gc) / 2 / g)
            new = px * g / 1000.0
        elif kind == "area":
            new = px * state.gsd_um["along"] * state.gsd_um["across"] / 1e6
            # along and across share height and f_px error, so add rather than quadrature
            tol = state.tol_rel["along"] + state.tol_rel["across"]
        else:
            raise CalError(f"record {rid}: kind must be 'length' or 'area'")
        old = r.get("old_mm")
        shift = (new / old - 1.0) if old else None
        label = f"{state.flag} ±{math.ceil(tol * 1000) / 10:.1f}%"
        if state.carried:
            label += " · " + " · ".join(state.carried)
        rows.append({"id": rid, "kind": kind, "old": old, "new": new, "shift": shift,
                     "flag_shift": shift is not None and abs(shift) > RETRO_FLAG_SHIFT, "label": label})
    return rows


def render_retro(rows: list[dict]) -> str:
    unit = {"length": "mm", "area": "mm²"}
    out = ["| id | kind | old | new | shift | flag |", "|---|---|---|---|---|---|"]
    for r in rows:
        u = unit.get(r["kind"], "")
        old = f"{r['old']:.2f} {u}" if isinstance(r["old"], (int, float)) else "—"
        new = f"{r['new']:.2f} {u}" if r["new"] is not None else "—"
        shift = f"{r['shift']:+.1%}" + (" **>20%**" if r["flag_shift"] else "") if r["shift"] is not None else "—"
        out.append(f"| {r['id']} | {r['kind']} | {old} | {new} | {shift} | {r['label']} |")
    n_flag = sum(r["flag_shift"] for r in rows)
    n_skip = sum(r["new"] is None for r in rows)
    out.append("")
    out.append(f"{len(rows)} records · {n_flag} shifted by more than 20% · {n_skip} off-rig, no mm emitted")
    return "\n".join(out)


def _state_with_optional_crosscheck(doc, args):
    state = derive(doc, crosscheck_passed=False)
    if args.known_mm is None:
        return state, None
    cc = cross_check(state, args.known_mm, args.px, args.axis)
    if cc["verdict"] == "STOP":
        return state, cc
    return derive(doc, crosscheck_passed=True), cc


def _print_state(state: CalState) -> None:
    print(f"flag: {state.label}")
    if state.gsd_um:
        print(f"GSD: along {state.gsd_um['along']:.2f} um/px, across {state.gsd_um['across']:.2f} um/px")
    if state.carried:
        print("carried on every output: " + ", ".join(state.carried))
    for r in state.reasons:
        print(f"  - {r}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("status", "crosscheck", "retro"):
        p = sub.add_parser(name)
        p.add_argument("cal2")
        if name == "retro":
            p.add_argument("records", help="JSONL: id, kind (length|area), px, axis, old_mm, geometry (rig|offrig)")
            p.add_argument("--out")
        p.add_argument("--known-mm", type=float, required=(name == "crosscheck"))
        p.add_argument("--px", type=float, required=(name == "crosscheck"))
        p.add_argument("--axis", choices=("along", "across"), default="across")
    args = ap.parse_args(argv)

    try:
        doc = load(args.cal2)
        state, cc = _state_with_optional_crosscheck(doc, args)
        if cc is not None:
            print(f"cross-check: {cc['verdict']}  implied {cc['implied_um_per_px']:.2f} vs derived "
                  f"{cc['derived_um_per_px']:.2f} um/px ({cc['deviation']:+.1%}, {cc['axis']} axis)")
            if cc["verdict"] == "STOP":
                print("STOP — do not publish any number. Usual causes:")
                for c in cc["likely_causes"]:
                    print(f"  - {c}")
                return 2
        _print_state(state)
        if args.cmd == "retro":
            records = [json.loads(line) for line in Path(args.records).read_text().splitlines() if line.strip()]
            table = render_retro(retro(state, records))
            if args.out:
                Path(args.out).write_text(table + "\n")
                print(f"wrote {args.out}")
            else:
                print(table)
    except CalError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
