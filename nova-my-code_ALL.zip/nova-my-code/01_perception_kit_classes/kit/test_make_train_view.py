"""Tests for make_train_view.py — ultralytics must read the REMAPPED labels, never the originals."""
import json
import os

import pytest
import yaml
from PIL import Image

import make_train_view as mtv
import relabel_locked6 as rl


def raw_set(root):
    """An original download: class 0 = 'hair', class 1 = 'glass' (dropped by the remap)."""
    (root / "train/images").mkdir(parents=True)
    (root / "train/labels").mkdir(parents=True)
    for i in range(3):
        Image.new("RGB", (32, 32)).save(root / f"train/images/{i}.jpg")
    (root / "train/labels/0.txt").write_text("0 0.5 0.5 0.1 0.1\n1 0.5 0.5 0.1 0.1\n")
    (root / "train/labels/1.txt").write_text("1 0.5 0.5 0.1 0.1\n")
    (root / "train/labels/2.txt").write_text("0 0.5 0.5 0.1 0.1\n0 0.4 0.4 0.1 0.1\n")
    (root / "data.yaml").write_text(yaml.safe_dump({"names": ["hair", "glass"]}))
    return root


def test_the_view_carries_the_remapped_labels_and_matches_the_manifest(tmp_path):
    rl.remap(raw_set(tmp_path / "raw"), tmp_path / "remapped")
    rep = mtv.build([tmp_path / "remapped"], tmp_path / "view")
    assert rep["remapped"]["instances"] == {"loose_debris": 3}
    lab = (tmp_path / "view/remapped/train/labels/0.txt").read_text().split()
    assert lab[0] == "4"                                        # hair -> loose_debris, glass gone
    img = tmp_path / "view/remapped/train/images/0.jpg"
    assert not img.is_symlink() and os.stat(img).st_nlink == 2  # a hard link, not a copy, not a symlink


def test_a_view_that_reads_the_original_labels_is_refused(tmp_path, monkeypatch):
    rl.remap(raw_set(tmp_path / "raw"), tmp_path / "remapped")
    # simulate the trap: the view's labels come from the original download instead of the remap
    orig = mtv.build_one
    def leaky(root, out):
        s = orig(root, out)
        for f in (tmp_path / "raw/train/labels").iterdir():
            (out / "train/labels" / f.name).write_text(f.read_text())
        return s
    monkeypatch.setattr(mtv, "build_one", leaky)
    with pytest.raises(mtv.ViewError, match="the remap kept"):
        mtv.build([tmp_path / "remapped"], tmp_path / "view")


def test_an_out_of_range_class_id_is_refused(tmp_path, monkeypatch):
    rl.remap(raw_set(tmp_path / "raw"), tmp_path / "remapped")
    orig = mtv.build_one
    def bad(root, out):
        s = orig(root, out)
        (out / "train/labels/1.txt").write_text("7 0.5 0.5 0.1 0.1\n")
        return s
    monkeypatch.setattr(mtv, "build_one", bad)
    with pytest.raises(mtv.ViewError, match="outside the locked 6"):
        mtv.build([tmp_path / "remapped"], tmp_path / "view")


def test_an_image_without_a_label_file_stays_a_negative(tmp_path):
    raw = raw_set(tmp_path / "raw")
    Image.new("RGB", (32, 32)).save(raw / "train/images/3.jpg")      # no label file at all
    rl.remap(raw, tmp_path / "remapped")
    mtv.build([tmp_path / "remapped"], tmp_path / "view")
    assert (tmp_path / "view/remapped/train/labels/3.txt").read_text() == ""
