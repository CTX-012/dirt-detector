#!/usr/bin/env python3
"""Phase 5 — compare two arms that were scored on THE SAME objects (added 2026-09-28).

The bake-off runs every arm over the same frames, so the results are PAIRED. Comparing two
independent confidence intervals and asking whether they overlap throws that pairing away: it is
far too conservative, and it hides real differences. Example this tool's tests carry: 40 objects,
arm A 30/40, arm B 22/40 — the two intervals overlap, yet every one of the 8 disagreements goes
the same way, and the paired test gives p = 0.008.

For each class it reports: n, each arm's recall with a 95% Clopper-Pearson interval, whether those
intervals overlap, the disagreement split (b = A found it and B didn't, c = the reverse), McNemar's
exact two-sided p, and the difference in recall with an exact interval built from the disagreements.

  python3 paired_compare.py results.jsonl --arm-a r1 --arm-b cutout_seg [--alpha 0.05] [--min-n 30]

results.jsonl — one line per ground-truth object, each arm a key with 1 (found) or 0 (missed):
  {"id": "val03-hair-1", "class": "hair", "r1": 1, "cutout_seg": 0}
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

from scipy.stats import beta, binomtest

MIN_N = 30


class PairedError(Exception):
    pass


def cp_interval(x: int, n: int, alpha: float = 0.05):
    if n == 0:
        return (float("nan"), float("nan"))
    lo = 0.0 if x == 0 else float(beta.ppf(alpha / 2, x, n - x + 1))
    hi = 1.0 if x == n else float(beta.ppf(1 - alpha / 2, x + 1, n - x))
    return lo, hi


def compare(rows: list[dict], arm_a: str, arm_b: str, alpha: float = 0.05, min_n: int = MIN_N) -> list[dict]:
    """One row per class, plus an 'ALL' row. Rows must carry both arms for the same object ids."""
    by_class: dict[str, list[dict]] = defaultdict(list)
    seen = set()
    for r in rows:
        for arm in (arm_a, arm_b):
            if arm not in r:
                raise PairedError(f"object {r.get('id', '?')!r} has no result for arm {arm!r} — "
                                  f"both arms must be scored on the same objects")
            if r[arm] not in (0, 1, True, False):
                raise PairedError(f"object {r.get('id', '?')!r}, arm {arm!r}: expected 1 or 0, got {r[arm]!r}")
        oid = r.get("id")
        if oid in seen:
            raise PairedError(f"duplicate object id {oid!r}")
        seen.add(oid)
        by_class[str(r.get("class", "unclassified"))].append(r)

    out = []
    for cls in sorted(by_class) + ["ALL"]:
        rs = rows if cls == "ALL" else by_class[cls]
        n = len(rs)
        ka = sum(bool(r[arm_a]) for r in rs)
        kb = sum(bool(r[arm_b]) for r in rs)
        b = sum(bool(r[arm_a]) and not bool(r[arm_b]) for r in rs)   # A found it, B missed it
        c = sum(not bool(r[arm_a]) and bool(r[arm_b]) for r in rs)   # B found it, A missed it
        lo_a, hi_a = cp_interval(ka, n, alpha)
        lo_b, hi_b = cp_interval(kb, n, alpha)
        overlap = not (hi_a < lo_b or hi_b < lo_a)
        if b + c == 0:
            p, diff_ci = 1.0, (0.0, 0.0)
        else:
            test = binomtest(b, b + c, 0.5)
            p = float(test.pvalue)
            lo_p, hi_p = test.proportion_ci(confidence_level=1 - alpha, method="exact")
            diff_ci = ((2 * lo_p - 1) * (b + c) / n, (2 * hi_p - 1) * (b + c) / n)
        if n < min_n:
            verdict = f"NOT A MEASUREMENT (n<{min_n})"
        elif p < alpha:
            verdict = f"{arm_a} better" if b > c else f"{arm_b} better"
        else:
            verdict = "no difference detectable"
        out.append({"class": cls, "n": n, f"{arm_a}_k": ka, f"{arm_b}_k": kb,
                    f"{arm_a}_ci": (lo_a, hi_a), f"{arm_b}_ci": (lo_b, hi_b), "ci_overlap": overlap,
                    "b_only_a": b, "c_only_b": c, "p_mcnemar": p,
                    "diff": (ka - kb) / n if n else float("nan"), "diff_ci": diff_ci, "verdict": verdict})
    return out


def render(rows: list[dict], arm_a: str, arm_b: str) -> str:
    def pct(k, n, ci):
        return f"{k}/{n} = {k / n:.0%} [{ci[0]:.0%}, {ci[1]:.0%}]" if n else "—"
    lines = [f"| class | n | {arm_a} | {arm_b} | CIs overlap? | only {arm_a} | only {arm_b} | McNemar p | difference [95% CI] | verdict |",
             "|---|---|---|---|---|---|---|---|---|---|"]
    for r in rows:
        lines.append(
            f"| {r['class']} | {r['n']} | {pct(r[f'{arm_a}_k'], r['n'], r[f'{arm_a}_ci'])} | "
            f"{pct(r[f'{arm_b}_k'], r['n'], r[f'{arm_b}_ci'])} | {'yes' if r['ci_overlap'] else 'no'} | "
            f"{r['b_only_a']} | {r['c_only_b']} | {r['p_mcnemar']:.4f} | "
            f"{r['diff']:+.1%} [{r['diff_ci'][0]:+.1%}, {r['diff_ci'][1]:+.1%}] | {r['verdict']} |")
    lines += ["",
              "The arms saw the same objects, so the paired test (McNemar, exact) decides — not whether the two",
              "confidence intervals overlap. Overlapping intervals with a small p means the arms disagree",
              "consistently on the same objects; that is a real difference, and the CI-overlap rule would miss it.",
              f"Any class with n below {MIN_N} is printed as NOT A MEASUREMENT, whatever p says."]
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("results")
    ap.add_argument("--arm-a", required=True)
    ap.add_argument("--arm-b", required=True)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--min-n", type=int, default=MIN_N)
    ap.add_argument("--out")
    args = ap.parse_args(argv)
    try:
        rows = [json.loads(line) for line in Path(args.results).read_text().splitlines() if line.strip()]
        table = compare(rows, args.arm_a, args.arm_b, args.alpha, args.min_n)
    except PairedError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    text = render(table, args.arm_a, args.arm_b)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
