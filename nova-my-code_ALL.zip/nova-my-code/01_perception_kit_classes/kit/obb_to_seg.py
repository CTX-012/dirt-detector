#!/usr/bin/env python3
"""Convert a DOTA / YOLOv5-OBB dataset to YOLO segmentation, so the locked-6 remap can read it.

OBB label lines are `x1 y1 x2 y2 x3 y3 x4 y4 class difficulty` in **pixel** coordinates, with the class
as a NAME in the ninth field. YOLO-seg wants `class_index x1 y1 … xn yn` **normalised** to the image,
with the index first. Nothing else about the geometry changes: the four corners are kept as a 4-point
polygon, so no area is invented or lost.

  python3 obb_to_seg.py SRC_ROOT DST_ROOT [--names 0,1]

SRC_ROOT holds <split>/images and <split>/labelTxt (Roboflow's yolov5-obb layout). Class names come
from SRC_ROOT/data.yaml unless --names is given. Images are symlinked, never copied or dropped.
"""
from __future__ import annotations

import argparse
import sys
from collections import Counter
from pathlib import Path

import yaml
from PIL import Image

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp")


class ObbError(Exception):
    pass


def read_names(src: Path, override: str | None) -> list[str]:
    if override:
        return [n.strip() for n in override.split(",") if n.strip()]
    cfg_path = src / "data.yaml"
    if not cfg_path.exists():
        raise ObbError(f"{cfg_path} not found — pass --names")
    cfg = yaml.safe_load(cfg_path.read_text()) or {}
    names = cfg.get("names")
    if isinstance(names, dict):
        names = [names[k] for k in sorted(names, key=int)]
    if not names:
        raise ObbError(f"{cfg_path}: no names")
    return [str(n) for n in names]


def convert(src: Path, dst: Path, names_override: str | None = None) -> dict:
    src, dst = Path(src).resolve(), Path(dst).resolve()
    if dst == src or src in dst.parents:
        raise ObbError("DST must not be the source or sit inside it")
    if dst.exists() and any(dst.iterdir()):
        raise ObbError(f"{dst} exists and is not empty")
    names = read_names(src, names_override)
    index = {n: i for i, n in enumerate(names)}

    label_dirs = sorted(p for p in src.rglob("labelTxt") if p.is_dir())
    if not label_dirs:
        raise ObbError(f"no labelTxt directory under {src}")
    # every counter starts at zero, so a caller never has to guess whether a key is missing
    stats = Counter({k: 0 for k in ("lines_in", "lines_out", "malformed", "unknown_class", "clamped",
                                    "label_files", "empty_label_files", "images")})
    missing_images, unknown_classes = [], Counter()

    for ldir in label_dirs:
        split = ldir.relative_to(src).parts[0]
        images_dir = ldir.parent / "images"
        out_dir = dst / split / "labels"
        out_dir.mkdir(parents=True, exist_ok=True)
        for lf in sorted(ldir.glob("*.txt")):
            img = next((images_dir / (lf.stem + e) for e in IMAGE_EXT if (images_dir / (lf.stem + e)).exists()), None)
            if img is None:
                missing_images.append(lf.name)
                continue
            with Image.open(img) as im:
                w, h = im.size
            out_lines = []
            for raw in lf.read_text().splitlines():
                tok = raw.split()
                if not tok:
                    continue
                stats["lines_in"] += 1
                if len(tok) < 9:
                    stats["malformed"] += 1
                    continue
                cls = tok[8]
                if cls not in index:
                    unknown_classes[cls] += 1
                    stats["unknown_class"] += 1
                    continue
                try:
                    xy = [float(v) for v in tok[:8]]
                except ValueError:
                    stats["malformed"] += 1
                    continue
                norm = []
                for i, v in enumerate(xy):
                    d = w if i % 2 == 0 else h
                    n = v / d
                    if n < 0 or n > 1:
                        stats["clamped"] += 1
                        n = min(max(n, 0.0), 1.0)
                    norm.append(f"{n:.6f}")
                out_lines.append(" ".join([str(index[cls])] + norm))
                stats["lines_out"] += 1
            (out_dir / lf.name).write_text("\n".join(out_lines) + ("\n" if out_lines else ""))
            stats["label_files"] += 1
            stats["empty_label_files"] += not out_lines
        if images_dir.is_dir():
            link = dst / split / "images"
            link.parent.mkdir(parents=True, exist_ok=True)
            if not link.exists():
                link.symlink_to(images_dir, target_is_directory=True)
            stats["images"] += sum(1 for p in images_dir.iterdir() if p.suffix.lower() in IMAGE_EXT)

    cfg = {"names": names, "nc": len(names), "path": str(dst)}
    for split in sorted({p.relative_to(src).parts[0] for p in label_dirs}):
        key = "val" if split in ("valid", "val") else split
        cfg[key] = f"{split}/images"
    (dst / "data.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))

    summary = {"source": str(src), "destination": str(dst), "names": names,
               "missing_images": missing_images[:5], "missing_image_count": len(missing_images),
               "unknown_classes": dict(unknown_classes), **stats}
    return summary


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--names", help="comma list, overriding data.yaml")
    args = ap.parse_args(argv)
    try:
        s = convert(Path(args.src), Path(args.dst), args.names)
    except ObbError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    print(f"converted {s['label_files']} label files · {s['lines_in']} lines in → {s['lines_out']} out · "
          f"{s['images']} images linked")
    for k in ("malformed", "unknown_class", "clamped", "empty_label_files", "missing_image_count"):
        if s.get(k):
            print(f"  {k}: {s[k]}" + (f" {s['unknown_classes']}" if k == "unknown_class" else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
