"""Tests for obb_to_seg.py — geometry must survive the conversion exactly."""
import pytest
import yaml
from PIL import Image

import obb_to_seg as ob


def build(root, lines, names=("0", "1"), w=100, h=50, with_image=True):
    (root / "train/labelTxt").mkdir(parents=True)
    (root / "train/images").mkdir(parents=True)
    (root / "train/labelTxt/a.txt").write_text("\n".join(lines) + "\n")
    if with_image:
        Image.new("RGB", (w, h), (120, 120, 120)).save(root / "train/images/a.jpg")
    (root / "data.yaml").write_text(yaml.safe_dump({"names": list(names), "nc": len(names)}))
    return root


def out_lines(dst):
    return (dst / "train/labels/a.txt").read_text().strip().splitlines()


def test_pixel_quad_becomes_a_normalised_polygon(tmp_path):
    # a 20x10 px box at (10,5) on a 100x50 image
    src = build(tmp_path / "src", ["10 5 30 5 30 15 10 15 1 0"])
    s = ob.convert(src, tmp_path / "dst")
    assert s["lines_in"] == 1 and s["lines_out"] == 1
    got = out_lines(tmp_path / "dst")[0].split()
    assert got[0] == "1"                                   # class name "1" -> index 1
    assert [float(v) for v in got[1:]] == pytest.approx([0.1, 0.1, 0.3, 0.1, 0.3, 0.3, 0.1, 0.3])


def test_a_rotated_quad_keeps_all_four_corners(tmp_path):
    src = build(tmp_path / "src", ["50 5 90 25 50 45 10 25 0 0"])
    ob.convert(src, tmp_path / "dst")
    vals = [float(v) for v in out_lines(tmp_path / "dst")[0].split()[1:]]
    assert len(vals) == 8
    assert vals == pytest.approx([0.5, 0.1, 0.9, 0.5, 0.5, 0.9, 0.1, 0.5])


def test_coordinates_outside_the_image_are_clamped_and_counted(tmp_path):
    src = build(tmp_path / "src", ["-10 5 110 5 110 60 -10 60 0 0"])
    s = ob.convert(src, tmp_path / "dst")
    vals = [float(v) for v in out_lines(tmp_path / "dst")[0].split()[1:]]
    # x: -0.1, 1.1, 1.1, -0.1 (4 clamps) · y: 0.1, 0.1, 1.2, 1.2 (2 clamps)
    assert min(vals) == 0.0 and max(vals) == 1.0 and s["clamped"] == 6


def test_malformed_and_unknown_classes_are_skipped_not_guessed(tmp_path):
    src = build(tmp_path / "src", ["10 5 30 5 30 15 10 15 0 0", "1 2 3", "10 5 30 5 30 15 10 15 banana 0"])
    s = ob.convert(src, tmp_path / "dst")
    assert s["lines_in"] == 3 and s["lines_out"] == 1
    assert s["malformed"] == 1 and s["unknown_classes"] == {"banana": 1}


def test_a_label_with_no_usable_lines_stays_as_a_negative(tmp_path):
    src = build(tmp_path / "src", ["10 5 30 5 30 15 10 15 banana 0"])
    s = ob.convert(src, tmp_path / "dst")
    assert (tmp_path / "dst/train/labels/a.txt").read_text() == ""
    assert s["empty_label_files"] == 1


def test_images_are_linked_and_the_config_is_rewritten(tmp_path):
    src = build(tmp_path / "src", ["10 5 30 5 30 15 10 15 0 0"])
    dst = tmp_path / "dst"
    ob.convert(src, dst)
    assert (dst / "train/images").is_symlink() and (dst / "train/images/a.jpg").exists()
    cfg = yaml.safe_load((dst / "data.yaml").read_text())
    assert cfg["names"] == ["0", "1"] and cfg["train"] == "train/images"


def test_a_label_without_its_image_is_reported_not_converted(tmp_path):
    src = build(tmp_path / "src", ["10 5 30 5 30 15 10 15 0 0"], with_image=False)
    s = ob.convert(src, tmp_path / "dst")
    assert s["missing_image_count"] == 1 and s["lines_out"] == 0


def test_refuses_nested_or_occupied_destination(tmp_path):
    src = build(tmp_path / "src", ["10 5 30 5 30 15 10 15 0 0"])
    with pytest.raises(ob.ObbError, match="inside"):
        ob.convert(src, src / "out")
    busy = tmp_path / "busy"
    busy.mkdir()
    (busy / "x").write_text("x")
    with pytest.raises(ob.ObbError, match="not empty"):
        ob.convert(src, busy)
