"""Tests for the calibration ingest, the locked-6 re-labeller and the policy migrator.

Synthetic inputs only: the real labels, policy file and readings are on the 3080 / not
taken yet. Run: python3 -m pytest -q test_kit.py
"""
import json
import math
from pathlib import Path

import pytest
import yaml

import cal_ingest as ci
import migrate_policy as mp
import relabel_locked6 as rl

KIT = Path(__file__).resolve().parent


# ---------------------------------------------------------------- calibration ingest
def template():
    return json.loads((KIT / "cal2.template.json").read_text())


def full_reading(**over):
    doc = template()
    doc.update({
        "camera_id": "test-cam-001", "height_mm": 140.0, "height_tol_mm": 5.0,
        "pitch_deg": 13.0, "pitch_tol_deg": 0.5, "pitch_reference": "from_nadir",
        "method": {"height": "tape", "pitch": "clinometer"}, "proxy": False,
        "intrinsics": {"source": "synthetic", "sha256": None, "fx_px": 1000.0, "fy_px": 1000.0,
                       "fx_std_px": None, "rms_px": 0.3, "width_px": 1920, "height_px": 1080},
        "measured_by": "test", "date": "2026-09-18",
    })
    doc.update(over)
    return ci.validate(doc)


def test_template_is_valid_and_uncal():
    s = ci.derive(ci.validate(template()))
    assert s.flag == ci.UNCAL and s.gsd_um is None
    assert any("height" in r for r in s.reasons) and any("f_px" in r for r in s.reasons)


def test_height_without_pitch_is_derived_and_pitch_unverified():
    s = ci.derive(full_reading(pitch_deg=None, pitch_tol_deg=None,
                               method={"height": "tape", "pitch": None}))
    assert s.flag == ci.DERIVED
    assert "PITCH-UNVERIFIED" in s.carried
    assert s.gsd_um["along"] == pytest.approx(140.0)
    assert s.label == "CAL-DERIVED ±3.6%"


def test_brief_arithmetic_5mm_on_140mm_is_3_6_not_5_6_percent():
    s = ci.derive(full_reading(pitch_deg=None, pitch_tol_deg=None,
                               method={"height": "tape", "pitch": None}))
    assert s.tol_rel["along"] == pytest.approx(5 / 140)          # 3.57 %
    assert abs(s.tol_rel["along"] - 0.056) > 0.02                  # not 5.6 %


def test_tilt_correction_per_axis_above_5_deg():
    s = ci.derive(full_reading())                                  # 13 deg from nadir
    t = math.radians(13)
    assert s.gsd_um["along"] == pytest.approx(140 / math.cos(t) ** 2)   # 147.46
    assert s.gsd_um["across"] == pytest.approx(140 / math.cos(t))       # 143.68


def test_no_tilt_correction_at_or_below_5_deg_but_skip_is_carried_as_tolerance():
    s = ci.derive(full_reading(pitch_deg=4.0))
    assert s.gsd_um["along"] == pytest.approx(140.0)
    skipped = 1 / math.cos(math.radians(4)) ** 2 - 1
    assert s.tol_rel["along"] > math.hypot(5 / 140, skipped) - 1e-12


def test_reference_conversion_is_equivalent():
    a = ci.derive(full_reading(pitch_deg=13.0, pitch_reference="from_nadir"))
    b = ci.derive(full_reading(pitch_deg=77.0, pitch_reference="from_horizontal"))
    assert a.gsd_um == pytest.approx(b.gsd_um)


def test_reading_13_deg_against_the_wrong_reference_is_an_18x_error():
    right = ci.derive(full_reading(pitch_deg=13.0, pitch_reference="from_nadir"))
    wrong = ci.derive(full_reading(pitch_deg=13.0, pitch_reference="from_horizontal"))
    ratio = wrong.gsd_um["along"] / right.gsd_um["along"]
    assert 18.0 < ratio < 19.5


def test_calibrated_needs_the_cross_check():
    assert ci.derive(full_reading()).flag == ci.DERIVED
    s = ci.derive(full_reading(), crosscheck_passed=True)
    assert s.flag == ci.CALIBRATED and s.carried == []


@pytest.mark.parametrize("over, why", [
    ({"proxy": True}, "PROXY"),
    ({"intrinsics": {"source": "x", "sha256": None, "fx_px": 1000.0, "fy_px": 1000.0,
                     "fx_std_px": None, "rms_px": 0.8, "width_px": 1920, "height_px": 1080}}, "RMS"),
    ({"method": {"height": "tape", "pitch": None}}, "pitch not measured"),
    ({"pitch_tol_deg": None}, "pitch tolerance"),
])
def test_calibrated_refused(over, why):
    s = ci.derive(full_reading(**over), crosscheck_passed=True)
    assert s.flag == ci.DERIVED
    assert any(why in r for r in s.reasons)


def test_claiming_a_higher_status_is_refused():
    with pytest.raises(ci.CalError, match="claims CALIBRATED"):
        ci.derive(ci.validate({**template(), "status_claimed": "CALIBRATED"}))
    with pytest.raises(ci.CalError, match="claims CALIBRATED"):
        ci.derive(full_reading(status_claimed="CALIBRATED"))       # no cross-check yet


def test_schema_rejects_bad_readings():
    with pytest.raises(ci.CalError):
        full_reading(pitch_deg=120.0)
    bad = template()
    del bad["pitch_reference"]
    with pytest.raises(ci.CalError):
        ci.validate(bad)


def test_cross_check_pass_and_stop():
    s = ci.derive(full_reading())
    expected_px = 50_000 / s.gsd_um["along"]                       # a 50 mm part along the axis
    ok = ci.cross_check(s, 50, expected_px * 1.03, "along")
    assert ok["verdict"] == "PASS"
    stop = ci.cross_check(s, 50, expected_px / 1.3, "along")       # implies 30 % coarser
    assert stop["verdict"] == "STOP" and stop["likely_causes"]
    with pytest.raises(ci.CalError):
        ci.cross_check(ci.derive(ci.validate(template())), 50, 300, "along")


def test_retro_recompute_flags_big_shifts_and_never_gives_offrig_mm():
    s = ci.derive(full_reading(), crosscheck_passed=True)
    rows = ci.retro(s, [
        {"id": "hair-1", "kind": "length", "px": 100, "axis": "along", "old_mm": 30.0, "geometry": "rig"},
        {"id": "spill-1", "kind": "area", "px": 10_000, "old_mm": 200.0, "geometry": "rig"},
        {"id": "phone-1", "kind": "length", "px": 100, "axis": "along", "old_mm": 42.3, "geometry": "offrig"},
    ])
    hair, spill, phone = rows
    assert hair["new"] == pytest.approx(100 * s.gsd_um["along"] / 1000)
    assert hair["flag_shift"]                                      # 30 -> 14.7 mm, over 20 %
    assert spill["new"] == pytest.approx(10_000 * s.gsd_um["along"] * s.gsd_um["across"] / 1e6)
    assert not spill["flag_shift"]                                 # 200 -> 211.9 mm², under 20 %
    assert phone["new"] is None and "NOT-RIG-GEOMETRY" in phone["label"]
    assert "CALIBRATED" in hair["label"]
    table = ci.render_retro(rows)
    assert "**>20%**" in table and "off-rig" in table


def test_retro_is_blocked_while_uncal():
    with pytest.raises(ci.CalError, match="blocked"):
        ci.retro(ci.derive(ci.validate(template())), [])


def test_cli_stops_with_exit_2_on_a_failed_cross_check(tmp_path, capsys):
    p = tmp_path / "cal2.json"
    p.write_text(json.dumps(full_reading()))
    assert ci.main(["crosscheck", str(p), "--known-mm", "50", "--px", "200", "--axis", "along"]) == 2
    assert "STOP" in capsys.readouterr().out
    assert ci.main(["status", str(KIT / "cal2.template.json")]) == 0


# ---------------------------------------------------------------- locked-6 re-label
NAMES = ["hair", "spill", "dirt", "cable", "paper", "textile", "wire", "sock", "poop", "shadow"]


def make_dataset(root: Path, names=NAMES):
    (root / "labels/train").mkdir(parents=True)
    (root / "labels/val").mkdir(parents=True)
    for split in ("train", "val"):
        (root / f"images/{split}").mkdir(parents=True)
    box = "0.5 0.5 0.1 0.1"
    (root / "labels/train/a.txt").write_text(f"0 {box}\n2 {box}\n2 {box}\n9 {box}\n")
    (root / "labels/val/b.txt").write_text(f"3 {box}\n6 {box}\n4 {box}\n8 {box}\n")
    (root / "labels/val/neg.txt").write_text("")
    for f in ("train/a.jpg", "val/b.jpg", "val/neg.jpg"):
        (root / "images" / f).write_bytes(b"\xff\xd8")
    (root / "data.yaml").write_text(yaml.safe_dump(
        {"path": str(root), "train": "images/train", "val": "images/val", "names": names}))
    return root


def test_relabel_auto_drops_every_unmapped_class_and_reports_it(tmp_path):
    """Policy 2026-10-01: keep the locked 6, drop the rest without prompting, and say what was dropped."""
    src = make_dataset(tmp_path / "src", NAMES[:-1] + ["mop_bucket"])
    s = rl.remap(src, tmp_path / "dst")
    assert set(s["classes_kept"]) == {"hair", "spill", "dirt", "cable", "paper", "textile", "wire", "sock", "poop"}
    assert s["classes_dropped"] == {"mop_bucket": "does not map to the locked 6"}
    assert s["classes_found"] == NAMES[:-1] + ["mop_bucket"]


def test_relabel_drops_labels_never_images(tmp_path):
    src, dst = make_dataset(tmp_path / "src"), tmp_path / "dst"
    s = rl.remap(src, dst)
    assert s["images_before"] == s["images_after"] == 3          # nothing is ever removed
    assert (s["label_lines_before"], s["label_lines_after"]) == (8, 7)   # only the shadow line goes
    assert "shadow" in s["classes_dropped"]
    md = (dst / "counts.md").read_text()
    assert "images before → after | 3 → 3" in md and "8 → 7" in md


def test_an_image_whose_only_label_was_dropped_becomes_a_negative(tmp_path):
    src = tmp_path / "src"
    (src / "labels/train").mkdir(parents=True)
    (src / "images/train").mkdir(parents=True)
    (src / "labels/train/hair.txt").write_text("0 0.5 0.5 0.1 0.1\n")
    (src / "labels/train/shadow_only.txt").write_text("1 0.5 0.5 0.3 0.3\n")
    for n in ("hair.jpg", "shadow_only.jpg"):
        (src / "images/train" / n).write_bytes(b"\xff\xd8")
    (src / "data.yaml").write_text(yaml.safe_dump({"names": ["hair", "shadow"]}))
    dst = tmp_path / "dst"
    s = rl.remap(src, dst)
    assert (dst / "labels/train/shadow_only.txt").read_text() == ""     # kept, as background
    assert (dst / "images/train/shadow_only.jpg").exists()              # image still reachable
    assert s["negative_files_kept"] == 1 and s["images_after"] == 2


def test_a_dataset_where_nothing_maps_is_refused(tmp_path):
    src = tmp_path / "chickens"
    (src / "labels/train").mkdir(parents=True)
    (src / "images/train").mkdir(parents=True)
    (src / "labels/train/a.txt").write_text("0 0.5 0.5 0.1 0.1\n")
    (src / "images/train/a.jpg").write_bytes(b"\xff\xd8")
    (src / "data.yaml").write_text(yaml.safe_dump({"names": ["coccidiosis", "salmonella"]}))
    with pytest.raises(rl.RelabelError, match="dataset dropped: no class maps"):
        rl.remap(src, tmp_path / "dst")


def test_relabel_counts_sidecar_and_negatives(tmp_path):
    src, dst = make_dataset(tmp_path / "src"), tmp_path / "dst"
    s = rl.remap(src, dst)
    assert s["counts"]["train"]["loose_debris"] == {"hair": 1, "dirt": 2}
    assert s["counts"]["val"]["cable_cord"] == {"cable": 1, "wire": 1}
    assert s["counts"]["val"]["paper_flat"] == {"paper": 1}
    assert s["counts"]["val"]["pet_waste"] == {"poop": 1}
    assert s["dropped"]["train"] == {"shadow": 1}
    assert s["negative_files_kept"] == 1
    ld = rl.LOCKED6.index("loose_debris")
    assert (dst / "labels/train/a.txt").read_text().split("\n")[:3] == [f"{ld} 0.5 0.5 0.1 0.1"] * 3
    assert (dst / "sources/labels/train/a.txt").read_text().split() == ["hair", "dirt", "dirt"]
    assert (dst / "labels/val/neg.txt").read_text() == ""
    cfg = yaml.safe_load((dst / "data.yaml").read_text())
    assert cfg["names"] == rl.LOCKED6 and cfg["nc"] == 6 and cfg["path"] == str(dst.resolve())
    assert (dst / "images").is_symlink()
    md = (dst / "counts.md").read_text()
    assert "Zero instances" in md and "soft_object" in md and "spill_coloured" in md


def test_provenance_travels_with_the_remapped_copy(tmp_path):
    src, dst = make_dataset(tmp_path / "src"), tmp_path / "dst"
    (src / "DATASET_MANIFEST.json").write_text('{"licence": "CC BY 4.0"}')
    rl.remap(src, dst)
    assert json.loads((dst / "DATASET_MANIFEST.json").read_text())["licence"] == "CC BY 4.0"


def test_an_alias_cannot_launder_a_rejection_into_a_label(tmp_path):
    src = make_dataset(tmp_path / "src")
    with pytest.raises(rl.RelabelError, match="refusing --alias shadow"):
        rl.remap(src, tmp_path / "dst", aliases={"shadow": "dirt"})


def test_an_alias_can_rescue_a_renamed_class(tmp_path):
    src = tmp_path / "wire_set"
    (src / "labels/train").mkdir(parents=True)
    (src / "images/train").mkdir(parents=True)
    (src / "labels/train/a.txt").write_text("0 0.5 0.5 0.1 0.1\n1 0.2 0.2 0.1 0.1\n")
    (src / "images/train/a.jpg").write_bytes(b"\xff\xd8")
    (src / "data.yaml").write_text(yaml.safe_dump({"names": ["Red wire", "hair"]}))
    s = rl.remap(src, tmp_path / "dst", aliases={"red wire": "wire"})
    assert s["classes_kept"] == {"Red wire": "cable_cord", "hair": "loose_debris"}
    assert s["label_lines_after"] == 2


def test_relabel_never_writes_inside_or_over(tmp_path):
    src = make_dataset(tmp_path / "src")
    with pytest.raises(rl.RelabelError, match="inside"):
        rl.remap(src, src / "out")
    busy = tmp_path / "busy"
    busy.mkdir()
    (busy / "keep.txt").write_text("x")
    with pytest.raises(rl.RelabelError, match="not empty"):
        rl.remap(src, busy)


def test_merge_without_subclass_flips_the_e46_verdict():
    """E46 counted, conf 0.2: hair r1 3/3 vs cutout 1/3; dirt r1 0/62 vs cutout 5/62."""
    r1 = {"hair": (3, 3), "dirt": (0, 62)}
    cutout = {"hair": (1, 3), "dirt": (5, 62)}
    merged = lambda m: sum(tp for tp, _ in m.values()) / sum(n for _, n in m.values())
    assert merged(cutout) > merged(r1)                  # merged class: cutout 6/65 beats r1 3/65
    assert r1["hair"][0] > cutout["hair"][0]            # sub-class: r1 still wins hair


# ---------------------------------------------------------------- policy migration
def old_policy():
    row = lambda d, w, m: {"dry": d, "wet": w, "mop": m}
    return {"version": 3, "classes": {
        "hair": row("SUCTION", "SUCTION", "IGNORE"), "dirt": row("SUCTION", "SUCTION", "IGNORE"),
        "spill": row("AVOID", "MOP", "MOP"), "cable": row("AVOID", "AVOID", "AVOID"),
        "paper": row("AVOID", "AVOID", "AVOID"), "textile": row("AVOID", "AVOID", "AVOID"),
        "biohazard": row("STOP_NOTIFY", "STOP_NOTIFY", "STOP_NOTIFY"),
        "unknown": row("AVOID", "AVOID", "AVOID"), "shadow": row("IGNORE", "IGNORE", "IGNORE")}}


def test_policy_migrates_keeps_transition_rows_and_moves_rejections():
    doc, report = mp.migrate(old_policy())
    c = doc["classes"]
    assert c["loose_debris"] == c["hair"] == {"dry": "SUCTION", "wet": "SUCTION", "mop": "IGNORE"}
    assert c["spill_coloured"] == {"dry": "AVOID", "wet": "MOP", "mop": "MOP"}
    assert set(c["pet_waste"].values()) == {"STOP_NOTIFY"}
    assert c["filament"] == c["clear_water"] == {"dry": "AVOID", "wet": "AVOID", "mop": "AVOID"}
    assert "shadow" not in c and doc["reject_first"] == ["glare", "shadow"]
    assert "dirt" in c and "cable" in c                  # transition rows kept for the deployed emitters
    assert any("transition rows kept" in r for r in report)


def test_policy_refuses_merge_conflicts_unless_conservative():
    old = old_policy()
    old["classes"]["dirt"]["mop"] = "SUCTION"            # hair IGNORE vs dirt SUCTION in mop phase
    with pytest.raises(mp.PolicyError, match="disagree"):
        mp.migrate(old)
    doc, _ = mp.migrate(old, prefer_conservative=True)
    assert doc["classes"]["loose_debris"]["mop"] == "SUCTION"


def test_policy_refuses_dry_phase_liquid_cleaning():
    old = old_policy()
    old["classes"]["spill"]["dry"] = "SUCTION"
    with pytest.raises(mp.PolicyError, match="never dry-vac liquid"):
        mp.migrate(old)


def test_policy_refuses_when_a_locked_class_has_no_source_row():
    old = old_policy()
    del old["classes"]["paper"]
    with pytest.raises(mp.PolicyError, match="paper_flat"):
        mp.migrate(old)


def test_policy_string_style_and_root_table():
    old = {"hair": "SUCTION", "dirt": "SUCTION", "spill": "AVOID", "cable": "AVOID",
           "paper": "AVOID", "textile": "AVOID", "poop": "STOP_NOTIFY", "unknown": "AVOID", "glare": "IGNORE"}
    doc, report = mp.migrate(old)
    assert doc["loose_debris"] == "SUCTION" and doc["pet_waste"] == "STOP_NOTIFY"
    assert "glare" not in doc and "reject_first" not in doc
    assert any("reject_first was NOT added" in r for r in report)


def test_policy_cli_refuses_to_overwrite_the_old_file(tmp_path):
    p = tmp_path / "cleaning_policy.yaml"
    p.write_text(yaml.safe_dump(old_policy()))
    assert mp.main([str(p), str(p)]) == 1
    out = tmp_path / "new.yaml"
    assert mp.main([str(p), str(out)]) == 0 and out.exists()
