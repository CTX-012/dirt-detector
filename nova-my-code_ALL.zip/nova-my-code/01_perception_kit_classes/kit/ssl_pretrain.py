#!/usr/bin/env python3
"""Self-supervised pretraining of the YOLO11n-seg backbone on unlabeled floor imagery (2026-10-07).

Arm B of the head-to-head in PREREGISTRATION_SSL_VS_COCO.md. Arm A is COCO-pretrained only, and both
arms then get the identical supervised recipe. This script makes arm B's starting weights, and nothing else.

  - Starts FROM the COCO weights (domain-adaptive SSL), so the only difference between the arms is
    "has seen floors without labels".
  - SimCLR (NT-Xent) on backbone layers 0-10, a strictly sequential stack in YOLO11, with global-pooled
    features into a 2-layer projector.
  - Augmentations keep colour almost fixed: hue jitter 0.02, no grayscale. spill_coloured is defined by
    colour, and an SSL objective that made features colour-invariant would teach the backbone to
    ignore the one cue that class needs. Flips in both axes and 90-degree rotations are allowed,
    because the camera looks down at the floor.
  - The corpus is TRAIN splits only, listed in a file. Public val/test images (the public column is
    scored there) and the hair held-out/guard frames never enter it.

  python3 -I ssl_pretrain.py --list corpus.txt --init yolo11n-seg.pt --out ssl_run/ [--epochs 100]

Outputs ssl_run/backbone_ssl.pt (the state dict of layers 0-10), ssl_run/yolo11n-seg-sslfloor.pt (the
COCO checkpoint with ONLY its backbone replaced), and ssl_run/last_state.pt (per-epoch resume point; re-run the same command to
continue) and ssl_run/log.json (loss per epoch plus a collapse
check: the mean per-dimension std of the L2-normalised embeddings, which goes to 0 when the features
collapse; healthy is near 1/sqrt(dim)).
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import random
import sys
import time
from pathlib import Path

import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms as T

BACKBONE_LAYERS = 11          # YOLO11 layers 0-10: Conv/C3k2 stack, SPPF, C2PSA — no skip inputs


def backbone_of(det_model: nn.Module) -> nn.Sequential:
    layers = list(det_model.model[:BACKBONE_LAYERS])
    for i, m in enumerate(layers):
        if getattr(m, "f", -1) != -1:
            raise ValueError(f"layer {i} reads from {m.f} — backbone is not sequential, refusing to guess")
    return nn.Sequential(*layers)


class SimCLR(nn.Module):
    def __init__(self, backbone: nn.Sequential, feat_dim: int, proj_dim: int = 128):
        super().__init__()
        self.backbone = backbone
        self.proj = nn.Sequential(nn.Linear(feat_dim, 512), nn.BatchNorm1d(512), nn.ReLU(inplace=True),
                                  nn.Linear(512, proj_dim))

    def embed(self, x):
        return F.adaptive_avg_pool2d(self.backbone(x), 1).flatten(1)

    def forward(self, x):
        return self.proj(self.embed(x))


def nt_xent(z1: torch.Tensor, z2: torch.Tensor, tau: float = 0.2) -> torch.Tensor:
    z = F.normalize(torch.cat([z1, z2]), dim=1)
    sim = z @ z.t() / tau
    n = z1.shape[0]
    sim.fill_diagonal_(float("-inf"))
    target = torch.cat([torch.arange(n, 2 * n), torch.arange(0, n)]).to(z.device)
    return F.cross_entropy(sim, target)


def collapse_std(z: torch.Tensor) -> float:
    return F.normalize(z.float(), dim=1).std(0).mean().item()


class Rot90:
    def __call__(self, img):
        return img.rotate(90 * random.randint(0, 3), expand=True)


def make_aug(size: int):
    return T.Compose([
        Rot90(),
        T.RandomResizedCrop(size, scale=(0.2, 1.0)),
        T.RandomHorizontalFlip(), T.RandomVerticalFlip(),
        T.RandomApply([T.ColorJitter(0.4, 0.4, 0.2, 0.02)], p=0.8),
        T.RandomApply([T.GaussianBlur(9, (0.1, 2.0))], p=0.5),
        T.ToTensor(),                                   # YOLO expects 0-1 RGB, no mean/std normalisation
    ])


class Pairs(Dataset):
    def __init__(self, paths: list[str], size: int):
        self.paths, self.aug = paths, make_aug(size)

    def __len__(self):
        return len(self.paths)

    def __getitem__(self, i):
        img = Image.open(self.paths[i]).convert("RGB")
        img.thumbnail((640, 640))
        return self.aug(img), self.aug(img)


def transplant(init_ckpt: str, backbone_sd: dict, out_path: Path) -> dict:
    """Write a copy of the COCO checkpoint with ONLY layers 0-10 replaced. Returns what changed."""
    ck = torch.load(init_ckpt, map_location="cpu", weights_only=False)
    model = ck["model"].float()
    before = copy.deepcopy(model.state_dict())
    own = {f"model.{k}": v for k, v in backbone_sd.items()}
    missing = [k for k in own if k not in before]
    if missing:
        raise ValueError(f"backbone keys not in the detector: {missing[:3]}")
    model.load_state_dict({**before, **own})
    after = model.state_dict()
    changed = sorted({k.split(".")[1] for k in after if not torch.equal(after[k], before[k])}, key=int)
    ck["model"] = model.half()
    ck.pop("optimizer", None)
    ck["train_args"] = {**(ck.get("train_args") or {}), "ssl_floor": True}
    torch.save(ck, out_path)
    return {"layers_changed": changed, "n_tensors_replaced": len(own)}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--list", required=True)
    ap.add_argument("--init", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--batch", type=int, default=128)
    ap.add_argument("--size", type=int, default=224)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--max-steps", type=int, default=0, help="smoke test: stop after N steps")
    a = ap.parse_args(argv)

    torch.manual_seed(a.seed)
    random.seed(a.seed)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    paths = [p for p in Path(a.list).read_text().split("\n") if p.strip()]
    dev = "cuda" if torch.cuda.is_available() else "cpu"

    det = torch.load(a.init, map_location="cpu", weights_only=False)["model"].float()
    bb = backbone_of(det)
    with torch.no_grad():
        feat_dim = bb(torch.zeros(2, 3, a.size, a.size)).shape[1]
    net = SimCLR(bb, feat_dim).to(dev)
    for p in net.parameters():
        p.requires_grad_(True)
    opt = torch.optim.AdamW(net.parameters(), lr=a.lr, weight_decay=0.05)
    dl = DataLoader(Pairs(paths, a.size), batch_size=a.batch, shuffle=True, drop_last=True,
                    num_workers=a.workers, pin_memory=True, persistent_workers=a.workers > 0)
    total = a.epochs * len(dl)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1, (s + 1) / 200) * 0.5 * (1 + math.cos(math.pi * s / total)))
    scaler = torch.amp.GradScaler(enabled=dev == "cuda")
    log = {"args": vars(a), "corpus_images": len(paths), "feat_dim": feat_dim, "epochs": []}
    step, t0, start = 0, time.time(), 0
    ckpt = out / "last_state.pt"
    if ckpt.exists():               # resume: a killed session must not cost the epochs already run
        st = torch.load(ckpt, map_location="cpu", weights_only=False)   # RNG states must stay CPU ByteTensors
        if st["args"] != {k: v for k, v in vars(a).items() if k != "max_steps"}:
            raise SystemExit(f"{ckpt} was written with different args — refusing to resume into a different run")
        net.load_state_dict(st["net"]); opt.load_state_dict(st["opt"])
        sched.load_state_dict(st["sched"]); scaler.load_state_dict(st["scaler"])
        torch.set_rng_state(st["rng_cpu"]); random.setstate(st["rng_py"])
        if dev == "cuda":
            torch.cuda.set_rng_state(st["rng_cuda"])
        start, step, log = st["epoch"] + 1, st["step"], st["log"]
        log.setdefault("resumed_at_epoch", []).append(start)
        print(f"resumed at epoch {start}", flush=True)
    for ep in range(start, a.epochs):
        net.train()
        losses, stds = [], []
        for x1, x2 in dl:
            x1, x2 = x1.to(dev, non_blocking=True), x2.to(dev, non_blocking=True)
            with torch.autocast(dev, dtype=torch.float16, enabled=dev == "cuda"):
                z1, z2 = net(x1), net(x2)
                loss = nt_xent(z1.float(), z2.float())
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
            sched.step()
            losses.append(loss.item())
            stds.append(collapse_std(z1.detach()))
            step += 1
            if a.max_steps and step >= a.max_steps:
                break
        row = {"epoch": ep, "loss": sum(losses) / len(losses), "embed_std": sum(stds) / len(stds),
               "healthy_std": 1 / math.sqrt(128), "minutes": round((time.time() - t0) / 60, 2)}
        log["epochs"].append(row)
        print(json.dumps(row), flush=True)
        (out / "log.json").write_text(json.dumps(log, indent=2) + "\n")
        torch.save({"epoch": ep, "step": step, "log": log, "net": net.state_dict(), "opt": opt.state_dict(),
                    "sched": sched.state_dict(), "scaler": scaler.state_dict(),
                    "rng_cpu": torch.get_rng_state(), "rng_py": random.getstate(),
                    "rng_cuda": torch.cuda.get_rng_state() if dev == "cuda" else None,
                    "args": {k: v for k, v in vars(a).items() if k != "max_steps"}}, ckpt.with_suffix(".tmp"))
        ckpt.with_suffix(".tmp").replace(ckpt)       # atomic: a kill mid-save leaves the previous epoch intact
        if a.max_steps and step >= a.max_steps:
            break
    sd = {k: v.detach().cpu() for k, v in net.backbone.state_dict().items()}
    torch.save(sd, out / "backbone_ssl.pt")
    log["transplant"] = transplant(a.init, sd, out / "yolo11n-seg-sslfloor.pt")
    log["status"] = "BENCHMARK_ONLY — public imagery; never registered or released"
    (out / "log.json").write_text(json.dumps(log, indent=2) + "\n")
    print(json.dumps(log["transplant"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
