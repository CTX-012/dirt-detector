#!/usr/bin/env python3
"""Make a remapped dataset trainable by ultralytics without it reading the WRONG labels (added 2026-10-29).

The trap, measured: relabel_locked6.py links each `images/` directory back to the original download.
ultralytics' check_det_dataset() calls .resolve() on the train/val paths, so it follows that link and
derives label paths in the ORIGINAL folder. Those are the raw, un-remapped labels. On the dirt set that meant
4,833 of 5,123 images were read as empty backgrounds (the raw labels are OBB in labelTxt/), and on the spill set
the original class ids 6 and 7 reached a 6-class model. Nothing errors. Training simply learns from nothing.

This builds a view of REAL directories: images are hard-linked (no copy, same disk; a link that would cross
disks is refused, never silently copied), labels are copied from the remapped set. It then re-reads the view
the way ultralytics will and refuses to finish unless the instance count per class equals what
relabel_manifest.json says the remap kept.

  python3 make_train_view.py REMAPPED_ROOT [REMAPPED_ROOT ...] --out VIEW_DIR
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from collections import Counter
from pathlib import Path

from relabel_locked6 import IMAGE_EXT, LOCKED6


class ViewError(Exception):
    pass


def expected_counts(root: Path) -> Counter:
    m = json.loads((root / "relabel_manifest.json").read_text())
    c = Counter()
    for per_class in m["counts"].values():
        for cls, origins in per_class.items():
            c[LOCKED6.index(cls)] += sum(origins.values())
    return c


def build_one(root: Path, out: Path) -> dict:
    root, out = Path(root), Path(out)
    splits = {}
    for img_dir in sorted(p for p in root.rglob("images") if p.is_dir() and "sources" not in p.relative_to(root).parts):
        rel = img_dir.relative_to(root)
        lab_dir = root / rel.parent / "labels"
        dst_img, dst_lab = out / rel, out / rel.parent / "labels"
        dst_img.mkdir(parents=True, exist_ok=True)
        dst_lab.mkdir(parents=True, exist_ok=True)
        n_img = 0
        for f in sorted(img_dir.iterdir()):          # iterdir through the link: the files are the originals
            if f.suffix.lower() not in IMAGE_EXT:
                continue
            target = dst_img / f.name
            try:
                os.link(f.resolve(), target)
            except OSError as e:
                raise ViewError(f"cannot hard-link {f} ({e.strerror}) — the view must be on the same disk as the images")
            lf = lab_dir / (f.stem + ".txt")
            if lf.exists():
                shutil.copyfile(lf, dst_lab / lf.name)
            else:
                (dst_lab / lf.name).write_text("")   # an image with no label file is a negative, as in the remap
            n_img += 1
        splits[str(rel.parent)] = n_img
    return splits


def read_like_ultralytics(view: Path) -> Counter:
    """Image path -> label path the way ultralytics derives it (img2label_paths), on the view's real paths."""
    from ultralytics.data.utils import img2label_paths
    imgs = [str(p) for p in view.rglob("*") if p.suffix.lower() in IMAGE_EXT and "/images/" in str(p)]
    c = Counter()
    for lp in img2label_paths(imgs):
        for line in Path(lp).read_text().splitlines():
            if line.strip():
                c[int(line.split()[0])] += 1
    return c


def build(roots: list[Path], out: Path) -> dict:
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise ViewError(f"{out} exists and is not empty")
    report = {}
    for r in roots:
        r = Path(r)
        splits = build_one(r, out / r.name)
        got, want = read_like_ultralytics(out / r.name), expected_counts(r)
        bad = [i for i in set(got) if not 0 <= i < len(LOCKED6)]
        if bad:
            raise ViewError(f"{r.name}: class ids {sorted(bad)} are outside the locked 6")
        if got != want:
            raise ViewError(f"{r.name}: the view holds {dict(got)} but the remap kept {dict(want)}")
        report[r.name] = {"images": splits, "instances": {LOCKED6[i]: n for i, n in sorted(got.items())}}
    return report


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("roots", nargs="+")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    try:
        print(json.dumps(build([Path(r) for r in a.roots], Path(a.out)), indent=2))
    except ViewError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
