#!/usr/bin/env python3
"""Open a downloaded dataset BEFORE training on it (added 2026-10-01).

Filenames lie. The five traps this project already hit, each of which this tool flags:
  the "poop" set was veterinary chicken disease   -> UNMAPPED CLASSES
  the "hair" set had no label directories         -> NO LABEL FILES
  the "spill" set had boilerplate class names     -> SUSPECT CLASS NAMES
  the "wire" set was "Red wire" only              -> SINGLE CLASS (+ unmapped)
  the "paper" set was waste-sorting, paper 1-of-6 -> TARGET CLASS IS A MINORITY

It also records provenance: a dataset is NOT READY until DATASET_MANIFEST.json carries the source URL,
licence, retrieval date, viewpoint (top_down / eye_level / mixed) and benchmark_only. Open annotations
don't make images shippable, so the licence is a required field, not a note.

  python3 inspect_dataset.py ROOT [ROOT ...] [--out report.md]

Exit code 1 if any dataset is NOT READY, so a pipeline can't train on an unopened set.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import yaml

from relabel_locked6 import LOCKED6, MERGE, NEVER_LABELS   # one source of truth for the mapping

IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
REQUIRED_MANIFEST = ("source_url", "licence", "retrieval_date", "viewpoint", "benchmark_only")
VIEWPOINTS = ("top_down", "eye_level", "mixed")
SUSPECT_NAME = re.compile(
    r"^(class(es)?|object(s)?|label(s)?|item|thing|none|null|n/?a|new|test|sample|train|valid|"
    r"dataset|project|roboflow|untitled|unnamed|your[-_ ]?class|\d+|[a-z])$", re.I)
MINORITY_SHARE = 0.25
BLOCKING = ("NO data.yaml", "NO LABEL FILES", "BAD LABEL LINES", "MANIFEST INCOMPLETE", "NOTHING MAPS")


def line_kind(ntok: int) -> str:
    if ntok == 5:
        return "bbox"
    if ntok == 9:
        return "obb_or_4pt_polygon"      # YOLO-OBB and a 4-point polygon are the same 9 tokens
    if ntok >= 7 and ntok % 2 == 1:
        return "polygon"
    return "unknown"


def read_manifest(root: Path) -> tuple[dict, list[str]]:
    path = root / "DATASET_MANIFEST.json"
    if not path.exists():
        template = {k: None for k in REQUIRED_MANIFEST}
        template["benchmark_only"] = True
        path.write_text(json.dumps(template, indent=2) + "\n")
        return template, list(REQUIRED_MANIFEST)
    man = json.loads(path.read_text())
    missing = [k for k in REQUIRED_MANIFEST if man.get(k) in (None, "")]
    if man.get("viewpoint") not in (None, "") and man["viewpoint"] not in VIEWPOINTS:
        missing.append(f"viewpoint must be one of {VIEWPOINTS}")
    return man, missing


def inspect(root: Path) -> dict:
    root = Path(root)
    flags: list[str] = []
    cfg_path = root / "data.yaml"
    names: list[str] = []
    if not cfg_path.exists():
        flags.append("NO data.yaml")
        cfg = {}
    else:
        cfg = yaml.safe_load(cfg_path.read_text()) or {}
        raw = cfg.get("names")
        if isinstance(raw, dict):
            raw = [raw[k] for k in sorted(raw, key=int)]
        names = [str(n) for n in (raw or [])]
        if not names:
            flags.append("NO data.yaml")   # a config without names is unusable all the same

    # sources/ holds the original class name per kept line (written by relabel_locked6); counting it
    # as labels doubles every instance total
    label_files = [p for p in root.rglob("*.txt") if "labels" in p.relative_to(root).parts
                   and "sources" not in p.relative_to(root).parts]
    obb_dirs = [p for p in root.rglob("labelTxt") if p.is_dir()]
    if obb_dirs and not label_files:
        flags.append("OBB LAYOUT (labelTxt/): rotated boxes in pixels — convert with obb_to_seg.py before training")
        label_files = [p for d in obb_dirs for p in d.glob("*.txt")]
    # rglob does not descend into symlinked directories, and converted datasets link their images
    image_dirs = [p for p in root.rglob("images") if p.is_dir()
                  and "images" not in p.relative_to(root).parts[:-1]]
    images = [p for d in image_dirs for p in d.rglob("*") if p.suffix.lower() in IMAGE_EXT]
    per_class: dict[str, int] = defaultdict(int)
    kinds, bad, empty = set(), [], 0
    for lf in label_files:
        lines = [ln for ln in lf.read_text().splitlines() if ln.strip()]
        if not lines:
            empty += 1
        for i, ln in enumerate(lines, 1):
            tok = ln.split()
            where = f"{lf.relative_to(root)}:{i}"
            if obb_dirs:
                # DOTA / yolov5-obb: x1 y1 … x4 y4 CLASS-NAME difficulty — the class is a name, not an index
                if len(tok) < 9 or tok[8] not in names:
                    bad.append(where)
                    continue
                cid, kind = names.index(tok[8]), "obb(dota, pixels)"
            else:
                try:
                    cid = int(tok[0])
                except (ValueError, IndexError):
                    bad.append(where)
                    continue
                kind = line_kind(len(tok))
            if not 0 <= cid < len(names):
                bad.append(f"{where} (class id {cid})")
                continue
            kinds.add(kind)
            per_class[names[cid]] += 1

    if images and not label_files:
        flags.append(f"NO LABEL FILES: {len(images)} images, 0 labels")
    if label_files and images and abs(len(label_files) - len(images)) > 0.1 * len(images):
        flags.append(f"LABEL/IMAGE MISMATCH: {len(label_files)} labels vs {len(images)} images")
    if bad:
        flags.append(f"BAD LABEL LINES: {len(bad)} (e.g. {bad[0]})")

    suspect = [n for n in names if SUSPECT_NAME.match(n.strip())]
    if suspect:
        flags.append(f"SUSPECT CLASS NAMES: {suspect} — placeholder names, open the images before trusting them")
    if len(names) == 1:
        flags.append(f"SINGLE CLASS ({names[0]!r}) — confirm it covers the class you need, not one variant of it")

    mapped, unmapped = {}, []
    for n in names:
        low = n.strip().lower()
        if low in LOCKED6:
            mapped[n] = low
        elif low in MERGE:
            mapped[n] = MERGE[low]
        elif low in NEVER_LABELS:
            mapped[n] = "(rejection — never a label)"
        else:
            unmapped.append(n)
    if unmapped:
        flags.append(f"UNMAPPED CLASSES (dropped by the remap): {unmapped}")
    if names and not mapped:
        flags.append("NOTHING MAPS: no class in this set reaches the locked 6")

    total = sum(per_class.values())
    minority = [f"{n} {per_class[n] / total:.0%}" for n in mapped
                if total and len(names) >= 3 and per_class[n] / total < MINORITY_SHARE]
    if minority:
        flags.append(f"TARGET CLASS IS A MINORITY: {minority} of instances")
    if kinds == {"bbox"}:
        flags.append("BOXES ONLY — length needs masks; this set can't train a segmenter")
    if "obb_or_4pt_polygon" in kinds:
        flags.append("OBB OR 4-POINT POLYGON — convert to YOLO-seg before training")
    if len([k for k in kinds if k != "unknown"]) > 1:
        flags.append(f"MIXED LABEL FORMATS: {sorted(kinds)}")

    man, missing = read_manifest(root)
    if missing:
        flags.append(f"MANIFEST INCOMPLETE: {missing} — a dataset isn't opened until provenance is recorded")

    ready = not any(f.startswith(b) for f in flags for b in BLOCKING)
    return {"root": str(root), "name": root.name, "classes": names, "mapped": mapped,
            "unmapped": unmapped, "instances": dict(per_class), "images": len(images),
            "label_files": len(label_files), "empty_labels": empty, "formats": sorted(kinds),
            "manifest": man, "flags": flags, "ready": ready}


def render(reports: list[dict]) -> str:
    out = ["| dataset | classes | instances | images | format | viewpoint | licence | verdict |",
           "|---|---|---|---|---|---|---|---|"]
    for r in reports:
        out.append(f"| {r['name']} | {len(r['classes'])} | {sum(r['instances'].values())} | {r['images']} | "
                   f"{', '.join(r['formats']) or '—'} | {r['manifest'].get('viewpoint') or '—'} | "
                   f"{r['manifest'].get('licence') or '—'} | {'READY' if r['ready'] else '**NOT READY**'} |")
    for r in reports:
        out += ["", f"### {r['name']}", f"- classes: {r['classes']}",
                f"- maps to: { {k: v for k, v in r['mapped'].items()} or 'nothing' }",
                f"- instances per class: {r['instances'] or 'none counted'}",
                f"- label files {r['label_files']} ({r['empty_labels']} empty) · images {r['images']}"]
        out += [f"- ⚠ {f}" for f in r["flags"]] or ["- no flags"]
    out += ["", "A dataset is READY only when it has a data.yaml with names, label files that parse, at least one",
            "class that reaches the locked 6, and a complete DATASET_MANIFEST.json (source, licence, retrieval date,",
            "viewpoint, benchmark_only). Warnings don't block, but they are the traps that already cost this project time."]
    return "\n".join(out)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("roots", nargs="+")
    ap.add_argument("--out")
    args = ap.parse_args(argv)
    reports = [inspect(Path(r)) for r in args.roots]
    text = render(reports)
    print(text)
    if args.out:
        Path(args.out).write_text(text + "\n")
    not_ready = [r["name"] for r in reports if not r["ready"]]
    if not_ready:
        print(f"\nNOT READY: {not_ready} — do not train on these yet", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
