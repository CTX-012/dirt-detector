"""Tests for score_real.py — the pre-registered hit and false-safe rules, on a synthetic real val."""
import json

import numpy as np
import pytest
import yaml
from PIL import Image

import score_real as sr

SQ = "{c} 0.1 0.1 0.4 0.1 0.4 0.4 0.1 0.4"            # a 30x30 square at (10,10) in a 100x100 image


def val_set(root, names, lines):
    (root / "images").mkdir(parents=True)
    (root / "labels").mkdir(parents=True)
    Image.new("RGB", (100, 100)).save(root / "images/f0.jpg")
    (root / "labels/f0.txt").write_text("\n".join(lines) + "\n")
    (root / "data.yaml").write_text(yaml.safe_dump({"names": names}))
    return root


def square(x0=10, y0=10, s=30):
    m = np.zeros((100, 100), bool)
    m[y0:y0 + s, x0:x0 + s] = True
    return m


def fake(preds_by_arm):
    return lambda weights, img, h, w: preds_by_arm[weights]


def test_hit_needs_iou_03_and_conf_025(tmp_path):
    root = val_set(tmp_path / "v", ["dirt"], [SQ.format(c=0)])
    arms = {"a": "good", "b": "lowconf", "c": "offset"}
    preds = {"good": [{"mask": square(), "cls": "loose_debris", "conf": 0.9}],
             "lowconf": [{"mask": square(), "cls": "loose_debris", "conf": 0.2}],
             "offset": [{"mask": square(x0=28), "cls": "loose_debris", "conf": 0.9}]}   # IoU ~0.18
    s = sr.score(root, arms, tmp_path / "o", predictor=fake(preds))
    pc = s["per_class"]["dirt"]
    assert (pc["a"]["k"], pc["b"]["k"], pc["c"]["k"]) == (1, 0, 0)


def test_an_avoid_object_called_clean_is_a_false_safe(tmp_path):
    root = val_set(tmp_path / "v", ["cable"], [SQ.format(c=0)])
    preds = {"x": [{"mask": square(), "cls": "loose_debris", "conf": 0.9}],
             "y": [{"mask": square(), "cls": "cable_cord", "conf": 0.9}]}
    s = sr.score(root, {"x": "x", "y": "y"}, tmp_path / "o", predictor=fake(preds))
    assert s["false_safe"] == {"x": 1, "y": 0} and s["avoid_instances"] == 1
    assert s["per_class"]["cable"]["x"]["k"] == 1          # still a hit: recall and false-safe are separate


def test_hair_keeps_its_own_row_and_rows_feed_paired_compare(tmp_path):
    root = val_set(tmp_path / "v", ["dirt", "hair"], [SQ.format(c=0), SQ.format(c=1).replace("0.1 ", "0.6 ", 1)])
    preds = {"p": []}
    s = sr.score(root, {"p": "p"}, tmp_path / "o", predictor=fake(preds))
    assert set(s["per_class"]) == {"dirt", "hair"} and s["per_class"]["hair"]["p"]["measurement"] is False
    rows = [json.loads(l) for l in (tmp_path / "o/results.jsonl").read_text().splitlines()]
    assert {r["locked"] for r in rows} == {"loose_debris"} and all(r["p"] == 0 for r in rows)


def test_an_unmapped_real_class_stops_the_run(tmp_path):
    root = val_set(tmp_path / "v", ["dirt", "glass"], [SQ.format(c=1)])
    with pytest.raises(sr.ScoreError, match="map to nothing"):
        sr.score(root, {"p": "p"}, tmp_path / "o", predictor=fake({"p": []}))


def test_box_labels_are_refused(tmp_path):
    root = val_set(tmp_path / "v", ["dirt"], ["0 0.5 0.5 0.2 0.2"])
    with pytest.raises(sr.ScoreError, match="masks, not boxes"):
        sr.score(root, {"p": "p"}, tmp_path / "o", predictor=fake({"p": []}))
