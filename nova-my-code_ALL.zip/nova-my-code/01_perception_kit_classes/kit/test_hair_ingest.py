"""Tests for hair_ingest.py — human masks become YOLO-seg only if they obey the labelling rules."""
import json
import zipfile

import pytest

import hair_ingest as hi
import hair_split as hs
from test_hair_split import jpg

TRI = [[10, 10], [50, 12], [30, 40]]


@pytest.fixture
def ws(tmp_path):
    z = tmp_path / "h.zip"
    with zipfile.ZipFile(z, "w") as zf:
        for i in range(1, 21):
            zf.writestr(f"train/empty/output{i}_jpg.rf.{i:032x}.jpg", jpg(i))
    hs.build(z, tmp_path / "ws")
    return tmp_path / "ws"


def label_all(ws, shapes=lambda name: [{"label": "hair", "shape_type": "polygon", "points": TRI}]):
    for img in (ws / "images").rglob("*.jpg"):
        img.with_suffix(".json").write_text(json.dumps(
            {"imageWidth": 64, "imageHeight": 64, "shapes": shapes(img.name)}))


def test_a_fully_labelled_workspace_ingests_and_guard_is_left_out(ws, tmp_path):
    label_all(ws, lambda n: [] if n == "output2.jpg" else
              [{"label": "hair", "shape_type": "polygon", "points": TRI}])
    s = hi.ingest(ws, tmp_path / "ds")
    m = json.loads((ws / "split_manifest.json").read_text())["totals"]
    assert s["images"] == {"train": m["label_pool"], "heldout": m["heldout"]}
    assert s["hair_instances"]["train"] == m["label_pool"] - 1          # output2 = looked, found none
    line = (tmp_path / "ds/labels/heldout/output20.txt").read_text().split()
    assert line[0] == "4" and len(line) == 7                               # loose_debris, 3 points
    assert not list((tmp_path / "ds/images").rglob("output16.jpg"))        # output16 is a guard frame


def test_a_missing_label_file_is_not_treated_as_no_hair(ws, tmp_path):
    label_all(ws)
    next((ws / "images/label_pool").glob("*.json")).unlink()
    with pytest.raises(hi.IngestError, match="no label file"):
        hi.ingest(ws, tmp_path / "ds")


@pytest.mark.parametrize("shape,msg", [
    ({"label": "shadow", "shape_type": "polygon", "points": TRI}, "never a label"),
    ({"label": "hair", "shape_type": "rectangle", "points": TRI[:2]}, "masks, not boxes"),
    ({"label": "hair", "shape_type": "polygon", "points": TRI[:2]}, "at least 3"),
    ({"label": "dirt", "shape_type": "polygon", "points": TRI}, "only label"),
])
def test_rule_breaking_shapes_are_refused(ws, tmp_path, shape, msg):
    label_all(ws, lambda n: [shape])
    with pytest.raises(hi.IngestError, match=msg):
        hi.ingest(ws, tmp_path / "ds")


def test_a_swapped_image_is_caught(ws, tmp_path):
    label_all(ws)
    (ws / "images/heldout/output20.jpg").write_bytes(jpg(555))
    with pytest.raises(hi.IngestError, match="sha256"):
        hi.ingest(ws, tmp_path / "ds")
