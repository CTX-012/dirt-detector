#!/usr/bin/env python3
"""Remap a YOLO dataset to the locked 6 classes, into a NEW root, never in place.

Policy (set 2026-10-01):
  - Keep only the locked 6. **Every other class is DROPPED and reported** — no prompting, no guessing.
  - **Drop class LABELS, never images.** An image that held an unwanted class keeps its wanted labels,
    and the unwanted ones simply become background. An image whose every label was dropped stays as a
    negative (an empty label file), which is what makes the false-positive rate measurable.
  - **A dataset where zero classes map is refused** — there is nothing in it to train on.

Every kept instance's original class is written to a parallel `sources/` file, line for line, so
per-sub-class counts (hair vs dirt, cable vs wire) stay computable after the merge. That matters: on
E46's numbers, merging hair into loose_debris flips the r1-vs-cutout comparison unless the sub-class
survives.

The one refusal left is laundering: an `--alias` that would turn a rejection (shadow, glare,
clear_water, filament) into a trained label.

  python3 relabel_locked6.py SRC_ROOT DST_ROOT [--alias "red wire=wire"] [--drop paper]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import yaml

LOCKED6 = ["pet_waste", "cable_cord", "soft_object", "spill_coloured", "loose_debris", "paper_flat"]
MERGE = {
    "poop": "pet_waste",
    "cable": "cable_cord", "wire": "cable_cord",
    "sock": "soft_object", "textile": "soft_object",
    "spill": "spill_coloured",
    "dirt": "loose_debris", "hair": "loose_debris",
    "paper": "paper_flat",
}
NEVER_LABELS = {
    "shadow": "a physics rejection that runs first — never a label",
    "glare": "a physics rejection that runs first — never a label",
    "clear_water": "a physics wall (0.4% recall) — not trained",
    "filament": "a no-claim classical output — never a training label",
}
SPLITS = ("train", "val", "valid", "test")
IMAGE_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


class RelabelError(Exception):
    pass


def read_names(data_yaml: Path) -> list[str]:
    cfg = yaml.safe_load(data_yaml.read_text()) or {}
    names = cfg.get("names")
    if isinstance(names, dict):
        names = [names[k] for k in sorted(names, key=int)]
    if not isinstance(names, list) or not names:
        raise RelabelError(f"{data_yaml}: no 'names' list")
    return [str(n) for n in names]


def build_map(names: list[str], drops=(), aliases=None) -> tuple[dict[int, str | None], dict[str, str]]:
    """index -> locked-6 name, or None to drop that class's LABELS. Also why each one was dropped."""
    drops = {d.strip().lower() for d in drops}
    aliases = {k.strip().lower(): v.strip().lower() for k, v in (aliases or {}).items()}
    mapping: dict[int, str | None] = {}
    reasons: dict[str, str] = {}
    for i, raw in enumerate(names):
        low = raw.strip().lower()
        if low in NEVER_LABELS:          # checked on the RAW name, so an alias cannot launder it
            if low in aliases:
                raise RelabelError(f"refusing --alias {low}={aliases[low]}: '{raw}' is {NEVER_LABELS[low]}")
            mapping[i], reasons[raw] = None, NEVER_LABELS[low]
            continue
        if low in drops:
            mapping[i], reasons[raw] = None, "dropped on request"
            continue
        name = aliases.get(low, low)
        if name in LOCKED6:
            mapping[i] = name
        elif name in MERGE:
            mapping[i] = MERGE[name]
        else:
            mapping[i], reasons[raw] = None, "does not map to the locked 6"
    return mapping, reasons


def _split_of(rel: Path) -> str:
    return next((p for p in rel.parts if p in SPLITS), "all")


def remap(src: Path, dst: Path, drops=(), aliases=None) -> dict:
    src, dst = Path(src).resolve(), Path(dst).resolve()
    if dst == src or src in dst.parents:
        raise RelabelError("DST must not be the source or sit inside it")
    if dst.exists() and any(dst.iterdir()):
        raise RelabelError(f"{dst} exists and is not empty — refusing to overwrite")
    data_yaml = src / "data.yaml"
    if not data_yaml.exists():
        raise RelabelError(f"{data_yaml} not found")

    names = read_names(data_yaml)
    mapping, drop_reasons = build_map(names, drops, aliases)
    kept = {raw: mapping[i] for i, raw in enumerate(names) if mapping[i]}
    if not kept:
        raise RelabelError(f"dataset dropped: no class maps to the locked 6 — found {names}")

    dst.mkdir(parents=True, exist_ok=True)
    counts = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))   # split -> new -> orig -> n
    dropped = defaultdict(lambda: defaultdict(int))                       # split -> orig -> n
    n_files = n_negatives = lines_before = lines_after = 0

    label_files = sorted(p for p in src.rglob("*.txt") if "labels" in p.relative_to(src).parts)
    for lf in label_files:
        rel = lf.relative_to(src)
        split = _split_of(rel)
        out_lines, src_lines = [], []
        for ln, line in enumerate(lf.read_text().splitlines(), 1):
            tok = line.split()
            if not tok:
                continue
            lines_before += 1
            try:
                cid = int(tok[0])
            except ValueError:
                raise RelabelError(f"{rel}:{ln}: class id '{tok[0]}' is not an integer")
            if not 0 <= cid < len(names):
                raise RelabelError(f"{rel}:{ln}: class id {cid} is outside names (0..{len(names) - 1})")
            orig, new = names[cid], mapping[cid]
            if new is None:
                dropped[split][orig] += 1
                continue
            out_lines.append(" ".join([str(LOCKED6.index(new))] + tok[1:]))
            src_lines.append(orig)
            counts[split][new][orig] += 1
        lines_after += len(out_lines)
        for base, lines in ((dst / rel, out_lines), (dst / "sources" / rel, src_lines)):
            base.parent.mkdir(parents=True, exist_ok=True)
            base.write_text("\n".join(lines) + ("\n" if lines else ""))
        n_files += 1
        n_negatives += not out_lines

    image_dirs = [p for p in src.rglob("images") if p.is_dir()
                  and "images" not in p.relative_to(src).parts[:-1]]
    # count inside each image dir: rglob does not descend into symlinked directories, and a converted
    # dataset links its images rather than copying them
    images = [p for d in image_dirs for p in d.rglob("*") if p.suffix.lower() in IMAGE_EXT]
    for d in image_dirs:
        link = dst / d.relative_to(src)
        link.parent.mkdir(parents=True, exist_ok=True)
        os.symlink(d, link, target_is_directory=True)
        if not link.is_dir():
            raise RelabelError(f"image link {link} does not resolve — images must never be dropped")

    manifest = src / "DATASET_MANIFEST.json"
    if manifest.exists():          # provenance travels with the data that actually gets trained
        (dst / "DATASET_MANIFEST.json").write_text(manifest.read_text())

    cfg = yaml.safe_load(data_yaml.read_text()) or {}
    cfg["names"] = list(LOCKED6)
    cfg["nc"] = len(LOCKED6)
    if "path" in cfg:
        cfg["path"] = str(dst)
    (dst / "data.yaml").write_text(yaml.safe_dump(cfg, sort_keys=False))

    summary = {
        "source": str(src), "destination": str(dst),
        "classes_found": names, "classes_kept": kept, "classes_dropped": drop_reasons,
        "images_before": len(images), "images_after": len(images),   # images are symlinked, never dropped
        "label_lines_before": lines_before, "label_lines_after": lines_after,
        "label_files": n_files, "negative_files_kept": n_negatives,
        "locked6": LOCKED6, "merge": MERGE, "aliases": dict(aliases or {}),
        "counts": {s: {c: dict(o) for c, o in v.items()} for s, v in counts.items()},
        "dropped": {s: dict(v) for s, v in dropped.items()},
    }
    (dst / "relabel_manifest.json").write_text(json.dumps(summary, indent=2) + "\n")
    (dst / "counts.md").write_text(render_counts(summary) + "\n")
    return summary


def render_counts(summary: dict) -> str:
    splits = sorted(set(summary["counts"]) | set(summary["dropped"]))
    kept_txt = ", ".join(f"{k} → {v}" for k, v in summary["classes_kept"].items()) or "none"
    drop_txt = ", ".join(f"{k} ({why})" for k, why in summary["classes_dropped"].items()) or "none"
    lines = [
        f"## {Path(summary['source']).name} → {Path(summary['destination']).name}", "",
        "| item | value |", "|---|---|",
        f"| classes found | {len(summary['classes_found'])}: {', '.join(summary['classes_found'])} |",
        f"| classes kept | {kept_txt} |",
        f"| classes dropped | {drop_txt} |",
        f"| images before → after | {summary['images_before']} → {summary['images_after']} "
        f"(images are never dropped) |",
        f"| label lines before → after | {summary['label_lines_before']} → {summary['label_lines_after']} "
        f"({summary['label_lines_before'] - summary['label_lines_after']} dropped) |",
        f"| label files | {summary['label_files']} ({summary['negative_files_kept']} now negatives) |",
        "",
        "| locked class | " + " | ".join(splits) + " | total | from |",
        "|---|" + "---|" * (len(splits) + 2),
    ]
    zero = []
    for c in LOCKED6:
        per = [sum(summary["counts"].get(s, {}).get(c, {}).values()) for s in splits]
        origins = defaultdict(int)
        for s in splits:
            for o, n in summary["counts"].get(s, {}).get(c, {}).items():
                origins[o] += n
        if sum(per) == 0:
            zero.append(c)
        lines.append(f"| {c} | " + " | ".join(map(str, per)) + f" | {sum(per)} | "
                     + (" + ".join(f"{o} {n}" for o, n in sorted(origins.items())) or "—") + " |")
    drop_tot = defaultdict(int)
    for s in splits:
        for o, n in summary["dropped"].get(s, {}).items():
            drop_tot[o] += n
    lines += ["", "Dropped label lines by original class: "
              + (", ".join(f"{o} {n}" for o, n in sorted(drop_tot.items())) or "none")]
    if zero:
        lines.append("Zero instances — nothing can be measured for: " + ", ".join(zero))
    lines.append("Per-sub-class counts stay computable from sources/ (e.g. hair vs dirt inside loose_debris).")
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("src")
    ap.add_argument("dst")
    ap.add_argument("--drop", action="append", default=[], help="also drop this class, by name")
    ap.add_argument("--alias", action="append", default=[], help='OLD=NEW, e.g. "red wire=wire"')
    args = ap.parse_args(argv)
    try:
        aliases = dict(a.split("=", 1) for a in args.alias)
        summary = remap(Path(args.src), Path(args.dst), args.drop, aliases)
    except (RelabelError, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    print(render_counts(summary))
    return 0


if __name__ == "__main__":
    sys.exit(main())
