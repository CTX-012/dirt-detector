#!/usr/bin/env python3
"""Build the hair mask-labelling workspace with the held-out split fixed BEFORE anything is labelled (2026-10-07).

What the "400 hair images" actually are (measured, not assumed):
  - 400 files but only 235 distinct source frames: Roboflow exported 165 frames twice (pixel diff ~0.5/255),
    and 79 of those duplicate pairs straddle its own train/valid/test split — its split leaks.
  - three sources, each close to one scene:  VID_010 (one video, ~2 physical hairs, 161 frames),
    output* (hairs on a ribbed white tray, 50 frames), *_lmc_* (24 phone photos on varied real floors).

So a random 20% would hold out near-copies of training frames. Instead, per source, the held-out set is
one CONTIGUOUS block at the end of the sequence, with a guard band of neighbours just before it that
belongs to neither side (labelled last, never trained on, never scored).

  python3 -I hair_split.py HAIR_ZIP OUT_DIR

Writes OUT_DIR/images/{label_pool,heldout,guard}/, split_manifest.json (sha256 per image) and prints the
manifest's sha256 so it can be pinned in STATUS.md before labelling starts.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import sys
import zipfile
from collections import defaultdict
from pathlib import Path

import numpy as np
from PIL import Image

HELDOUT_SHARE = 0.20
GUARD = {"VID_010": 6, "output": 3, "lmc": 2}     # neighbours dropped between the pool and the held-out block
DUP_MAX_DIFF = 2.0                                # mean abs diff (0-255, 16x16 gray) for "same frame"


def source_key(member: str) -> str:
    return re.sub(r"_jpg\.rf\..*$", "", member.rsplit("/", 1)[-1])


def group_and_order(key: str) -> tuple[str, tuple]:
    if key.startswith("VID_010"):
        return "VID_010", (int(key.split("-")[-1]),)
    m = re.fullmatch(r"output(\d+)", key)
    if m:
        return "output", (int(m.group(1)),)
    if "_lmc_" in key:
        return "lmc", (key,)                      # YYYYMMDD_HHMMSS prefix sorts by capture time
    raise ValueError(f"unknown hair source '{key}' — add it to group_and_order before splitting")


def thumb(data: bytes) -> np.ndarray:
    return np.asarray(Image.open(io.BytesIO(data)).convert("L").resize((16, 16)), float)


def plan(keys_by_group: dict[str, list[str]], share=HELDOUT_SHARE, guard=GUARD) -> dict[str, str]:
    """key -> 'label_pool' | 'heldout' | 'guard'. Held-out total is round(share * all keys)."""
    total = sum(len(v) for v in keys_by_group.values())
    want = round(share * total)
    groups = sorted(keys_by_group)
    # held-out per group proportional to its size (largest remainder), at least 1 per group
    raw = {g: share * len(keys_by_group[g]) for g in groups}
    n = {g: max(1, int(raw[g])) for g in groups}
    for g in sorted(groups, key=lambda g: raw[g] - int(raw[g]), reverse=True):
        if sum(n.values()) >= want:
            break
        n[g] += 1
    out = {}
    for g in groups:
        ordered = sorted(keys_by_group[g], key=lambda k: group_and_order(k)[1])
        k_hold, k_guard = n[g], guard.get(g, 0)
        if k_hold + k_guard >= len(ordered):
            raise ValueError(f"group {g}: {len(ordered)} frames can't hold {k_hold} out with a {k_guard} guard")
        cut = len(ordered) - k_hold
        for i, k in enumerate(ordered):
            out[k] = "heldout" if i >= cut else "guard" if i >= cut - k_guard else "label_pool"
    return out


def build(zip_path: Path, out: Path) -> dict:
    if out.exists() and any(out.iterdir()):
        raise SystemExit(f"{out} exists and is not empty — the split is fixed once; refusing to rebuild over it")
    z = zipfile.ZipFile(zip_path)
    members = sorted(n for n in z.namelist() if n.lower().endswith((".jpg", ".jpeg", ".png")))
    by_key = defaultdict(list)
    for n in members:
        by_key[source_key(n)].append(n)
    for k, ms in by_key.items():                  # a "duplicate" must really be the same frame
        if len(ms) > 1:
            t0 = thumb(z.read(ms[0]))
            for m in ms[1:]:
                d = float(np.abs(thumb(z.read(m)) - t0).mean())
                if d > DUP_MAX_DIFF:
                    raise SystemExit(f"{k}: copies differ (diff {d:.1f}) — not a duplicate, inspect by hand")
    groups = defaultdict(list)
    for k in by_key:
        groups[group_and_order(k)[0]].append(k)
    assign = plan(groups)

    rows = []
    for k in sorted(by_key):
        data = z.read(by_key[k][0])
        dst = out / "images" / assign[k] / f"{k}.jpg"
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(data)
        rows.append({"file": str(dst.relative_to(out)), "source_key": k, "group": group_and_order(k)[0],
                     "split": assign[k], "copies_in_zip": len(by_key[k]),
                     "sha256": hashlib.sha256(data).hexdigest()})
    summary = {
        "zip": zip_path.name, "zip_files": len(members), "distinct_frames": len(by_key),
        "duplicates_collapsed": len(members) - len(by_key), "heldout_share": HELDOUT_SHARE, "guard": GUARD,
        "per_group": {g: {s: sum(1 for r in rows if r["group"] == g and r["split"] == s)
                          for s in ("label_pool", "guard", "heldout")} for g in sorted(groups)},
        "totals": {s: sum(1 for r in rows if r["split"] == s) for s in ("label_pool", "guard", "heldout")},
        "images": rows,
    }
    text = json.dumps(summary, indent=2) + "\n"
    (out / "split_manifest.json").write_text(text)
    summary["manifest_sha256"] = hashlib.sha256(text.encode()).hexdigest()
    return summary


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("zip")
    ap.add_argument("out")
    a = ap.parse_args(argv)
    s = build(Path(a.zip), Path(a.out))
    print(json.dumps({k: v for k, v in s.items() if k != "images"}, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
