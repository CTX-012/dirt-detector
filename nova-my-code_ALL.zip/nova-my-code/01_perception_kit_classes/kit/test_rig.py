"""Tests for rig_session_check.py — synthetic session folders built with Pillow."""
import json
from pathlib import Path

from PIL import Image

import cal_ingest as ci
import rig_session_check as rc

GOOD_SHEET = {
    "camera_id": "rig-cam-01", "height_mm": 140, "height_tol_mm": 5,
    "pitch_readings_deg": [12.8, 13.2], "pitch_deg": 13.0, "pitch_tol_deg": 0.5,
    "pitch_reference": "from_nadir", "clinometer_face": "top face",
    "known_part": {"name": "brush", "size_mm": 62}, "measured_by": "F", "date": "2026-09-19",
}


def make_session(d: Path, size=(1664, 936), skip=None, **sheet_over):
    d.mkdir(parents=True, exist_ok=True)
    names = [f"ruler_d{r}_{o}_{k}.jpg" for (r, o, k) in sorted(rc.REQUIRED)] + ["part_brush_62mm.jpg"]
    for n in names:
        if n != skip:
            Image.new("RGB", size, (128, 128, 128)).save(d / n, quality=90)
    (d / "rig_sheet.json").write_text(json.dumps({**GOOD_SHEET, **sheet_over}))
    return d


def problems_of(d):
    return rc.check(d)[0]


def test_the_grid_is_twenty_frames():
    assert len(rc.REQUIRED) == 20


def test_complete_session_passes_and_the_draft_stays_uncal(tmp_path):
    d = make_session(tmp_path / "s")
    problems, draft = rc.check(d)
    assert problems == []
    state = ci.derive(ci.validate(draft))
    assert state.flag == ci.UNCAL and any("f_px" in r for r in state.reasons)
    assert rc.main([str(d)]) == 0 and (d / "cal2.draft.json").exists()


def test_a_missing_frame_is_named(tmp_path):
    p = problems_of(make_session(tmp_path / "s", skip="ruler_d0.26_across_2.jpg"))
    assert any("ruler_d0.26_across_2.jpg" in x for x in p)


def test_mixed_resolution_fails(tmp_path):
    d = make_session(tmp_path / "s")
    Image.new("RGB", (1920, 1080)).save(d / "ruler_d0.10_along_1.jpg")
    assert any("mixed resolutions" in x for x in problems_of(d))


def test_messenger_sized_frames_fail(tmp_path):
    p = problems_of(make_session(tmp_path / "s", size=(960, 540)))
    assert any("messenger" in x for x in p)


def test_incomplete_sheet_fails(tmp_path):
    p = problems_of(make_session(tmp_path / "s", clinometer_face=None))
    assert any("clinometer_face" in x for x in p)


def test_part_size_must_match_a_part_frame(tmp_path):
    p = problems_of(make_session(tmp_path / "s", known_part={"name": "brush", "size_mm": 70}))
    assert any("matches no part frame" in x for x in p)


def test_pitch_must_be_the_mean_of_the_reversal_readings(tmp_path):
    p = problems_of(make_session(tmp_path / "s", pitch_deg=14.0))
    assert any("not the mean" in x for x in p)


def test_reversal_readings_too_far_apart(tmp_path):
    p = problems_of(make_session(tmp_path / "s", pitch_readings_deg=[12.0, 14.0], pitch_deg=13.0))
    assert any("re-seat" in x for x in p)


def test_a_misnamed_ruler_frame_is_reported(tmp_path):
    d = make_session(tmp_path / "s")
    Image.new("RGB", (1664, 936)).save(d / "ruler_13cm.jpg")
    assert any("ruler_13cm.jpg" in x for x in problems_of(d))


def test_cli_fails_loudly(tmp_path, capsys):
    d = make_session(tmp_path / "s", skip="part_brush_62mm.jpg")
    assert rc.main([str(d)]) == 1
    assert "FAIL" in capsys.readouterr().out
