#!/usr/bin/env python3
"""Migrate cleaning_policy.yaml to the locked 6 — a config edit, not a retrain.

Each locked class inherits its row from the old class(es) it merges. The old rows are
KEPT as transition rows: the deployed r1 and the classical channels still emit the old
names (dirt, hair, spill, ...), and a table that only knows the locked names would send
every one of them to the unknown -> AVOID default — the robot would stop cleaning dirt.
Remove the transition rows only after every emitter outputs the locked names.

Refuses (exit 1) instead of guessing when:
  - two merged classes disagree on a phase (unless --prefer-conservative, which takes
    the most restrictive action per phase)
  - the result breaks a lock invariant: pet_waste below alert level; cable_cord /
    soft_object / paper_flat below AVOID; spill_coloured cleanable in the dry phase
    (never dry-vac liquid); unknown / filament / clear_water below AVOID

shadow and glare are moved out of the class table into reject_first: rejections, never
output classes.

  python3 migrate_policy.py OLD.yaml NEW.yaml [--prefer-conservative]
"""
from __future__ import annotations

import argparse
import copy
import sys
from pathlib import Path

import yaml

INHERIT = {
    "pet_waste": ["poop", "biohazard"],
    "cable_cord": ["cable", "wire"],
    "soft_object": ["textile", "sock"],
    "spill_coloured": ["spill"],
    "loose_debris": ["dirt", "hair"],
    "paper_flat": ["paper"],
}
REJECT_FIRST = ["shadow", "glare"]
MUST_AVOID = ["unknown", "filament", "clear_water"]
KNOWN_OLD = {"hair", "dirt", "spill", "cable", "wire", "paper", "textile", "sock", "poop",
             "biohazard", "unknown", "shadow", "glare"}
RESTRICT = {"STOP_NOTIFY": 5, "ALERT_AVOID": 5, "ALERT": 5, "AVOID": 4,
            "MOP": 2, "CLEAN_MOP": 2, "SUCTION": 1, "CLEAN_SUCTION": 1, "IGNORE": 0}
AVOID_TOKEN = "AVOID"


class PolicyError(Exception):
    pass


def _find_table(obj, path=()):
    """Path to the dict holding the class -> action table (the one naming the most old classes)."""
    best = None
    if isinstance(obj, dict):
        hits = len(KNOWN_OLD & {str(k).lower() for k in obj})
        if hits >= 3:
            best = (hits, path)
        for k, v in obj.items():
            sub = _find_table(v, path + (k,))
            if sub and (best is None or sub[0] > best[0]):
                best = sub
    return best


def _rank(token: str, where: str) -> int:
    if token not in RESTRICT:
        raise PolicyError(f"{where}: unknown action '{token}' — add it to RESTRICT with its severity")
    return RESTRICT[token]


def _phases(table: dict) -> list[str]:
    ph = []
    for v in table.values():
        if isinstance(v, dict):
            ph += [p for p in v if p not in ph]
    return ph or ["*"]


def _row(value, phases):
    if isinstance(value, dict):
        return {p: value.get(p, value.get("*")) for p in phases}
    return {p: value for p in phases}


def migrate(old_doc: dict, prefer_conservative: bool = False) -> tuple[dict, list[str]]:
    doc = copy.deepcopy(old_doc)
    found = _find_table(doc)
    if not found:
        raise PolicyError("no class -> action table found (need a mapping naming at least 3 known classes)")
    path = found[1]
    parent = doc
    for k in path[:-1]:
        parent = parent[k]
    table = parent[path[-1]] if path else doc
    table_lc = {str(k).lower(): v for k, v in table.items()}
    phases = _phases(table_lc)
    string_style = all(not isinstance(v, dict) for v in table_lc.values())
    report, problems = [], []

    new_rows = {}
    for new, sources in INHERIT.items():
        present = [s for s in sources if s in table_lc]
        if new in table_lc:
            new_rows[new] = _row(table_lc[new], phases)
            report.append(f"{new}: already present, kept")
            continue
        if not present:
            problems.append(f"{new}: none of {sources} exists in the old table — add its row by hand")
            continue
        rows = [_row(table_lc[s], phases) for s in present]
        merged = {}
        for p in phases:
            acts = {r[p] for r in rows}
            if len(acts) == 1:
                merged[p] = acts.pop()
            elif prefer_conservative:
                merged[p] = max(acts, key=lambda a: _rank(a, f"{new}/{p}"))
                report.append(f"{new}/{p}: {sorted(acts)} disagree -> took the most restrictive, {merged[p]}")
            else:
                problems.append(f"{new}/{p}: {present} disagree ({sorted(acts)}) — decide by hand, "
                                f"or rerun with --prefer-conservative")
        new_rows[new] = merged
        report.append(f"{new} <- {' + '.join(present)}")

    for name in MUST_AVOID:
        if name not in table_lc:
            new_rows[name] = {p: AVOID_TOKEN for p in phases}
            report.append(f"{name}: added as AVOID (lock requirement)")

    moved = [n for n in REJECT_FIRST if n in table_lc]
    if problems:
        raise PolicyError("refusing to migrate:\n  " + "\n  ".join(problems))

    out_table = {}
    for k, v in table.items():
        if str(k).lower() not in REJECT_FIRST:
            out_table[k] = v                            # transition rows kept, untouched
    for name, row in new_rows.items():
        out_table[name] = row["*"] if string_style else row
    if path:
        parent[path[-1]] = out_table
        parent["reject_first"] = sorted(set(parent.get("reject_first", [])) | set(REJECT_FIRST))
        if moved:
            report.append(f"moved {moved} out of the class table into reject_first")
    else:  # the table IS the document: a reject_first key here would read as a class row
        doc = out_table
        report.append(f"class table is the document root, so reject_first was NOT added — the loader "
                      f"must reject {REJECT_FIRST} before routing"
                      + (f"; removed {moved} from the table" if moved else ""))

    check_invariants(out_table, phases)
    report.append("transition rows kept: remove the old names only after r1 and the classical "
                  "channels emit the locked names")
    return doc, report


def check_invariants(table: dict, phases: list[str]) -> None:
    t = {str(k).lower(): _row(v, phases) for k, v in table.items()}
    bad = []

    def need(name, min_rank, only=None, why=""):
        if name not in t:
            bad.append(f"{name}: missing")
            return
        for p in (only or phases):
            if p in t[name] and _rank(t[name][p], f"{name}/{p}") < min_rank:
                bad.append(f"{name}/{p} = {t[name][p]} — {why}")

    need("pet_waste", 5, why="must be alert level (catastrophic smear)")
    for c in ("cable_cord", "soft_object", "paper_flat"):
        need(c, 4, why="must be AVOID or stricter (jam / entangle / scatter)")
    need("spill_coloured", 4, only=[p for p in phases if p in ("dry", "*")],
         why="never dry-vac liquid: the dry phase must AVOID")
    for c in MUST_AVOID:
        need(c, 4, why="default-safe route")
    for c in REJECT_FIRST:
        if c in t:
            bad.append(f"{c}: still an output class — it must be a rejection")
    if bad:
        raise PolicyError("lock invariants broken:\n  " + "\n  ".join(bad))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("old")
    ap.add_argument("new")
    ap.add_argument("--prefer-conservative", action="store_true")
    args = ap.parse_args(argv)
    if Path(args.new).resolve() == Path(args.old).resolve():
        print("ERROR: write to a new file; the old policy is the rollback", file=sys.stderr)
        return 1
    try:
        doc, report = migrate(yaml.safe_load(Path(args.old).read_text()), args.prefer_conservative)
    except PolicyError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    Path(args.new).write_text(yaml.safe_dump(doc, sort_keys=False))
    print("\n".join(report))
    print(f"wrote {args.new}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
