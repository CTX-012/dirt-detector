"""Tests for g8_agreement.py — the selftests named in G8_DOUBLE_LABEL.md, on synthetic labels."""
import math

import pytest

import g8_agreement as g8

W, H = 200, 100
NAMES = ["hair", "dirt", "cable"]


def box(cls, cx, cy, bw=0.1, bh=0.2):
    return f"{cls} {cx} {cy} {bw} {bh}"


def strip(cls, y_px, x0=20, x1=180, width=3):
    """A horizontal 'hair' polygon, `width` px tall, top row at y_px."""
    y0, y1 = y_px, y_px + width - 1
    pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    return f"{cls} " + " ".join(f"{x / W:.6f} {y / H:.6f}" for x, y in pts)


def write(root, files):
    root.mkdir(parents=True, exist_ok=True)
    for name, lines in files.items():
        (root / name).write_text("\n".join(lines) + ("\n" if lines else ""))
    return root


def row(report, cls):
    return next(r for r in report["rows"] if r["class"] == cls)


def test_identical_labels_agree_perfectly(tmp_path):
    files = {"f1.txt": [box(1, 0.2, 0.3), box(1, 0.6, 0.6), strip(0, 50)], "f2.txt": [box(2, 0.5, 0.5)]}
    a, b = write(tmp_path / "a", files), write(tmp_path / "b", files)
    rep = g8.run(a, b, NAMES, size=(W, H))
    for cls in ("hair", "dirt", "cable"):
        assert row(rep, cls)["f1"] == pytest.approx(1.0)
        assert row(rep, cls)["verdict"].startswith("NOT A MEASUREMENT")      # n < 30


def test_one_deleted_instance_gives_the_known_f1(tmp_path):
    a = write(tmp_path / "a", {"f1.txt": [box(1, 0.2, 0.3), box(1, 0.6, 0.6)], "f2.txt": [box(1, 0.3, 0.3), box(1, 0.8, 0.5)]})
    b = write(tmp_path / "b", {"f1.txt": [box(1, 0.2, 0.3), box(1, 0.6, 0.6)], "f2.txt": [box(1, 0.3, 0.3)]})
    r = row(g8.run(a, b, NAMES, size=(W, H)), "dirt")
    assert (r["n_a"], r["n_b"], r["matched"]) == (4, 3, 3)
    assert r["f1"] == pytest.approx(6 / 7)


def test_a_2px_shift_on_a_hair_matches_under_the_thin_rule_but_not_iou(tmp_path):
    a = write(tmp_path / "a", {"f.txt": [strip(0, 50)]})
    b = write(tmp_path / "b", {"f.txt": [strip(0, 52)]})                   # same hair, marked 2 px lower
    thin = row(g8.run(a, b, NAMES, size=(W, H), thin_classes={"hair"}), "hair")
    blob = row(g8.run(a, b, NAMES, size=(W, H), thin_classes=set()), "hair")
    assert thin["f1"] == pytest.approx(1.0)
    assert blob["f1"] == pytest.approx(0.0)                                 # IoU 0.2 < 0.5


def test_two_different_hairs_do_not_match_under_the_thin_rule(tmp_path):
    a = write(tmp_path / "a", {"f.txt": [strip(0, 20)]})
    b = write(tmp_path / "b", {"f.txt": [strip(0, 70)]})
    assert row(g8.run(a, b, NAMES, size=(W, H)), "hair")["matched"] == 0


def test_kappa_on_a_known_presence_table():
    a = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0]
    b = [1, 1, 1, 1, 0, 1, 0, 0, 0, 0]
    assert g8.kappa([bool(x) for x in a], [bool(x) for x in b]) == pytest.approx(0.6)
    assert g8.kappa([True] * 5, [True] * 5) is None                      # no variation


def test_pass_and_fail_verdicts_need_n_of_30(tmp_path):
    same = {f"f{i:02d}.txt": [box(2, 0.5, 0.5)] for i in range(30)}
    a, b = write(tmp_path / "a", same), write(tmp_path / "b", same)
    assert row(g8.run(a, b, NAMES, size=(W, H)), "cable")["verdict"] == "PASS"
    moved = {f"f{i:02d}.txt": [box(2, 0.5 if i < 20 else 0.1, 0.5)] for i in range(30)}
    c = write(tmp_path / "c", moved)
    r = row(g8.run(a, c, NAMES, size=(W, H)), "cable")
    assert r["f1"] == pytest.approx(40 / 60) and r["verdict"] == "FAIL"
    lo, hi = r["a_found_by_b"][1:]
    assert lo < 20 / 30 < hi


def test_annotators_must_label_the_same_frames(tmp_path):
    a = write(tmp_path / "a", {"f1.txt": [box(1, 0.2, 0.3)], "f2.txt": []})
    b = write(tmp_path / "b", {"f1.txt": [box(1, 0.2, 0.3)]})
    with pytest.raises(g8.G8Error, match="different frames"):
        g8.run(a, b, NAMES, size=(W, H))


def test_bad_label_lines_fail_loudly(tmp_path):
    a = write(tmp_path / "a", {"f.txt": ["7 0.5 0.5 0.1 0.1"]})
    b = write(tmp_path / "b", {"f.txt": ["7 0.5 0.5 0.1 0.1"]})
    with pytest.raises(g8.G8Error, match="outside names"):
        g8.run(a, b, NAMES, size=(W, H))


def test_cli_writes_the_report(tmp_path):
    files = {"f.txt": [box(1, 0.2, 0.3)]}
    a, b = write(tmp_path / "a", files), write(tmp_path / "b", files)
    out = tmp_path / "out"
    assert g8.main([str(a), str(b), "--names", "hair,dirt,cable", "--size", f"{W}x{H}", "--out", str(out)]) == 0
    assert "NOT A MEASUREMENT" in (out / "agreement.md").read_text()
    assert not math.isnan(1.0)
