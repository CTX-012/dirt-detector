#!/usr/bin/env python3
"""Move the held files onto the HDD once it is mounted — one command, safe to re-run.

For every ~/faiz_work_pending/<date>/ folder:
  - copies its contents into faiz_work/perception_<date>/ — identical files are skipped; if a
    DIFFERENT file is already there, it is kept and ours is written beside it as <name>.from-pending
  - appends its STATUS_APPEND.md to faiz_work/STATUS.md, once per heading (re-runs don't duplicate)
Nothing is deleted. Remove ~/faiz_work_pending yourself after checking the result.

  python3 sync_pending_to_hdd.py [--pending DIR] [--hdd-root DIR] [--dry-run]
"""
from __future__ import annotations

import argparse
import filecmp
import re
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_PENDING = Path.home() / "faiz_work_pending"
DEVICE = "/dev/sda1"
SKIP = {"__pycache__", ".pytest_cache"}


class SyncError(Exception):
    pass


def find_hdd_root() -> Path:
    r = subprocess.run(["findmnt", "-no", "TARGET", DEVICE], capture_output=True, text=True)
    if r.returncode != 0 or not r.stdout.strip():
        raise SyncError(f"{DEVICE} is not mounted — run:  udisksctl mount -b {DEVICE}")
    return Path(r.stdout.strip()) / "faiz_work"


def _headings(text: str) -> list[str]:
    return [line.strip() for line in text.splitlines() if line.startswith("## ")]


def sync(pending: Path, work: Path, dry_run: bool = False) -> list[str]:
    if not work.is_dir():
        raise SyncError(f"{work} not found — is the right drive mounted?")
    log = []
    status = work / "STATUS.md"
    for day in sorted(p for p in pending.iterdir() if p.is_dir() and re.fullmatch(r"\d{4}-\d{2}-\d{2}", p.name)):
        dest_root = work / f"perception_{day.name}"
        for src in sorted(day.rglob("*")):
            rel = src.relative_to(day)
            if src.is_dir() or SKIP & set(rel.parts):
                continue
            dst = dest_root / rel
            if dst.exists() and filecmp.cmp(src, dst, shallow=False):
                continue
            if dst.exists():
                dst = dst.with_name(dst.name + ".from-pending")
                log.append(f"KEPT existing {dst.with_name(src.name)}; wrote ours beside it: {dst.name}")
            else:
                log.append(f"copy {day.name}/{rel}")
            if not dry_run:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        append = day / "STATUS_APPEND.md"
        if append.exists():
            existing = status.read_text() if status.exists() else ""
            new = [h for h in _headings(append.read_text()) if h not in existing]
            if new:
                log.append(f"append {day.name} STATUS block ({len(new)} new section(s))")
                if not dry_run:
                    with status.open("a") as f:
                        f.write("\n" + append.read_text().strip("\n") + "\n")
    return log


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--pending", default=str(DEFAULT_PENDING))
    ap.add_argument("--hdd-root", help="the faiz_work folder; default: find it via findmnt")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)
    try:
        work = Path(args.hdd_root) if args.hdd_root else find_hdd_root()
        log = sync(Path(args.pending), work, args.dry_run)
    except SyncError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    print("\n".join(log) if log else "nothing to do — everything is already on the HDD")
    print(("DRY RUN — nothing written. " if args.dry_run else "") + f"{len(log)} action(s) · target {work}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
