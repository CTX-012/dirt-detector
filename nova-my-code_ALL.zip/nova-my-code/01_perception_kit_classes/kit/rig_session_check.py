#!/usr/bin/env python3
"""Check a rig-session folder BEFORE leaving the rig, so calibration is one visit, not two.

Expected contents (the file names are the ground truth for range and orientation):
  ruler_d<range>_<across|along|tilt30>_<k>.jpg   6 ranges x 3 orientations (k=1),
                                                  plus across_2 at 0.13 m and 0.26 m  -> 20 frames
  part_<name>_<size>mm.jpg                        at least one known robot part
  rig_sheet.json                                  height, pitch readings, clinometer face, reference, part size

Fails on: a missing ruler frame · no part frame, or a part size that doesn't match the sheet · mixed
resolutions (different camera settings) · a messenger-sized frame (long side <= 1000 px; E73 measured
1660 -> 960) · an incomplete sheet · a pitch that isn't the mean of its two reversal readings.

On PASS it writes cal2.draft.json — schema-valid, intrinsics null — which stays UNCAL until
ruler_solve.py supplies f_px.

  python3 rig_session_check.py SESSION_DIR
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

RANGES = ("0.10", "0.13", "0.20", "0.26", "0.35", "0.50")
ORIENTATIONS = ("across", "along", "tilt30")
REPEATS = (("0.13", "across", 2), ("0.26", "across", 2))
REQUIRED = {(r, o, 1) for r in RANGES for o in ORIENTATIONS} | set(REPEATS)
MESSENGER_LONG_SIDE = 1000
REVERSAL_MAX_SPREAD_DEG = 1.0
RULER_RE = re.compile(r"^ruler_d(\d\.\d\d)_(across|along|tilt30)_(\d+)\.(jpe?g|png)$", re.I)
PART_RE = re.compile(r"^part_([a-z0-9-]+)_(\d+(?:\.\d+)?)mm\.(jpe?g|png)$", re.I)
IMAGE_EXT = {".jpg", ".jpeg", ".png"}


def _image_size(path: Path):
    from PIL import Image
    with Image.open(path) as im:
        return im.size


def check(session: Path) -> tuple[list[str], dict | None]:
    session = Path(session)
    problems: list[str] = []
    files = sorted(p for p in session.iterdir() if p.is_file())
    images = [p for p in files if p.suffix.lower() in IMAGE_EXT]

    found, parts = set(), {}
    for p in images:
        m = RULER_RE.match(p.name)
        if m:
            found.add((m.group(1), m.group(2).lower(), int(m.group(3))))
        elif p.name.lower().startswith("ruler"):
            problems.append(f"{p.name}: doesn't match ruler_d<range>_<across|along|tilt30>_<k>.jpg")
        pm = PART_RE.match(p.name)
        if pm:
            parts[p.name] = float(pm.group(2))
    for r, o, k in sorted(REQUIRED - found):
        problems.append(f"missing ruler frame: ruler_d{r}_{o}_{k}.jpg")
    if not parts:
        problems.append("no known-part frame (part_<name>_<size>mm.jpg)")

    sizes = {}
    for p in images:
        try:
            sizes[p.name] = _image_size(p)
        except Exception as e:  # unreadable image is a problem, not a crash
            problems.append(f"{p.name}: cannot read ({e.__class__.__name__})")
    distinct = sorted(set(sizes.values()))
    if len(distinct) > 1:
        problems.append(f"mixed resolutions {distinct}: every frame must use the same camera settings")
    small = [n for n, (w, h) in sizes.items() if max(w, h) <= MESSENGER_LONG_SIDE]
    if small:
        problems.append(f"{len(small)} frame(s) with long side <= {MESSENGER_LONG_SIDE} px — looks like "
                        f"messenger transport (E73: 1660 -> 960 px). Copy by USB: {small[:3]}")

    sheet_path = session / "rig_sheet.json"
    sheet = None
    if not sheet_path.exists():
        problems.append("rig_sheet.json missing")
    else:
        sheet = json.loads(sheet_path.read_text())
        for key in ("camera_id", "height_mm", "height_tol_mm", "pitch_deg", "pitch_tol_deg",
                    "pitch_reference", "clinometer_face", "measured_by", "date"):
            if sheet.get(key) in (None, ""):
                problems.append(f"rig_sheet.json: {key} not filled")
        if sheet.get("pitch_reference") not in (None, "", "from_nadir", "from_horizontal"):
            problems.append("rig_sheet.json: pitch_reference must be from_nadir or from_horizontal")
        part = sheet.get("known_part") or {}
        if not part.get("name") or part.get("size_mm") is None:
            problems.append("rig_sheet.json: known_part name and size_mm not filled")
        elif parts and all(abs(v - float(part["size_mm"])) > 1e-6 for v in parts.values()):
            problems.append(f"rig_sheet.json: known part {part['size_mm']} mm matches no part frame {sorted(parts)}")
        readings = sheet.get("pitch_readings_deg") or []
        if len(readings) < 2:
            problems.append("rig_sheet.json: pitch_readings_deg needs two readings (phone rotated 180° between them)")
        else:
            spread = max(readings) - min(readings)
            if spread > REVERSAL_MAX_SPREAD_DEG:
                problems.append(f"pitch readings differ by {spread:.2f}° (> {REVERSAL_MAX_SPREAD_DEG}°): re-seat the phone")
            mean = sum(readings) / len(readings)
            if sheet.get("pitch_deg") is not None and abs(float(sheet["pitch_deg"]) - mean) > 0.05:
                problems.append(f"pitch_deg {sheet['pitch_deg']} is not the mean of the readings ({mean:.2f})")

    if problems:
        return problems, None
    part = sheet["known_part"]
    draft = {
        "schema_version": 2, "camera_id": sheet["camera_id"],
        "height_mm": float(sheet["height_mm"]), "height_tol_mm": float(sheet["height_tol_mm"]),
        "pitch_deg": float(sheet["pitch_deg"]), "pitch_tol_deg": float(sheet["pitch_tol_deg"]),
        "pitch_reference": sheet["pitch_reference"],
        "method": {"height": "tape", "pitch": "clinometer"}, "proxy": False,
        "intrinsics": None, "status_claimed": None,
        "measured_by": sheet["measured_by"], "date": sheet["date"],
        "notes": (f"clinometer face: {sheet['clinometer_face']}; readings {sheet['pitch_readings_deg']}; "
                  f"known part: {part['name']} {part['size_mm']} mm; ruler frames: {session.name} (20). "
                  f"Add intrinsics from ruler_solve.py to leave UNCAL."),
    }
    return [], draft


def main(argv=None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    if len(argv) != 1:
        print(__doc__)
        return 1
    session = Path(argv[0])
    problems, draft = check(session)
    if problems:
        print(f"FAIL — {len(problems)} problem(s); fix them before leaving the rig:")
        for p in problems:
            print(f"  - {p}")
        return 1
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import cal_ingest
    cal_ingest.validate(draft)
    out = session / "cal2.draft.json"
    out.write_text(json.dumps(draft, indent=2) + "\n")
    state = cal_ingest.derive(draft)
    print("PASS — session complete: 20 ruler frames, part frame, one resolution, sheet filled.")
    print(f"wrote {out}  ->  {state.label}: " + "; ".join(state.reasons))
    return 0


if __name__ == "__main__":
    sys.exit(main())
