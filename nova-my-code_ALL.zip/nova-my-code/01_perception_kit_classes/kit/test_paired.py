"""Tests for paired_compare.py — including the case the CI-overlap rule gets wrong."""
import json

import pytest

import paired_compare as pc


def rows(spec, cls="hair"):
    """spec: list of (a, b) outcomes."""
    return [{"id": f"o{i}", "class": cls, "r1": a, "cutout": b} for i, (a, b) in enumerate(spec)]


def row_for(table, cls):
    return next(r for r in table if r["class"] == cls)


def test_the_case_ci_overlap_gets_wrong():
    """40 objects: r1 30/40, cutout 22/40, and every disagreement goes the same way."""
    spec = [(1, 1)] * 22 + [(1, 0)] * 8 + [(0, 0)] * 10
    r = row_for(pc.compare(rows(spec), "r1", "cutout"), "hair")
    assert (r["r1_k"], r["cutout_k"], r["n"]) == (30, 22, 40)
    assert r["ci_overlap"] is True                    # the overlap rule would say "no winner"
    assert r["b_only_a"] == 8 and r["c_only_b"] == 0
    assert r["p_mcnemar"] == pytest.approx(2 * 0.5 ** 8, rel=1e-6)   # 0.0078
    assert r["verdict"] == "r1 better"                # the paired test finds it


def test_identical_arms_have_no_evidence_either_way():
    spec = [(1, 1)] * 20 + [(0, 0)] * 20
    r = row_for(pc.compare(rows(spec), "r1", "cutout"), "hair")
    assert (r["b_only_a"], r["c_only_b"]) == (0, 0)
    assert r["p_mcnemar"] == 1.0 and r["diff_ci"] == (0.0, 0.0)
    assert r["verdict"] == "no difference detectable"


def test_disagreements_that_cancel_prove_nothing():
    spec = [(1, 0)] * 6 + [(0, 1)] * 6 + [(1, 1)] * 28
    r = row_for(pc.compare(rows(spec), "r1", "cutout"), "hair")
    assert r["p_mcnemar"] > 0.05 and r["verdict"] == "no difference detectable"
    assert r["diff"] == pytest.approx(0.0)


def test_small_n_is_never_a_pass():
    spec = [(1, 0)] * 8 + [(1, 1)] * 5            # n = 13, p = 0.0078
    r = row_for(pc.compare(rows(spec), "r1", "cutout"), "hair")
    assert r["p_mcnemar"] < 0.05
    assert r["verdict"] == "NOT A MEASUREMENT (n<30)"


def test_the_other_arm_can_win():
    spec = [(0, 1)] * 9 + [(1, 1)] * 25 + [(0, 0)] * 6
    r = row_for(pc.compare(rows(spec), "r1", "cutout"), "hair")
    assert r["verdict"] == "cutout better" and r["diff"] < 0


def test_per_class_rows_and_an_all_row():
    data = rows([(1, 0)] * 30, "hair") + rows([(0, 1)] * 32, "dirt")
    for i, r in enumerate(data):
        r["id"] = f"x{i}"
    table = pc.compare(data, "r1", "cutout")
    assert {r["class"] for r in table} == {"hair", "dirt", "ALL"}
    assert row_for(table, "hair")["verdict"] == "r1 better"
    assert row_for(table, "dirt")["verdict"] == "cutout better"
    assert row_for(table, "ALL")["n"] == 62


def test_unpaired_or_malformed_input_is_refused():
    with pytest.raises(pc.PairedError, match="no result for arm"):
        pc.compare([{"id": "a", "class": "hair", "r1": 1}], "r1", "cutout")
    with pytest.raises(pc.PairedError, match="expected 1 or 0"):
        pc.compare([{"id": "a", "class": "hair", "r1": 1, "cutout": "yes"}], "r1", "cutout")
    with pytest.raises(pc.PairedError, match="duplicate object id"):
        pc.compare([{"id": "a", "class": "h", "r1": 1, "cutout": 1},
                    {"id": "a", "class": "h", "r1": 0, "cutout": 1}], "r1", "cutout")


def test_cli(tmp_path, capsys):
    f = tmp_path / "results.jsonl"
    f.write_text("\n".join(json.dumps(r) for r in rows([(1, 1)] * 22 + [(1, 0)] * 8 + [(0, 0)] * 10)))
    assert pc.main([str(f), "--arm-a", "r1", "--arm-b", "cutout"]) == 0
    out = capsys.readouterr().out
    assert "r1 better" in out and "McNemar" in out
