#!/usr/bin/env python3
"""G8 — inter-annotator agreement on a blind double-labelled set.

Compares two YOLO label directories (annotator A, annotator B, same file names) and reports per class:
instance-agreement F1, both directional match rates with 95% Clopper-Pearson intervals and n,
presence agreement per frame (Cohen's kappa), and the median match quality.

Matching rules:
  blob classes : mask IoU >= 0.5
  thin classes : skeletonise both masks; match when >= 80% of EACH skeleton lies within --tol-px
                 of the other. Mask IoU is brittle on strands a few px wide: a 3-px hair offset by
                 2 px has IoU 0.2 even though both annotators marked the same hair.

Verdict: AVOID classes need F1 >= 0.90, CLEAN classes F1 >= 0.80. Fewer than 30 instances on either
side prints NOT A MEASUREMENT — never a pass.

  python3 g8_agreement.py LABELS_A LABELS_B --names data.yaml (--size 1664x936 | --images DIR)
                          [--thin hair,cable,wire,cable_cord] [--tol-px 3] [--out g8_out]
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml
from PIL import Image, ImageDraw

BLOB_IOU = 0.5
THIN_FRACTION = 0.8
MIN_N = 30
F1_BAR = {"AVOID": 0.90, "CLEAN": 0.80}
CLEAN_CLASSES = {"hair", "dirt", "spill", "loose_debris", "spill_coloured"}
DEFAULT_THIN = {"hair", "cable", "wire", "cable_cord"}
IMAGE_EXT = (".jpg", ".jpeg", ".png")


class G8Error(Exception):
    pass


def cp_interval(x: int, n: int, a: float = 0.05):
    from scipy.stats import beta
    if n == 0:
        return (math.nan, math.nan)
    lo = 0.0 if x == 0 else float(beta.ppf(a / 2, x, n - x + 1))
    hi = 1.0 if x == n else float(beta.ppf(1 - a / 2, x + 1, n - x))
    return lo, hi


def kappa(a: list[bool], b: list[bool]):
    n = len(a)
    if n == 0:
        return None
    po = sum(x == y for x, y in zip(a, b)) / n
    pa, pb = sum(a) / n, sum(b) / n
    pe = pa * pb + (1 - pa) * (1 - pb)
    if pe >= 1.0:
        return None  # no variation in presence: kappa undefined
    return (po - pe) / (1 - pe)


def read_names(spec: str) -> list[str]:
    p = Path(spec)
    if p.exists():
        names = (yaml.safe_load(p.read_text()) or {}).get("names")
        if isinstance(names, dict):
            names = [names[k] for k in sorted(names, key=int)]
        if not names:
            raise G8Error(f"{p}: no names")
        return [str(n) for n in names]
    return [n.strip() for n in spec.split(",") if n.strip()]


def _rasterize(points, w, h) -> np.ndarray:
    img = Image.new("L", (w, h), 0)
    ImageDraw.Draw(img).polygon(points, fill=1, outline=1)
    return np.array(img, dtype=bool)


def parse_labels(path: Path, w: int, h: int, n_names: int) -> list[tuple[int, np.ndarray]]:
    out = []
    for ln, line in enumerate(path.read_text().splitlines(), 1):
        tok = line.split()
        if not tok:
            continue
        try:
            cls, vals = int(tok[0]), [float(t) for t in tok[1:]]
        except ValueError:
            raise G8Error(f"{path}:{ln}: not a YOLO label line")
        if not 0 <= cls < n_names:
            raise G8Error(f"{path}:{ln}: class id {cls} outside names (0..{n_names - 1})")
        if len(vals) == 4:
            cx, cy, bw, bh = vals
            x0, y0, x1, y1 = (cx - bw / 2) * w, (cy - bh / 2) * h, (cx + bw / 2) * w, (cy + bh / 2) * h
            pts = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        elif len(vals) >= 6 and len(vals) % 2 == 0:
            pts = [(vals[i] * w, vals[i + 1] * h) for i in range(0, len(vals), 2)]
        else:
            raise G8Error(f"{path}:{ln}: expected 4 box values or an even count >= 6 of polygon values")
        out.append((cls, _rasterize(pts, w, h)))
    return out


def _bbox(m):
    ys, xs = np.nonzero(m)
    return (ys.min(), ys.max(), xs.min(), xs.max()) if ys.size else None


def _crop_pair(ma, mb, pad):
    ba, bb = _bbox(ma), _bbox(mb)
    if ba is None or bb is None:
        return None
    y0, y1 = max(min(ba[0], bb[0]) - pad, 0), min(max(ba[1], bb[1]) + pad + 1, ma.shape[0])
    x0, x1 = max(min(ba[2], bb[2]) - pad, 0), min(max(ba[3], bb[3]) + pad + 1, ma.shape[1])
    return ma[y0:y1, x0:x1], mb[y0:y1, x0:x1]


def _far_apart(ma, mb, pad):
    ba, bb = _bbox(ma), _bbox(mb)
    if ba is None or bb is None:
        return True
    return ba[1] + pad < bb[0] or bb[1] + pad < ba[0] or ba[3] + pad < bb[2] or bb[3] + pad < ba[2]


def iou(ma, mb) -> float:
    c = _crop_pair(ma, mb, 0)
    if c is None:
        return 0.0
    a, b = c
    union = np.logical_or(a, b).sum()
    return float(np.logical_and(a, b).sum() / union) if union else 0.0


def thin_score(ma, mb, tol: float) -> float:
    from scipy.ndimage import distance_transform_edt
    from skimage.morphology import skeletonize
    c = _crop_pair(ma, mb, int(math.ceil(tol)) + 2)
    if c is None:
        return 0.0
    sa, sb = skeletonize(c[0]), skeletonize(c[1])
    if not sa.any() or not sb.any():
        return 0.0
    near_a = distance_transform_edt(~sa)   # distance to the nearest A-skeleton pixel
    near_b = distance_transform_edt(~sb)
    return float(min((near_b[sa] <= tol).mean(), (near_a[sb] <= tol).mean()))


def match(ms_a, ms_b, thin: bool, tol: float) -> list[float]:
    cands = []
    for i, ma in enumerate(ms_a):
        for j, mb in enumerate(ms_b):
            if _far_apart(ma, mb, int(math.ceil(tol)) if thin else 0):
                continue
            s = thin_score(ma, mb, tol) if thin else iou(ma, mb)
            if s >= (THIN_FRACTION if thin else BLOB_IOU):
                cands.append((s, i, j))
    cands.sort(reverse=True)
    used_a, used_b, quality = set(), set(), []
    for s, i, j in cands:
        if i not in used_a and j not in used_b:
            used_a.add(i)
            used_b.add(j)
            quality.append(s)
    return quality


def _size_for(rel: Path, size, images: Path | None):
    if size:
        return size
    stem = rel.with_suffix("")
    for ext in IMAGE_EXT:
        for cand in (images / stem.with_suffix(ext), images / stem.name):
            cand = cand.with_suffix(ext)
            if cand.exists():
                with Image.open(cand) as im:
                    return im.size
    raise G8Error(f"no image for {rel} under {images} — pass --size WxH or the right --images dir")


def run(dir_a: Path, dir_b: Path, names: list[str], size=None, images: Path | None = None,
        thin_classes=DEFAULT_THIN, tol: float = 3.0) -> dict:
    fa = {p.relative_to(dir_a): p for p in Path(dir_a).rglob("*.txt")}
    fb = {p.relative_to(dir_b): p for p in Path(dir_b).rglob("*.txt")}
    only_a, only_b = sorted(set(fa) - set(fb)), sorted(set(fb) - set(fa))
    if only_a or only_b:
        raise G8Error(f"annotators labelled different frames — only A: {[str(p) for p in only_a[:5]]}, "
                      f"only B: {[str(p) for p in only_b[:5]]}")
    if not fa:
        raise G8Error("no label files found")
    thin_classes = {c.lower() for c in thin_classes}
    stats = defaultdict(lambda: {"n_a": 0, "n_b": 0, "matched": 0, "quality": [], "pres_a": [], "pres_b": []})
    for rel in sorted(fa):
        w, h = _size_for(rel, size, images)
        la, lb = parse_labels(fa[rel], w, h, len(names)), parse_labels(fb[rel], w, h, len(names))
        by_a, by_b = defaultdict(list), defaultdict(list)
        for c, m in la:
            by_a[c].append(m)
        for c, m in lb:
            by_b[c].append(m)
        for c in range(len(names)):
            s = stats[names[c]]
            s["pres_a"].append(bool(by_a[c]))
            s["pres_b"].append(bool(by_b[c]))
            if not by_a[c] and not by_b[c]:
                continue
            q = match(by_a[c], by_b[c], names[c].lower() in thin_classes, tol)
            s["n_a"] += len(by_a[c])
            s["n_b"] += len(by_b[c])
            s["matched"] += len(q)
            s["quality"] += q

    rows = []
    for name in names:
        s = stats[name]
        if s["n_a"] + s["n_b"] == 0:
            continue
        group = "CLEAN" if name.lower() in CLEAN_CLASSES else "AVOID"
        m, na, nb = s["matched"], s["n_a"], s["n_b"]
        f1 = 2 * m / (na + nb)
        if min(na, nb) < MIN_N:
            verdict = f"NOT A MEASUREMENT (n<{MIN_N})"
        else:
            verdict = "PASS" if f1 >= F1_BAR[group] else "FAIL"
        rows.append({
            "class": name, "group": group, "rule": "thin" if name.lower() in thin_classes else "blob",
            "n_a": na, "n_b": nb, "matched": m, "f1": f1,
            "a_found_by_b": [m / na if na else math.nan, *cp_interval(m, na)],
            "b_found_by_a": [m / nb if nb else math.nan, *cp_interval(m, nb)],
            "kappa": kappa(s["pres_a"], s["pres_b"]),
            "median_quality": statistics.median(s["quality"]) if s["quality"] else None,
            "verdict": verdict,
        })
    return {"frames": len(fa), "tol_px": tol, "rows": rows}


def render(report: dict) -> str:
    def pct(v):
        return f"{v[0]:.0%} [{v[1]:.0%}, {v[2]:.0%}]" if not math.isnan(v[0]) else "—"
    lines = [f"G8 agreement — {report['frames']} frames, thin-class tolerance {report['tol_px']} px", "",
             "| class | rule | n A | n B | matched | F1 | A found by B (95% CI) | B found by A (95% CI) | κ presence | median match | verdict |",
             "|---|---|---|---|---|---|---|---|---|---|---|"]
    for r in report["rows"]:
        k = f"{r['kappa']:.2f}" if r["kappa"] is not None else "n/a"
        q = f"{r['median_quality']:.2f}" if r["median_quality"] is not None else "—"
        lines.append(f"| {r['class']} | {r['rule']} | {r['n_a']} | {r['n_b']} | {r['matched']} | {r['f1']:.2f} | "
                     f"{pct(r['a_found_by_b'])} | {pct(r['b_found_by_a'])} | {k} | {q} | {r['verdict']} |")
    lines.append("")
    lines.append(f"Bars: AVOID F1 ≥ {F1_BAR['AVOID']}, CLEAN F1 ≥ {F1_BAR['CLEAN']}. Below n={MIN_N} on either side "
                 f"is printed as NOT A MEASUREMENT. Below the bar: adjudicate every disagreement, fix the guide, re-label.")
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("labels_a")
    ap.add_argument("labels_b")
    ap.add_argument("--names", required=True, help="data.yaml, or a comma list")
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--size", help="WxH for every frame, e.g. 1664x936")
    g.add_argument("--images", help="image dir, to read each frame's size")
    ap.add_argument("--thin", default=",".join(sorted(DEFAULT_THIN)), help="comma list, or 'none'")
    ap.add_argument("--tol-px", type=float, default=3.0)
    ap.add_argument("--out")
    args = ap.parse_args(argv)
    try:
        size = tuple(int(v) for v in args.size.lower().split("x")) if args.size else None
        thin = set() if args.thin.lower() == "none" else {t.strip() for t in args.thin.split(",") if t.strip()}
        report = run(Path(args.labels_a), Path(args.labels_b), read_names(args.names), size,
                     Path(args.images) if args.images else None, thin, args.tol_px)
    except (G8Error, ValueError) as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    text = render(report)
    print(text)
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        (out / "agreement.md").write_text(text + "\n")
        (out / "agreement.json").write_text(json.dumps(report, indent=2, default=float) + "\n")
    return 0


if __name__ == "__main__":
    sys.exit(main())
