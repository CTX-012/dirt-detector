"""Tests for ssl_pretrain.py — the loss, the collapse check and the backbone-only transplant."""
import pytest
import torch
import torch.nn as nn

import ssl_pretrain as sp


def test_nt_xent_rewards_matching_views():
    torch.manual_seed(0)
    z = torch.randn(32, 16)
    assert sp.nt_xent(z, z + 0.01 * torch.randn_like(z)) < sp.nt_xent(z, torch.randn(32, 16))


def test_collapse_check_reads_zero_on_collapsed_features_and_near_healthy_on_random():
    assert sp.collapse_std(torch.ones(64, 128)) == pytest.approx(0, abs=1e-6)
    assert sp.collapse_std(torch.randn(4096, 128)) == pytest.approx(1 / 128 ** 0.5, rel=0.05)


def test_a_backbone_with_a_skip_input_is_refused():
    class L(nn.Identity):
        def __init__(self, f):
            super().__init__()
            self.f = f
    det = nn.Module()
    det.model = nn.ModuleList([L(-1)] * 5 + [L([-1, 2])] + [L(-1)] * 6)
    with pytest.raises(ValueError, match="not sequential"):
        sp.backbone_of(det)


def test_transplant_replaces_the_backbone_and_nothing_else(tmp_path):
    from ultralytics.nn.tasks import SegmentationModel
    model = SegmentationModel("yolo11n-seg.yaml", nc=6, verbose=False)
    init = tmp_path / "init.pt"
    torch.save({"model": model.half(), "train_args": {}}, init)
    bb = sp.backbone_of(model.float())
    sd = {k: v + 1 if v.is_floating_point() else v for k, v in bb.state_dict().items()}
    info = sp.transplant(str(init), sd, tmp_path / "out.pt")
    assert info["layers_changed"] == [str(i) for i in range(sp.BACKBONE_LAYERS)]
    out = torch.load(tmp_path / "out.pt", weights_only=False)
    assert out["train_args"]["ssl_floor"] is True


def test_a_killed_run_resumes_where_it_stopped_and_refuses_other_args(tmp_path):
    from PIL import Image
    from ultralytics.nn.tasks import SegmentationModel
    torch.save({"model": SegmentationModel("yolo11n-seg.yaml", nc=6, verbose=False).half()}, tmp_path / "i.pt")
    for i in range(8):
        Image.new("RGB", (64, 64), (i * 30, 90, 200 - i * 20)).save(tmp_path / f"{i}.jpg")
    (tmp_path / "l.txt").write_text("\n".join(str(tmp_path / f"{i}.jpg") for i in range(8)))
    base = ["--list", str(tmp_path / "l.txt"), "--init", str(tmp_path / "i.pt"), "--out", str(tmp_path / "r"),
            "--batch", "4", "--size", "64", "--workers", "0"]
    sp.main(base + ["--epochs", "3", "--max-steps", "2"])          # "killed" after epoch 0
    assert torch.load(tmp_path / "r/last_state.pt", weights_only=False)["epoch"] == 0
    sp.main(base + ["--epochs", "3"])
    import json
    log = json.loads((tmp_path / "r/log.json").read_text())
    assert [e["epoch"] for e in log["epochs"]] == [0, 1, 2] and log["resumed_at_epoch"] == [1]
    with pytest.raises(SystemExit, match="different args"):
        sp.main(base + ["--epochs", "3", "--lr", "0.5"])
