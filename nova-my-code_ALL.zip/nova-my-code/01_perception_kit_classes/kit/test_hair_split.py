"""Tests for hair_split.py — the held-out set must be fixed, contiguous, guarded and duplicate-free."""
import io
import json
import zipfile

import numpy as np
import pytest
from PIL import Image

import hair_split as hs


def jpg(seed):
    rng = np.random.default_rng(seed)
    buf = io.BytesIO()
    Image.fromarray(rng.integers(0, 255, (32, 32, 3), dtype=np.uint8)).resize((64, 64)).save(buf, "JPEG", quality=95)
    return buf.getvalue()


def make_zip(path, names, dup=()):
    with zipfile.ZipFile(path, "w") as z:
        for i, n in enumerate(names):
            z.writestr(f"train/empty/{n}_jpg.rf.{i:032x}.jpg", jpg(i))
        for n in dup:                                   # a Roboflow re-export of the same frame
            i = names.index(n)
            z.writestr(f"valid/empty/{n}_jpg.rf.{999:032x}.jpg", jpg(i))
    return path


def test_plan_holds_out_a_contiguous_tail_with_a_guard_band():
    keys = {"VID_010": [f"VID_010-{i:04d}" for i in range(0, 400, 4)]}      # 100 frames
    a = hs.plan(keys, share=0.2, guard={"VID_010": 6})
    order = sorted(keys["VID_010"], key=lambda k: int(k.split("-")[1]))
    labels = [a[k] for k in order]
    assert labels == ["label_pool"] * 74 + ["guard"] * 6 + ["heldout"] * 20


def test_every_group_contributes_and_the_total_is_twenty_percent():
    keys = {"VID_010": [f"VID_010-{i:04d}" for i in range(161)],
            "output": [f"output{i}" for i in range(1, 51)],
            "lmc": [f"20241024_12{i:04d}_lmc_8" for i in range(24)]}
    a = hs.plan(keys)
    held = [k for k, s in a.items() if s == "heldout"]
    assert len(held) == round(0.2 * 235)
    assert {hs.group_and_order(k)[0] for k in held} == {"VID_010", "output", "lmc"}
    pool = {k for k, s in a.items() if s == "label_pool"}
    assert not pool & set(held)


def test_output_frames_order_numerically_not_lexically():
    keys = {"output": [f"output{i}" for i in range(1, 21)]}
    a = hs.plan(keys, share=0.2, guard={"output": 1})
    assert {k for k, s in a.items() if s == "heldout"} == {"output17", "output18", "output19", "output20"}


def test_duplicates_are_collapsed_and_a_rebuild_is_refused(tmp_path):
    z = make_zip(tmp_path / "h.zip", [f"output{i}" for i in range(1, 21)], dup=["output3", "output19"])
    s = hs.build(z, tmp_path / "ws")
    assert s["zip_files"] == 22 and s["distinct_frames"] == 20 and s["duplicates_collapsed"] == 2
    m = json.loads((tmp_path / "ws/split_manifest.json").read_text())
    assert len({r["sha256"] for r in m["images"]}) == 20
    with pytest.raises(SystemExit, match="refusing to rebuild"):
        hs.build(z, tmp_path / "ws")


def test_copies_that_are_not_the_same_frame_stop_the_build(tmp_path):
    p = tmp_path / "h.zip"
    with zipfile.ZipFile(p, "w") as zf:
        for i in range(1, 11):
            zf.writestr(f"train/empty/output{i}_jpg.rf.{i:032x}.jpg", jpg(i))
        zf.writestr(f"valid/empty/output4_jpg.rf.{999:032x}.jpg", jpg(77))     # same name, different pixels
    with pytest.raises(SystemExit, match="not a duplicate"):
        hs.build(p, tmp_path / "ws")


def test_an_unknown_source_is_refused_not_guessed():
    with pytest.raises(ValueError, match="unknown hair source"):
        hs.group_and_order("IMG_5531")


def test_a_small_source_still_gets_a_held_out_frame():
    """round(0.2*102)=20 would all go to the big group; the small source must still be scored."""
    keys = {"VID_010": [f"VID_010-{i:04d}" for i in range(100)], "lmc": ["20241024_121000_lmc_8", "20241024_121100_lmc_8"]}
    a = hs.plan(keys, share=0.2, guard={})
    assert a["20241024_121100_lmc_8"] == "heldout"
