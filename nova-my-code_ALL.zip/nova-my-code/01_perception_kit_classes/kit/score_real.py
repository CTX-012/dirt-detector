#!/usr/bin/env python3
"""Score arms on the REAL val exactly as PREREGISTRATION_SSL_VS_COCO.md fixes it (added 2026-10-29).

Per labelled instance:
  hit         = some predicted mask, of any locked-6 class, at confidence >= 0.25, has mask IoU >= 0.3
  false-safe  = an AVOID-class instance (cable_cord, soft_object, pet_waste, paper_flat) whose best
                IoU >= 0.3 prediction is a CLEAN class (loose_debris, spill_coloured) — the robot would
                drive over it to clean it
Both thresholds are fixed by the pre-registration. Nothing here takes a threshold from the real val.

Writes results.jsonl in paired_compare.py's format (one line per instance, each arm 1/0, keyed by its
ORIGINAL class, so hair stays its own row), plus summary.json with k/n and a 95% Clopper-Pearson
interval per class and the false-safe count per arm.

  python3 score_real.py REAL_VAL_ROOT --arm coco=a/last.pt --arm ssl=b/last.pt --out scored/

REAL_VAL_ROOT is a YOLO-seg set (images/ + labels/ + data.yaml). Its class names go through the same
mapping as relabel_locked6 (dirt/hair -> loose_debris, ...). A name that maps nowhere stops the run, so
nothing is silently left unscored.
"""
from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from pathlib import Path

import cv2
import numpy as np

from paired_compare import cp_interval
from relabel_locked6 import IMAGE_EXT, LOCKED6, build_map, read_names

CONF, IOU = 0.25, 0.3                          # pinned in the pre-registration
AVOID = {"cable_cord", "soft_object", "pet_waste", "paper_flat"}
CLEAN = {"loose_debris", "spill_coloured"}


class ScoreError(Exception):
    pass


def gt_instances(label_file: Path, names: list[str], mapping: dict, h: int, w: int) -> list[dict]:
    out = []
    for i, line in enumerate(label_file.read_text().splitlines()):
        tok = line.split()
        if not tok:
            continue
        cid = int(tok[0])
        xy = np.array(tok[1:], float).reshape(-1, 2)
        if len(xy) < 3:
            raise ScoreError(f"{label_file}:{i + 1}: {len(xy)} points — the real val must be masks, not boxes")
        mask = np.zeros((h, w), np.uint8)
        cv2.fillPoly(mask, [np.round(xy * [w, h]).astype(np.int32)], 1)
        out.append({"id": f"{label_file.stem}#{i}", "orig": names[cid], "locked": mapping[cid], "mask": mask.astype(bool)})
    return out


def judge(gt: dict, preds: list[dict]) -> tuple[int, int]:
    """(hit, false_safe) for one GT instance. preds: [{"mask": bool HxW, "cls": locked name, "conf": float}]."""
    best_iou, best_cls = 0.0, None
    for p in preds:
        if p["conf"] < CONF:
            continue
        inter = np.logical_and(gt["mask"], p["mask"]).sum()
        union = np.logical_or(gt["mask"], p["mask"]).sum()
        iou = inter / union if union else 0.0
        if iou > best_iou:
            best_iou, best_cls = iou, p["cls"]
    hit = int(best_iou >= IOU)
    false_safe = int(hit and gt["locked"] in AVOID and best_cls in CLEAN)
    return hit, false_safe


def predict(weights: str, img: Path, h: int, w: int) -> list[dict]:
    from ultralytics import YOLO
    model = predict.cache.get(weights) or predict.cache.setdefault(weights, YOLO(weights))
    if list(model.names.values()) != LOCKED6:
        raise ScoreError(f"{weights} predicts {len(model.names)} classes, not the locked 6 — wrong weights")
    r = model.predict(str(img), conf=CONF, retina_masks=True, verbose=False)[0]
    if r.masks is None:
        return []
    masks = r.masks.data.cpu().numpy() > 0.5
    if masks.shape[1:] != (h, w):
        masks = np.stack([cv2.resize(m.astype(np.uint8), (w, h), interpolation=cv2.INTER_NEAREST) > 0 for m in masks])
    return [{"mask": m, "cls": LOCKED6[int(c)], "conf": float(s)}
            for m, c, s in zip(masks, r.boxes.cls.tolist(), r.boxes.conf.tolist())]


predict.cache = {}


def score(root: Path, arms: dict[str, str], out: Path, predictor=predict) -> dict:
    root, out = Path(root), Path(out)
    names = read_names(root / "data.yaml")
    mapping, dropped = build_map(names)
    if dropped:
        raise ScoreError(f"real-val classes that map to nothing: {dropped} — fix the mapping, don't drop real instances")
    imgs = sorted(p for p in root.rglob("*") if p.suffix.lower() in IMAGE_EXT and "images" in p.parts)
    if not imgs:
        raise ScoreError(f"no images under {root}")
    rows, fs = [], defaultdict(int)
    for img in imgs:
        lf = Path(str(img).replace("/images/", "/labels/")).with_suffix(".txt")
        h, w = cv2.imread(str(img)).shape[:2]
        gts = gt_instances(lf, names, mapping, h, w) if lf.exists() else []
        preds = {a: predictor(wt, img, h, w) for a, wt in arms.items()}
        for g in gts:
            row = {"id": g["id"], "class": g["orig"], "locked": g["locked"]}
            for a in arms:
                row[a], f = judge(g, preds[a])
                fs[a] += f
            rows.append(row)
    out.mkdir(parents=True, exist_ok=True)
    (out / "results.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))
    per = defaultdict(lambda: defaultdict(list))
    for r in rows:
        for a in arms:
            per[r["class"]][a].append(r[a])
    summary = {"conf": CONF, "iou": IOU, "images": len(imgs), "instances": len(rows),
               "false_safe": dict(fs), "avoid_instances": sum(r["locked"] in AVOID for r in rows), "per_class": {}}
    for c, by_arm in sorted(per.items()):
        summary["per_class"][c] = {a: {"k": sum(v), "n": len(v), "ci95": cp_interval(sum(v), len(v)),
                                       "measurement": len(v) >= 30} for a, v in by_arm.items()}
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("root")
    ap.add_argument("--arm", action="append", required=True, help="NAME=weights.pt")
    ap.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    try:
        s = score(Path(a.root), dict(x.split("=", 1) for x in a.arm), Path(a.out))
    except ScoreError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    print(json.dumps(s, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
