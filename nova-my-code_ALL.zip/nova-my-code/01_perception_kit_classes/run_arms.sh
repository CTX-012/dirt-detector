#!/usr/bin/env bash
# One command for the blocked part of the 2026-10-07 brief, run ONLY once the real frames exist:
#   arm A (COCO) and arm B (COCO + SSL floors) get the identical supervised stage, then both are scored
#   on the real val by the pre-registered rules (PREREGISTRATION_SSL_VS_COCO.md). Arm A is also the transfer test.
#   usage: run_arms.sh REAL_VAL_ROOT
set -euo pipefail
D=/media/faiz/6780edd4-68c2-41a8-b5d9-be1cd7b4a97f/faiz_work/perception_2026-10-07
K=/media/faiz/6780edd4-68c2-41a8-b5d9-be1cd7b4a97f/faiz_work/perception_2026-09-18/kit
REAL=${1:?usage: run_arms.sh REAL_VAL_ROOT}
# STOP rule (brief a): no real frames -> no training
n=$(find -L "$REAL" -path '*images*' \( -iname '*.jpg' -o -iname '*.png' -o -iname '*.jpeg' \) 2>/dev/null | wc -l || true)
[ "$n" -gt 0 ] || { echo "STOPPED: no real-val images under $REAL — not training" >&2; exit 2; }
SSLW=$D/ssl/run_e100/yolo11n-seg-sslfloor.pt
[ -f "$SSLW" ] || { echo "STOPPED: arm B weights $SSLW missing — finish ssl_pretrain first" >&2; exit 2; }
for arm in coco:$D/weights/yolo11n-seg.pt ssl:$SSLW; do
  name=${arm%%:*}; w=${arm#*:}
  if [ -f "$D/arms/runs/$name/weights/last.pt" ]; then echo "$name already trained — skipping"; continue; fi
  # per-trial GPU gate, in the same command: refuse, never print-and-continue
  [ -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)" ] || { echo "REFUSED: GPU busy before arm $name" >&2; exit 3; }
  (cd "$D/arms" && python3 -c "
from ultralytics import YOLO
YOLO('$w').train(data='$D/arms/public_locked6.yaml', imgsz=640, epochs=50, seed=0, deterministic=True,
                 project='$D/arms/runs', name='$name', exist_ok=True, plots=False)")
done
(cd "$K" && python3 score_real.py "$REAL" --arm coco=$D/arms/runs/coco/weights/last.pt \
     --arm ssl=$D/arms/runs/ssl/weights/last.pt --out $D/arms/scored_real)
(cd "$K" && python3 paired_compare.py $D/arms/scored_real/results.jsonl --arm-a coco --arm-b ssl | tee $D/arms/scored_real/paired.md)
echo "Public column: run 'yolo val' per arm on public_locked6.yaml split=test — report it in a SEPARATE column."
