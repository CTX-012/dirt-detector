#!/usr/bin/env python3
"""nav_for_slam.launch.py - EKF + Nav2 nav-only (localization/map from SLAM).

Provides odom->base_footprint (EKF) and the Nav2 planner/controller/costmaps,
but NOT map_server or AMCL - slam_toolbox supplies the map and map->odom.

    ros2 launch nova slam.launch.py
    ros2 launch nova nav_for_slam.launch.py
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():
    nav2 = get_package_share_directory('nav2_bringup')
    nova = get_package_share_directory('nova')
    params = os.path.join(nova, 'params', 'nav2_params.yaml')

    # EKF - publishes odom -> base_footprint (SLAM needs this to place scans)
    ekf = Node(
        package='robot_localization', executable='ekf_node',
        name='ekf_filter_node', output='screen',
        parameters=[os.path.join(nova, 'config', 'ekf.yaml'),
                    {'use_sim_time': True}])

    # Nav2 navigation half only (no map_server / amcl)
    navigation = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2, 'launch', 'navigation_launch.py')),
        launch_arguments={'use_sim_time': 'true', 'params_file': params}.items())

    return LaunchDescription([ekf, navigation])
