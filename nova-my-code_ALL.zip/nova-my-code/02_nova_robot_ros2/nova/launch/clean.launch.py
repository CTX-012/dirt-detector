#!/usr/bin/env python3
"""clean.launch.py - the full autonomous cleaning stack (yesterday's working setup).

Starts:
  dirt_mapper   - finds dirt with the CAMERA (no ign model --list)
  vacuum_pump   - vacuum + brush
  auto_cleaner  - sweep-and-clean + dirt REFLEX (dirt overrides any goal)

Run AFTER nova.launch.py (sim) and navigation.launch.py (nav) are up and the
robot is localized at (0,0).

Then EITHER:
  ros2 service call /clean_floor std_srvs/srv/Trigger "{}"   # sweep the whole floor
OR just set a goal in RViz - the reflex breaks off to any dirt the camera sees.
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    world = LaunchConfiguration('world_name')
    reflex = LaunchConfiguration('dirt_reflex')

    return LaunchDescription([
        DeclareLaunchArgument('world_name', default_value='default'),
        DeclareLaunchArgument('dirt_reflex', default_value='true',
                              description='dirt overrides any active goal'),

        # ---- the eye: camera -> dirt in map frame ----
        Node(package='nova', executable='dirt_mapper',
             name='dirt_mapper', output='screen',
             parameters=[{
                 'use_sim_time': True,
                 'optical_convention': False,   # Gazebo body frame (x fwd, y left, z up)
                 'fallback_hfov': 1.2,          # only used if camera_info absent
                 'body_crop': 0.30,             # bottom band = robot chassis
                 'edge_margin_px': 6,           # reject frame-clipped fragments
                 'min_patch_area_m2': 0.040,    # physical area gate (real disc ~0.071)
                 'cluster_radius': 0.25,
                 'close_range': 0.15,
                 'lock_conf': 0.80,
             }]),

        # ---- vacuum + brush ----
        Node(package='nova', executable='vacuum_pump',
             name='vacuum_pump', output='screen',
             parameters=[{'use_sim_time': True}]),

        # ---- the driver: sweep-and-clean + reflex ----
        Node(package='nova', executable='auto_cleaner',
             name='auto_cleaner', output='screen',
             parameters=[{
                 'use_sim_time': True,
                 'world_name': world,
                 # roller alignment (calibrated yesterday)
                 'roller_offset': 0.21,
                 'roller_px_x': 0.499,
                 'roller_px_y': 0.504,
                 'align_radius': 0.08,
                 'align_tol_m': 0.03,
                 # full-disc spiral sweep
                 'sweep_enable': False,
                 'patch_radius': 0.15,
                 'ring_step': 0.05,
                 'ring_inner': 0.03,
                 'ring_tol': 0.03,
                 'sweep_omega': 0.6,
                 'k_radial': 2.0,
                 'v_max': 0.10,
                 'w_max': 0.8,
                 'sweep_timeout': 90.0,
                 # sweep-and-clean coverage box (proven-reachable floor)
                 'sweep_min_x': -0.30,
                 'sweep_max_x':  0.90,
                 'sweep_min_y': -0.30,
                 'sweep_max_y':  0.90,
                 'lane_spacing': 0.35,
                 'dirt_conf': 0.60,
                 'cleaned_tol': 0.35,
                 'wp_timeout': 60.0,
                 # dirt reflex
                 'dirt_reflex': reflex,
                 'resume_goal': False,
             }]),
    ])
