import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg_desc = get_package_share_directory('nova')
    pkg_world = get_package_share_directory('aws_robomaker_hospital_world')
    xacro_file = os.path.join(pkg_desc, 'urdf', 'nova.urdf.xacro')
    pkg_nav2 = get_package_share_directory('nav2_bringup')

    spawn_x = LaunchConfiguration('x', default='2.0')
    spawn_y = LaunchConfiguration('y', default='2.0')
    spawn_z = LaunchConfiguration('z', default='0.15')
    spawn_yaw = LaunchConfiguration('yaw', default='0.0')
    map_yaml = os.path.join(pkg_desc, 'maps', 'hospital_map.yaml')
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    params = os.path.join(pkg_desc, 'params', 'nav2_params.yaml')
    autostart = LaunchConfiguration('autostart', default='true')

    robot_desc = ParameterValue(
        Command(['xacro ', xacro_file, ' use_sim:=true']), value_type=str)
    robot_desc_param = {'robot_description': robot_desc, 'use_sim_time': True}

    set_resource_path = SetEnvironmentVariable(
        name='IGN_GAZEBO_RESOURCE_PATH',
        value=os.path.join(pkg_desc, '..', '..'))

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_world, 'launch', 'hospital.launch.py')))

    rsp = Node(
        package='robot_state_publisher', executable='robot_state_publisher',
        name='robot_state_publisher', output='screen',
        parameters=[robot_desc_param])

    spawn = Node(
        package='ros_gz_sim', executable='create',
        arguments=['-name', 'nova', '-topic', '/robot_description',
                   '-x', spawn_x, '-y', spawn_y, '-z', spawn_z, '-Y', spawn_yaw],
        output='screen')

    bridge = Node(
        package='ros_gz_bridge', executable='parameter_bridge',
        name='ros_gz_bridge', output='screen',
        parameters=[{'use_sim_time': True}],
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
            '/cmd_vel@geometry_msgs/msg/Twist]ignition.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry[ignition.msgs.Odometry',
            '/joint_states@sensor_msgs/msg/JointState[ignition.msgs.Model',
            '/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            '/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/imu/data@sensor_msgs/msg/Imu[ignition.msgs.IMU',
            '/camera/image@sensor_msgs/msg/Image[ignition.msgs.Image',
            '/cliff/fl@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/cliff/fr@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/cliff/rl@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/cliff/rr@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ultrasonic/left@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ultrasonic/center@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ultrasonic/right@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ir/left@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/ir/right@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
        ])

    # odom_tf = Node(
    #     package='nova', executable='odom_tf_broadcaster',
    #     name='odom_tf_broadcaster', output='screen',
    #     parameters=[{'use_sim_time': True}])

    # converter = Node(
    #     package='nova', executable='range_converter',
    #     name='range_converter', output='screen',
    #     parameters=[{'use_sim_time': True}])

    rviz = Node(package='rviz2', executable='rviz2', name='rviz2', output='screen',
                parameters=[{'use_sim_time': True}])

    bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_nav2, 'launch', 'bringup_launch.py')),
        launch_arguments={
            'map': map_yaml,
            'use_sim_time': use_sim_time,
            'params_file': params,
            'autostart': autostart,
        }.items(),
    )

    return LaunchDescription([
        DeclareLaunchArgument('x', default_value='2.0'),
        DeclareLaunchArgument('y', default_value='2.0'),
        DeclareLaunchArgument('z', default_value='0.15'),
        DeclareLaunchArgument('yaw', default_value='0.0'),
        set_resource_path, gazebo, rsp, spawn, bridge, rviz,bringup,
    ])