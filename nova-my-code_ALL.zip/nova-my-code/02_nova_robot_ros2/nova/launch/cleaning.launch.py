#!/usr/bin/env python3
"""cleaning.launch.py — spawn 3 dirt patches + autonomous clean.
Run AFTER nova.launch.py (sim) and navigation.launch.py (nav) are up.
Sequence: start nodes -> localize (3s) -> spawn dirt (9s) -> clean all (16s)."""
from launch import LaunchDescription
from launch.actions import TimerAction, ExecuteProcess, DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    world = LaunchConfiguration('world_name')
    declare_world = DeclareLaunchArgument('world_name', default_value='default')

    # cleaning nodes (start immediately)
    vacuum = Node(package='nova', executable='vacuum_pump',
                  name='vacuum_pump', output='screen',
                  parameters=[{'use_sim_time': True}])
    auto_cleaner = Node(package='nova', executable='auto_cleaner',
                        name='auto_cleaner', output='screen',
                        parameters=[{
                            'use_sim_time': True,
                            'world_name': world,
                            'roller_offset': 0.21,    # tf2_echo base_footprint->vacuum_roller_link
                            'roller_px_x': 0.499,     # calibrated
                            'roller_px_y': 0.504,     # calibrated
                            'align_radius': 0.08,
                            'align_tol_m': 0.03,
                            'sweep_enable': False,
                            'patch_radius': 0.15,
                            'ring_step': 0.05,
                            'ring_inner': 0.03,
                            'ring_tol': 0.03,
                            'sweep_omega': 0.6,
                            'k_radial': 2.0,
                            'v_max': 0.10,
                            'w_max': 0.8,
                            'sweep_timeout': 90.0,
                            'sweep_enable': False,
                            'k_radial': 4.0,
                            'sweep_speed': 0.07,
                            'ring_step': 0.05,   # Sweep A already laps the ring
                        }])
    spawner = Node(package='nova', executable='dirt_spawner',
                   name='dirt_spawner', output='screen',
                   parameters=[{'use_sim_time': True}])

    # t=3s: localize robot at (0,0) so Nav2 goals work
    localize = TimerAction(period=3.0, actions=[
        ExecuteProcess(
            cmd=['ros2', 'topic', 'pub', '-1', '/initialpose',
                 'geometry_msgs/msg/PoseWithCovarianceStamped',
                 '{header: {frame_id: "map"}, pose: {pose: {position: {x: 0.0, y: 0.0, z: 0.0}, '
                 'orientation: {x: 0.0, y: 0.0, z: 0.0, w: 1.0}}, '
                 'covariance: [0.25,0,0,0,0,0, 0,0.25,0,0,0,0, 0,0,0,0,0,0, '
                 '0,0,0,0,0,0, 0,0,0,0,0,0, 0,0,0,0,0,0.068]}}'],
            output='screen')
    ])

    # t=9s: spawn the 3 dirt patches
    make_dirty = TimerAction(period=9.0, actions=[
        ExecuteProcess(
            cmd=['ros2', 'service', 'call', '/make_dirty', 'std_srvs/srv/Trigger', '{}'],
            output='screen')
    ])

    # t=16s: autonomous clean-all (drive to each + remove)
    clean_all = TimerAction(period=16.0, actions=[
        ExecuteProcess(
            cmd=['ros2', 'service', 'call', '/clean_all', 'std_srvs/srv/Trigger', '{}'],
            output='screen')
    ])

    return LaunchDescription([
        declare_world,
        vacuum, auto_cleaner, spawner,
        localize, make_dirty, clean_all,
    ])
