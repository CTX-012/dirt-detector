#!/usr/bin/env python3
"""dirt_find.launch.py - realistic-dirt detection (dust + paper) + vacuum.

Run after sim + navigation + localization:
    ros2 launch nova dirt_find.launch.py
"""
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    common = {'use_sim_time': True}
    return LaunchDescription([
        Node(package='nova', executable='dirt_finder',
             name='dirt_finder', output='screen',
             # cv_bridge (apt, built for NumPy 1.x) segfaults under the pip NumPy 2.2.6
             # in ~/.local (installed 2026-09-16): '_ARRAY_API not found' -> exit -11, so
             # the detector died on its first frame and every run since ran blind.
             # PYTHONNOUSERSITE=1 gives this node system NumPy 1.21.5 + apt OpenCV only.
             additional_env={'PYTHONNOUSERSITE': '1'},
             parameters=[{**common,
                          'image_topic': '/dirt_cam/image',
                          'info_topic': '/dirt_cam/camera_info',
                          'body_crop': 0.30,
                          'edge_margin_px': 6,
                          'dark_delta': 45.0,
                          'bright_delta': 30.0,
                          'bright_sat_max': 70.0,
                          'min_area_px': 350,
                          'min_patch_area_m2': 0.008,
                          'merge_dist': 0.25,
                          'lock_conf': 0.80}]),

        Node(package='nova', executable='vacuum_pump',
             name='vacuum_pump', output='screen',
             parameters=[common]),
    ])
