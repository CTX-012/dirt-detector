#!/usr/bin/env python3
"""
navigation.launch.py — Nav2 on the EXISTING AWS small-house map.

Run this AFTER your sim is already up:
    ros2 launch nova nova.launch.py          # sim: gazebo + robot + sensors + /scan + /odom + TF
    ros2 launch nova navigation.launch.py    # this file: map_server + AMCL + Nav2

It explicitly loads the map from the aws-robomaker-small-house-world package
(maps/turtlebot3_waffle_pi/map.yaml) and brings up the Humble Nav2 stack with
nova/params/nav2_params.yaml.
"""
import os
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():
    pkg_nova = get_package_share_directory('nova')
    pkg_nav2 = get_package_share_directory('nav2_bringup')

    # --- locate the AWS map robustly ---
    # Primary: the installed aws world package share dir.
    # Fallback: the source tree path, in case the world pkg isn't installed
    #           with the maps (some forks don't install maps/).
    try:
        pkg_aws = get_package_share_directory('aws_robomaker_small_house_world')
        aws_map = os.path.join(pkg_aws, 'maps', 'turtlebot3_waffle_pi', 'map.yaml')
    except Exception:
        aws_map = ''

    if not aws_map or not os.path.exists(aws_map):
        # fallback to the source path used in your workspace
        src_guess = os.path.expanduser(
            '~/ros_ws/src/aws-robomaker-small-house-world/maps/turtlebot3_waffle_pi/map.yaml')
        aws_map = src_guess

    params_file = os.path.join(pkg_nova, 'params', 'nav2_params.yaml')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    map_yaml = LaunchConfiguration('map', default=aws_map)
    params = LaunchConfiguration('params_file', default=params_file)
    autostart = LaunchConfiguration('autostart', default='true')

    # Use Nav2's standard bringup, which wires map_server + amcl + nav2 lifecycle.
    bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_nav2, 'launch', 'bringup_launch.py')),
        launch_arguments={
            'map': map_yaml,
            'use_sim_time': use_sim_time,
            'params_file': params,
            'autostart': autostart,
        }.items(),
    )

    ekf_node = Node(
        package='robot_localization', executable='ekf_node',
        name='ekf_filter_node', output='screen',
        parameters=[os.path.join(pkg_nova, 'config', 'ekf.yaml'),
                    {'use_sim_time': True}])

    # Laser scan-matcher odometry (rf2o). Feeds /odom_rf2o into the EKF (odom1) to
    # cut yaw/slip drift. publish_tf MUST be false - the EKF owns odom->base_footprint;
    # two publishers of that TF edge would corrupt localisation.
    rf2o_node = Node(
        package='rf2o_laser_odometry', executable='rf2o_laser_odometry_node',
        name='rf2o_laser_odometry', output='screen',
        parameters=[{
            'laser_scan_topic': '/scan',
            'odom_topic': '/odom_rf2o',
            'publish_tf': False,
            'base_frame_id': 'base_footprint',
            'odom_frame_id': 'odom',
            'init_pose_from_topic': '',
            'freq': 20.0,
            'use_sim_time': True}])

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='true'),
        DeclareLaunchArgument('map', default_value=aws_map,
                              description='Path to the map yaml (defaults to AWS small-house map)'),
        DeclareLaunchArgument('params_file', default_value=params_file),
        DeclareLaunchArgument('autostart', default_value='true'),
        # rf2o_node,  # unfused - removed to stop log spam
        ekf_node,
        bringup,
    ])  