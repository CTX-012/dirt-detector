#!/usr/bin/env python3
"""static_localization.launch.py - RIGID map->odom for simulation.

AMCL corrects its estimate continuously, which makes the map frame shift and
can momentarily place obstacles where there are none. In simulation the wheel
odometry is accurate enough to navigate on directly, so this publishes a FIXED
map->odom transform instead: the origin can never move.

Trade-off: nothing corrects genuine odometry drift over a long run. This is a
simulation convenience, not a hardware localisation strategy.

Run INSTEAD of the AMCL part of navigation:
    ros2 launch nova static_localization.launch.py
"""
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='map_to_odom_static',
            output='screen',
            arguments=['--x', '0', '--y', '0', '--z', '0',
                       '--yaw', '0', '--pitch', '0', '--roll', '0',
                       '--frame-id', 'map', '--child-frame-id', 'odom'],
            parameters=[{'use_sim_time': True}],
        ),
    ])
