#!/usr/bin/env python3
"""world_clean.launch.py - whole-world coverage + clean-on-detect."""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    common = {'use_sim_time': True}
    # Drift control. AMCL + the IMU-yaw EKF localise well in the feature-rich
    # house (measured map->odom ~0.1-0.6 m). No laser scan-matcher package is
    # available in this environment (apt has neither rf2o nor laser_scan_matcher),
    # so a scan-matcher fusion is not wired. The periodic AMCL re-seed is the
    # documented fallback, but live measurement showed it REINFORCES AMCL errors
    # in feature-poor far regions (peak map->odom 4.5 m with it ON vs ~1.1 m with
    # it OFF), so it is OFF by default. Opt back in with relocalize_enable:=true.
    relocalize_enable = LaunchConfiguration('relocalize_enable')
    relocalize_period = LaunchConfiguration('relocalize_period')
    return LaunchDescription([
        DeclareLaunchArgument('relocalize_enable', default_value='false'),
        DeclareLaunchArgument('relocalize_period', default_value='25.0'),
        Node(package='nova', executable='dirt_mapper',
             name='dirt_mapper', output='screen',
             parameters=[{**common,
                          'optical_convention': False,
                          'fallback_hfov': 1.2,
                          'body_crop': 0.30,
                          'edge_margin_px': 6,
                          'min_patch_area_m2': 0.040,
                          'close_range': 0.15,
                          'lock_conf': 0.80}]),
        Node(package='nova', executable='vacuum_pump',
             name='vacuum_pump', output='screen',
             parameters=[common]),
        Node(package='nova', executable='world_cleaner',
             name='world_cleaner', output='screen',
             parameters=[{**common,
                          'robot_radius': 0.22,
                          'cover_radius': 0.30,
                          'frontier_min_cells': 8,
                          'nav_timeout': 60.0,
                          'blacklist_after': 2,
                          'roller_offset': 0.21,
                          'patch_radius': 0.15,
                          'ring_step': 0.05,
                          'ring_inner': 0.03,
                          'ring_tol': 0.03,
                          'sweep_omega': 0.6,
                          'k_radial': 2.0,
                          'v_max': 0.10,
                          'w_max': 0.8,
                          'sweep_timeout': 90.0,
                          'relocalize_enable': relocalize_enable,
                          'relocalize_period': relocalize_period}]),
    ])
