#!/usr/bin/env python3
"""dashboard.launch.py - rosbridge + rosapi for the nova-ai web dashboard.

Run AFTER nova.launch.py + navigation.launch.py (+ cleaning.launch.py).
Then serve the page:  cd ~/nova-ai && python3 -m http.server 5173
                      -> http://localhost:5173/web/

coverage:=true also starts nova_coverage_tracker, which fills the dashboard's
coverage panel and gives you a cleaned-area percentage. It is passive - it only
reads /map and TF, and never publishes /cmd_vel - so it cannot interfere with
navigation or cleaning.
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    coverage = LaunchConfiguration('coverage')
    port = LaunchConfiguration('port')

    return LaunchDescription([
        DeclareLaunchArgument('coverage', default_value='true'),
        DeclareLaunchArgument('port', default_value='9090'),

        Node(
            package='rosbridge_server', executable='rosbridge_websocket',
            name='rosbridge_websocket', output='screen',
            parameters=[{
                'port': port,
                # grids are big - without this rosbridge SILENTLY drops /map
                # and the canvas stays blank with no error anywhere
                'max_message_size': 100000000,
                'fragment_timeout': 600,
                'use_compression': False,       # must be off for CBOR
                'unregister_timeout': 86400.0,
            }],
        ),

        # REQUIRED, not optional: the dashboard calls /rosapi/get_time for
        # clock-skew estimation. Without it that call hangs and skew stays 0.
        Node(package='rosapi', executable='rosapi_node',
             name='rosapi', output='screen'),

        Node(package='nova', executable='map_relay',
             name='map_relay', output='screen',
             parameters=[{'use_sim_time': True}]),

        Node(
            package='nova_coverage_tracker', executable='coverage_tracker',
            name='nova_coverage_tracker', output='screen',
            parameters=[__import__('os').path.join(
                __import__('ament_index_python.packages', fromlist=['x'])
                .get_package_share_directory('nova_coverage_tracker'),
                'config', 'coverage_tracker.yaml'), {'use_sim_time': True}],
            condition=IfCondition(coverage),
        ),
    ])
