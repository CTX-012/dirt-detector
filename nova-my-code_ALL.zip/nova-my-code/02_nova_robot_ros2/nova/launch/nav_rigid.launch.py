#!/usr/bin/env python3
"""nav_rigid.launch.py - navigation with a RIGID map->odom frame (simulation).

AMCL continuously corrects its estimate, which shifts the map frame and can
briefly project obstacles into free space. This launch brings up navigation,
then deactivates AMCL and publishes a FIXED map->odom, so the origin never moves.

Trade-off: nothing corrects genuine odometry drift on a long run. Simulation
convenience, not a hardware localisation strategy.

    ros2 launch nova nav_rigid.launch.py
"""
import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, ExecuteProcess
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory('nova')
    nav = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg, 'launch', 'navigation.launch.py')))

    # fixed map->odom: the frame can never move
    static_tf = Node(
        package='tf2_ros', executable='static_transform_publisher',
        name='map_to_odom_static', output='screen',
        arguments=['--x', '0', '--y', '0', '--z', '0',
                   '--yaw', '0', '--pitch', '0', '--roll', '0',
                   '--frame-id', 'map', '--child-frame-id', 'odom'],
        parameters=[{'use_sim_time': True}])

    # give nav time to come up, then stop AMCL publishing its own map->odom
    kill_amcl = TimerAction(
        period=18.0,
        actions=[ExecuteProcess(
            cmd=['ros2', 'lifecycle', 'set', '/amcl', 'deactivate'],
            output='screen')])

    return LaunchDescription([nav, kill_amcl, TimerAction(period=20.0,
                                                          actions=[static_tf])])
