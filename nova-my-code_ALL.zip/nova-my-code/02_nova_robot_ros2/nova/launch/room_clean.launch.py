#!/usr/bin/env python3
"""room_clean.launch.py - rooms + dirt detection + room-by-room cleaning."""
from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    common = {'use_sim_time': True}
    return LaunchDescription([
        Node(package='nova', executable='room_segmenter',
             name='room_segmenter', output='screen',
             parameters=[{**common, 'core_dist': 0.45, 'min_room_area': 1.0,
                          'split_mode': True, 'n_rooms': 1,
                          'split_mode': True, 'n_rooms': 1}]),
        Node(package='nova', executable='dirt_finder',
             name='dirt_finder', output='screen',
             # cv_bridge (apt, built for NumPy 1.x) segfaults under the pip NumPy 2.2.6
             # in ~/.local (installed 2026-09-16): '_ARRAY_API not found' -> exit -11, so
             # the detector died on its first frame and every run since ran blind.
             # PYTHONNOUSERSITE=1 gives this node system NumPy 1.21.5 + apt OpenCV only.
             additional_env={'PYTHONNOUSERSITE': '1'},
             parameters=[{**common,
                          'image_topic': '/dirt_cam/image',
                          'info_topic': '/dirt_cam/camera_info',
                          'body_crop': 0.30, 'edge_margin_px': 6,
                          'dark_delta': 35.0, 'bright_delta': 25.0,
                          'bright_sat_max': 70.0, 'min_area_px': 350,
                          'min_patch_area_m2': 0.02, 'merge_dist': 0.25,
                          'lock_conf': 0.80}]),
        Node(package='nova', executable='vacuum_pump',
             name='vacuum_pump', output='screen', parameters=[common]),
        Node(package='nova', executable='room_cleaner',
             name='room_cleaner', output='screen',
             parameters=[{**common,
                          'lane_spacing': 0.50, 'step_along_lane': 0.50,  # R5: 1.0 m poses + 20-pose chunks cut the sweep rate 0.95-1.03 -> 0.68 %/min; reverted
                          'robot_radius': 0.22, 'nav_timeout': 20.0,
                          'max_retries': 1, 'room_margin': 0.15,
                          'dirt_conf': 0.4, 'cleaned_tol': 0.50, 'remove_tol': 0.60,
                          'roller_offset': 0.21, 'patch_radius': 0.25,
                          'ring_step': 0.05, 'ring_inner': 0.03,
                          'ring_tol': 0.03, 'sweep_omega': 0.6,
                          'k_radial': 2.0, 'v_max': 0.10, 'w_max': 0.8,
                          'sweep_timeout': 90.0}]),
    ])
