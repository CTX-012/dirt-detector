#!/usr/bin/env python3
"""LaserScan (1-beam sim range sensors) -> sensor_msgs/Range + cliff Bool."""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan, Range
from std_msgs.msg import Bool

ULTRA_IR = {
    "ultrasonic/left": ("range/us_left", "us_left_link", 0.5, 4.0),
    "ultrasonic/center": ("range/us_center", "us_center_link", 0.5, 4.0),
    "ultrasonic/right": ("range/us_right", "us_right_link", 0.5, 4.0),
    "ir/left": ("range/ir_left", "ir_left_link", 0.1, 0.8),
    "ir/right": ("range/ir_right", "ir_right_link", 0.1, 0.8),
}
CLIFFS = {
    "cliff/fl": ("range/cliff_fl", "cliff_fl_link", 0.2, 0.30, 0.08),
    "cliff/fr": ("range/cliff_fr", "cliff_fr_link", 0.2, 0.30, 0.08),
    "cliff/rl": ("range/cliff_rl", "cliff_rl_link", 0.2, 0.30, 0.08),
    "cliff/rr": ("range/cliff_rr", "cliff_rr_link", 0.2, 0.30, 0.08),
}

def min_valid(scan):
    vals = [r for r in scan.ranges if scan.range_min <= r <= scan.range_max]
    return min(vals) if vals else float("inf")

class RangeConverter(Node):
    def __init__(self):
        super().__init__("range_converter")
        self._pubs = {}
        self._cliff_pubs = {}
        for in_topic, (out_topic, frame, fov, mx) in ULTRA_IR.items():
            pub = self.create_publisher(Range, "/" + out_topic, 10)
            self._pubs[in_topic] = (pub, frame, fov, mx)
            self.create_subscription(LaserScan, "/" + in_topic,
                lambda msg, t=in_topic: self._on_range(msg, t), 10)
        for in_topic, (out_topic, frame, fov, mx, thr) in CLIFFS.items():
            rpub = self.create_publisher(Range, "/" + out_topic, 10)
            cpub = self.create_publisher(Bool, "/cliff_detected/" + frame, 10)
            self._pubs[in_topic] = (rpub, frame, fov, mx)
            self._cliff_pubs[in_topic] = (cpub, thr, mx)
            self.create_subscription(LaserScan, "/" + in_topic,
                lambda msg, t=in_topic: self._on_cliff(msg, t), 10)
        self.get_logger().info("range_converter up")

    def _make_range(self, scan, frame, fov, mx):
        r = Range()
        r.header = scan.header
        r.header.frame_id = frame
        r.radiation_type = Range.ULTRASOUND
        r.field_of_view = float(fov)
        r.min_range = float(scan.range_min)
        r.max_range = float(mx)
        d = min_valid(scan)
        r.range = float(d) if d != float("inf") else float(mx)
        return r

    def _on_range(self, scan, in_topic):
        pub, frame, fov, mx = self._pubs[in_topic]
        pub.publish(self._make_range(scan, frame, fov, mx))

    def _on_cliff(self, scan, in_topic):
        pub, frame, fov, mx = self._pubs[in_topic]
        pub.publish(self._make_range(scan, frame, fov, mx))
        cpub, thr, _mx = self._cliff_pubs[in_topic]
        d = min_valid(scan)
        b = Bool()
        b.data = bool(d == float("inf") or d > (0.0 + thr + 0.20))
        cpub.publish(b)

def main():
    rclpy.init()
    node = RangeConverter()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
