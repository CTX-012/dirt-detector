#!/usr/bin/env python3
"""
coverage_tracker.py — simulate floor "cleaning" as COVERAGE, gated on the pump.

Only marks floor cells as cleaned WHILE the vacuum pump is ON (it subscribes to
/vacuum/status from the vacuum_pump node). Drive with the pump off and you cover
ground but clean nothing — exactly like the real machine.

Publishes:
  /coverage_map    (OccupancyGrid) the growing cleaned area — view in RViz
  /coverage_area   (Float32)       cleaned area in m^2
  /cleaning/report (String)        combined "PUMP: ON | cleaned: 12.4 m^2"

Frame note: default global_frame is 'map', so localization must be running.
To test without localization, set global_frame:=odom .

Run:  ros2 run nova coverage_tracker
"""
import math
import numpy as np
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Float32, Bool, String
import tf2_ros


class CoverageTracker(Node):
    def __init__(self):
        super().__init__('coverage_tracker')

        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('robot_frame', 'base_footprint')
        self.declare_parameter('resolution', 0.05)
        self.declare_parameter('width_m', 30.0)
        self.declare_parameter('height_m', 60.0)
        self.declare_parameter('origin_x', -15.0)
        self.declare_parameter('origin_y', -35.0)
        self.declare_parameter('cleaning_radius', 0.20)
        self.declare_parameter('publish_period', 1.0)

        g = self.get_parameter
        self.global_frame = g('global_frame').value
        self.robot_frame = g('robot_frame').value
        self.res = g('resolution').value
        self.width = int(g('width_m').value / self.res)
        self.height = int(g('height_m').value / self.res)
        self.ox = g('origin_x').value
        self.oy = g('origin_y').value
        self.clean_r = g('cleaning_radius').value
        period = g('publish_period').value

        self.grid = np.zeros((self.height, self.width), dtype=np.int8)

        rc = int(math.ceil(self.clean_r / self.res))
        self.disk = [(dx, dy)
                     for dy in range(-rc, rc + 1)
                     for dx in range(-rc, rc + 1)
                     if (dx * self.res) ** 2 + (dy * self.res) ** 2 <= self.clean_r ** 2]

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        # pump gate: only clean while pump is ON (starts OFF until we hear otherwise)
        self.pump_on = False
        self.create_subscription(Bool, '/vacuum/status', self.pump_cb, 1)

        self.grid_pub = self.create_publisher(OccupancyGrid, '/coverage_map', 1)
        self.area_pub = self.create_publisher(Float32, '/coverage_area', 1)
        self.report_pub = self.create_publisher(String, '/cleaning/report', 1)

        self.create_timer(0.1, self.mark)
        self.create_timer(period, self.publish)

        self._warned = False
        self.get_logger().info(
            f'coverage_tracker: {self.width}x{self.height} @ {self.res}m, '
            f'clean radius {self.clean_r}m, gated on /vacuum/status')

    def pump_cb(self, msg: Bool):
        self.pump_on = msg.data

    def mark(self):
        if not self.pump_on:
            return  # pump off -> no cleaning
        try:
            tf = self.tf_buffer.lookup_transform(
                self.global_frame, self.robot_frame, rclpy.time.Time())
        except Exception:
            if not self._warned:
                self.get_logger().warn(
                    f'waiting for TF {self.global_frame}->{self.robot_frame} '
                    f'(localization running? or set global_frame:=odom)')
                self._warned = True
            return
        x = tf.transform.translation.x
        y = tf.transform.translation.y
        cx = int((x - self.ox) / self.res)
        cy = int((y - self.oy) / self.res)
        for dx, dy in self.disk:
            gx, gy = cx + dx, cy + dy
            if 0 <= gx < self.width and 0 <= gy < self.height:
                self.grid[gy, gx] = 100

    def publish(self):
        msg = OccupancyGrid()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = self.global_frame
        msg.info.resolution = self.res
        msg.info.width = self.width
        msg.info.height = self.height
        msg.info.origin.position.x = self.ox
        msg.info.origin.position.y = self.oy
        msg.info.origin.orientation.w = 1.0
        msg.data = self.grid.flatten().tolist()
        self.grid_pub.publish(msg)

        cleaned_cells = int(np.count_nonzero(self.grid))
        area = cleaned_cells * self.res * self.res
        self.area_pub.publish(Float32(data=float(area)))

        state = 'ON' if self.pump_on else 'OFF'
        report = f'PUMP: {state} | cleaned: {area:.2f} m^2'
        self.report_pub.publish(String(data=report))
        self.get_logger().info(report)


def main():
    rclpy.init()
    node = CoverageTracker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()