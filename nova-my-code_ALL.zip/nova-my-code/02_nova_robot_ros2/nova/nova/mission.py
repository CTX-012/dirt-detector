#!/usr/bin/env python3
"""mission.py - sequential MAP -> CLEAN -> DOCK coordinator with timing."""
import json
import subprocess
import threading
import time

import rclpy
from rclpy.node import Node
from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist
from nav2_msgs.action import NavigateToPose
from nav2_msgs.srv import ClearEntireCostmap
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from std_msgs.msg import String
from std_srvs.srv import Trigger, SetBool


class Mission(Node):
    def __init__(self):
        super().__init__('mission')
        p = self.declare_parameter
        p('auto', False)
        p('global_frame', 'map')
        p('staging_x', -4.18)
        p('staging_y', -3.07)
        p('explore_done_timeout', 600.0)
        p('clean_done_timeout', 1800.0)
        p('dock_done_timeout', 180.0)
        p('vacuum_on', True)

        self.auto = self.get_parameter('auto').value
        self.gframe = self.get_parameter('global_frame').value

        self._clean_running_seen = False
        self._clean_done = False
        self._dock_done = False
        self._next = threading.Event()

        self.create_subscription(String, '/rooms/progress', self._clean_cb, 10)
        self.create_subscription(String, '/dock/status', self._dock_cb, 10)

        self.cmd = self.create_publisher(Twist, '/cmd_vel_nav', 10)
        self.nav = ActionClient(self, NavigateToPose, '/navigate_to_pose')

        self.create_service(Trigger, '/mission/start', self._start_cb)
        self.create_service(Trigger, '/mission/next', self._next_cb)

        self._times = {}
        self.get_logger().info(
            f"mission ready ({'AUTO' if self.auto else 'SEMI'}). "
            f"Start: ros2 service call /mission/start std_srvs/srv/Trigger '{{}}'")

    def _clean_cb(self, msg):
        try:
            d = json.loads(msg.data)
        except Exception:
            return
        if d.get('running'):
            self._clean_running_seen = True
        if self._clean_running_seen and not d.get('running'):
            self._clean_done = True

    def _dock_cb(self, msg):
        if 'DOCKED' in msg.data:
            self._dock_done = True

    def _next_cb(self, req, resp):
        self._next.set()
        resp.success = True
        resp.message = "continuing"
        return resp

    def _start_cb(self, req, resp):
        threading.Thread(target=self._run_mission, daemon=True).start()
        resp.success = True
        resp.message = "mission started"
        return resp

    def _say(self, s):
        self.get_logger().info(f"[MISSION] {s}")

    def _gate(self, phase):
        if self.auto:
            return
        self._say(f"--- PAUSED after {phase}. Verify, then: "
                  f"ros2 service call /mission/next std_srvs/srv/Trigger '{{}}' ---")
        self._next.clear()
        self._next.wait()
        self._say(f"resuming after {phase}")

    def _call_trigger(self, srv):
        cli = self.create_client(Trigger, srv)
        if not cli.wait_for_service(timeout_sec=10.0):
            self._say(f"service {srv} unavailable")
            return False
        fut = cli.call_async(Trigger.Request())
        t0 = time.time()
        while rclpy.ok() and not fut.done() and time.time() - t0 < 10:
            time.sleep(0.05)
        return fut.done()

    def _set_vacuum(self, on):
        cli = self.create_client(SetBool, '/vacuum/set_state')
        if not cli.wait_for_service(timeout_sec=5.0):
            self._say("vacuum service unavailable (continuing)")
            return
        req = SetBool.Request(); req.data = on
        cli.call_async(req)

    def _goto(self, x, y):
        self.nav.wait_for_server(timeout_sec=20.0)
        g = NavigateToPose.Goal()
        g.pose.header.frame_id = self.gframe
        g.pose.header.stamp = self.get_clock().now().to_msg()
        g.pose.pose.position.x = float(x)
        g.pose.pose.position.y = float(y)
        g.pose.pose.orientation.w = 1.0
        sf = self.nav.send_goal_async(g)
        t0 = time.time()
        while rclpy.ok() and not sf.done() and time.time() - t0 < 10:
            time.sleep(0.05)
        if sf.result() is None or not sf.result().accepted:
            return False
        rf = sf.result().get_result_async()
        t0 = time.time()
        while rclpy.ok() and time.time() - t0 < 120:
            if rf.done():
                return rf.result().status == GoalStatus.STATUS_SUCCEEDED
            time.sleep(0.1)
        return False

    def _run_mission(self):
        t_start = time.time()

        # PHASE 1: MAP
        self._say("PHASE 1: MAPPING - launching frontier exploration")
        t0 = time.time()
        explore = subprocess.Popen(
            ['ros2', 'run', 'explore_lite', 'explore', '--ros-args',
             '-p', 'use_sim_time:=true',
             '-p', 'costmap_topic:=/global_costmap/costmap',
             '-p', 'costmap_updates_topic:=/global_costmap/costmap_updates',
             '-p', 'robot_base_frame:=base_footprint',
             '-p', 'global_frame:=map',
             '-p', 'min_frontier_size:=0.75'],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
        done = False
        tmax = self.get_parameter('explore_done_timeout').value
        while rclpy.ok() and time.time() - t0 < tmax:
            line = explore.stdout.readline()
            if not line:
                if explore.poll() is not None:
                    break
                continue
            if 'No frontiers found' in line or 'All frontiers traversed' in line:
                done = True
                break
        self._times['map'] = time.time() - t0
        explore.terminate()
        try:
            explore.wait(timeout=5)
        except Exception:
            explore.kill()
        subprocess.run(['pkill', '-9', '-f', 'explore_lite/lib/explore_lite/explore'],
                       stderr=subprocess.DEVNULL)
        time.sleep(2)
        self.cmd.publish(Twist())
        self._say(f"PHASE 1 done ({'complete' if done else 'timeout'}) "
                  f"in {self._times['map']:.0f}s")
        self._gate("MAPPING")

        # PHASE 2: CLEAN
        self._say("PHASE 2: CLEANING - starting coverage sweep")
        self.cmd.publish(Twist())
        t0 = time.time()
        if self.get_parameter('vacuum_on').value:
            self._set_vacuum(True)
        self._clean_running_seen = False
        self._clean_done = False
        # force a fresh segmentation of the now-complete map before cleaning
        self._say("re-segmenting the full map before cleaning")
        self._call_trigger('/segment_rooms')
        time.sleep(2.0)   # let /rooms/list propagate to the cleaner
        if not self._call_trigger('/clean_rooms'):
            self._say("failed to start cleaning")
        tmax = self.get_parameter('clean_done_timeout').value
        while rclpy.ok() and time.time() - t0 < tmax:
            if self._clean_done:
                break
            time.sleep(0.5)
        self._times['clean'] = time.time() - t0
        if self.get_parameter('vacuum_on').value:
            self._set_vacuum(False)
        self._say(f"PHASE 2 done ({'complete' if self._clean_done else 'timeout'}) "
                  f"in {self._times['clean']:.0f}s")
        self._gate("CLEANING")

        # PHASE 3: DOCK
        self._say("PHASE 3: DOCKING - clearing costmaps, routing to staging")
        t0 = time.time()
        for svc in ['/global_costmap/clear_entirely_global_costmap',
                    '/local_costmap/clear_entirely_local_costmap']:
            c = self.create_client(ClearEntireCostmap, svc)
            if c.wait_for_service(timeout_sec=5.0):
                c.call_async(ClearEntireCostmap.Request())
        time.sleep(2.0)
        sx = self.get_parameter('staging_x').value
        sy = self.get_parameter('staging_y').value
        if not self._goto(sx, sy):
            self._say("could not reach staging (docking anyway)")
        self._dock_done = False
        if not self._call_trigger('/dock'):
            self._say("failed to start docking")
        tmax = self.get_parameter('dock_done_timeout').value
        while rclpy.ok() and time.time() - t0 < tmax:
            if self._dock_done:
                break
            time.sleep(0.5)
        self._times['dock'] = time.time() - t0
        self._say(f"PHASE 3 done ({'DOCKED' if self._dock_done else 'timeout'}) "
                  f"in {self._times['dock']:.0f}s")

        # REPORT
        total = time.time() - t_start
        self._say("=" * 44)
        self._say("MISSION COMPLETE - timing:")
        self._say(f"  MAP   : {self._times.get('map',0):6.0f} s")
        self._say(f"  CLEAN : {self._times.get('clean',0):6.0f} s")
        self._say(f"  DOCK  : {self._times.get('dock',0):6.0f} s")
        self._say(f"  TOTAL : {total:6.0f} s  ({int(total//60)}m{int(total%60):02d}s)")
        self._say("=" * 44)


def main():
    rclpy.init()
    node = Mission()
    ex = MultiThreadedExecutor()
    ex.add_node(node)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
