#!/usr/bin/env python3
"""dirt_spawner.py — spawns magenta dirt via ros_gz_sim create tool. Call /make_dirty."""
import random
import subprocess
import tempfile
import os

import rclpy
from rclpy.node import Node
from std_srvs.srv import Trigger
from nav_msgs.msg import OccupancyGrid


DIRT_SDF = '''<?xml version="1.0" ?>
<sdf version="1.6">
  <model name="dirt_patch">
    <static>true</static>
    <link name="link">
      <visual name="visual">
        <geometry><cylinder><radius>0.15</radius><length>0.005</length></cylinder></geometry>
        <material>
          <ambient>1.0 0.0 1.0 1.0</ambient>
          <diffuse>1.0 0.0 1.0 1.0</diffuse>
          <emissive>0.6 0.0 0.6 1.0</emissive>
        </material>
      </visual>
    </link>
  </model>
</sdf>'''


class DirtSpawner(Node):
    def __init__(self):
        super().__init__('dirt_spawner')
        self.declare_parameter('num_patches', 8)
        self.declare_parameter('area_min_x', -2.5)
        self.declare_parameter('area_min_y', -2.5)
        self.declare_parameter('area_max_x', 2.5)
        self.declare_parameter('area_max_y', 2.5)
        g = self.get_parameter
        self.n = int(g('num_patches').value)
        self.axmin = g('area_min_x').value; self.aymin = g('area_min_y').value
        self.axmax = g('area_max_x').value; self.aymax = g('area_max_y').value
        self.sdf_path = os.path.join(tempfile.gettempdir(), 'nova_dirt_patch.sdf')
        with open(self.sdf_path, 'w') as f:
            f.write(DIRT_SDF)
        self.map = None
        self.create_subscription(OccupancyGrid, '/map', self._map_cb, 1)
        self.count = 0
        self.srv = self.create_service(Trigger, '/make_dirty', self._on_make_dirty)
        self.get_logger().info(f"dirt_spawner ready. Call /make_dirty to scatter {self.n} patches.")

    def _map_cb(self, msg):
        self.map = msg

    def _free(self, x, y):
        if self.map is None:
            return True
        res = self.map.info.resolution
        w, h = self.map.info.width, self.map.info.height
        mx = int((x - self.map.info.origin.position.x) / res)
        my = int((y - self.map.info.origin.position.y) / res)
        if mx < 0 or my < 0 or mx >= w or my >= h:
            return False
        return 0 <= self.map.data[my * w + mx] < 50

    def _spawn_one(self, x, y):
        self.count += 1
        name = f"dirt_auto_{self.count}"
        cmd = ['ros2', 'run', 'ros_gz_sim', 'create',
               '-name', name, '-file', self.sdf_path,
               '-x', str(x), '-y', str(y), '-z', '0.01']
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
            ok = ('OK creation' in r.stdout) or (r.returncode == 0)
            if not ok:
                self.get_logger().warn(f"spawn failed: {r.stdout[-120:]} {r.stderr[-120:]}")
            return ok
        except Exception as e:
            self.get_logger().warn(f"spawn exception: {e}")
            return False

    def _on_make_dirty(self, req, resp):
        # EXACTLY 3 dirt patches at fixed, verified-reachable open-floor positions
        fixed = [(0.8, 0.0), (0.0, 0.8), (0.8, 0.8)]
        got = 0
        for (x, y) in fixed:
            if self._spawn_one(x, y):
                got += 1
                self.get_logger().info(f"spawned dirt at ({x},{y}) [{got}/3]")

        resp.success = got > 0
        resp.message = f"spawned {got} dirt patches (fixed, max 3)"
        return resp


def main():
    rclpy.init(); node = DirtSpawner()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
