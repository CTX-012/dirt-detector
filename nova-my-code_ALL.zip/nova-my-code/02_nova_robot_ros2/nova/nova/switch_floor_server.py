#!/usr/bin/env python3
"""SwitchFloor action server for NOVA multi-floor navigation."""

import time
import math

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy

from geometry_msgs.msg import PoseWithCovarianceStamped
from nav2_msgs.srv import LoadMap

from nova_interfaces.action import SwitchFloor


FLOORS = {
    1: {
        "map_path": "/home/faiz/ros_ws/install/nova/share/nova/maps/hospital_map.yaml",
        "home_pose": (2.0, 1.0, 0.0),
        "name": "Ground floor (hospital)",
    },
    2: {
        "map_path": "/home/faiz/ros_ws/install/nova/share/nova/maps/floor2_map.yaml",
        "home_pose": (2.0, 2.0, 0.0),
        "name": "Second floor",
    },
}


class SwitchFloorServer(Node):
    def __init__(self):
        super().__init__("switch_floor_server")
        self._cb_group = ReentrantCallbackGroup()

        self._load_map_client = self.create_client(
            LoadMap, "/map_server/load_map", callback_group=self._cb_group)

        pose_qos = QoSProfile(depth=1)
        pose_qos.durability = QoSDurabilityPolicy.TRANSIENT_LOCAL
        pose_qos.reliability = QoSReliabilityPolicy.RELIABLE
        self._initialpose_pub = self.create_publisher(
            PoseWithCovarianceStamped, "/initialpose", pose_qos)

        self._action_server = ActionServer(
            self, SwitchFloor, "switch_floor",
            execute_callback=self.execute_callback,
            goal_callback=self.goal_callback,
            cancel_callback=self.cancel_callback,
            callback_group=self._cb_group)

        self.get_logger().info("SwitchFloor action server ready on 'switch_floor'.")
        self.get_logger().info(f"Configured floors: {sorted(FLOORS.keys())}")

    def goal_callback(self, goal_request):
        floor = goal_request.floor_number
        if floor not in FLOORS:
            self.get_logger().warn(
                f"Rejecting: floor {floor} not configured (known: {sorted(FLOORS.keys())}).")
            return GoalResponse.REJECT
        self.get_logger().info(f"Accepting goal: switch to floor {floor}.")
        return GoalResponse.ACCEPT

    def cancel_callback(self, goal_handle):
        self.get_logger().info("Cancel requested.")
        return CancelResponse.ACCEPT

    def execute_callback(self, goal_handle):
        floor = goal_handle.request.floor_number
        cfg = FLOORS[floor]
        feedback = SwitchFloor.Feedback()
        result = SwitchFloor.Result()

        def fb(status, progress):
            feedback.status = status
            feedback.progress = float(progress)
            goal_handle.publish_feedback(feedback)
            self.get_logger().info(f"[floor {floor}] {status} ({progress:.0%})")

        fb(f"Loading map for {cfg['name']}", 0.1)
        if not self._load_map_client.wait_for_service(timeout_sec=5.0):
            result.success = False
            result.message = "map_server /load_map service unavailable"
            self.get_logger().error(result.message)
            goal_handle.abort()
            return result

        req = LoadMap.Request()
        req.map_url = cfg["map_path"]
        future = self._load_map_client.call_async(req)

        while rclpy.ok() and not future.done():
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                result.success = False
                result.message = "canceled during map load"
                return result
            time.sleep(0.05)

        resp = future.result()
        if resp is None or resp.result != LoadMap.Response.RESULT_SUCCESS:
            code = None if resp is None else resp.result
            result.success = False
            result.message = f"LoadMap failed (result code {code})"
            self.get_logger().error(result.message)
            goal_handle.abort()
            return result

        fb("Map loaded; re-localizing", 0.5)

        x, y, yaw = cfg["home_pose"]
        self._publish_initial_pose(x, y, yaw)
        fb("Initial pose published to AMCL", 0.7)

        steps = 10
        for i in range(steps):
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
                result.success = False
                result.message = "canceled during localization settle"
                return result
            time.sleep(0.2)
            fb("Localizing on new floor", 0.7 + 0.3 * (i + 1) / steps)

        result.success = True
        result.message = f"Switched to {cfg['name']} (floor {floor})."
        self.get_logger().info(result.message)
        goal_handle.succeed()
        return result

    def _publish_initial_pose(self, x, y, yaw):
        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = "map"
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose.position.x = float(x)
        msg.pose.pose.position.y = float(y)
        msg.pose.pose.orientation.z = math.sin(yaw / 2.0)
        msg.pose.pose.orientation.w = math.cos(yaw / 2.0)
        cov = [0.0] * 36
        cov[0] = 0.25
        cov[7] = 0.25
        cov[35] = 0.0685
        msg.pose.covariance = cov
        self._initialpose_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = SwitchFloorServer()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
