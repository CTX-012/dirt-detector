#!/usr/bin/env python3
"""dirt_detector.py — detects magenta dirt from the down camera, projects to floor."""
import math
import numpy as np
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from visualization_msgs.msg import Marker, MarkerArray
import tf2_ros


class DirtDetector(Node):
    def __init__(self):
        super().__init__('dirt_detector')
        self.declare_parameter('img_w', 640)
        self.declare_parameter('img_h', 480)
        self.declare_parameter('hfov', 1.2)
        self.declare_parameter('cam_height', 0.06)
        self.declare_parameter('min_area_px', 300)
        self.declare_parameter('dedup_dist', 0.25)
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('cam_frame', 'dirt_cam_link')
        g = self.get_parameter
        self.W = int(g('img_w').value); self.H = int(g('img_h').value)
        self.hfov = g('hfov').value; self.cam_h = g('cam_height').value
        self.min_area = g('min_area_px').value; self.dedup = g('dedup_dist').value
        self.gframe = g('global_frame').value; self.cframe = g('cam_frame').value
        self.fx = (self.W / 2.0) / math.tan(self.hfov / 2.0); self.fy = self.fx
        self.tfb = tf2_ros.Buffer(); self.tfl = tf2_ros.TransformListener(self.tfb, self)
        self.detected = []
        self.sub = self.create_subscription(Image, '/dirt_cam/image', self._on_img, 5)
        self.marker_pub = self.create_publisher(MarkerArray, '/detected_dirt', 1)
        self.dbg_pub = self.create_publisher(Image, '/dirt_detected/image', 1)
        self.get_logger().info("dirt_detector ready. Watching /dirt_cam/image for magenta dirt.")

    def _on_img(self, msg):
        try:
            img = np.frombuffer(msg.data, dtype=np.uint8).reshape(msg.height, msg.width, 3)
        except Exception as e:
            self.get_logger().warn(f"decode failed: {e}"); return
        if msg.encoding == 'rgb8':
            img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        lower = np.array([140, 80, 80]); upper = np.array([170, 255, 255])
        mask = cv2.inRange(hsv, lower, upper)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((5, 5), np.uint8))
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        dbg = img.copy(); new_world = []
        for c in contours:
            if cv2.contourArea(c) < self.min_area: continue
            M = cv2.moments(c)
            if M['m00'] == 0: continue
            cx = M['m10']/M['m00']; cy = M['m01']/M['m00']
            cv2.drawContours(dbg, [c], -1, (0,255,0), 2)
            cv2.circle(dbg, (int(cx), int(cy)), 5, (0,0,255), -1)
            w = self._pixel_to_map(cx, cy)
            if w is not None: new_world.append(w)
        for (wx, wy) in new_world:
            if not any(math.hypot(wx-ex, wy-ey) < self.dedup for (ex, ey) in self.detected):
                self.detected.append((wx, wy))
                self.get_logger().info(f"NEW dirt at map ({wx:.2f},{wy:.2f}). Total: {len(self.detected)}")
        self._publish_markers(); self._publish_debug(dbg, msg.header)

    def _pixel_to_map(self, px, py):
        dx_cam = (px - self.W/2.0)/self.fx * self.cam_h
        dy_cam = (py - self.H/2.0)/self.fy * self.cam_h
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.cframe, rclpy.time.Time())
        except Exception:
            return None
        cxm = tf.transform.translation.x; cym = tf.transform.translation.y
        q = tf.transform.rotation
        yaw = math.atan2(2*(q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z))
        fwd = dy_cam; right = dx_cam
        wx = cxm + fwd*math.cos(yaw) - (-right)*math.sin(yaw)
        wy = cym + fwd*math.sin(yaw) + (-right)*math.cos(yaw)
        return (wx, wy)

    def _publish_markers(self):
        arr = MarkerArray()
        for i, (x, y) in enumerate(self.detected):
            m = Marker(); m.header.frame_id = self.gframe
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = "detected_dirt"; m.id = i
            m.type = Marker.CYLINDER; m.action = Marker.ADD
            m.pose.position.x = x; m.pose.position.y = y; m.pose.position.z = 0.02
            m.pose.orientation.w = 1.0
            m.scale.x = 0.2; m.scale.y = 0.2; m.scale.z = 0.03
            m.color.r = 1.0; m.color.g = 0.0; m.color.b = 1.0; m.color.a = 0.8
            arr.markers.append(m)
        self.marker_pub.publish(arr)

    def _publish_debug(self, dbg, header):
        out = Image(); out.header = header
        out.height, out.width = dbg.shape[:2]
        out.encoding = 'bgr8'; out.step = out.width*3
        out.data = dbg.tobytes()
        self.dbg_pub.publish(out)


def main():
    rclpy.init(); node = DirtDetector()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()