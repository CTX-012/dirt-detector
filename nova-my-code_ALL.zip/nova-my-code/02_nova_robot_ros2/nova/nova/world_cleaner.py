#!/usr/bin/env python3
"""world_cleaner.py - whole-world coverage + clean-on-detect, native to nova."""
import math
import time
import threading
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy

from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Twist, PoseStamped, PoseWithCovarianceStamped
from nav2_msgs.action import NavigateToPose
from nav2_msgs.srv import ClearEntireCostmap
from action_msgs.msg import GoalStatus
from action_msgs.srv import CancelGoal
from std_srvs.srv import Trigger, SetBool
from std_msgs.msg import String
import tf2_ros
import subprocess, re, json


class WorldCleaner(Node):
    def __init__(self):
        super().__init__('world_cleaner')
        p = self.declare_parameter
        p('map_topic', '/map')
        p('global_frame', 'map')
        p('base_frame', 'base_footprint')
        p('world_name', 'default')
        p('model_prefix', 'dirt_')
        p('robot_radius', 0.22)
        p('cover_radius', 0.30)
        p('frontier_min_cells', 8)
        p('goal_reached_tol', 0.30)
        p('nav_timeout', 60.0)
        p('blacklist_after', 2)
        p('blacklist_radius', 0.5)
        p('max_nav_retries', 2)          # nav failures on ONE target before blacklisting it (skip fast)
        p('complete_confirmations', 3)   # consecutive empty-frontier reads before "done"
        p('complete_recheck_delay', 2.0) # seconds to wait between completion re-checks
        p('relocalize_period', 25.0)   # seconds between AMCL nudges
        p('relocalize_enable', True)
        p('dirt_conf', 0.60)
        p('cleaned_tol', 0.35)
        p('roller_offset', 0.21)
        p('patch_radius', 0.15)
        p('ring_step', 0.05)
        p('ring_inner', 0.03)
        p('ring_tol', 0.03)
        p('sweep_omega', 0.6)
        p('k_radial', 2.0)
        p('v_max', 0.10)
        p('w_max', 0.8)
        p('sweep_timeout', 90.0)

        g = self.get_parameter
        self.gframe = g('global_frame').value
        self.bframe = g('base_frame').value
        self.world = g('world_name').value
        self.prefix = g('model_prefix').value
        self.roller_off = g('roller_offset').value

        self.map = None
        self.visited = None
        self.blacklist = []
        self._dirt_seen = []
        self._cleaned = []
        self._busy = False
        self._stop = False
        self._reach = None            # cached reachable free-cell mask (map is static)
        self._free = None             # cached free-space mask (map is static)
        self._interior = None         # cached free cells with robot-radius clearance (static)
        self._t_start = None          # run start time (for elapsed / time-taken)
        self._complete = False        # true only on genuine, confirmed completion
        self._interrupted_for_dirt = False  # _goto broke off to clean, NOT a nav failure

        latched = QoSProfile(depth=1, history=QoSHistoryPolicy.KEEP_LAST,
                             reliability=QoSReliabilityPolicy.RELIABLE,
                             durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(OccupancyGrid, g('map_topic').value, self._map_cb, latched)
        self.create_subscription(String, '/dirt/map_points', self._dirt_cb, 10)

        self.cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        self.initpose = self.create_publisher(PoseWithCovarianceStamped, '/initialpose', 10)
        # Honest run telemetry (area covered % + time taken) for the dashboard.
        self.covrun = self.create_publisher(String, '/coverage/run', 10)
        self._last_reloc = 0.0
        self.nav = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.vac = self.create_client(SetBool, '/vacuum/set_state')
        self.clr_local = self.create_client(
            ClearEntireCostmap, '/local_costmap/clear_entirely_local_costmap')
        self.clr_global = self.create_client(
            ClearEntireCostmap, '/global_costmap/clear_entirely_global_costmap')
        self.tfb = tf2_ros.Buffer(); tf2_ros.TransformListener(self.tfb, self)

        self.create_service(Trigger, '/clean_world', self._on_start)
        self.create_service(Trigger, '/stop_world', self._on_stop)

        # Publish area-covered% + elapsed time continuously so the dashboard shows it.
        self.create_timer(1.0, self._publish_coverage)

        self.get_logger().info(
            "world_cleaner ready. Start: ros2 service call /clean_world "
            "std_srvs/srv/Trigger '{}'")

    def _map_cb(self, m):
        self.map = m
        if self.visited is None or self.visited.size != m.info.width * m.info.height:
            self.visited = np.zeros((m.info.height, m.info.width), dtype=bool)

    def _dirt_cb(self, m):
        try:
            self._dirt_seen = json.loads(m.data)
        except Exception:
            pass

    def _on_start(self, req, resp):
        if self._busy:
            resp.success = False; resp.message = "already running"; return resp
        if self.map is None:
            resp.success = False; resp.message = "no /map yet"; return resp
        self._stop = False
        self._complete = False
        self._t_start = time.time()
        threading.Thread(target=self._run, daemon=True).start()
        resp.success = True; resp.message = "whole-world coverage started"
        return resp

    def _on_stop(self, req, resp):
        self._stop = True
        resp.success = True; resp.message = "stopping after current action"
        return resp

    def _robot_xy(self):
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            return tf.transform.translation.x, tf.transform.translation.y
        except Exception:
            return 0.0, 0.0

    def _w2g(self, x, y):
        info = self.map.info
        gx = int((x - info.origin.position.x) / info.resolution)
        gy = int((y - info.origin.position.y) / info.resolution)
        return gx, gy

    def _g2w(self, gx, gy):
        info = self.map.info
        x = info.origin.position.x + (gx + 0.5) * info.resolution
        y = info.origin.position.y + (gy + 0.5) * info.resolution
        return x, y

    def _free_mask(self):
        """Free-space mask (occupancy in [0,50]); cached - the map is static."""
        info = self.map.info
        if self._free is not None and self._free.shape == (info.height, info.width):
            return self._free
        data = np.array(self.map.data, dtype=np.int16).reshape(info.height, info.width)
        self._free = (data >= 0) & (data <= 50)
        return self._free

    def _interior_mask(self):
        """Free cells with >= robot_radius obstacle clearance - a cheap 4-connected
        erosion of the free mask (cell True iff all cells within Manhattan distance r
        are free). Coverage targets one of these instead of a wall-hugging edge cell,
        so Nav2 can actually reach the goal (edge cells just fail + get blacklisted).
        Cached - the map is static."""
        free = self._free_mask()
        h, w = free.shape
        if self._interior is not None and self._interior.shape == (h, w):
            return self._interior
        r = max(1, int(self.get_parameter('robot_radius').value / self.map.info.resolution))
        er = free
        for _ in range(r):
            e = er.copy()
            e[1:, :] &= er[:-1, :]
            e[:-1, :] &= er[1:, :]
            e[:, 1:] &= er[:, :-1]
            e[:, :-1] &= er[:, 1:]
            er = e
        self._interior = er
        return er

    def _mark_visited(self, x, y):
        if self.map is None:
            return
        info = self.map.info
        r = int(self.get_parameter('cover_radius').value / info.resolution)
        gx, gy = self._w2g(x, y)
        y0, y1 = max(0, gy - r), min(info.height, gy + r + 1)
        x0, x1 = max(0, gx - r), min(info.width, gx + r + 1)
        # Mark only actually-free cells - never bleed "visited" through walls, which
        # would inflate coverage and strand unreachable unvisited pockets.
        self.visited[y0:y1, x0:x1] |= self._free_mask()[y0:y1, x0:x1]

    def _is_blacklisted(self, x, y):
        br = self.get_parameter('blacklist_radius').value
        return any(math.hypot(bx - x, by - y) < br for bx, by in self.blacklist)

    def _reachable(self, free):
        """Connected free region the robot can actually drive to (flood-fill from
        the robot's cell over free space). The map is static, so cache it.
        Cells behind walls are a DIFFERENT connected component and are excluded -
        so genuinely-unreachable floor never blocks 'coverage complete'.
        Returns a bool mask, or None if we cannot seed (transient bad pose)."""
        h, w = free.shape
        if self._reach is not None and self._reach.shape == (h, w):
            return self._reach
        rx, ry = self._robot_xy()
        rgx, rgy = self._w2g(rx, ry)
        seed = None
        if 0 <= rgx < w and 0 <= rgy < h and free[rgy, rgx]:
            seed = (rgx, rgy)
        else:
            for dr in range(1, 12):           # robot may sit just off a free cell
                for yy in range(max(0, rgy - dr), min(h, rgy + dr + 1)):
                    for xx in range(max(0, rgx - dr), min(w, rgx + dr + 1)):
                        if free[yy, xx]:
                            seed = (xx, yy); break
                    if seed: break
                if seed: break
        if seed is None:
            return None
        mask = np.zeros_like(free)
        stack = [seed]
        while stack:
            x, y = stack.pop()
            if x < 0 or y < 0 or x >= w or y >= h: continue
            if mask[y, x] or not free[y, x]: continue
            mask[y, x] = True
            stack.append((x + 1, y)); stack.append((x - 1, y))
            stack.append((x, y + 1)); stack.append((x, y - 1))
        if np.count_nonzero(mask) > 50:       # only cache a real region, not a bad seed
            self._reach = mask
        return mask

    def _blacklist_mask(self, info):
        mask = np.zeros((info.height, info.width), dtype=bool)
        br = self.get_parameter('blacklist_radius').value
        r = int(br / info.resolution)
        for bx, by in self.blacklist:
            gx, gy = self._w2g(bx, by)
            y0, y1 = max(0, gy - r), min(info.height, gy + r + 1)
            x0, x1 = max(0, gx - r), min(info.width, gx + r + 1)
            mask[y0:y1, x0:x1] = True
        return mask

    def _coverage_stats(self):
        """(visited_reachable, total_reachable, pct). Denominator is the reachable
        free floor MINUS genuinely-unreachable blacklisted regions - the honest
        'whole reachable world' number the completion test and dashboard use."""
        if self.map is None or self.visited is None:
            return 0, 0, 0.0
        info = self.map.info
        free = self._free_mask()
        reach = self._reachable(free)
        if reach is None:
            reach = free
        if self.blacklist:
            reach = reach & (~self._blacklist_mask(info))
        total = int(np.count_nonzero(reach))
        if total == 0:
            return 0, 0, 0.0
        vis = int(np.count_nonzero(reach & self.visited))
        return vis, total, 100.0 * vis / total

    def _publish_coverage(self):
        if self.map is None:
            return
        vis, total, pct = self._coverage_stats()
        elapsed = 0.0 if self._t_start is None else time.time() - self._t_start
        m, s = divmod(int(elapsed), 60)
        data = {
            'coverage_pct': round(pct, 2),
            'covered_cells': int(vis),
            'free_cells': int(total),
            'elapsed_s': round(elapsed, 1),
            'time_str': f"{m}m{s:02d}s",
            'patches_cleaned': len(self._cleaned),
            'complete': bool(self._complete),
            'running': bool(self._busy),
        }
        msg = String(); msg.data = json.dumps(data)
        self.covrun.publish(msg)

    def _find_frontier(self):
        info = self.map.info
        free = self._free_mask()
        candidates = free & (~self.visited)
        # Only chase cells the robot can actually reach; disconnected free cells
        # behind walls would only fail navigation and get wrongly blacklisted.
        reach = self._reachable(free)
        if reach is not None:
            candidates = candidates & reach
        if not candidates.any():
            return None
        rx, ry = self._robot_xy()
        rgx, rgy = self._w2g(rx, ry)
        ys, xs = np.where(candidates)
        d2 = (xs - rgx) ** 2 + (ys - rgy) ** 2
        order = np.argsort(d2)
        min_cells = self.get_parameter('frontier_min_cells').value
        seen = np.zeros_like(candidates)
        for idx in order:
            gx, gy = xs[idx], ys[idx]
            if seen[gy, gx] or not candidates[gy, gx]:
                continue
            blob = self._flood(candidates, seen, gx, gy)
            if len(blob) < min_cells:
                continue
            # Target the unvisited blob cell with obstacle CLEARANCE (interior mask)
            # that is nearest the ROBOT. Clearance keeps the goal Nav2-reachable (not a
            # wall-hugging edge cell that just fails + gets blacklisted); nearest-to-robot
            # makes coverage grow OUTWARD from the robot. Targeting the blob CENTROID
            # instead made the robot corner-dive: in an open-plan house all free space is
            # ONE big blob whose centroid is the far side of the house, so every goal
            # pointed at the far edge - the robot drove to unreachable far corners and
            # never swept the near rooms (so it reached no dirt). The target is always
            # unvisited, so every goal strictly grows the visited set (region -> empty),
            # preserving the no-infinite-stall guarantee.
            interior = self._interior_mask()
            pool = [c for c in blob if interior[c[1], c[0]]] or blob
            bx, by = min(pool, key=lambda c: (c[0] - rgx) ** 2 + (c[1] - rgy) ** 2)
            wx, wy = self._g2w(bx, by)
            if self._is_blacklisted(wx, wy):
                continue
            return wx, wy
        return None

    def _flood(self, cand, seen, gx, gy, cap=4000):
        stack = [(gx, gy)]; blob = []
        h, w = cand.shape
        while stack and len(blob) < cap:
            x, y = stack.pop()
            if x < 0 or y < 0 or x >= w or y >= h: continue
            if seen[y, x] or not cand[y, x]: continue
            seen[y, x] = True; blob.append((x, y))
            stack.extend([(x+1,y),(x-1,y),(x,y+1),(x,y-1)])
        return blob

    def _wait(self, fut, t):
        t0 = time.time()
        while rclpy.ok() and not fut.done():
            if time.time() - t0 > t: return False
            time.sleep(0.05)
        return fut.done()

    def _set_vac(self, on):
        if not self.vac.wait_for_service(timeout_sec=2.0):
            self.get_logger().warn("vacuum service unavailable"); return
        req = SetBool.Request(); req.data = bool(on)
        self.vac.call_async(req)

    def _maybe_relocalize(self):
        """Periodically re-seed AMCL - the documented drift FALLBACK (a laser
        scan-matcher package is unavailable in this environment). OFF by default:
        live measurement showed re-seeding from AMCL's own (possibly-wrong) pose
        with a tight covariance REINFORCES error in feature-poor areas - peak
        map->odom was 4.5 m with this ON vs ~1.1 m with it OFF (AMCL + IMU-yaw
        EKF alone). Enable with relocalize_enable:=true only if AMCL spreads."""
        if not self.get_parameter('relocalize_enable').value:
            return
        period = self.get_parameter('relocalize_period').value
        now = time.time()
        if now - self._last_reloc < period:
            return
        self._last_reloc = now
        rx, ry = self._robot_xy()
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            q = tf.transform.rotation
        except Exception:
            return
        msg = PoseWithCovarianceStamped()
        msg.header.frame_id = self.gframe
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.pose.pose.position.x = rx
        msg.pose.pose.position.y = ry
        msg.pose.pose.orientation = q
        # small covariance -> "we are fairly sure", tightens the cloud
        cov = [0.0]*36
        cov[0] = 0.08; cov[7] = 0.08; cov[35] = 0.02
        msg.pose.covariance = cov
        self.initpose.publish(msg)
        self.get_logger().info("   re-seeded AMCL (drift control)")

    def _spot_dirt(self):
        conf = self.get_parameter('dirt_conf').value
        tol = self.get_parameter('cleaned_tol').value
        rx, ry = self._robot_xy()
        best, bd = None, 1e9
        for p in list(self._dirt_seen):
            if p.get('conf', 0) < conf: continue
            x, y = float(p['x']), float(p['y'])
            if any(math.hypot(cx-x, cy-y) <= tol for cx, cy in self._cleaned): continue
            d = math.hypot(x-rx, y-ry)
            if d < bd: best, bd = (x, y), d
        return best

    def _goto(self, wx, wy):
        tmax = self.get_parameter('nav_timeout').value
        g = NavigateToPose.Goal()
        g.pose.header.frame_id = self.gframe
        g.pose.header.stamp = self.get_clock().now().to_msg()
        g.pose.pose.position.x = float(wx)
        g.pose.pose.position.y = float(wy)
        g.pose.pose.orientation.w = 1.0
        self._interrupted_for_dirt = False
        sf = self.nav.send_goal_async(g)
        if not self._wait(sf, 10) or sf.result() is None or not sf.result().accepted:
            return False
        gh = sf.result(); rf = gh.get_result_async()
        t0 = time.time()
        while rclpy.ok() and not self._stop:
            rx, ry = self._robot_xy(); self._mark_visited(rx, ry)
            self._maybe_relocalize()
            d = self._spot_dirt()
            if d is not None:
                self.get_logger().info(f"   DIRT at ({d[0]:+.2f},{d[1]:+.2f}) - cleaning")
                self._cancel_all()
                self._clean_patch(d[0], d[1])
                self._cleaned.append(d)
                self._interrupted_for_dirt = True   # not a nav failure - resume w/o penalty
                return False
            if rf.done():
                return rf.result().status == GoalStatus.STATUS_SUCCEEDED
            if time.time() - t0 > tmax:
                self._cancel_all()
                return False
            time.sleep(0.1)
        return False

    def _cancel_all(self):
        self.cmd.publish(Twist()); time.sleep(0.3)

    def _recover(self):
        """Un-stick after a nav failure: clear stale costmap obstacles, then a short
        backup + turn so Nav2 replans from a fresh, unobstructed start. The robot is
        rarely physically wedged - the usual cause is a stale/inflated costmap around
        furniture that makes the planner reject nearby coverage goals (robot then sits
        idle, cycling failed goals, and looks 'stopped')."""
        for c in (self.clr_local, self.clr_global):
            if c.wait_for_service(timeout_sec=1.5):
                c.call_async(ClearEntireCostmap.Request())
        time.sleep(0.4)
        # Back straight up only - NO in-place turn. Turning in these feature-poor
        # rooms corrupts skid-steer yaw and destabilises AMCL (drift spiked >10 m
        # with a recovery turn). Nav2's own recovery behaviours handle spins if the
        # planner needs them during the goal.
        t = Twist(); t.linear.x = -0.10
        t0 = time.time()
        while time.time() - t0 < 1.5 and rclpy.ok() and not self._stop:
            self.cmd.publish(t); time.sleep(0.05)
        self.cmd.publish(Twist())

    def _roller_map(self):
        rx, ry = self._robot_xy()
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            q = tf.transform.rotation
            yaw = math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
        except Exception:
            yaw = 0.0
        rox = rx + self.roller_off * math.cos(yaw)
        roy = ry + self.roller_off * math.sin(yaw)
        return rox, roy, yaw

    def _clean_patch(self, tx, ty):
        self._set_vac(True)
        gp = self.get_parameter
        R_out = gp('patch_radius').value; R_in = gp('ring_inner').value
        step = max(0.01, gp('ring_step').value); omega = gp('sweep_omega').value
        k_r = gp('k_radial').value; tol = gp('ring_tol').value
        w_max = gp('w_max').value; v_max = gp('v_max').value
        tmax = gp('sweep_timeout').value; d_off = self.roller_off
        laps = max(1.0, (R_out - R_in) / step); total = 2.0*math.pi*laps
        R = R_out
        t0 = time.time(); swept = 0.0
        rox, roy, _ = self._roller_map(); phi_prev = math.atan2(roy-ty, rox-tx)
        while rclpy.ok() and time.time()-t0 < tmax and not self._stop:
            rox, roy, yaw = self._roller_map()
            dx, dy = rox-tx, roy-ty; rad = math.hypot(dx, dy)
            if rad < 1e-3:
                t = Twist(); t.linear.x = 0.04; self.cmd.publish(t); time.sleep(0.05); continue
            phi = math.atan2(dy, dx)
            dphi = math.atan2(math.sin(phi-phi_prev), math.cos(phi-phi_prev)); phi_prev = phi
            R = max(R_in, R_out - (abs(swept)/total)*(R_out-R_in))
            e_r = R - rad; on_ring = abs(e_r) <= tol
            if on_ring: swept += dphi
            if abs(swept) >= total: break
            v_tan = min(v_max, omega*max(R, 0.02)); gain = k_r
            if not on_ring: v_tan = 0.0; gain = k_r*2.0
            r_hat = (dx/rad, dy/rad); t_hat = (-r_hat[1], r_hat[0])
            vx = v_tan*t_hat[0] + gain*e_r*r_hat[0]
            vy = v_tan*t_hat[1] + gain*e_r*r_hat[1]
            v = vx*math.cos(yaw)+vy*math.sin(yaw)
            w = (-vx*math.sin(yaw)+vy*math.cos(yaw))/d_off
            t = Twist(); t.linear.x = max(-v_max, min(v_max, v))
            t.angular.z = max(-w_max, min(w_max, w)); self.cmd.publish(t)
            time.sleep(0.05)
        self.cmd.publish(Twist())
        self._remove_model(tx, ty)
        self._set_vac(False)

    def _remove_model(self, x, y):
        try:
            r = subprocess.run(['ign','model','--list'], capture_output=True, text=True, timeout=8)
            names = [l.strip().lstrip('-').strip() for l in r.stdout.splitlines()
                     if l.strip().lstrip('-').strip().startswith(self.prefix)]
        except Exception:
            return
        best, bd = None, 1e9
        for n in names:
            try:
                rr = subprocess.run(['ign','model','-m',n,'-p'], capture_output=True, text=True, timeout=8)
                m = re.search(r'\[\s*(-?\d+\.?\d*)\s+(-?\d+\.?\d*)', rr.stdout)
                if not m: continue
                d = math.hypot(float(m.group(1))-x, float(m.group(2))-y)
                if d < bd: best, bd = n, d
            except Exception:
                continue
        if best and bd <= 0.55:
            subprocess.run(['ign','service','-s',f'/world/{self.world}/remove',
                            '--reqtype','ignition.msgs.Entity','--reptype','ignition.msgs.Boolean',
                            '--timeout','3000','--req',f'name: "{best}", type: 2'],
                           capture_output=True, text=True, timeout=6)
            self.get_logger().info(f"   sim: removed {best}")
        else:
            self.get_logger().warn(f"   cleaned, no sim model near ({x:.2f},{y:.2f})")

    def _run(self):
        self._busy = True
        try:
            if not self.nav.wait_for_server(timeout_sec=10.0):
                self.get_logger().error("Nav2 not available"); return
            self.get_logger().info("*** WHOLE-WORLD COVERAGE started ***")
            retries = {}
            dirt_tries = {}
            covered_targets = 0
            empty_reads = 0
            max_retries = int(self.get_parameter('max_nav_retries').value)
            need = int(self.get_parameter('complete_confirmations').value)
            recheck = float(self.get_parameter('complete_recheck_delay').value)
            while rclpy.ok() and not self._stop:
                # PRIORITY: clean any detected, uncleaned dirt BEFORE covering, so a
                # patch is never abandoned when coverage drives off elsewhere. (Bug:
                # the robot cleaned ONE patch opportunistically, then corner-dived away
                # and never returned to the others -> "cleans one patch then stops".)
                dirt = self._spot_dirt()
                if dirt is not None:
                    dkey = (round(dirt[0], 1), round(dirt[1], 1))
                    if dirt_tries.get(dkey, 0) < 2:
                        dirt_tries[dkey] = dirt_tries.get(dkey, 0) + 1
                        self.get_logger().info(
                            f"-> DIRT at ({dirt[0]:+.2f},{dirt[1]:+.2f}) - cleaning before coverage")
                        self._goto(dirt[0], dirt[1])   # cleans en route via _spot_dirt
                        continue
                    if dirt not in self._cleaned:
                        # couldn't clean after 2 approaches (out of camera view /
                        # unreachable) - stop chasing it so coverage can proceed
                        self._cleaned.append(dirt)
                        self.get_logger().warn(
                            f"   dirt ({dirt[0]:+.2f},{dirt[1]:+.2f}) not cleanable - skipping")
                target = self._find_frontier()
                if target is None:
                    # Never conclude "done" on ONE empty read - map/pose can wobble.
                    # Require several consecutive confirmations that no reachable,
                    # unvisited, non-blacklisted free cell remains.
                    empty_reads += 1
                    vis, tot, pct = self._coverage_stats()
                    self.get_logger().info(
                        f"   no reachable frontier ({empty_reads}/{need}) - "
                        f"coverage {pct:.1f}% ({vis}/{tot})")
                    if empty_reads >= need:
                        self._complete = True
                        el = 0.0 if self._t_start is None else time.time() - self._t_start
                        mm, ss = divmod(int(el), 60)
                        self.get_logger().info(
                            f"*** COVERAGE COMPLETE: {pct:.1f}% ({vis}/{tot} cells) "
                            f"| time {mm}m{ss:02d}s | patches cleaned: {len(self._cleaned)} ***")
                        break
                    time.sleep(recheck)
                    continue
                empty_reads = 0            # reachable work remains - reset the confirm counter
                wx, wy = target
                key = (round(wx, 1), round(wy, 1))
                self.get_logger().info(f"-> coverage target ({wx:+.2f},{wy:+.2f})")
                ok = self._goto(wx, wy)
                if ok:
                    covered_targets += 1
                    self._mark_visited(wx, wy)
                    retries.pop(key, None)
                elif self._stop:
                    break
                elif self._interrupted_for_dirt:
                    # Broke off mid-drive to clean dirt - NOT a nav failure. Target is
                    # still unvisited and will be re-selected; no retry penalty.
                    continue
                else:
                    # Genuine navigation failure. DO NOT mark visited (failed != covered).
                    # Retry a few times; blacklist + mark off ONLY after repeated failure.
                    retries[key] = retries.get(key, 0) + 1
                    self.get_logger().warn(
                        f"   target ({wx:+.2f},{wy:+.2f}) not reached "
                        f"(attempt {retries[key]}/{max_retries}) - recovering")
                    self._recover()     # clear costmaps + escape nudge to un-stick
                    if retries[key] >= max_retries:
                        self.blacklist.append((wx, wy))
                        self._mark_visited(wx, wy)   # mark off only now, so we stop retrying it
                        self.get_logger().warn(
                            f"   blacklisted genuinely-unreachable ({wx:+.2f},{wy:+.2f}) "
                            f"after {max_retries} tries")
            self.cmd.publish(Twist())
            self.get_logger().info("*** robot stopped ***")
        finally:
            self._set_vac(False)
            self._busy = False


def main():
    rclpy.init()
    n = WorldCleaner()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
