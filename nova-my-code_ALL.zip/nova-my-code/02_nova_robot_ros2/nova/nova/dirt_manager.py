#!/usr/bin/env python3
"""dirt_manager.py — dirt spots (RViz markers) that vanish when cleaned."""
import random, math
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool
from std_srvs.srv import Trigger
from visualization_msgs.msg import Marker, MarkerArray
from nav_msgs.msg import OccupancyGrid
import tf2_ros


class DirtManager(Node):
    def __init__(self):
        super().__init__('dirt_manager')
        for n, v in [('area_min_x', -2.0), ('area_min_y', -2.0), ('area_max_x', 2.0),
                     ('area_max_y', 2.0), ('num_spots', 40), ('cleaning_radius', 0.20)]:
            self.declare_parameter(n, v)
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('robot_frame', 'base_footprint')
        g = self.get_parameter
        self.axmin = g('area_min_x').value; self.aymin = g('area_min_y').value
        self.axmax = g('area_max_x').value; self.aymax = g('area_max_y').value
        self.n = int(g('num_spots').value); self.clean_r = g('cleaning_radius').value
        self.gframe = g('global_frame').value; self.rframe = g('robot_frame').value
        self.map = None
        self.create_subscription(OccupancyGrid, '/map', self._map_cb, 1)
        self.pump_on = False
        self.create_subscription(Bool, '/vacuum/status', self._pump_cb, 1)
        self.tfb = tf2_ros.Buffer(); self.tfl = tf2_ros.TransformListener(self.tfb, self)
        self.pub = self.create_publisher(MarkerArray, '/dirt_markers', 1)
        self.srv = self.create_service(Trigger, '/scatter_dirt', self._on_scatter)
        self.spots = []; self._scattered = False
        self.create_timer(0.2, self._tick)
        self.create_timer(1.0, self._publish)
        self.create_timer(2.0, self._auto)
        self.get_logger().info(f"dirt_manager ready. Area x[{self.axmin},{self.axmax}] y[{self.aymin},{self.aymax}], {self.n} spots.")

    def _map_cb(self, m): self.map = m
    def _pump_cb(self, m): self.pump_on = m.data

    def _free(self, x, y):
        if self.map is None: return True
        res = self.map.info.resolution
        w, h = self.map.info.width, self.map.info.height
        mx = int((x - self.map.info.origin.position.x) / res)
        my = int((y - self.map.info.origin.position.y) / res)
        if mx < 0 or my < 0 or mx >= w or my >= h: return False
        return 0 <= self.map.data[my * w + mx] < 50

    def _scatter(self):
        self.spots = []; tries = 0
        while len(self.spots) < self.n and tries < self.n * 50:
            x = random.uniform(self.axmin, self.axmax); y = random.uniform(self.aymin, self.aymax)
            tries += 1
            if self._free(x, y): self.spots.append([x, y, False])
        self.get_logger().info(f"scattered {len(self.spots)} dirt spots"); self._publish()

    def _auto(self):
        if not self._scattered: self._scattered = True; self._scatter()

    def _on_scatter(self, req, resp):
        self._scatter(); resp.success = True
        resp.message = f"scattered {len(self.spots)} spots"; return resp

    def _tick(self):
        if not self.pump_on: return
        try: tf = self.tfb.lookup_transform(self.gframe, self.rframe, rclpy.time.Time())
        except Exception: return
        rx, ry = tf.transform.translation.x, tf.transform.translation.y
        for s in self.spots:
            if s[2]: continue
            if math.hypot(s[0]-rx, s[1]-ry) <= self.clean_r: s[2] = True

    def _publish(self):
        arr = MarkerArray()
        for i, (x, y, cl) in enumerate(self.spots):
            m = Marker(); m.header.frame_id = self.gframe
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = "dirt"; m.id = i; m.type = Marker.CYLINDER
            if cl: m.action = Marker.DELETE
            else:
                m.action = Marker.ADD
                m.pose.position.x = x; m.pose.position.y = y; m.pose.position.z = 0.01
                m.pose.orientation.w = 1.0
                m.scale.x = 0.15; m.scale.y = 0.15; m.scale.z = 0.02
                m.color.r = 0.4; m.color.g = 0.26; m.color.b = 0.13; m.color.a = 0.9
            arr.markers.append(m)
        self.pub.publish(arr)
        rem = sum(1 for s in self.spots if not s[2])
        if self.spots:
            self.get_logger().info(f"dirt: {rem}/{len(self.spots)} remaining", throttle_duration_sec=3.0)


def main():
    rclpy.init(); node = DirtManager()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
