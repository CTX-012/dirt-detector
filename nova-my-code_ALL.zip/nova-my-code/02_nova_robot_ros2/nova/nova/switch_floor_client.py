#!/usr/bin/env python3
"""CLI client for SwitchFloor. Usage: ros2 run nova switch_floor_client 2"""

import sys
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from nova_interfaces.action import SwitchFloor


class SwitchFloorClient(Node):
    def __init__(self):
        super().__init__("switch_floor_client")
        self._client = ActionClient(self, SwitchFloor, "switch_floor")

    def send(self, floor_number):
        self.get_logger().info("Waiting for switch_floor action server...")
        if not self._client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error("Action server not available.")
            return False
        goal = SwitchFloor.Goal()
        goal.floor_number = int(floor_number)
        self.get_logger().info(f"Sending goal: switch to floor {floor_number}")
        send_future = self._client.send_goal_async(goal, feedback_callback=self._on_feedback)
        rclpy.spin_until_future_complete(self, send_future)
        goal_handle = send_future.result()
        if not goal_handle.accepted:
            self.get_logger().error("Goal was rejected.")
            return False
        self.get_logger().info("Goal accepted; waiting for result...")
        result_future = goal_handle.get_result_async()
        rclpy.spin_until_future_complete(self, result_future)
        result = result_future.result().result
        if result.success:
            self.get_logger().info(f"SUCCESS: {result.message}")
        else:
            self.get_logger().error(f"FAILED: {result.message}")
        return result.success

    def _on_feedback(self, feedback_msg):
        fb = feedback_msg.feedback
        self.get_logger().info(f"  feedback: {fb.status} ({fb.progress:.0%})")


def main(args=None):
    rclpy.init(args=args)
    node = SwitchFloorClient()
    floor = sys.argv[1] if len(sys.argv) > 1 else "1"
    try:
        node.send(floor)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
