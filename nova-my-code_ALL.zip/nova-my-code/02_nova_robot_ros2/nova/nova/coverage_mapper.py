#!/usr/bin/env python3
"""coverage_mapper.py - map an unknown floor BY covering it, cleaning as it goes."""
import json
import math
import time

import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import String
from std_srvs.srv import Trigger, SetBool
from rcl_interfaces.srv import GetParameters, SetParameters
from rcl_interfaces.msg import Parameter as ParamMsg, ParameterValue, ParameterType
import tf2_ros


class CoverageMapper(Node):
    def __init__(self):
        super().__init__('coverage_mapper')
        p = self.declare_parameter
        p('max_passes', 2)             # BACKSTOP only - not the terminator.
        p('stop_at_x', 3.48)           # STOP the sweep when the robot reaches
        p('stop_at_y', 3.17)           # near here (the dumbbell / fitness gear)
        p('stop_at_radius', 1.0)       # within this many metres = stop
        p('stop_at_enable', True)      # turn the reach-the-dumbbell stop on/off
                                        # Completion is 'planned == 0' (see _run).
        p('settle_time', 3.0)           # let map/costmap settle between passes
        p('sweep_timeout', 7200.0)      # per-SWEEP backstop
        p('run_timeout', 5400.0)       # whole-RUN backstop (90 min), checked DURING the
                                       # sweep too: at 1200 s it could not contain even
                                       # one pass (run 100458 swept 3122 s). max_passes
                                        # is 30, so without this a stuck run
                                        # could grind for days.
        p('pass1_speed', 0.20)          # m/s for PASS 1 only (spawn keyhole). Both spawn
                                        # traps (R2, R4) were PASS 1 at 0.35; none at 0.20.
        p('freeze_timeout', 3.0)        # s (wall) with sim time not advancing = frozen sim
        p('no_progress_timeout', 300.0) # WATCHDOG: robot not moving this long = stuck
        p('coverage_plateau', 1.0)      # <1% gain = a STALLED pass (not 'covered')
        p('plateau_passes', 3)          # this many stalled passes IN A ROW = give up
        p('nav_wait_timeout', 600.0)    # s of ABORTED sweeps (Nav2 not up) before giving up
        p('abort_retry_s', 10.0)        # s between retries of an aborted sweep
        p('map_growth_frac', 0.02)      # known cells growing more than this per pass =
                                        # map still growing: never a completion or a stall
        p('plateau_hard_passes', 5)     # flat this many IN A ROW = stop even with never-
                                        # approached waypoints left (NOT a proven completion)
        p('min_coverage_pct', 0.0)     # never call it 'covered' below this
        p('cov_cell', 0.10)             # m, accumulator cell size
        p('cov_radius', 0.22)           # m, marked radius around the robot
        p('vacuum_on', True)

        self._map = None
        self._known_cells = 0
        self._free_cells = 0
        self._cov_pct = 0.0
        self._cov_seen = False
        self._run_deadline = None   # wall time the whole-run backstop expires
        self._reached_stop = False  # robot reached the dumbbell stop point
        self._svc_clients = {}
        self._cov_cells = set()
        self._fz_last_ns = None    # frozen-sim detector state
        self._fz_adv_wall = 0.0
        self._frozen_total = 0.0   # s of wall time the sim was frozen this run
        self._last_move_t = time.time()
        self._last_xy = None
        self._last_yaw = 0.0
        self._tfb = tf2_ros.Buffer()
        tf2_ros.TransformListener(self._tfb, self)   # NOT _clients: rclpy Node owns that name

        self.create_subscription(OccupancyGrid, '/map', self._map_cb, 1)
        # Own driven-coverage accumulator (_cov_tick). We do NOT use the
        # external tracker: it resets on mm-scale map origin drift.
        self.create_timer(0.2, self._cov_tick)

        self.get_logger().info("coverage_mapper up - will map by covering the floor.")
        import threading
        threading.Thread(target=self._run, daemon=True).start()

    def _map_cb(self, m):
        self._map = m
        # numpy, not two python generator passes over ~100k cells at map rate:
        # that starved this node's other callbacks as the map grew.
        arr = np.asarray(m.data, dtype=np.int16)
        self._known_cells = int(np.count_nonzero(arr >= 0))
        self._free_cells = int(np.count_nonzero((arr >= 0) & (arr < 50)))

    def _decide(self, i, gain, cov, planned, unatt, stalled, failed=0,
                prev_left=None, known=None, prev_known=None):
        """Termination decision after pass i -> (stop, covered, stalled, msgs).
        Pure, so every rule is unit-tested against real run traces.

        A COMPLETION needs BOTH driven coverage >= min_coverage_pct AND a map that
        has stopped growing. An empty or flat plan on a small or still-growing map
        means 'keep sweeping' (mapping reveals more floor), never 'done'. Run
        114053 quit at 1.4% with 5,108 known cells: below the floor the old empty-
        plan rule only changed the LABEL to 'NOT covered' - it still stopped.
        Below the floor a run can end only as a labelled FAILURE, after
        plateau_hard_passes passes with no coverage gain AND no map growth."""
        min_cov = self.get_parameter('min_coverage_pct').value
        plateau = self.get_parameter('coverage_plateau').value
        n = self.get_parameter('plateau_passes').value
        hard = self.get_parameter('plateau_hard_passes').value
        gfrac = self.get_parameter('map_growth_frac').value
        low = cov < min_cov
        grew = (known is not None and prev_known is not None
                and known - prev_known > gfrac * max(prev_known, 1))
        empty = planned is not None and int(planned) == 0
        # 1. EMPTY plan, above the floor, map settled: every reachable waypoint is
        #    driven or proven unreachable (wp_fail_limit). PASS 1 is exempt.
        if empty and i > 1 and not low and not grew:
            return True, True, stalled, [
                f"no un-driven reachable floor left to plan ({cov:.1f}% driven, "
                f"map settled at {known} known cells) - ALL REACHABLE FLOOR COVERED",
                "*** COVERAGE COMPLETE - 100% of the reachable world covered ***"]
        if gain is None:
            return False, False, stalled, []
        if gain >= plateau:
            return False, False, 0, ([f"only {cov:.1f}% driven (< {min_cov}%) - "
                                      f"continuing"] if low else [])
        if grew:
            # new floor was revealed and the next pass plans into it: not a stall
            return False, False, stalled, [
                f"pass added only +{gain:.2f}% but the map grew {prev_known} -> "
                f"{known} known cells - new floor to cover, continuing"]
        # 2. a STALLED pass: < plateau gain and the map is not growing
        stalled += 1
        msgs = [f"pass stalled: +{gain:.2f}% (< {plateau}%) at {cov:.1f}% "
                f"driven, {planned} planned, {unatt} not yet attempted - "
                f"{stalled}/{n}"]
        collapsed = (prev_left is not None and planned is not None
                     and int(prev_left) >= 10 and int(planned) < 0.5 * int(prev_left))
        if collapsed:
            msgs.append(f"plan collapsed: {planned} planned vs {prev_left} left "
                        f"after the previous pass - not proof the floor is covered")
        if int(failed or 0) > 0:
            msgs.append(f"{failed} room(s) reached no waypoint this pass - "
                        f"not proof the floor is covered")
        # A FULL ATTEMPT: every planned waypoint sent, the robot reached some, the
        # plan had not collapsed. R1: every near-zero pass later followed by real
        # gain was NOT one (PASS 5 planned 1 of ~111 left, then +6.0%; PASS 7
        # reached nothing, then +2.9%). An unknown or empty plan never is.
        full = (planned is not None and int(planned) > 0 and unatt == 0
                and not int(failed or 0) and not collapsed)
        if low:
            if empty:
                msgs.append(f"empty plan at only {cov:.1f}% driven - a trapped robot "
                            f"or a map that has not grown yet")
            if stalled >= hard:
                msgs.append(f"no coverage gain and no map growth for {stalled} passes "
                            f"at only {cov:.1f}% - robot trapped or cannot explore - "
                            f"STOPPING; FAILED, NOT covered")
                return True, False, stalled, msgs
            msgs.append(f"only {cov:.1f}% driven (< {min_cov}%) - never a completion; "
                        f"continuing ({stalled}/{hard} flat passes before FAILED)")
            return False, False, stalled, msgs
        if full or (stalled >= n and unatt == 0):
            why = ("this pass attempted every remaining waypoint" if full
                   else f"{stalled} stalled passes in a row")
            msgs.append(f"coverage plateaued at {cov:.1f}% on a settled map "
                        f"({known} known cells) - {why} and it added < {plateau}% "
                        f"- REACHABLE FLOOR COVERED (plateau)")
            msgs.append("*** COVERAGE COMPLETE - every reachable waypoint is "
                        "driven or proven unreachable ***")
            return True, True, stalled, msgs
        # last resort: planned floor the robot never got near is not proof of
        # anything, but it must not keep the run going for ever either
        if stalled >= hard:
            msgs.append(f"coverage flat for {stalled} passes at {cov:.1f}% with "
                        f"{unatt} planned waypoint(s) never approached - STOPPING; "
                        f"NOT a proven completion")
            return True, False, stalled, msgs
        return False, False, stalled, msgs

    def _sim_now_ns(self):
        return self.get_clock().now().nanoseconds

    def _sim_frozen(self):
        """True once simulation time has not advanced for freeze_timeout wall
        seconds (paused Gazebo / dead /clock bridge). Lazy against wall time:
        a sim-time timer - like _cov_tick - stops firing while frozen, which is
        exactly why the motion watchdog would otherwise abandon the sweep."""
        now_ns, wall = self._sim_now_ns(), time.time()
        if self._fz_last_ns is None or now_ns != self._fz_last_ns:
            self._fz_last_ns, self._fz_adv_wall = now_ns, wall
            return False
        return wall - self._fz_adv_wall > self.get_parameter('freeze_timeout').value

    def _robot_map_xy(self):
        """Robot (x, y) in the map frame, or (None, None) if TF isn't ready."""
        try:
            tf = self._tfb.lookup_transform('map', 'base_footprint',
                                            rclpy.time.Time())
            return tf.transform.translation.x, tf.transform.translation.y
        except Exception:
            return None, None

    def _cov_tick(self):
        """Mark where the robot footprint has actually been, keyed on quantised
        MAP-FRAME coordinates so map resize / origin drift cannot reset it."""
        try:
            tf = self._tfb.lookup_transform('map', 'base_footprint',
                                            rclpy.time.Time())
        except Exception:
            self._last_move_t = time.time()   # cannot judge -> do NOT accrue
            return
        x, y = tf.transform.translation.x, tf.transform.translation.y
        q = tf.transform.rotation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y),
                         1 - 2 * (q.y * q.y + q.z * q.z))
        # progress tracking for the sweep watchdog. Rotation counts:
        # a dirt spiral pivots in place and that IS work.
        if self._last_xy is None:
            self._last_xy = (x, y); self._last_yaw = yaw
            self._last_move_t = time.time()
        else:
            moved = math.hypot(x - self._last_xy[0], y - self._last_xy[1])
            turned = abs(math.atan2(math.sin(yaw - self._last_yaw),
                                    math.cos(yaw - self._last_yaw)))
            if moved > 0.05 or turned > 0.25:
                self._last_xy = (x, y); self._last_yaw = yaw
                self._last_move_t = time.time()
        c = self.get_parameter('cov_cell').value
        r = self.get_parameter('cov_radius').value
        n = int(r / c)
        cx, cy = int(math.floor(x / c)), int(math.floor(y / c))
        for dy in range(-n, n + 1):
            for dx in range(-n, n + 1):
                if (dx * c) ** 2 + (dy * c) ** 2 <= r * r:
                    self._cov_cells.add((cx + dx, cy + dy))
        self._cov_seen = True
        if self._map is not None and self._free_cells > 0:
            res = self._map.info.resolution
            free_area = self._free_cells * res * res
            covered_area = len(self._cov_cells) * c * c
            if free_area > 0:
                self._cov_pct = min(100.0, 100.0 * covered_area / free_area)

    def _say(self, s):
        self.get_logger().info(f"[COVERAGE] {s}")

    def _call(self, srv, cls=Trigger, req=None):
        # Returns the RESPONSE (or None). The old version returned fut.done(),
        # so it could not see resp.success: a /clean_rooms REJECTED with
        # "already running" was indistinguishable from a started sweep.
        cli = self._svc_clients.get(srv)
        if cli is None:
            cli = self.create_client(cls, srv)
            self._svc_clients[srv] = cli
        if not cli.wait_for_service(timeout_sec=10.0):
            self._say(f"service {srv} unavailable")
            return None
        fut = cli.call_async(req or cls.Request())
        t0 = time.time()
        while rclpy.ok() and not fut.done() and time.time() - t0 < 15:
            time.sleep(0.05)
        return fut.result() if fut.done() else None

    NAV_SPEED = 'FollowPath.desired_linear_vel'

    def _get_nav_speed(self):
        req = GetParameters.Request()
        req.names = [self.NAV_SPEED]
        r = self._call('/controller_server/get_parameters', GetParameters, req)
        try:
            v = r.values[0]
            return float(v.double_value) if v.type == ParameterType.PARAMETER_DOUBLE else None
        except Exception:
            return None

    def _set_nav_speed(self, v):
        req = SetParameters.Request()
        req.parameters = [ParamMsg(name=self.NAV_SPEED, value=ParameterValue(
            type=ParameterType.PARAMETER_DOUBLE, double_value=float(v)))]
        r = self._call('/controller_server/set_parameters', SetParameters, req)
        ok = bool(r is not None and r.results and r.results[0].successful)
        self._say(f"nav speed -> {v:.2f} m/s {'OK' if ok else 'FAILED'}")
        return ok

    def _set_vacuum(self, on):
        req = SetBool.Request(); req.data = on
        self._call('/vacuum/set_state', SetBool, req)

    def _wait_map(self):
        t0 = time.time()
        while rclpy.ok() and self._map is None and time.time() - t0 < 30:
            time.sleep(0.5)
        return self._map is not None

    def _cleaner_stats(self):
        r = self._call('/rooms_status')
        if r is None:
            return {}
        try:
            return json.loads(r.message)
        except Exception:
            return {} 

    def _stop_cleaner(self):
        """Never leave room_cleaner driving the robot without a coordinator."""
        r = self._call('/stop_rooms')
        ok = r is not None and getattr(r, 'success', False)
        self._say(f"/stop_rooms -> {'accepted' if ok else 'NO RESPONSE'}")
        t0 = time.time()
        while time.time() - t0 < 90:
            if self._cleaner_idle() is True:
                self._say(f"cleaner confirmed IDLE {time.time() - t0:.0f}s after stop")
                return True
            time.sleep(2.0)
        self._say("WARNING: cleaner STILL BUSY 90s after /stop_rooms")
        return False

    def _sweep_counted(self, base):
        """True once the cleaner's sweep counter has moved past base."""
        if base is None:
            return False
        try:
            return int(self._cleaner_stats().get('sweeps_done') or 0) > int(base)
        except Exception:
            return False

    def _cleaner_idle(self):
        """True=idle, False=busy, None=unknown (service round-trip)."""
        r = self._call('/rooms_status')
        if r is None:
            return None
        return bool(r.success)

    def _do_one_sweep(self):
        # Re-segment FIRST so this pass plans against the map as it is NOW.
        # The old code gated on a "stable" free-cell count, which a stationary
        # robot satisfies in 6s - segmenting a ~13 m2 keyhole around spawn.
        r = self._call('/segment_rooms')
        if r is not None:
            self._say(f"segmented: {r.message}")
        time.sleep(2.0)
        t0 = time.time()
        while self._cleaner_idle() is False and time.time() - t0 < 120:
            self._say("cleaner still busy - waiting before starting sweep")
            time.sleep(5.0)
        # read the cleaner's sweep counter first: an EMPTY-plan sweep ends faster
        # than the 2 s poll, is never seen busy, and used to sit until the 300 s
        # motion watchdog (R4: every empty pass took 302 s)
        base_sweeps = self._cleaner_stats().get('sweeps_done')
        r = self._call('/clean_rooms')
        if r is None or not r.success:
            self._say(f"sweep did NOT start: "
                      f"{'no response' if r is None else r.message}")
            return False
        self._say(f"sweep started: {r.message}")
        tmax = self.get_parameter('sweep_timeout').value
        nopro = self.get_parameter('no_progress_timeout').value
        t0 = time.time()
        self._last_move_t = time.time()      # clock starts when driving starts
        seen_busy = False
        while rclpy.ok() and time.time() - t0 < tmax:
            # the whole-run backstop must bite DURING a sweep: checked only
            # between passes, it let run 100458 overrun 1200 s by 32 minutes
            if (self._run_deadline is not None
                    and time.time() - self._frozen_total > self._run_deadline):
                self._say(f"whole-run backstop reached DURING the sweep at "
                          f"{self._cov_pct:.1f}% driven - ending the sweep now")
                self._stop_cleaner()
                return False
            # STOP when the robot reaches the dumbbell area: the world is covered
            # start-to-end by then, so end the sweep and finish the run there.
            if self.get_parameter('stop_at_enable').value:
                sx = self.get_parameter('stop_at_x').value
                sy = self.get_parameter('stop_at_y').value
                sr = self.get_parameter('stop_at_radius').value
                rx, ry = self._robot_map_xy()
                if rx is not None and math.hypot(rx - sx, ry - sy) < sr:
                    self._say(f"robot reached the dumbbell area ({sx:+.2f},{sy:+.2f}) "
                              f"at ({rx:+.2f},{ry:+.2f}) - 100% WORLD COVERED, STOPPING")
                    self._stop_cleaner()
                    self._reached_stop = True
                    return True
            if self._sim_frozen():
                fz0 = time.time()
                self._say("SIM FROZEN (sim time not advancing) - coordinator "
                          "holding; watchdog and deadlines paused")
                while rclpy.ok() and self._sim_frozen():
                    time.sleep(1.0)
                held = time.time() - fz0
                t0 += held
                self._last_move_t = time.time()
                self._frozen_total += held
                self._say(f"sim resumed after {held:.0f}s frozen")
                continue
            idle = self._cleaner_idle()
            if idle is False:
                seen_busy = True
            elif idle is True and (seen_busy or self._sweep_counted(base_sweeps)):
                self._say(f"sweep FINISHED after {time.time() - t0:.0f}s")
                return True
            # WATCHDOG on MOTION, not a cap on work. A real full-house sweep
            # takes ~47min; the old fixed cap abandoned working sweeps and
            # desynced the two nodes for the rest of the run.
            still = time.time() - self._last_move_t
            if still > nopro:
                self._say(f"robot has not moved for {still:.0f}s "
                          f"({time.time() - t0:.0f}s into sweep) - abandoning")
                self._stop_cleaner()
                return False
            time.sleep(2.0)
        self._say(f"sweep hit absolute backstop {tmax:.0f}s - NOT a completion")
        self._stop_cleaner()
        return False

    def _run(self):
        if not self._wait_map():
            self._say("no /map arrived - aborting")
            return

        if self.get_parameter('vacuum_on').value:
            self._set_vacuum(True)
            self._say("vacuum ON")

        max_passes = self.get_parameter('max_passes').value
        plateau = self.get_parameter('coverage_plateau').value
        plateau_n = self.get_parameter('plateau_passes').value
        min_cov = self.get_parameter('min_coverage_pct').value
        settle = self.get_parameter('settle_time').value

        run_tmax = self.get_parameter('run_timeout').value
        t_start = time.time()
        self._run_deadline = t_start + run_tmax
        prev_cov = -1.0
        covered = False
        stalled_passes = 0
        prev_left = None
        prev_known = None
        abort_t0 = None
        i = 0
        while i < max_passes:
            i += 1
            if time.time() - t_start - self._frozen_total > run_tmax:
                self._say(f"whole-run backstop {run_tmax:.0f}s reached at "
                          f"{self._cov_pct:.1f}% driven - STOPPING. This is a "
                          f"TIMEOUT, NOT a completion.")
                break
            self._say(f"--- PASS {i}: re-segment + sweep (driven coverage "
                      f"{self._cov_pct:.1f}%, {self._known_cells} known cells) ---")
            if i == 1:
                # read the launcher's sweep speed so it is restored EXACTLY
                self._sweep_speed = self._get_nav_speed()
                p1 = self.get_parameter('pass1_speed').value
                if self._sweep_speed is not None and p1 < self._sweep_speed:
                    self._set_nav_speed(p1)
                else:
                    self._sweep_speed = None       # nothing to restore
            ok = self._do_one_sweep()
            if i == 1 and self._sweep_speed is not None:
                self._set_nav_speed(self._sweep_speed)
            time.sleep(settle)
            st = self._cleaner_stats()
            if st.get('aborted'):
                # the cleaner never got to plan (Nav2 not up): no floor was tried,
                # so this is NOT a pass and must never reach _decide. Run 114053
                # stopped at 1.4% 'nothing reachable left' on exactly this.
                abort_t0 = abort_t0 or time.time()
                waited = time.time() - abort_t0
                wmax = self.get_parameter('nav_wait_timeout').value
                if waited > wmax:
                    self._say(f"cleaner could not start a sweep for {waited:.0f}s "
                              f"({st['aborted']}) - STOPPING; NOT a coverage result")
                    break
                self._say(f"PASS {i} ABORTED before planning ({st['aborted']}) - "
                          f"not counted as a pass; retrying ({waited:.0f}/{wmax:.0f}s)")
                i -= 1
                time.sleep(self.get_parameter('abort_retry_s').value)
                continue
            abort_t0 = None
            # Robot reached the dumbbell stop point during this sweep: the world
            # is covered start-to-end, so END THE RUN here - no further pass.
            if self._reached_stop:
                self._say("*" * 60)
                self._say("*** 100% WORLD COVERED - reached the dumbbell, coverage complete ***")
                self._say("*" * 60)
                covered = True
                break
            failed = int(st.get('rooms_failed', 0) or 0)
            cov = self._cov_pct
            self._say(f"PASS {i} {'completed' if ok else 'DID NOT complete'}; "
                      f"driven coverage {max(prev_cov, 0.0):.1f}% -> {cov:.1f}%; "
                      f"rooms_failed={failed}")
            gain = (cov - prev_cov) if prev_cov >= 0 else None
            if gain is not None and gain < 0:
                # the free-floor denominator grew with the map: a drop is neither
                # progress nor a stall - it is a new baseline
                self._say(f"coverage DROPPED {prev_cov:.1f}% -> {cov:.1f}% "
                          f"(map grew) - not counted as progress or stall")
                gain = None
            if not self._cov_seen:
                gain = None
            # watchdog-aborted passes are NOT skipped any more: zero progress is
            # the strongest stall signal there is (R4: 5 aborted passes, no stop)
            stop, cov_done, stalled_passes, msgs = self._decide(
                i, gain, cov, st.get('planned', None),
                int(st.get('unattempted', 0) or 0), stalled_passes,
                failed, prev_left, self._known_cells, prev_known)
            for m in msgs:
                self._say(m)
            prev_cov = cov
            prev_left = st.get('left', None)
            prev_known = self._known_cells
            if stop:
                covered = cov_done
                break

        # The run is over for ANY reason - completion, watchdog, pass cap.
        # The robot must not keep driving after the coordinator exits.
        self._stop_cleaner()
        if self.get_parameter('vacuum_on').value:
            self._set_vacuum(False)

        total = time.time() - t_start
        if self._frozen_total > 0:
            self._say(f"of {total:.0f}s wall time the sim was FROZEN for "
                      f"{self._frozen_total:.0f}s (excluded from deadlines)")
        self._say("=" * 40)
        if covered:
            self._say("*" * 60)
            self._say(f"*** COVERAGE COMPLETE: 100% WORLD COVERED "
                      f"({self._known_cells} known cells mapped) ***")
            self._say("*" * 60)
            self._say(f"COVERAGE COMPLETE (genuine) in {total:.0f}s "
                      f"({int(total//60)}m{int(total%60):02d}s)")
        else:
            self._say(f"COVERAGE INCOMPLETE after {total:.0f}s "
                      f"({int(total//60)}m{int(total%60):02d}s): see the "
                      f"termination reason above (blocked/trapped, or the "
                      f"{max_passes}-pass / sweep backstop)")
        self._say(f"driven coverage: {self._cov_pct:.1f}%")
        self._say(f"final known cells: {self._known_cells}")
        self._say("COVERAGE RUN ENDED")
        self._say("=" * 40)


def main():
    rclpy.init()
    node = CoverageMapper()
    ex = MultiThreadedExecutor()
    ex.add_node(node)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
