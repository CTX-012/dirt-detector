#!/usr/bin/env python3
"""docker.py - three-phase autonomous docking.

Phase 1 NAVIGATE: Nav2 to a staging pose ~1.2 m in front of the dock.
Phase 2 ALIGN: rotate so the robot's rear points at the dock.
Phase 3 REVERSE: slow reverse until within contact distance.

    ros2 service call /dock std_srvs/srv/Trigger "{}"
    ros2 service call /undock std_srvs/srv/Trigger "{}"
"""
import math
import time
import threading

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist
from nav2_msgs.action import NavigateToPose
from std_msgs.msg import String
from std_srvs.srv import Trigger
import tf2_ros


class Docker(Node):
    def __init__(self):
        super().__init__('docker')
        p = self.declare_parameter
        p('global_frame', 'map')
        p('base_frame', 'base_footprint')
        p('dock_x', -4.19467)
        p('dock_y', -4.56598)
        p('dock_yaw', 1.55807)
        p('standoff', 1.5)
        p('dock_open_dir', -1.0)   # +1 dock opens +x, -1 opens -x (robot approaches this side)
        p('dock_depth', 0.30)
        p('reverse_speed', 0.05)
        p('align_speed', 0.4)
        p('align_tol', 0.05)
        p('reverse_timeout', 40.0)
        p('nav_timeout', 60.0)
        p('lateral_offset', 0.0)   # contacts are centered - no shift

        g = self.get_parameter
        self.gframe = g('global_frame').value
        self.bframe = g('base_frame').value
        self._busy = False

        self.cmd = self.create_publisher(Twist, '/cmd_vel_nav', 10)
        self.status = self.create_publisher(String, '/dock/status', 10)
        self.nav = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.tfb = tf2_ros.Buffer()
        tf2_ros.TransformListener(self.tfb, self)

        self.create_service(Trigger, '/dock', self._dock_cb)
        self.create_service(Trigger, '/undock', self._undock_cb)
        self.create_timer(2.0, self._pub_status)
        self.get_logger().info("docker ready. Dock: ros2 service call /dock std_srvs/srv/Trigger '{}'")

    def _dock_pose(self):
        return (self.get_parameter('dock_x').value,
                self.get_parameter('dock_y').value,
                self.get_parameter('dock_yaw').value)

    def _staging_pose(self):
        dx, dy, dyaw = self._dock_pose()
        so = self.get_parameter('standoff').value
        # The dock's backboard is at local -x, so it OPENS toward local +x,
        # which in world frame is the direction (cos(dyaw), sin(dyaw)).
        open_x = math.cos(dyaw)
        open_y = math.sin(dyaw)
        # staging sits 'standoff' out along the opening direction
        sx = dx + so * open_x
        sy = dy + so * open_y
        # robot must face BACK toward the dock so its rear points in:
        # heading points from staging toward dock = opposite of opening dir
        robot_yaw = math.atan2(-open_y, -open_x)
        return sx, sy, robot_yaw

    def _robot_pose(self):
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            x = tf.transform.translation.x
            y = tf.transform.translation.y
            q = tf.transform.rotation
            yaw = math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
            return x, y, yaw
        except Exception:
            return None

    def _dock_cb(self, req, resp):
        if self._busy:
            resp.success = False; resp.message = "already busy"; return resp
        threading.Thread(target=self._run_dock, daemon=True).start()
        resp.success = True; resp.message = "docking started"; return resp

    def _undock_cb(self, req, resp):
        if self._busy:
            resp.success = False; resp.message = "already busy"; return resp
        threading.Thread(target=self._run_undock, daemon=True).start()
        resp.success = True; resp.message = "undocking started"; return resp

    def _run_dock(self):
        self._busy = True
        try:
            dx, dy, dyaw = self._dock_pose()
            lateral = self.get_parameter('lateral_offset').value
            base_off = 0.28
            perp_x = math.cos(dyaw + math.pi/2)
            perp_y = math.sin(dyaw + math.pi/2)
            tx = dx + base_off * math.cos(dyaw) + lateral * perp_x
            ty = dy + base_off * math.sin(dyaw) + lateral * perp_y
            face = dyaw             # front points away from dock -> rear toward dock
            self._say("PHASE 1: navigating to dock")
            if not self._goto(tx, ty, face):
                self._say("DOCK FAILED - could not reach dock")
                return
            # PHASE 2: explicit in-place rotation so REAR faces the dock.
            # target heading points FROM dock TO robot -> front away -> rear at dock.
            self._say("PHASE 2: rotating rear toward dock")
            t0 = time.time()
            while rclpy.ok() and time.time() - t0 < 15.0:
                rp = self._robot_pose()
                if rp is None:
                    time.sleep(0.05); continue
                rx, ry, ryaw = rp
                target = math.atan2(ry - dy, rx - dx)
                err = math.atan2(math.sin(target - ryaw), math.cos(target - ryaw))
                if abs(err) < 0.05:
                    break
                t = Twist(); t.angular.z = max(-0.4, min(0.4, 1.0 * err))
                self.cmd.publish(t); time.sleep(0.05)
            self.cmd.publish(Twist())
            # PHASE 3: reverse straight back toward dock, abort if moving away.
            self._say("PHASE 3: reversing onto dock")
            rp = self._robot_pose()
            last_dist = math.hypot(rp[0]-dx, rp[1]-dy) if rp else 99
            t0 = time.time()
            while rclpy.ok() and time.time() - t0 < 12.0:
                rp = self._robot_pose()
                if rp:
                    rx, ry, _ = rp
                    d = math.hypot(rx - dx, ry - dy)
                    if d <= 0.04:
                        break
                    if d > last_dist + 0.15:
                        self._say("reverse moving away - stopping")
                        break
                    last_dist = min(last_dist, d)
                t = Twist(); t.linear.x = -0.04
                self.cmd.publish(t); time.sleep(0.05)
            self.cmd.publish(Twist())
            # extra push: reverse a fixed ~0.2m more to seat firmly on the plate
            self._say("PHASE 3b: extra reverse to seat")
            t0 = time.time()
            while rclpy.ok() and time.time() - t0 < 5.0:
                t = Twist(); t.linear.x = -0.04
                self.cmd.publish(t); time.sleep(0.05)
            self.cmd.publish(Twist())
            if self._verify_docked():
                self._say("DOCKED")
            else:
                self._say("DOCKED (approx)")
        except Exception as e:
            self._say(f"dock error: {e}")
        finally:
            self.cmd.publish(Twist()); self._busy = False

    def _run_undock(self):
        self._busy = True
        try:
            self._say("undocking: driving forward off dock")
            t0 = time.time()
            while rclpy.ok() and time.time() - t0 < 10.0:
                t = Twist(); t.linear.x = 0.08
                self.cmd.publish(t); time.sleep(0.05)
            self.cmd.publish(Twist())
            self._say("UNDOCKED")
        finally:
            self.cmd.publish(Twist()); self._busy = False

    def _goto(self, wx, wy, wyaw=0.0):
        self.nav.wait_for_server(timeout_sec=20.0)
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = self.gframe
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = float(wx)
        goal.pose.pose.position.y = float(wy)
        goal.pose.pose.orientation.z = math.sin(wyaw/2.0)
        goal.pose.pose.orientation.w = math.cos(wyaw/2.0)
        sf = self.nav.send_goal_async(goal)
        t0 = time.time()
        while rclpy.ok() and not sf.done():
            if time.time()-t0 > 10:
                return False
            time.sleep(0.05)
        if sf.result() is None or not sf.result().accepted:
            return False
        rf = sf.result().get_result_async()
        tmax = self.get_parameter('nav_timeout').value
        t0 = time.time()
        while rclpy.ok():
            if rf.done():
                return rf.result().status == GoalStatus.STATUS_SUCCEEDED
            if time.time()-t0 > tmax:
                self.cmd.publish(Twist())
                return False
            time.sleep(0.1)
        return False

    def _goto_staging(self):
        sx, sy, syaw = self._staging_pose()
        self.nav.wait_for_server(timeout_sec=20.0)
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = self.gframe
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = float(sx)
        goal.pose.pose.position.y = float(sy)
        goal.pose.pose.orientation.z = math.sin(syaw/2.0)
        goal.pose.pose.orientation.w = math.cos(syaw/2.0)
        sf = self.nav.send_goal_async(goal)
        t0 = time.time()
        while rclpy.ok() and not sf.done():
            if time.time()-t0 > 10: return False
            time.sleep(0.05)
        if sf.result() is None or not sf.result().accepted:
            return False
        rf = sf.result().get_result_async()
        tmax = self.get_parameter('nav_timeout').value
        t0 = time.time()
        while rclpy.ok():
            if rf.done():
                return rf.result().status == GoalStatus.STATUS_SUCCEEDED
            if time.time()-t0 > tmax:
                self.cmd.publish(Twist()); return False
            time.sleep(0.1)
        return False

    def _align(self):
        """Rotate so the robot's REAR points into the dock. The dock opens along
        its yaw direction, so to reverse in, the robot heading must equal dock_yaw
        (rear then points opposite, into the dock)."""
        dx, dy, dyaw = self._dock_pose()
        tol = 0.03                                   # ~1.7 deg - tight
        wmax = self.get_parameter('align_speed').value
        t0 = time.time()
        while rclpy.ok() and time.time()-t0 < 20.0:
            rp = self._robot_pose()
            if rp is None:
                time.sleep(0.05); continue
            rx, ry, ryaw = rp
            # robot REAR faces dock: heading = dock_yaw + pi (face away from dock)
            tgt = dyaw + math.pi
            err = math.atan2(math.sin(tgt-ryaw), math.cos(tgt-ryaw))
            if abs(err) <= tol:
                break
            t = Twist(); t.angular.z = max(-wmax, min(wmax, 1.2*err))
            self.cmd.publish(t); time.sleep(0.05)
        self.cmd.publish(Twist())

    def _reverse_in(self):
        """Closed-loop reverse: servo on the dock axis so heading/lateral errors
        are corrected continuously instead of growing over the blind stretch."""
        dx, dy, dyaw = self._dock_pose()
        depth = self.get_parameter('dock_depth').value
        spd = self.get_parameter('reverse_speed').value
        tmax = self.get_parameter('reverse_timeout').value
        ax, ay = math.cos(dyaw), math.sin(dyaw)      # dock approach axis (opening dir)
        t0 = time.time()
        while rclpy.ok() and time.time()-t0 < tmax:
            rp = self._robot_pose()
            if rp is None:
                time.sleep(0.05); continue
            rx, ry, ryaw = rp
            ex, ey = rx-dx, ry-dy
            along = ex*ax + ey*ay                     # remaining distance along axis
            cross = -ex*ay + ey*ax                    # signed lateral offset
            tgt = dyaw + math.pi
            yaw_err = math.atan2(math.sin(ryaw-tgt), math.cos(ryaw-tgt))
            # stop when actually at the dock (all three small)
            self.get_logger().info(f"  rev: along={along:.2f} cross={cross:.2f} yaw_err={math.degrees(yaw_err):.0f}")
            if abs(along) <= depth and abs(cross) < 0.05 and abs(yaw_err) < 0.08:
                break
            # safety: if moving AWAY from the dock, abort (bad sign/divergence)
            if along > 2.5:
                self._say(f"reverse diverging (along={along:.2f}) - aborting")
                break
            t = Twist()
            t.linear.x = -abs(spd)                    # reverse: rear backs into dock
            # under reverse, steering sign flips: this drives cross->0 and yaw->dock_yaw
            t.angular.z = max(-0.3, min(0.3, 0.6*yaw_err + 0.4*cross))
            self.cmd.publish(t); time.sleep(0.05)
        self.cmd.publish(Twist())

    def _verify_docked(self):
        rp = self._robot_pose()
        if rp is None:
            return False
        rx, ry, ryaw = rp
        dx, dy, dyaw = self._dock_pose()
        dist = math.hypot(rx-dx, ry-dy)
        yaw_err = abs(math.atan2(math.sin(ryaw-(dyaw+math.pi)), math.cos(ryaw-(dyaw+math.pi))))
        ok = dist < 0.45          # ~15cm, ~7deg
        self._say(f"dock check: dist={dist:.3f}m yaw_err={math.degrees(yaw_err):.1f}deg "
                  f"-> {'DOCKED' if ok else 'MISALIGNED'}")
        return ok

    def _say(self, msg):
        self.get_logger().info(msg)
        m = String(); m.data = msg
        self.status.publish(m)

    def _pub_status(self):
        m = String()
        m.data = "busy" if self._busy else "idle"
        self.status.publish(m)


def main():
    rclpy.init()
    node = Docker()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
