#!/usr/bin/env python3
"""coverage_planner.py — autonomous boustrophedon coverage cleaning for NOVA."""
import math, threading, time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
import numpy as np
from nav_msgs.msg import OccupancyGrid, Path
from geometry_msgs.msg import PoseStamped
from std_srvs.srv import SetBool
from nav2_msgs.action import NavigateToPose
from nova_interfaces.srv import StartCleaning


class CoveragePlanner(Node):
    def __init__(self):
        super().__init__('coverage_planner')
        self.cb = ReentrantCallbackGroup()
        self.declare_parameter('robot_radius', 0.25)
        self.inflate = self.get_parameter('robot_radius').value
        self.map = None
        self.create_subscription(OccupancyGrid, '/map', self._map_cb, 1, callback_group=self.cb)
        self.vac_client = self.create_client(SetBool, '/vacuum/set_state', callback_group=self.cb)
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose', callback_group=self.cb)
        self.path_pub = self.create_publisher(Path, '/coverage_path', 1)
        self.srv = self.create_service(StartCleaning, '/start_cleaning', self._on_start, callback_group=self.cb)
        self._busy = False
        self.get_logger().info("coverage_planner ready. Call /start_cleaning to begin.")

    def _map_cb(self, msg): self.map = msg

    def _w2c(self, x, y):
        mx = int((x - self.map.info.origin.position.x) / self.map.info.resolution)
        my = int((y - self.map.info.origin.position.y) / self.map.info.resolution)
        return mx, my

    def _is_free(self, x, y):
        if self.map is None: return False
        res = self.map.info.resolution
        w, h = self.map.info.width, self.map.info.height
        margin = int(math.ceil(self.inflate / res))
        cx, cy = self._w2c(x, y)
        for dy in range(-margin, margin + 1):
            for dx in range(-margin, margin + 1):
                gx, gy = cx + dx, cy + dy
                if gx < 0 or gy < 0 or gx >= w or gy >= h: return False
                v = self.map.data[gy * w + gx]
                if v < 0 or v >= 50: return False
        return True

    def _generate_lanes(self, min_x, min_y, max_x, max_y, spacing):
        wps = []; y = min_y; direction = 1; step = spacing * 0.5
        while y <= max_y:
            xs = np.arange(min_x, max_x, step)
            if direction < 0: xs = xs[::-1]
            pts = [(x, y) for x in xs if self._is_free(x, y)]
            if pts:
                out = [pts[0]]
                if len(pts) > 1: out.append(pts[-1])
                wps.extend(out)
            y += spacing; direction *= -1
        return wps

    def _on_start(self, req, resp):
        if self._busy:
            resp.accepted = False; resp.message = "already cleaning"; return resp
        if self.map is None:
            resp.accepted = False; resp.message = "no map received yet"; return resp
        spacing = req.lane_spacing if req.lane_spacing > 0.01 else 0.2
        wps = self._generate_lanes(req.min_x, req.min_y, req.max_x, req.max_y, spacing)
        if not wps:
            resp.accepted = False; resp.message = "no free waypoints in area"; return resp
        self.get_logger().info(f"generated {len(wps)} waypoints; starting")
        self._publish_path(wps)
        threading.Thread(target=self._run, args=(wps,), daemon=True).start()
        resp.accepted = True; resp.message = f"cleaning started: {len(wps)} waypoints"; return resp

    def _publish_path(self, wps):
        path = Path(); path.header.frame_id = 'map'
        path.header.stamp = self.get_clock().now().to_msg()
        for x, y in wps:
            ps = PoseStamped(); ps.header.frame_id = 'map'
            ps.pose.position.x = float(x); ps.pose.position.y = float(y)
            ps.pose.orientation.w = 1.0; path.poses.append(ps)
        self.path_pub.publish(path)

    def _set_vac(self, on):
        if not self.vac_client.wait_for_service(timeout_sec=3.0):
            self.get_logger().warn("vacuum service unavailable"); return
        r = SetBool.Request(); r.data = on
        self.vac_client.call_async(r)
        self.get_logger().info(f"vacuum {'ON' if on else 'OFF'}")

    def _run(self, wps):
        self._busy = True; self._set_vac(True)
        if not self.nav_client.wait_for_server(timeout_sec=10.0):
            self.get_logger().error("Nav2 not available"); self._set_vac(False); self._busy = False; return
        total = len(wps)
        for i, (x, y) in enumerate(wps):
            g = NavigateToPose.Goal(); g.pose.header.frame_id = 'map'
            g.pose.header.stamp = self.get_clock().now().to_msg()
            g.pose.pose.position.x = float(x); g.pose.pose.position.y = float(y)
            g.pose.pose.orientation.w = 1.0
            sf = self.nav_client.send_goal_async(g); self._wait(sf)
            gh = sf.result()
            if not gh.accepted:
                self.get_logger().warn(f"wp {i+1}/{total} rejected"); continue
            rf = gh.get_result_async(); self._wait(rf)
            self.get_logger().info(f"wp {i+1}/{total} done")
        self._set_vac(False)
        self.get_logger().info("*** CLEANING COMPLETE ***")
        self._busy = False

    def _wait(self, fut):
        while rclpy.ok() and not fut.done(): time.sleep(0.05)


def main():
    rclpy.init()
    node = CoveragePlanner()
    ex = MultiThreadedExecutor(); ex.add_node(node)
    try: ex.spin()
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
