#!/usr/bin/env python3
"""room_cleaner.py - clean the world ROOM BY ROOM (lawnmower sweep per room)."""
import json
import math
import re
import subprocess
import threading
import time

import numpy as np
import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.qos import (QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy,
                       QoSHistoryPolicy)

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist, PoseStamped
from nav2_msgs.action import NavigateToPose, NavigateThroughPoses, ComputePathToPose
from nav2_msgs.srv import ClearEntireCostmap
from nav_msgs.msg import OccupancyGrid
from sensor_msgs.msg import Range
from rclpy.qos import qos_profile_sensor_data
from std_msgs.msg import String
from std_srvs.srv import SetBool, Trigger
import tf2_ros


class RoomCleaner(Node):
    def __init__(self):
        super().__init__('room_cleaner')
        p = self.declare_parameter
        p('global_frame', 'map')
        p('base_frame', 'base_footprint')
        p('world_name', 'default')
        p('model_prefix', 'dirt_')
        p('lane_spacing', 0.55)
        p('step_along_lane', 0.50)
        p('robot_radius', 0.22)
        p('nav_timeout', 20.0)
        p('max_retries', 1)
        p('room_margin', 0.15)
        p('dirt_conf', 0.30)
        p('cleaned_tol', 0.70)
        p('remove_tol', 0.80)
        p('roller_offset', 0.21)
        p('patch_radius', 0.25)
        p('clean_stop_enable', False)   # stop early once floor appears clean
        p('no_dirt_chunks', 2)         # chunks with no new dirt -> floor clean
        p('ring_step', 0.05)
        p('ring_inner', 0.03)
        p('ring_tol', 0.03)
        p('sweep_omega', 0.6)
        p('k_radial', 2.0)
        p('v_max', 0.10)
        p('w_max', 0.8)
        p('sweep_timeout', 90.0)
        p('phantom_radius', 0.60)     # blacklist disc around a false site
        p('phantom_cooldown', 0.0)    # 0 = blacklisted for the rest of the run
        p('spiral_lookahead', 0.20)   # m ahead of the roller to test
        p('spiral_lethal', 99)        # costmap cost treated as lethal
        p('wp_max_cost', 90)         # costmap cost at/above which a waypoint is
                                     # UNDRIVABLE (inscribed): the planner accepts it,
                                     # RPP refuses to drive it -> 'chunk stalled' x 90 s
        p('max_consec_chunk_fail', 5)  # abort only after N chunks fail IN A ROW
        p('per_wp_timeout', 10.0)      # absolute cap per waypoint (was nav_timeout=20)
        p('wp_fail_limit', 3)          # failed passes before a waypoint is
                                       # PROVEN unreachable and dropped
        p('wp_fail_cell', 0.20)        # m, quantisation of that memory
        p('retry_plan_frac', 0.5)       # retry only if plan >= this x the largest plan
        p('retry_total_budget', 1200.0) # s, run-wide cap on the deferred-retry stage
        p('chunk_poses', 40)            # poses per NavigateThroughPoses chunk
        p('skip_radius', 1.0)           # m; a stuck MOP-UP chunk skips only the poses this close
                                        # to where it stuck, then drives on (was: the whole chunk)
        p('orient_plans', False)       # start each pass at the nearer end. OFF: measured in
                                       # R5, reversed plans + 1 m poses cut the main-sweep rate
                                       # from 0.95-1.03 to 0.68 %/min (not separable per change)
        p('lane_scan_res', 0.50)        # m, row sampling; pose spacing is step_along_lane
        p('deferred_retry_budget', 600.0)  # s, cap on the deferred-chunk retry stage
        p('chunk_no_progress', 90.0)   # s without closing on the chunk end = give up
        p('chunk_progress_eps', 0.30)  # m of closing that counts as progress
        p('additive_passes', True)    # later passes skip already-driven floor
        p('driven_cell', 0.10)        # m, resolution of the driven memory
        p('stall_dist', 0.05)         # m of TF progress that counts as moving
        p('stall_yaw', 0.25)          # rad; a spiral pivots in place - that IS progress
        p('climb_delta', 0.05)         # m: (front-rear cliff) above level baseline = nose lifting (~6 deg)
        p('climb_block_radius', 0.50)  # m: plans avoid this radius around a caught climb
        p('climb_backoff', 0.25)       # m: straight reverse after a climb is caught
        p('freeze_timeout', 3.0)       # s (wall) with sim time not advancing = frozen sim
        p('stall_timeout', 15.0)      # s without progress = stalled
        p('escape_probe', 0.60)       # m to probe when looking for a way out

        g = self.get_parameter
        self.gframe = g('global_frame').value
        self.bframe = g('base_frame').value
        self.world = g('world_name').value
        self.prefix = g('model_prefix').value
        self.roller_off = g('roller_offset').value

        self.map = None
        self.rooms = []
        self._dirt_seen = []
        self._known = []
        self._failed = []      # [(x,y,t)] sites with no sim model = phantoms
        self._last_move_t = time.time()
        self._last_move_xy = None
        self._last_move_yaw = 0.0
        self._gcm = None       # global costmap (map frame)
        self._driven = set()   # quantised map cells the robot has driven
        self._cleaned = []
        self._busy = False
        self._stop = False
        self._t0 = 0.0
        self._patches = 0
        self._rooms_done = 0
        self._rooms_failed = 0
        # last sweep's plan accounting - the REAL completion signal.
        # planned == 0 means: no un-driven reachable floor left to visit.
        self._last_planned = None
        self._last_reached = 0
        self._last_unattempted = 0     # planned, un-driven, never sent this pass
        self._last_left = None         # un-driven, not retired, AFTER this pass's strikes
        self._consumed = 0             # poses of the last _drive() Nav2 actually passed
        self._last_abort = None        # why the last sweep could not start (None = it did)
        self._chunk_consumed = 0
        self._sweeps_done = 0          # bumped BEFORE busy clears, so the coordinator
                                       # sees a sweep that ended faster than its poll
        # per-waypoint failure memory. _plannable() only proves a PATH
        # EXISTS; it does not prove the robot can get there. A waypoint the
        # robot has failed to reach on N separate passes is unreachable in
        # practice, and must leave the plan or 'planned == 0' is impossible.
        self._wp_fail = {}
        self._max_plan = 0         # largest plan seen this run (retry gating)
        self._fz_last_ns = None    # frozen-sim detector state
        self._fz_adv_wall = 0.0
        # climb guard (cliff sensors). The lidar plane is 0.363 m up, so lower
        # props are invisible and the robot can ride up onto them. Measured in
        # R4: once mounted (pitch -47 deg) the wheels spin at the commanded rate
        # and the chassis does not move - so a climb must be caught at ONSET.
        self._cliff = {}           # sensor -> (range m, wall time)
        self._cliff_base = None    # level (front - rear) baseline, self-calibrated
        self._cliff_calib = []
        self._climb_hits = 0
        self._blocked = []         # map-frame spots where a climb was caught
        self._retry_spent = 0.0    # s of deferred retry spent this run

        latched = QoSProfile(depth=1, history=QoSHistoryPolicy.KEEP_LAST,
                             reliability=QoSReliabilityPolicy.RELIABLE,
                             durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(OccupancyGrid, '/map', self._map_cb, latched)
        self.create_subscription(String, '/rooms/list', self._rooms_cb, latched)
        self.create_subscription(String, '/dirt/map_points', self._dirt_cb, 10)
        # global costmap is in the MAP frame; local_costmap is in odom and
        # would not match the map-frame poses used throughout this node.
        self.create_subscription(OccupancyGrid, '/global_costmap/costmap',
                                 self._gcm_cb, latched)

        self.cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        for k in ('fl', 'fr', 'rl', 'rr'):
            self.create_subscription(Range, '/range/cliff_' + k,
                                     lambda m, k=k: self._cliff_cb(k, m),
                                     qos_profile_sensor_data)
        self.status = self.create_publisher(String, '/rooms/progress', 10)
        self.nav = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.ntp = ActionClient(self, NavigateThroughPoses, '/navigate_through_poses')
        self.planner = ActionClient(self, ComputePathToPose, '/compute_path_to_pose')
        self.vac = self.create_client(SetBool, '/vacuum/set_state')
        self.clr_g = self.create_client(ClearEntireCostmap,
                                        '/global_costmap/clear_entirely_global_costmap')
        self.clr_l = self.create_client(ClearEntireCostmap,
                                        '/local_costmap/clear_entirely_local_costmap')
        self.tfb = tf2_ros.Buffer()
        tf2_ros.TransformListener(self.tfb, self)

        self.create_service(Trigger, '/clean_rooms', self._on_start)
        self.create_service(Trigger, '/stop_rooms', self._on_stop)
        self.create_service(Trigger, '/rooms_status', self._on_status)
        self.create_timer(1.0, self._pub_status)
        self.create_timer(0.5, self._stall_tick)
        self.get_logger().info("room_cleaner ready. Start: /clean_rooms")

    def _map_cb(self, m):
        self.map = m

    def _rooms_cb(self, m):
        try:
            self.rooms = json.loads(m.data)
        except Exception:
            pass

    def _dirt_cb(self, m):
        try:
            self._dirt_seen = json.loads(m.data)
        except Exception:
            return
        conf = self.get_parameter('dirt_conf').value
        tol = self.get_parameter('cleaned_tol').value
        for d in self._dirt_seen:
            if d.get('conf', 0) < conf:
                continue
            x, y = float(d['x']), float(d['y'])
            if any(math.hypot(cx - x, cy - y) <= tol for cx, cy in self._cleaned):
                continue
            if any(math.hypot(kx - x, ky - y) <= 0.30 for kx, ky in self._known):
                continue
            if self._is_phantom(x, y):
                continue        # already serviced here and found nothing
            self._known.append((x, y))
            self.get_logger().info(f"   remembered dirt at ({x:+.2f},{y:+.2f})")

    def _on_start(self, req, resp):
        if self._busy:
            resp.success, resp.message = False, "already running"
            return resp
        if self.map is None:
            resp.success, resp.message = False, "no /map yet"
            return resp
        if not self.rooms:
            resp.success, resp.message = False, "no /rooms/list"
            return resp
        self._stop = False
        threading.Thread(target=self._run, daemon=True).start()
        resp.success, resp.message = True, f"cleaning {len(self.rooms)} rooms"
        return resp

    def _on_status(self, req, resp):
        # success == IDLE. A service round-trip is reliable; the
        # /rooms/progress topic was never observed by coverage_mapper.
        resp.success = not self._busy
        resp.message = json.dumps({
            'busy': self._busy, 'rooms_done': self._rooms_done,
            'rooms_failed': self._rooms_failed, 'patches': self._patches,
            'planned': self._last_planned, 'reached': self._last_reached,
            'unattempted': self._last_unattempted,
            'left': self._last_left,
            'aborted': self._last_abort,
            'sweeps_done': self._sweeps_done})
        return resp

    def _on_stop(self, req, resp):
        self._stop = True
        resp.success, resp.message = True, "stopping"
        return resp

    def _robot_xy(self):
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            return tf.transform.translation.x, tf.transform.translation.y
        except Exception:
            return 0.0, 0.0

    def _robot_pose(self):
        x, y = self._robot_xy()
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            q = tf.transform.rotation
            yaw = math.atan2(2 * (q.w * q.z + q.x * q.y),
                             1 - 2 * (q.y * q.y + q.z * q.z))
        except Exception:
            yaw = 0.0
        return x, y, yaw

    def _free_at(self, x, y):
        if self._blocked and self._near_blocked((x, y)):
            return False              # a prop the lidar cannot see was met here
        if self.map is None:
            return False
        info = self.map.info
        res = info.resolution
        gx = int((x - info.origin.position.x) / res)
        gy = int((y - info.origin.position.y) / res)
        r = max(1, int(self.get_parameter('robot_radius').value / res))
        data = self.map.data
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                nx, ny = gx + dx, gy + dy
                if nx < 0 or ny < 0 or nx >= info.width or ny >= info.height:
                    return False
                v = data[ny * info.width + nx]
                if v < 0 or v > 50:
                    return False
        return True

    def _wait(self, fut, t):
        t0 = time.time()
        while rclpy.ok() and not fut.done():
            if time.time() - t0 > t:
                return False
            time.sleep(0.05)
        return fut.done()

    def _set_vac(self, on):
        if not self.vac.wait_for_service(timeout_sec=2.0):
            return
        req = SetBool.Request()
        req.data = bool(on)
        self.vac.call_async(req)

    def _nudge(self):
        """Break a stall by reversing briefly, then clearing costmaps."""
        t = Twist()
        t.linear.x = -0.12
        for _ in range(12):
            if self._stop:
                break
            self.cmd.publish(t)
            time.sleep(0.1)
        self.cmd.publish(Twist())
        self._clear_costmaps()
        time.sleep(0.3)

    def _clear_costmaps(self):
        for c in (self.clr_g, self.clr_l):
            if c.wait_for_service(timeout_sec=1.0):
                c.call_async(ClearEntireCostmap.Request())
        time.sleep(0.5)

    def _room_waypoints(self, room):
        m = self.get_parameter('room_margin').value
        lane = self.get_parameter('lane_spacing').value
        step = self.get_parameter('step_along_lane').value
        x0, x1 = room['min_x'] + m, room['max_x'] - m
        y0, y1 = room['min_y'] + m, room['max_y'] - m
        # clamp to the actual map extent, inset by a full robot radius, so the
        # last lane column never lands on/over the map edge (planner worldToMap
        # rejects off-grid goals -> hundreds of errors + stalls).
        if self.map is not None:
            info = self.map.info
            rr = self.get_parameter('robot_radius').value
            mx0 = info.origin.position.x + rr
            my0 = info.origin.position.y + rr
            mx1 = info.origin.position.x + info.width * info.resolution - rr
            my1 = info.origin.position.y + info.height * info.resolution - rr
            x0, x1 = max(x0, mx0), min(x1, mx1)
            y0, y1 = max(y0, my0), min(y1, my1)
        if x1 <= x0 or y1 <= y0:
            return []
        scan = self.get_parameter('lane_scan_res').value
        pts = []
        y = y0
        flip = False
        while y <= y1 + 1e-6:
            # Sample the row at `scan` (the old pose spacing, so the candidate
            # points and every free fragment's extent are unchanged), then keep
            # one pose per `step` metres inside each contiguous free run.
            row, run = [], []
            x = x0
            while x <= x1 + 1e-6:
                if self._free_at(x, y) and not self._is_driven(x, y):
                    run.append((x, y))
                elif run:
                    row.extend(self._thin_run(run, step))
                    run = []
                x += scan
            if run:
                row.extend(self._thin_run(run, step))
            if flip:
                row.reverse()
            pts.extend(row)
            flip = not flip
            y += lane
        return pts

    @staticmethod
    def _thin_run(run, step):
        """Keep a contiguous free run's first and last samples, plus one sample
        per `step` metres between them. Nav2's RemovePassedGoals only drops a
        pose once the robot is within 0.7 m of it, and poses are visited in
        order, so every interior pose is a hard constraint. Measured: 0.5 m
        spacing gave 3.8-4.1x path inflation on the sweep."""
        if len(run) <= 2:
            return list(run)
        out = [run[0]]
        for q in run[1:-1]:
            if abs(q[0] - out[-1][0]) >= step - 1e-6:
                out.append(q)
        last = run[-1]
        if len(out) > 1 and abs(last[0] - out[-1][0]) < 0.5 * step - 1e-6:
            out[-1] = last      # don't stack two poses at the fragment end
        else:
            out.append(last)
        return out

    @staticmethod
    def _orient_plan(good, robot_xy):
        """A serpentine plan is valid in either direction: start from the end
        nearer the robot rather than always from the (min-x, min-y) corner,
        which forced a cross-house transit at the start of every pass."""
        if len(good) < 2 or robot_xy is None:
            return good
        rx, ry = robot_xy
        d0 = math.hypot(good[0][0] - rx, good[0][1] - ry)
        d1 = math.hypot(good[-1][0] - rx, good[-1][1] - ry)
        return list(reversed(good)) if d1 < d0 else good

    def _retry_allowed(self, plan_len):
        """In-pass deferred retry pays on the real sweep passes, not on mop-up
        passes. R1: after PASS 3, retries recovered 15 waypoints in ~3400 s -
        and the cross-pass failure memory re-attempts those next pass anyway."""
        frac = self.get_parameter('retry_plan_frac').value
        cap = self.get_parameter('retry_total_budget').value
        if self._retry_spent >= cap:
            return False, f"run-wide retry budget {int(cap)}s already spent"
        if self._max_plan > 0 and plan_len < frac * self._max_plan:
            return False, (f"mop-up pass ({plan_len} poses < {frac:.0%} of the "
                           f"largest plan, {self._max_plan}); next pass re-attempts them")
        return True, ""

    def _refused(self, pts):
        """Poses the planner refuses NOW, from where the robot is. One refused pose
        fails a whole NavigateThroughPoses chunk and every pose behind it."""
        return [q for q in pts if not self._plannable(q[0], q[1])]

    def _stuck_cluster(self, pts, k):
        """pts[k] - the pose Nav2 could not get to - and the poses after it within
        skip_radius of it: the one spot the robot cannot get into."""
        if not 0 <= k < len(pts):
            return []
        r = self.get_parameter('skip_radius').value
        tx, ty = pts[k]
        return [q for q in pts[k:] if math.hypot(q[0] - tx, q[1] - ty) <= r]

    def _plannable(self, wx, wy):
        """OPTION 1: ask Nav2's planner for a path; keep the waypoint only if reachable."""
        goal = ComputePathToPose.Goal()
        goal.goal.header.frame_id = self.gframe
        goal.goal.header.stamp = self.get_clock().now().to_msg()
        goal.goal.pose.position.x = float(wx)
        goal.goal.pose.position.y = float(wy)
        goal.goal.pose.orientation.w = 1.0
        goal.use_start = False
        sf = self.planner.send_goal_async(goal)
        if not self._wait(sf, 5) or sf.result() is None or not sf.result().accepted:
            return False
        rf = sf.result().get_result_async()
        if not self._wait(rf, 5) or rf.result() is None:
            return False
        res = rf.result()
        return (res.status == GoalStatus.STATUS_SUCCEEDED and
                len(res.result.path.poses) > 0)

    def _cliff_cb(self, k, m):
        """Store every cliff reading; evaluate once per frame, on 'fl'."""
        self._cliff[k] = (float(m.range), time.time())
        if k != 'fl' or len(self._cliff) < 4:
            return
        now = time.time()
        if any(now - t > 0.5 for _, t in self._cliff.values()):
            return                                    # stale: cannot judge
        d = self._cliff_pitch_proxy()
        if self._cliff_base is None:
            self._cliff_calib.append(d)
            if len(self._cliff_calib) >= 30:          # ~2 s, robot level on the floor
                cal = sorted(self._cliff_calib)
                self._cliff_base = cal[len(cal) // 2]
                self.get_logger().info(
                    f"cliff baseline (front - rear) = {self._cliff_base:+.3f} m")
            return
        self._climb_hits = self._climb_hits + 1 if self._cliff_signal(d) else 0

    def _cliff_pitch_proxy(self):
        """(front - rear) cliff range: grows as the nose lifts."""
        c = self._cliff
        return (c['fl'][0] + c['fr'][0]) / 2.0 - (c['rl'][0] + c['rr'][0]) / 2.0

    def _cliff_signal(self, d):
        front = min(self._cliff['fl'][0], self._cliff['fr'][0])
        rear = max(self._cliff['rl'][0], self._cliff['rr'][0])
        lifted = d - self._cliff_base > self.get_parameter('climb_delta').value
        lost = front >= 0.29 and rear < 0.20      # front off the floor, rear on it
        return lifted or lost

    def _climb_detected(self):
        """Two consecutive abnormal frames (~130 ms at 15.6 Hz)."""
        return self._cliff_base is not None and self._climb_hits >= 2

    def _near_blocked(self, p):
        r = self.get_parameter('climb_block_radius').value
        return any(math.hypot(p[0] - bx, p[1] - by) < r for bx, by in self._blocked)

    def _back_off_climb(self):
        """Stop and reverse straight back. The costmap-behind check is NOT used:
        nose-up, the tilted scan hits the floor behind and paints obstacles that
        are not there (measured in R4). The rear cliff sensors guard it instead."""
        x, y, yaw = self._robot_pose()
        self._blocked.append((x + 0.35 * math.cos(yaw), y + 0.35 * math.sin(yaw)))
        self.cmd.publish(Twist())
        time.sleep(0.3)                  # let the velocity smoother decay to zero
        t = Twist(); t.linear.x = -0.12
        for _ in range(int(self.get_parameter('climb_backoff').value / 0.12 / 0.05)):
            if self._stop:
                break
            if max(self._cliff.get('rl', (0.0, 0))[0], self._cliff.get('rr', (0.0, 0))[0]) >= 0.29:
                self.get_logger().warn("   climb back-off halted: floor lost behind")
                break
            self.cmd.publish(t); time.sleep(0.05)
        self.cmd.publish(Twist())
        time.sleep(0.3)
        self._climb_hits = 0
        level = (self._cliff_base is not None and len(self._cliff) == 4
                 and not self._cliff_signal(self._cliff_pitch_proxy()))
        self.get_logger().warn(
            f"   CLIMB caught at ({x:+.2f},{y:+.2f}) - backed off, "
            f"{'LEVEL again' if level else 'STILL TILTED'}; "
            f"{len(self._blocked)} blocked spot(s) now avoided by plans")
        self._reset_stall()
        return level

    def _sim_now_ns(self):
        return self.get_clock().now().nanoseconds

    def _sim_frozen(self):
        """True once simulation time has not advanced for freeze_timeout wall
        seconds: a paused Gazebo, or a dead /clock bridge. While frozen, TF is
        frozen too, so every motion check reads exactly 0.000 m and Nav2 aborts
        goals off a frozen costmap - none of which is a real failure. Evaluated
        lazily against wall time, because a sim-time timer stops firing too."""
        now_ns, wall = self._sim_now_ns(), time.time()
        if self._fz_last_ns is None or now_ns != self._fz_last_ns:
            self._fz_last_ns, self._fz_adv_wall = now_ns, wall
            return False
        return wall - self._fz_adv_wall > self.get_parameter('freeze_timeout').value

    def _drive(self, pts, allow_dirt=True):
        """_drive_through, re-sent when a sim freeze disrupted it. Measured in
        R3: a pause made 57 reachable waypoints 'fail' three passes running and
        retired them - a freeze must never count as a failure or bank a strike.
        Re-sends only the poses Nav2 had not yet passed, so no backtracking.
        Leaves self._consumed = poses of the ORIGINAL pts that Nav2 passed."""
        n0 = len(pts)
        while True:
            r = self._drive_through(pts, allow_dirt)
            self._consumed = min(n0, n0 - len(pts) + self._chunk_consumed)
            if r != 'frozen':
                return r
            if self._stop:
                return 'fail'
            rem = self._chunk_remaining
            if rem is not None and 0 < rem < len(pts):
                pts = pts[-rem:]

    def _drive_through(self, pts, allow_dirt=True):
        """OPTION 2: drive a whole lane as ONE continuous path (no stop-start)."""
        self._chunk_consumed = 0
        if not pts:
            return 'ok'
        goal = NavigateThroughPoses.Goal()
        for (wx, wy) in pts:
            ps = PoseStamped()
            ps.header.frame_id = self.gframe
            ps.header.stamp = self.get_clock().now().to_msg()
            ps.pose.position.x = float(wx)
            ps.pose.position.y = float(wy)
            ps.pose.orientation.w = 1.0
            goal.poses.append(ps)
        self._chunk_remaining = None
        def _fb(fmsg):
            try:
                self._chunk_remaining = int(
                    fmsg.feedback.number_of_poses_remaining)
            except Exception:
                pass
        sf = self.ntp.send_goal_async(goal, feedback_callback=_fb)
        if not self._wait(sf, 10) or sf.result() is None or not sf.result().accepted:
            return 'fail'
        gh = sf.result()
        rf = gh.get_result_async()
        self._reset_stall()
        # A 40-waypoint chunk used to allow nav_timeout(20) x 40 = 800s, and a
        # failed chunk was retried 3x - measured at 959s, 67% of a whole sweep.
        tmax = max(self.get_parameter('nav_timeout').value,
                   self.get_parameter('per_wp_timeout').value * max(1, len(pts)))
        nopro = self.get_parameter('chunk_no_progress').value
        best_rem = None
        prog_t = time.time()
        t0 = time.time()
        froze = False
        while rclpy.ok() and not self._stop:
            if self._sim_frozen():
                froze = True
                fz0 = time.time()
                self.get_logger().warn(
                    "   SIM FROZEN (sim time not advancing) - holding; nothing "
                    "counts as a failure while frozen")
                while rclpy.ok() and not self._stop and self._sim_frozen():
                    time.sleep(0.5)
                held = time.time() - fz0
                self.get_logger().info(f"   sim resumed after {held:.0f}s frozen")
                prog_t += held
                t0 += held
                self._reset_stall()
                continue
            if self._climb_detected():
                try:
                    gh.cancel_goal_async()
                except Exception:
                    pass
                self._back_off_climb()
                return 'climb'
            # PROGRESS = poses actually consumed, from Nav2's own feedback.
            # Straight-line distance to the chunk END is NOT a progress measure:
            # a serpentine chunk drives AWAY from its endpoint for most lanes.
            rem = self._chunk_remaining
            if rem is not None and (best_rem is None or rem < best_rem):
                best_rem = rem
                prog_t = time.time()
                self._chunk_consumed = max(0, len(pts) - rem)
            if time.time() - prog_t > nopro:
                try:
                    gh.cancel_goal_async()
                except Exception:
                    pass
                self.cmd.publish(Twist())
                self.get_logger().warn(
                    f"   chunk stalled: {best_rem if best_rem is not None else '?'}"
                    f"/{len(pts)} poses left, none consumed in {nopro:.0f}s "
                    f"- giving up on it")
                time.sleep(0.2)
                return 'fail'
            if allow_dirt and self._pick_dirt() is not None:
                try:
                    gh.cancel_goal_async()
                except Exception:
                    pass
                self.cmd.publish(Twist())
                time.sleep(0.2)
                return 'dirt'
            if rf.done():
                if rf.result().status == GoalStatus.STATUS_SUCCEEDED:
                    self._chunk_consumed = len(pts)
                    return 'ok'
                # Nav2 aborts goals during a freeze (frozen costmap -> "collision
                # ahead" -> controller patience exceeded): not a real failure.
                return 'frozen' if froze else 'fail'
            if self._stalled_s() > self.get_parameter('stall_timeout').value:
                # do not sit here for nav_timeout * len(pts) (800s for a chunk)
                try:
                    gh.cancel_goal_async()
                except Exception:
                    pass
                self.cmd.publish(Twist())
                time.sleep(0.2)
                return 'stall'
            if time.time() - t0 > tmax:
                self.cmd.publish(Twist())
                return 'fail'
            time.sleep(0.1)
        return 'fail'

    def _goto(self, wx, wy, allow_dirt=True):
        tmax = self.get_parameter('nav_timeout').value
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = self.gframe
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = float(wx)
        goal.pose.pose.position.y = float(wy)
        goal.pose.pose.orientation.w = 1.0
        sf = self.nav.send_goal_async(goal)
        if not self._wait(sf, 10) or sf.result() is None or not sf.result().accepted:
            return 'fail'
        rf = sf.result().get_result_async()
        self._reset_stall()
        t0 = time.time()
        while rclpy.ok() and not self._stop:
            if allow_dirt and self._pick_dirt() is not None:
                self.cmd.publish(Twist())
                time.sleep(0.2)
                return 'dirt'
            if rf.done():
                return 'ok' if rf.result().status == GoalStatus.STATUS_SUCCEEDED else 'fail'
            if self._stalled_s() > self.get_parameter('stall_timeout').value:
                self.cmd.publish(Twist())
                time.sleep(0.2)
                return 'stall'
            if time.time() - t0 > tmax:
                self.cmd.publish(Twist())
                return 'fail'
            time.sleep(0.1)
        return 'fail'

    def _gcm_cb(self, m):
        self._gcm = m

    def _cost_at(self, x, y):
        g = self._gcm
        if g is None:
            return -1
        info = g.info
        gx = int((x - info.origin.position.x) / info.resolution)
        gy = int((y - info.origin.position.y) / info.resolution)
        if gx < 0 or gy < 0 or gx >= info.width or gy >= info.height:
            return -1
        return g.data[gy * info.width + gx]

    def _wp_key(self, x, y):
        c = self.get_parameter('wp_fail_cell').value
        return (int(math.floor(x / c)), int(math.floor(y / c)))

    def _wp_dead(self, x, y):
        lim = self.get_parameter('wp_fail_limit').value
        return self._wp_fail.get(self._wp_key(x, y), 0) >= lim

    def _is_driven(self, x, y):
        if not self.get_parameter('additive_passes').value:
            return False
        dc = self.get_parameter('driven_cell').value
        return (int(math.floor(x / dc)), int(math.floor(y / dc))) in self._driven

    def _is_phantom(self, x, y):
        r = self.get_parameter('phantom_radius').value
        cd = self.get_parameter('phantom_cooldown').value
        now = time.time()
        for fx, fy, ft in self._failed:
            if cd > 0 and (now - ft) > cd:
                continue
            if math.hypot(fx - x, fy - y) <= r:
                return True
        return False

    def _stall_tick(self):
        """Track progress from the SLAM TF pose. Wheel odometry is unusable
        here: a wedged robot spins its wheels and odometry reports motion."""
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe,
                                           rclpy.time.Time())
        except Exception:
            self._last_move_t = time.time()   # cannot judge -> do NOT accrue
            return
        x, y = tf.transform.translation.x, tf.transform.translation.y
        q = tf.transform.rotation
        yaw = math.atan2(2 * (q.w * q.z + q.x * q.y),
                         1 - 2 * (q.y * q.y + q.z * q.z))
        # remember where we have actually driven, for additive passes
        dc = self.get_parameter('driven_cell').value
        rr = self.get_parameter('robot_radius').value
        nb = int(rr / dc)
        cx, cy = int(math.floor(x / dc)), int(math.floor(y / dc))
        for ddy in range(-nb, nb + 1):
            for ddx in range(-nb, nb + 1):
                if (ddx * dc) ** 2 + (ddy * dc) ** 2 <= rr * rr:
                    self._driven.add((cx + ddx, cy + ddy))
        if self._last_move_xy is None:
            self._last_move_xy = (x, y)
            self._last_move_yaw = yaw
            self._last_move_t = time.time()
            return
        moved = math.hypot(x - self._last_move_xy[0], y - self._last_move_xy[1])
        turned = abs(math.atan2(math.sin(yaw - self._last_move_yaw),
                                math.cos(yaw - self._last_move_yaw)))
        if (moved > self.get_parameter('stall_dist').value
                or turned > self.get_parameter('stall_yaw').value):
            self._last_move_xy = (x, y)
            self._last_move_yaw = yaw
            self._last_move_t = time.time()

    def _stalled_s(self):
        return time.time() - self._last_move_t

    def _reset_stall(self):
        """The stall clock must start when DRIVING starts. Waypoint
        validation legitimately parks the robot for tens of seconds."""
        self._last_move_t = time.time()
        self._last_move_xy = None

    def _escape(self):
        """Drive out of a pose the planner cannot plan from. Picks the
        least-costly heading from the global costmap and moves that way."""
        lethal = self.get_parameter('spiral_lethal').value
        probe = self.get_parameter('escape_probe').value
        x, y, yaw = self._robot_pose()
        here = self._cost_at(x, y)
        self.get_logger().warn(
            f"   STALL {self._stalled_s():.0f}s at ({x:+.2f},{y:+.2f}) "
            f"cost={here} - attempting ESCAPE")
        best_h, best_c = None, 1e9
        for k in range(16):
            h = yaw + (2.0 * math.pi * k / 16.0)
            c = max(self._cost_at(x + d * math.cos(h), y + d * math.sin(h))
                    for d in (0.30, probe))
            if c < best_c:
                best_c, best_h = c, h
        if best_h is None or best_c >= lethal:
            self.get_logger().warn("   escape: no free direction found")
            self._last_move_t = time.time()      # do not re-trigger immediately
            return False
        # Clear ONLY after choosing a heading. Clearing first wipes the
        # obstacle layer we need to choose safely, and the escape then
        # drives blind - that is how it moved the robot INTO cost 99.
        self._clear_costmaps()
        for _ in range(60):                       # rotate toward it
            if self._stop:
                break
            _, _, cy = self._robot_pose()
            e = math.atan2(math.sin(best_h - cy), math.cos(best_h - cy))
            if abs(e) < 0.15:
                break
            t = Twist(); t.angular.z = max(-0.8, min(0.8, 1.5 * e))
            self.cmd.publish(t); time.sleep(0.05)
        self.cmd.publish(Twist())
        for _ in range(30):                       # then drive out
            if self._stop:
                break
            if self._climb_detected():
                self._back_off_climb()
                break
            cx, cyy, cyaw = self._robot_pose()
            if self._cost_at(cx + 0.25 * math.cos(cyaw),
                             cyy + 0.25 * math.sin(cyaw)) >= lethal:
                break
            t = Twist(); t.linear.x = 0.12
            self.cmd.publish(t); time.sleep(0.1)
        self.cmd.publish(Twist())
        self._clear_costmaps()
        nx, ny = self._robot_xy()
        now_c = self._cost_at(nx, ny)
        moved = math.hypot(nx - x, ny - y)
        if moved < 0.05:
            verdict = (f"produced NO MOTION ({moved:.3f}m) - obstruction "
                       f"is not in the costmap")
            ok = False
            # A real obstruction the lidar cannot see (prop below the 0.363 m
            # scan plane): the costmap stays 0 here, so plans keep aiming back
            # into it. Remember the spot and retire the waypoint on it.
            self._blocked.append((x, y))
            self._wp_fail[self._wp_key(x, y)] = self.get_parameter('wp_fail_limit').value
        elif here < lethal:
            verdict = "was not trapped (stall was not a lethal pocket)"
            ok = True
        elif now_c < lethal:
            verdict = "SUCCEEDED"
            ok = True
        else:
            verdict = "STILL TRAPPED"
            ok = False
        self.get_logger().warn(
            f"   escape {verdict}: ({nx:+.2f},{ny:+.2f}) cost {here} -> {now_c}")
        self._last_move_t = time.time()
        return ok

    def _pick_dirt(self):
        if not self._known:
            return None
        rx, ry = self._robot_xy()
        best, bd = None, 1e9
        for x, y in self._known:
            d = math.hypot(x - rx, y - ry)
            if d < bd:
                best, bd = (x, y), d
        return best

    def _clean_all_known(self):
        guard = 0
        while self._known and not self._stop and guard < 20:
            guard += 1
            tgt = self._pick_dirt()
            if tgt is None:
                break
            x, y = tgt
            self.get_logger().info(f"-> DIRT at ({x:+.2f},{y:+.2f}) - cleaning")
            rx, ry = self._robot_xy()
            ang = math.atan2(y - ry, x - rx)
            ax = x - self.roller_off * math.cos(ang)
            ay = y - self.roller_off * math.sin(ang)
            if self._goto(ax, ay, allow_dirt=False) == 'stall':
                self._escape()
            self._spiral(x, y)
            self._cleaned.append((x, y))
            self._known = [k for k in self._known
                           if math.hypot(k[0] - x, k[1] - y) > 0.30]
            self._patches += 1

    def _roller_map(self):
        x, y, yaw = self._robot_pose()
        return (x + self.roller_off * math.cos(yaw),
                y + self.roller_off * math.sin(yaw), yaw)

    def _spiral(self, tx, ty):
        self._set_vac(True)
        gp = self.get_parameter
        R_out, R_in = gp('patch_radius').value, gp('ring_inner').value
        step = max(0.01, gp('ring_step').value)
        omega, k_r = gp('sweep_omega').value, gp('k_radial').value
        tol, w_max = gp('ring_tol').value, gp('w_max').value
        v_max, tmax = gp('v_max').value, gp('sweep_timeout').value
        d_off = self.roller_off
        laps = max(1.0, (R_out - R_in) / step)
        total = 2.0 * math.pi * laps
        t0, swept = time.time(), 0.0
        aborted = False
        self._reset_stall()
        rox, roy, _ = self._roller_map()
        phi_prev = math.atan2(roy - ty, rox - tx)
        while rclpy.ok() and time.time() - t0 < tmax and not self._stop:
            rox, roy, yaw = self._roller_map()
            dx, dy = rox - tx, roy - ty
            rad = math.hypot(dx, dy)
            if rad < 1e-3:
                t = Twist()
                t.linear.x = 0.04
                self.cmd.publish(t)
                time.sleep(0.05)
                continue
            phi = math.atan2(dy, dx)
            dphi = math.atan2(math.sin(phi - phi_prev), math.cos(phi - phi_prev))
            phi_prev = phi
            R = max(R_in, R_out - (abs(swept) / total) * (R_out - R_in))
            e_r = R - rad
            on_ring = abs(e_r) <= tol
            if on_ring:
                swept += dphi
            if abs(swept) >= total:
                break
            v_tan, gain = (min(v_max, omega * max(R, 0.02)), k_r) if on_ring \
                else (0.0, k_r * 2.0)
            r_hat = (dx / rad, dy / rad)
            t_hat = (-r_hat[1], r_hat[0])
            vx = v_tan * t_hat[0] + gain * e_r * r_hat[0]
            vy = v_tan * t_hat[1] + gain * e_r * r_hat[1]
            v = vx * math.cos(yaw) + vy * math.sin(yaw)
            w = (-vx * math.sin(yaw) + vy * math.cos(yaw)) / d_off
            # This ring drives open-loop straight to /cmd_vel and never
            # consulted a costmap - that is how the robot drove into the sofa.
            # The costmap is correct here; read it before committing.
            nrm = math.hypot(vx, vy)
            if nrm > 1e-6:
                la = gp('spiral_lookahead').value
                px, py = rox + la * vx / nrm, roy + la * vy / nrm
                c = self._cost_at(px, py)
                if c >= gp('spiral_lethal').value:
                    self.get_logger().warn(
                        f"   spiral aborted: obstacle ahead at "
                        f"({px:+.2f},{py:+.2f}) cost={c}")
                    aborted = True
                    break
            if self._stalled_s() > gp('stall_timeout').value:
                self.get_logger().warn(
                    "   spiral aborted: robot not moving (stall)")
                aborted = True
                break
            t = Twist()
            t.linear.x = max(-v_max, min(v_max, v))
            t.angular.z = max(-w_max, min(w_max, w))
            self.cmd.publish(t)
            time.sleep(0.05)
        self.cmd.publish(Twist())
        res = self._remove_model(tx, ty)
        if res is False and not aborted:
            # Definite phantom: camera fired, ring completed, no dirt model
            # within tolerance. Blacklist so the carpet is not re-serviced.
            self._failed.append((tx, ty, time.time()))
            self._known = [k for k in self._known
                           if not self._is_phantom(k[0], k[1])]
            self.get_logger().warn(
                f"   phantom site blacklisted ({tx:+.2f},{ty:+.2f}) "
                f"[{len(self._failed)} blacklisted]")
        # do NOT switch the pump off here: the sweep continues and must keep
        # cleaning. _run's finally turns it off when the sweep actually ends.

    def _remove_model(self, x, y):
        try:
            r = subprocess.run(['ign', 'model', '--list'],
                               capture_output=True, text=True, timeout=20)
            names = [l.strip().lstrip('-').strip() for l in r.stdout.splitlines()
                     if l.strip().lstrip('-').strip().startswith(self.prefix)]
        except Exception:
            return None      # query failed - do NOT conclude 'phantom'
        best, bd = None, 1e9
        for n in names:
            try:
                rr = subprocess.run(['ign', 'model', '-m', n, '-p'],
                                    capture_output=True, text=True, timeout=8)
                m = re.search(r'\[\s*(-?\d+\.?\d*)\s+(-?\d+\.?\d*)', rr.stdout)
                if not m:
                    continue
                d = math.hypot(float(m.group(1)) - x, float(m.group(2)) - y)
                if d < bd:
                    best, bd = n, d
            except Exception:
                continue
        if best and bd <= self.get_parameter('remove_tol').value:
            subprocess.run(
                ['ign', 'service', '-s', f'/world/{self.world}/remove',
                 '--reqtype', 'ignition.msgs.Entity',
                 '--reptype', 'ignition.msgs.Boolean',
                 '--timeout', '3000', '--req', f'name: "{best}", type: 2'],
                capture_output=True, text=True, timeout=6)
            self.get_logger().info(f"   sim: removed {best}")
            return True
        else:
            self.get_logger().warn(f"   cleaned, no sim model near ({x:.2f},{y:.2f})")
            return False

    def _run(self):
        self._busy = True
        self._t0 = time.time()
        # vacuum ON for the whole sweep: we clean WHILE covering. Previously the
        # pump was only on during dirt spirals, so the lawnmower traversal ran
        # dry and coverage_tracker (which is pump-gated) saw almost nothing.
        self._set_vac(True)
        self._patches = 0
        self._rooms_done = 0
        self._rooms_failed = 0
        # planned stays None until planning really starts: a sweep that could not
        # start reported 'planned 0' and the coordinator read it as 'nothing left
        # to cover' (run 114053: Nav2 never came up, run stopped at 1.4%)
        self._last_planned = None
        self._last_reached = 0
        self._last_unattempted = 0
        self._last_left = None
        self._last_abort = None
        try:
            for cli, name, tmo in ((self.nav, 'NavigateToPose', 10.0),
                                   (self.ntp, 'NavigateThroughPoses', 5.0),
                                   (self.planner, 'ComputePathToPose', 5.0)):
                if not cli.wait_for_server(timeout_sec=tmo):
                    self._last_abort = f"Nav2 {name} action server not available"
                    self.get_logger().error(f"sweep ABORTED: {self._last_abort}")
                    return
            self._last_planned = 0
            self._last_left = 0
            rx, ry = self._robot_xy()
            order = sorted(self.rooms,
                           key=lambda r: math.hypot(r['cx'] - rx, r['cy'] - ry))
            self.get_logger().info(
                f"*** ROOM-BY-ROOM CLEANING: {len(order)} rooms, nearest first ***")
            for room in order:
                if self._stop:
                    break
                rid = room['id']
                pts = self._room_waypoints(room)
                self.get_logger().info(
                    f"--- room {rid} ({room['area_m2']:.1f} m2) : {len(pts)} waypoints ---")
                if not pts:
                    if self._driven:
                        # additive passes: everything reachable here is already
                        # driven. That is SUCCESS, not a failure.
                        self.get_logger().info(
                            f"   room {rid}: nothing left to cover "
                            f"({len(self._driven)} cells already driven)")
                        self._rooms_done += 1
                    else:
                        self.get_logger().warn(f"   room {rid}: no reachable waypoints")
                        self._rooms_failed += 1
                    continue
                # OPTION 1: keep only waypoints Nav2 can actually plan to
                good = []
                dead = 0
                inflated = 0
                maxc = self.get_parameter('wp_max_cost').value
                for (wx, wy) in pts:
                    if self._stop:
                        break
                    if self._wp_dead(wx, wy):
                        dead += 1
                        continue
                    # The MAP says free; the COSTMAP is what the controller obeys.
                    # Measured on run 100458: 29% of map-free floor is inscribed
                    # (>=90) inside the 0.35 m inflation. Such waypoints plan fine
                    # and then RPP will not drive them - each one burned 90 s as
                    # "chunk stalled: 40/40 poses left, none consumed".
                    c = self._cost_at(wx, wy)
                    if c >= maxc:
                        inflated += 1
                        continue
                    if self._plannable(wx, wy):
                        good.append((wx, wy))
                skipped = len(pts) - len(good) - dead - inflated
                lim = self.get_parameter('wp_fail_limit').value
                self.get_logger().info(
                    f"   {len(good)}/{len(pts)} waypoints reachable "
                    f"({skipped} unplannable, {inflated} in inflation "
                    f"(cost>={maxc}), {dead} proven unreachable after "
                    f"{lim} failed passes)")
                attempted_wps = set()
                self._max_plan = max(self._max_plan, len(good))
                oriented = (self._orient_plan(good, self._robot_xy())
                            if self.get_parameter('orient_plans').value else good)
                if len(good) > 1 and oriented[0] != good[0]:
                    self.get_logger().info(
                        '   plan reversed: starting from the end nearer the robot')
                good = oriented
                plan0 = list(good)     # accounting is on the plan AS MADE: pruning
                                       # shrinks good and must never fake 'planned 0'
                mopup = len(good) < (self.get_parameter('retry_plan_frac').value
                                     * self._max_plan)

                # OPTION 2: drive the reachable waypoints as continuous lanes,
                # pausing to clean dirt when the camera spots it.
                # EARLY-STOP: track chunks since the camera last found new dirt;
                # once all known dirt is cleaned and we've swept several chunks
                # with nothing new, the floor is clean -> stop (don't grind the
                # whole house after the dirt is gone).
                reached = 0
                i = 0
                LANE = max(1, int(self.get_parameter('chunk_poses').value))
                stop_en = self.get_parameter('clean_stop_enable').value
                no_dirt_limit = self.get_parameter('no_dirt_chunks').value
                patches_at_last_check = self._patches
                chunks_since_dirt = 0
                consec_fail = 0
                skipped_chunks = 0
                deferred = []
                max_fail = self.get_parameter('max_consec_chunk_fail').value
                while i < len(good) and not self._stop:
                    chunk = good[i:i + LANE]
                    res = self._drive(chunk)
                    # ATTEMPTED = the poses Nav2 passed plus the one it was driving
                    # to. Passed-but-not-driven still earns a strike (R1: 55
                    # 'reached', plan shrank only 105 -> 80) - but NOT the rest of a
                    # failed chunk: marking all 40 when it stuck on pose 1 retired
                    # floor the robot never went near, and let a mop-up pass pass
                    # for a full attempt and end the run short of that floor.
                    attempted_wps.update(chunk[:self._consumed + 1])
                    if res == 'climb':
                        # the path led onto a prop the lidar cannot see: do NOT
                        # retry in place (that drives into it again). Drop the
                        # nearby waypoints from this pass and defer the rest.
                        consec_fail += 1
                        skipped_chunks += 1
                        keep = [q for q in chunk if not self._near_blocked(q)]
                        if keep:
                            deferred.append(keep)
                        good = good[:i + LANE] + [q for q in good[i + LANE:]
                                                  if not self._near_blocked(q)]
                        i += LANE
                        if consec_fail >= max_fail:
                            self.get_logger().warn(
                                f"   {consec_fail} chunks failed IN A ROW - robot "
                                f"cannot make progress; ending sweep at chunk {i}")
                            break
                        continue
                    if res == 'dirt':
                        consec_fail = 0
                        self._clean_all_known()
                        # advance past this chunk after cleaning - do NOT re-drive
                        # it forever (re-detecting the same spot caused looping)
                        reached += len(chunk)
                        i += LANE
                        if self._patches > patches_at_last_check:
                            patches_at_last_check = self._patches
                            chunks_since_dirt = 0
                        continue
                    if res == 'ok':
                        consec_fail = 0
                        reached += len(chunk)
                        i += LANE
                        # did the camera find (and clean) new dirt this stretch?
                        if self._patches > patches_at_last_check:
                            patches_at_last_check = self._patches
                            chunks_since_dirt = 0        # reset - keep going
                        else:
                            chunks_since_dirt += 1
                        # floor appears clean: all known dirt cleaned AND no new
                        # dirt for several chunks -> stop early
                        if (stop_en and not self._known
                                and self._patches > 0
                                and chunks_since_dirt >= no_dirt_limit):
                            self.get_logger().info(
                                f"   floor appears clean ({self._patches} patches, "
                                f"no new dirt for {chunks_since_dirt} chunks) - stopping")
                            break
                        continue
                    # A pose the planner refuses NOW (the costmap moved since the
                    # plan was made) fails the WHOLE chunk and every pose behind it.
                    # Run 101050: (3.91,-3.34) refused 42x sent the lane past the
                    # paper to the end-of-sweep retry, and the run never got there.
                    # Drop only the refused poses and drive the rest now. If EVERY
                    # pose is refused, the robot's own start is the problem: no prune.
                    if res in ('fail', 'stall'):
                        k = self._consumed
                        rest = chunk[k:]
                        refused = self._refused(rest)
                        if refused and len(refused) < len(rest):
                            attempted_wps.update(refused)
                            gone = set(refused)
                            good = good[:i] + [q for q in good[i + k:] if q not in gone]
                            reached += k
                            self.get_logger().warn(
                                f"   planner refuses {len(refused)} pose(s) of chunk {i} "
                                f"(first ({refused[0][0]:+.2f},{refused[0][1]:+.2f})) - "
                                f"dropped them, driving the rest of the chunk")
                            continue
                    # stalled -> ESCALATING recovery so we never freeze permanently
                    if res == 'stall':
                        self._escape()
                    recovered = False
                    for attempt in range(2):
                        self._nudge()                       # reverse + clear costmaps
                        r_again = self._drive(chunk)
                        attempted_wps.update(chunk[:self._consumed + 1])
                        if r_again == 'ok':
                            reached += len(chunk)
                            recovered = True
                            break
                    if not recovered:
                        # A single unreachable chunk (a map-edge column, a blocked
                        # doorway) must cost ONE CHUNK of coverage - not the room.
                        # The old code broke here and discarded every remaining
                        # waypoint because one chunk failed.
                        self._clear_costmaps()
                        # this open-loop backup now runs up to max_fail times per
                        # sweep instead of once, so do not reverse into furniture
                        rx, ry, ryaw = self._robot_pose()
                        bx = rx - 0.30 * math.cos(ryaw)
                        by = ry - 0.30 * math.sin(ryaw)
                        if self._cost_at(bx, by) < self.get_parameter('spiral_lethal').value:
                            bt = Twist(); bt.linear.x = -0.15
                            for _ in range(20):
                                if self._stop:
                                    break
                                self.cmd.publish(bt); time.sleep(0.1)
                            self.cmd.publish(Twist())
                        else:
                            self.get_logger().warn(
                                "   backup blocked by costmap - not reversing")
                        consec_fail += 1
                        skipped_chunks += 1
                        k = min(self._consumed, len(chunk) - 1)
                        if mopup and consec_fail < 2:
                            # mop-up leftovers are scattered and the in-pass retry
                            # is off: one spot the robot cannot get into must not
                            # write off the rest of the chunk. Skip that spot only.
                            stuck = self._stuck_cluster(chunk, k)
                            attempted_wps.update(stuck)
                            gone = set(stuck)
                            good = good[:i] + [q for q in good[i + k:] if q not in gone]
                            reached += k
                            self.get_logger().warn(
                                f"   stuck at ({chunk[k][0]:+.2f},{chunk[k][1]:+.2f}) - "
                                f"skipping {len(stuck)} pose(s) there, driving on")
                            continue
                        # do NOT discard these waypoints: a chunk that is
                        # unreachable from HERE is often reachable from a
                        # different approach later in the sweep.
                        deferred.append(chunk)
                        i += LANE
                        if consec_fail >= max_fail:
                            self.get_logger().warn(
                                f"   {consec_fail} chunks failed IN A ROW - robot "
                                f"cannot make progress; ending sweep at chunk {i}")
                            break
                        self.get_logger().warn(
                            f"   chunk {i - LANE} unreachable - SKIPPING to chunk "
                            f"{i} ({consec_fail}/{max_fail} consecutive failures)")
                        continue
                    consec_fail = 0
                    i += LANE
                # ---- deferred retry: second attempt, finer granularity ----
                retry_ok, why_not = self._retry_allowed(len(good))
                if deferred and not self._stop and not retry_ok:
                    self.get_logger().info(f"   deferred retry SKIPPED: {why_not}")
                if deferred and not self._stop and retry_ok:
                    SUB = 10
                    budget = min(self.get_parameter('deferred_retry_budget').value,
                                 self.get_parameter('retry_total_budget').value
                                 - self._retry_spent)
                    subs = [c[k:k + SUB] for c in deferred
                            for k in range(0, len(c), SUB)]
                    self.get_logger().info(
                        f"   retrying {len(deferred)} deferred chunk(s) as "
                        f"{len(subs)} sub-chunks (budget {int(budget)}s)")
                    t_ret = time.time()
                    recov = 0
                    sub_fail = 0
                    for sub in subs:
                        if self._stop or (time.time() - t_ret) > budget:
                            break
                        sub = [q for q in sub if not self._near_blocked(q)]
                        if not sub:
                            continue
                        if sub_fail >= 8:
                            self.get_logger().warn(
                                '   deferred retry: 8 sub-chunks failed in a '
                                'row - stopping retry stage')
                            break
                        r2 = self._drive(sub)
                        attempted_wps.update(sub[:self._consumed + 1])
                        if r2 in ('fail', 'stall'):
                            k = self._consumed
                            rest = sub[k:]
                            refused = self._refused(rest)
                            if refused and len(refused) < len(rest):
                                attempted_wps.update(refused)
                                gone = set(refused)
                                rest = [q for q in rest if q not in gone]
                                r2 = self._drive(rest)
                                attempted_wps.update(rest[:self._consumed + 1])
                                sub = rest
                        if r2 == 'dirt':
                            self._clean_all_known()
                        if r2 in ('ok', 'dirt'):
                            reached += len(sub)
                            recov += len(sub)
                            sub_fail = 0
                        else:
                            sub_fail += 1
                    self._retry_spent += time.time() - t_ret
                    self.get_logger().info(
                        f"   deferred retry recovered {recov} waypoint(s) "
                        f"in {int(time.time() - t_ret)}s "
                        f"(run total {int(self._retry_spent)}s)")
                if attempted_wps:
                    newly_dead = 0
                    lim = self.get_parameter('wp_fail_limit').value
                    for (fx, fy) in attempted_wps:
                        if self._is_driven(fx, fy):
                            continue   # reached after all - not evidence
                        k = self._wp_key(fx, fy)
                        self._wp_fail[k] = self._wp_fail.get(k, 0) + 1
                        if self._wp_fail[k] == lim:
                            newly_dead += 1
                    if newly_dead:
                        self.get_logger().warn(
                            f"   {newly_dead} waypoint(s) hit {lim} failed "
                            f"passes (attempted, never physically reached) - PROVEN "
                            f"unreachable, dropped from future plans")
                self._clean_all_known()
                if skipped_chunks:
                    self.get_logger().warn(
                        f"   {skipped_chunks} chunk(s) skipped as unreachable; "
                        f"sweep continued past them")
                # count the NAV2-REACHABLE un-driven waypoints, not the raw
                # lane plan: a waypoint Nav2 can never plan to would sit in
                # pts forever and planned would never reach 0, so the real
                # completion signal could never fire.
                self._last_planned += len(plan0)
                self._last_unattempted += sum(
                    1 for q in plan0
                    if q not in attempted_wps and not self._is_driven(q[0], q[1])
                    and not self._near_blocked(q))
                self._last_reached += reached
                # what the NEXT pass should plan (strikes already banked). Lets
                # the coordinator tell a finished plan from one that collapsed
                # because the room was re-segmented small (R1 PASS 5: 1 waypoint
                # planned after 127, +0.1%, then +6.0% the pass after).
                self._last_left += sum(
                    1 for q in plan0
                    if not self._is_driven(q[0], q[1]) and not self._wp_dead(q[0], q[1])
                    and not self._near_blocked(q))
                if reached > 0:
                    self._rooms_done += 1
                    self.get_logger().info(
                        f"--- room {rid} DONE: {reached}/{len(pts)} ({skipped} skipped) ---")
                else:
                    self._rooms_failed += 1
                    self.get_logger().warn(
                        f"--- room {rid} UNREACHABLE: 0/{len(pts)} ---")
            self.cmd.publish(Twist())
            el = time.time() - self._t0
            self.get_logger().info(
                f"*** COMPLETE: rooms {self._rooms_done}/{len(order)} cleaned, "
                f"{self._rooms_failed} unreachable | patches {self._patches} | "
                f"time {int(el//60)}m{int(el%60):02d}s ***")
            self.get_logger().info("*** robot stopped ***")
        finally:
            self._set_vac(False)
            self._sweeps_done += 1        # must precede _busy = False
            self._busy = False

    def _pub_status(self):
        el = (time.time() - self._t0) if self._busy else 0.0
        m = String()
        m.data = json.dumps({
            'running': self._busy,
            'rooms_total': len(self.rooms),
            'rooms_done': self._rooms_done,
            'rooms_failed': self._rooms_failed,
            'patches_cleaned': self._patches,
            'known_dirt': len(self._known),
            'elapsed_s': round(el, 1),
            'time_str': f"{int(el//60)}m{int(el%60):02d}s"})
        self.status.publish(m)


def main():
    rclpy.init()
    node = RoomCleaner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
