#!/usr/bin/env python3
"""room_segmenter.py - split the occupancy map into rooms.

Method (classic, no ML):
  1. free-space mask from /map
  2. distance transform -> how far each free cell is from the nearest wall
  3. threshold it -> "room cores" (open middles). Doorways are narrow, so the
     threshold naturally cuts them, separating adjacent rooms.
  4. connected components on the cores -> one seed per room
  5. multi-source BFS over free space -> every free cell joins its nearest seed

Publishes:
  /rooms/list   std_msgs/String  JSON [{id, cx, cy, min_x, min_y, max_x, max_y,
                                        area_m2, cells}, ...]
  /rooms/grid   nav_msgs/OccupancyGrid   room id per cell (for RViz)

Call /segment_rooms to re-run on demand.
"""
import json
import time
from collections import deque

import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import (QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy,
                       QoSHistoryPolicy)
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import String
from std_srvs.srv import Trigger


class RoomSegmenter(Node):
    def __init__(self):
        super().__init__('room_segmenter')
        p = self.declare_parameter
        p('map_topic', '/map')
        p('core_dist', 0.45)        # m from wall to count as "room core"
        p('min_room_area', 1.0)     # m^2 - discard slivers
        p('occupied_thresh', 50)
        p('republish_period', 5.0)
        p('split_mode', True)
        p('n_rooms', 3)
        p('zone_mode', True)
        p('zone_size', 3.0)
        p('resegment_growth', 0.25)        # re-segment when free area +25%
        p('resegment_min_interval', 20.0)  # s, avoid thrashing

        self.map = None
        self.rooms = []
        self.labels = None
        self._seg_free = 0
        self._seg_t = 0.0

        latched = QoSProfile(depth=1, history=QoSHistoryPolicy.KEEP_LAST,
                             reliability=QoSReliabilityPolicy.RELIABLE,
                             durability=QoSDurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(OccupancyGrid,
                                 self.get_parameter('map_topic').value,
                                 self._map_cb, latched)

        self.pub_list = self.create_publisher(String, '/rooms/list', latched)
        self.pub_grid = self.create_publisher(OccupancyGrid, '/rooms/grid', latched)
        self.create_service(Trigger, '/segment_rooms', self._on_segment)
        self.create_timer(self.get_parameter('republish_period').value,
                          self._republish)

        self.get_logger().info("room_segmenter up - waiting for /map")

    # ---------------- map ----------------
    def _free_count(self):
        if self.map is None:
            return 0
        occ = self.get_parameter('occupied_thresh').value
        arr = np.asarray(self.map.data, dtype=np.int16)
        return int(np.count_nonzero((arr >= 0) & (arr <= occ)))

    def _map_cb(self, msg):
        first = self.map is None
        self.map = msg
        if first:
            self.get_logger().info(
                f"map {msg.info.width}x{msg.info.height} @ {msg.info.resolution:.3f} m/cell")
            self._segment()
            return
        # The FIRST map is a keyhole around spawn (~13 m2 of a 155 m2 house).
        # Without this, the sweep is planned forever against that stale box.
        free = self._free_count()
        grow = self.get_parameter('resegment_growth').value
        gap = self.get_parameter('resegment_min_interval').value
        if (self._seg_free > 0 and free > self._seg_free * (1.0 + grow)
                and (time.time() - self._seg_t) >= gap):
            self.get_logger().info(
                f"map grew {self._seg_free} -> {free} free cells - re-segmenting")
            self._segment()

    def _on_segment(self, req, resp):
        if self.map is None:
            resp.success = False
            resp.message = "no /map yet"
            return resp
        n = self._segment()
        resp.success = n > 0
        resp.message = f"segmented {n} rooms"
        return resp

    # ---------------- segmentation ----------------
    def _distance_transform(self, free):
        """Chamfer distance (cells) to the nearest non-free cell. Two passes."""
        h, w = free.shape
        BIG = 1e9
        d = np.where(free, BIG, 0.0)
        # forward
        for y in range(h):
            row = d[y]
            up = d[y - 1] if y > 0 else None
            for x in range(w):
                if row[x] == 0.0:
                    continue
                best = row[x]
                if x > 0:
                    best = min(best, row[x - 1] + 1.0)
                if up is not None:
                    best = min(best, up[x] + 1.0)
                    if x > 0:
                        best = min(best, up[x - 1] + 1.414)
                    if x < w - 1:
                        best = min(best, up[x + 1] + 1.414)
                row[x] = best
        # backward
        for y in range(h - 1, -1, -1):
            row = d[y]
            dn = d[y + 1] if y < h - 1 else None
            for x in range(w - 1, -1, -1):
                if row[x] == 0.0:
                    continue
                best = row[x]
                if x < w - 1:
                    best = min(best, row[x + 1] + 1.0)
                if dn is not None:
                    best = min(best, dn[x] + 1.0)
                    if x < w - 1:
                        best = min(best, dn[x + 1] + 1.414)
                    if x > 0:
                        best = min(best, dn[x - 1] + 1.414)
                row[x] = best
        return d

    def _segment(self):
        self._seg_free = self._free_count()
        self._seg_t = time.time()
        if self.get_parameter('split_mode').value:
            return self._segment_splits()
        if self.get_parameter('zone_mode').value:
            return self._segment_zones()
        info = self.map.info
        res = info.resolution
        h, w = info.height, info.width
        data = np.array(self.map.data, dtype=np.int16).reshape(h, w)
        occ = self.get_parameter('occupied_thresh').value
        free = (data >= 0) & (data <= occ)

        if not free.any():
            self.get_logger().warn("no free space in map")
            return 0

        # try SciPy / OpenCV for speed, fall back to the pure-python transform
        dist = None
        try:
            from scipy import ndimage
            dist = ndimage.distance_transform_edt(free)
        except Exception:
            try:
                import cv2
                dist = cv2.distanceTransform(free.astype(np.uint8), cv2.DIST_L2, 5)
            except Exception:
                self.get_logger().warn("scipy/cv2 unavailable - using slow transform")
                dist = self._distance_transform(free)

        core_cells = self.get_parameter('core_dist').value / res
        cores = free & (dist > core_cells)
        if not cores.any():
            self.get_logger().warn(
                f"no cells further than {self.get_parameter('core_dist').value} m "
                f"from a wall - lower core_dist")
            return 0

        # --- seeds: connected components of the cores ---
        labels = np.zeros((h, w), dtype=np.int32)
        seed_id = 0
        for sy in range(h):
            for sx in range(w):
                if not cores[sy, sx] or labels[sy, sx] != 0:
                    continue
                seed_id += 1
                q = deque([(sx, sy)])
                labels[sy, sx] = seed_id
                while q:
                    x, y = q.popleft()
                    for nx, ny in ((x+1, y), (x-1, y), (x, y+1), (x, y-1)):
                        if 0 <= nx < w and 0 <= ny < h and cores[ny, nx] \
                                and labels[ny, nx] == 0:
                            labels[ny, nx] = seed_id
                            q.append((nx, ny))

        # --- grow seeds over all free space (multi-source BFS) ---
        q = deque()
        ys, xs = np.where(labels > 0)
        for x, y in zip(xs, ys):
            q.append((int(x), int(y)))
        while q:
            x, y = q.popleft()
            lab = labels[y, x]
            for nx, ny in ((x+1, y), (x-1, y), (x, y+1), (x, y-1)):
                if 0 <= nx < w and 0 <= ny < h and free[ny, nx] \
                        and labels[ny, nx] == 0:
                    labels[ny, nx] = lab
                    q.append((nx, ny))

        # --- summarise, dropping slivers ---
        cell_area = res * res
        min_cells = self.get_parameter('min_room_area').value / cell_area
        rooms = []
        out = np.zeros((h, w), dtype=np.int32)
        new_id = 0
        for rid in range(1, seed_id + 1):
            m = labels == rid
            n = int(m.sum())
            if n < min_cells:
                continue
            new_id += 1
            out[m] = new_id
            ys, xs = np.where(m)
            cx = info.origin.position.x + (xs.mean() + 0.5) * res
            cy = info.origin.position.y + (ys.mean() + 0.5) * res
            rooms.append({
                'id': new_id,
                'cx': round(float(cx), 3),
                'cy': round(float(cy), 3),
                'min_x': round(float(info.origin.position.x + (xs.min() + 0.5) * res), 3),
                'max_x': round(float(info.origin.position.x + (xs.max() + 0.5) * res), 3),
                'min_y': round(float(info.origin.position.y + (ys.min() + 0.5) * res), 3),
                'max_y': round(float(info.origin.position.y + (ys.max() + 0.5) * res), 3),
                'area_m2': round(n * cell_area, 2),
                'cells': n,
            })

        self.labels = out
        self.rooms = rooms
        self.get_logger().info(f"*** segmented {len(rooms)} rooms ***")
        for r in rooms:
            self.get_logger().info(
                f"   room {r['id']}: centre ({r['cx']:+.2f},{r['cy']:+.2f})  "
                f"{r['area_m2']:.1f} m2")
        self._republish()
        return len(rooms)

    # ---------------- output ----------------

    def _segment_zones(self):
        """Tile free space into fixed zones - for OPEN-PLAN houses with no doorways."""
        info = self.map.info
        res = info.resolution
        h, w = info.height, info.width
        data = np.array(self.map.data, dtype=np.int16).reshape(h, w)
        free = (data >= 0) & (data <= self.get_parameter('occupied_thresh').value)
        zc = max(4, int(self.get_parameter('zone_size').value / res))
        min_cells = self.get_parameter('min_room_area').value / (res * res)
        rooms = []
        out = np.zeros((h, w), dtype=np.int32)
        zid = 0
        for gy0 in range(0, h, zc):
            for gx0 in range(0, w, zc):
                gy1, gx1 = min(h, gy0 + zc), min(w, gx0 + zc)
                tile = free[gy0:gy1, gx0:gx1]
                n = int(tile.sum())
                if n < min_cells:
                    continue
                zid += 1
                out[gy0:gy1, gx0:gx1][tile] = zid
                ys, xs = np.where(tile)
                ys = ys + gy0
                xs = xs + gx0
                rooms.append({
                    'id': zid,
                    'cx': round(float(info.origin.position.x + (xs.mean()+0.5)*res), 3),
                    'cy': round(float(info.origin.position.y + (ys.mean()+0.5)*res), 3),
                    'min_x': round(float(info.origin.position.x + (xs.min()+0.5)*res), 3),
                    'max_x': round(float(info.origin.position.x + (xs.max()+0.5)*res), 3),
                    'min_y': round(float(info.origin.position.y + (ys.min()+0.5)*res), 3),
                    'max_y': round(float(info.origin.position.y + (ys.max()+0.5)*res), 3),
                    'area_m2': round(n * res * res, 2), 'cells': n})
        self.labels = out
        self.rooms = rooms
        self.get_logger().info(f"*** segmented {len(rooms)} ZONES ***")
        for r in rooms[:12]:
            self.get_logger().info(
                f"   zone {r['id']}: ({r['cx']:+.2f},{r['cy']:+.2f})  {r['area_m2']:.1f} m2")
        if len(rooms) > 12:
            self.get_logger().info(f"   ... and {len(rooms)-12} more")
        self._republish()
        return len(rooms)


    def _segment_splits(self):
        """Divide the free space into N equal rooms along its longer axis."""
        info = self.map.info
        res = info.resolution
        h, w = info.height, info.width
        data = np.array(self.map.data, dtype=np.int16).reshape(h, w)
        free = (data >= 0) & (data <= self.get_parameter('occupied_thresh').value)
        if not free.any():
            self.get_logger().warn("no free space"); return 0
        n = max(1, int(self.get_parameter('n_rooms').value))
        ys, xs = np.where(free)
        x0, x1, y0, y1 = int(xs.min()), int(xs.max()), int(ys.min()), int(ys.max())
        span_x, span_y = x1 - x0, y1 - y0
        vertical = span_x >= span_y
        cols = np.arange(w)[None, :]
        rows = np.arange(h)[:, None]
        rooms = []
        out = np.zeros((h, w), dtype=np.int32)
        for i in range(n):
            if vertical:
                a = x0 + (span_x * i) // n
                b = (x0 + (span_x * (i + 1)) // n) if i < n - 1 else x1
                sel = free & (cols >= a) & (cols <= b)
            else:
                a = y0 + (span_y * i) // n
                b = (y0 + (span_y * (i + 1)) // n) if i < n - 1 else y1
                sel = free & (rows >= a) & (rows <= b)
            cnt = int(sel.sum())
            if cnt == 0:
                continue
            rid = len(rooms) + 1
            out[sel] = rid
            sy, sx = np.where(sel)
            rooms.append({
                'id': rid,
                'cx': round(float(info.origin.position.x + (sx.mean()+0.5)*res), 3),
                'cy': round(float(info.origin.position.y + (sy.mean()+0.5)*res), 3),
                'min_x': round(float(info.origin.position.x + (sx.min()+0.5)*res), 3),
                'max_x': round(float(info.origin.position.x + (sx.max()+0.5)*res), 3),
                'min_y': round(float(info.origin.position.y + (sy.min()+0.5)*res), 3),
                'max_y': round(float(info.origin.position.y + (sy.max()+0.5)*res), 3),
                'area_m2': round(cnt * res * res, 2), 'cells': cnt})
        self.labels = out
        self.rooms = rooms
        axis = "vertical" if vertical else "horizontal"
        self.get_logger().info(f"*** split into {len(rooms)} ROOMS ({axis}) ***")
        for r in rooms:
            self.get_logger().info(
                f"   room {r['id']}: centre ({r['cx']:+.2f},{r['cy']:+.2f})  "
                f"{r['area_m2']:.1f} m2   x[{r['min_x']:+.1f},{r['max_x']:+.1f}] "
                f"y[{r['min_y']:+.1f},{r['max_y']:+.1f}]")
        self._republish()
        return len(rooms)

    def _republish(self):
        if not self.rooms or self.map is None:
            return
        m = String()
        m.data = json.dumps(self.rooms)
        self.pub_list.publish(m)

        g = OccupancyGrid()
        g.header.frame_id = self.map.header.frame_id or 'map'
        g.header.stamp = self.get_clock().now().to_msg()
        g.info = self.map.info
        n = max(1, len(self.rooms))
        vis = np.where(self.labels > 0,
                       (self.labels * (100 // n)).clip(1, 100), -1)
        g.data = vis.astype(np.int8).flatten().tolist()
        self.pub_grid.publish(g)


def main():
    rclpy.init()
    node = RoomSegmenter()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()