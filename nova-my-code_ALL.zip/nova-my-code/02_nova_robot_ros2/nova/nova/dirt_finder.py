#!/usr/bin/env python3
"""dirt_finder.py (v2) - nadir-camera dirt detection via map-frame evidence grid.

Why v2: the dirt camera looks STRAIGHT DOWN from ~0.28 m. Its ground footprint
(~0.52 x 0.27 m after body crop) is SMALLER than the dirt_paper target
(0.30 x 0.21 m), so any per-frame "complete blob" logic (edge margins,
per-frame area gates) rejects real dirt in every possible pose. v2 therefore:

  1. classifies dirt PIXELS per frame (bright+desaturated OR dark vs. a
     slowly-adapting floor reference, immune to the median flipping when
     paper fills the view),
  2. projects those pixels to the floor plane and VOTES into a map-frame
     cell grid (5 cm cells),
  3. confirms cells only after `vote_min` hits seen from >=2 distinct robot
     poses (kills specular highlights / projection noise, which move with
     the robot),
  4. clusters confirmed cells; cluster area = n_cells * cell_area, which is
     pose-invariant by construction,
  5. decays cells only when they are RE-OBSERVED clean (so cleaned dirt
     retires naturally, but out-of-view dirt is never forgotten).

Publishes the same /dirt/map_points JSON contract as v1, so room_cleaner /
coordinator work unchanged. All v1 parameters are still declared so existing
launch files don't crash; the obsolete ones are simply unused.
"""
import json
import math
import numpy as np
import cv2
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String
from cv_bridge import CvBridge
import tf2_ros


class DirtFinder(Node):
    def __init__(self):
        super().__init__('dirt_finder')
        p = self.declare_parameter
        # ---- v1-compatible parameters (declared so launch overrides don't crash)
        p('image_topic', '/dirt_cam/image')
        p('info_topic', '/dirt_cam/camera_info')
        p('map_frame', 'map')
        p('body_crop', 0.30)          # ignore bottom 30% of frame (chassis / rear)
        p('edge_margin_px', 0)        # v2: unused (kept for launch compat)
        p('detect_dark', False)       # False = ONLY white paper (carpet is dark, skip it)
        p('dark_delta', 28.0)         # V below floor ref -> dark dirt
        p('bright_delta', 25.0)       # V above floor ref -> light dirt
        p('bright_sat_max', 50.0)     # light dirt must be desaturated
        # ABSOLUTE gate (v3): measured paper V197-215/S2-3 vs floors
        # V98-170/S17-76. Replaces the ref_v-relative test, which
        # lagged at carpet->wood boundaries and flagged whole floors.
        p('abs_v_min', 190.0)         # paper is >=197 at every angle/dist
        p('abs_s_max', 30.0)          # paper S~2-3; wood floor S 63-76
        p('min_area_px', 0)           # v2: unused (kept for launch compat)
        p('min_patch_area_m2', 0.015) # min CLUSTER area (launch may override)
        p('merge_dist', 0.25)         # v2: unused
        p('conf_gain', 0.40)          # v2: unused
        p('conf_loss', 0.15)          # v2: unused
        p('lock_conf', 0.80)          # v2: unused
        p('dock_x', -4.19467)
        p('dock_y', -4.56598)
        p('dock_exclude_r', 0.6)
        p('publish_rate', 2.0)
        p('fx', 343.5)
        p('fy', 343.5)
        # ---- v2 parameters
        p('cell_size', 0.05)          # evidence-grid cell (m)
        p('vote_min', 3)              # frames of evidence before confirm
        p('vote_cap', 12)
        p('pose_min_move', 0.10)      # m of camera travel for "second pose"
        p('pose_min_yaw', 0.5)        # rad of yaw change for "second pose"
        p('clean_decay', 0.5)         # votes lost per frame when seen clean
        p('max_patch_area_m2', 0.15)  # bigger than this = carpet/furniture, not dirt
        p('ref_alpha', 0.05)          # floor-reference EMA rate
        p('px_stride', 4)             # subsample dirt pixels before projection
        p('obs_stride', 12)           # subsample full view for "observed" cells
        p('s_min', 0.05)              # sane ray-length bounds (rejects TF garbage,
        p('s_max', 1.20)              #   e.g. right after a teleport)

        g = self.get_parameter
        self.map_frame = g('map_frame').value
        self.bridge = CvBridge()
        # fallback intrinsics (v1 had these too, but its fallback frame was
        # overwritten to None -> dead code; fixed here)
        _w, _h, _fov = 640.0, 480.0, 1.5
        _fx = (_w / 2.0) / math.tan(_fov / 2.0)
        self.K = (_fx, _fx, _w / 2.0, _h / 2.0)
        self.cam_frame = 'dirt_cam_link'
        self._k_from_info = False

        self.ref_v = None             # slowly-adapting floor V reference
        # evidence grid: {(i,j): {'v':votes,'px':first_cam_x,'py':first_cam_y,
        #                          'pyaw':first_cam_yaw,'div':bool}}
        self.grid = {}
        self._announced = set()       # clusters already logged as NEW

        self.create_subscription(CameraInfo, g('info_topic').value, self._info_cb, 1)
        self.create_subscription(Image, g('image_topic').value, self._img_cb, 1)
        self.pub = self.create_publisher(String, '/dirt/map_points', 10)
        self.dbg = self.create_publisher(Image, '/dirt/detect_view', 1)
        self.tfb = tf2_ros.Buffer()
        tf2_ros.TransformListener(self.tfb, self)
        self.create_timer(1.0 / max(0.5, g('publish_rate').value), self._publish)
        self.get_logger().info("dirt_finder v2 up - map-frame evidence grid")

    # ------------------------------------------------------------------ info
    def _info_cb(self, msg):
        if not self._k_from_info:
            self.K = (msg.k[0], msg.k[4], msg.k[2], msg.k[5])
            self.cam_frame = msg.header.frame_id
            self._k_from_info = True
            self.get_logger().info(
                f"camera: fx={self.K[0]:.1f} cx={self.K[2]:.1f} frame={self.cam_frame}")

    # ------------------------------------------------- vectorised projection
    def _tf_Rt(self, stamp):
        """Map<-camera rotation matrix, translation, and camera yaw."""
        try:
            tf = self.tfb.lookup_transform(
                self.map_frame, self.cam_frame, stamp,
                timeout=rclpy.duration.Duration(seconds=0.05))
        except Exception:
            try:
                tf = self.tfb.lookup_transform(self.map_frame, self.cam_frame,
                                               rclpy.time.Time())
            except Exception:
                return None
        t = tf.transform.translation
        q = tf.transform.rotation
        x, y, z, w = q.x, q.y, q.z, q.w
        R = np.array([
            [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
            [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
            [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
        yaw = math.atan2(R[1, 0], R[0, 0])
        return R, np.array([t.x, t.y, t.z]), yaw

    def _project_many(self, us, vs, R, t):
        """Project pixel arrays to floor-plane map points. Returns X, Y arrays."""
        fx, fy, cx, cy = self.K
        g = self.get_parameter
        rays = np.stack([np.ones_like(us, dtype=np.float64),
                         -(us - cx) / fx,
                         -(vs - cy) / fy], axis=1)       # camera BODY frame
        d = rays @ R.T
        dz = d[:, 2]
        ok = np.abs(dz) > 1e-6
        s = np.where(ok, -t[2] / np.where(ok, dz, 1.0), -1.0)
        ok &= (s > g('s_min').value) & (s < g('s_max').value)
        X = t[0] + s * d[:, 0]
        Y = t[1] + s * d[:, 1]
        return X[ok], Y[ok]

    @staticmethod
    def _cells(X, Y, cs):
        if X.size == 0:
            return set()
        ci = np.floor(X / cs).astype(np.int64)
        cj = np.floor(Y / cs).astype(np.int64)
        return set(zip(ci.tolist(), cj.tolist()))

    # ------------------------------------------------------------- detection
    def _img_cb(self, msg):
        g = self.get_parameter
        try:
            img = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        except Exception:
            return
        H, W = img.shape[:2]
        keep_h = int(H * (1.0 - g('body_crop').value))
        view = img[:keep_h, :]

        hsv = cv2.cvtColor(view, cv2.COLOR_BGR2HSV)
        S = hsv[:, :, 1].astype(np.float32)
        V = hsv[:, :, 2].astype(np.float32)

        # ---- slowly-adapting floor reference (survives paper filling the view)
        if self.ref_v is None:
            self.ref_v = float(np.median(V))
        # ABSOLUTE, not relative to the slowly-adapting ref_v: that EMA
        # (alpha=0.05) lags across floor-material boundaries, so driving
        # from dark carpet (V~110) onto light wood (V~160) flagged the
        # whole wood floor as dirt. Absolute thresholds cannot drift.
        bright = (V > g('abs_v_min').value) & (S < g('abs_s_max').value)
        if g('detect_dark').value:
            dark = V < (self.ref_v - g('dark_delta').value)
            mask = (dark | bright).astype(np.uint8) * 255
        else:
            # dirt paper is WHITE - only detect bright+desaturated, skip dark carpet
            mask = bright.astype(np.uint8) * 255
        k = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)
        # update reference from NON-dirt pixels only, slowly
        clean_px = V[mask == 0]
        if clean_px.size > 500:
            a = g('ref_alpha').value
            self.ref_v = (1 - a) * self.ref_v + a * float(np.median(clean_px))

        Rt = self._tf_Rt(msg.header.stamp)
        if Rt is None:
            self._debug(view, mask, "no TF")
            return
        R, t, yaw = Rt
        cs = g('cell_size').value

        # ---- dirt-pixel votes
        vs_px, us_px = np.nonzero(mask)
        st = max(1, int(g('px_stride').value))
        us_d = us_px[::st].astype(np.float64)
        vs_d = vs_px[::st].astype(np.float64)
        Xd, Yd = self._project_many(us_d, vs_d, R, t)
        hit = self._cells(Xd, Yd, cs)

        # dock exclusion
        dx, dy, dr = g('dock_x').value, g('dock_y').value, g('dock_exclude_r').value
        if hit:
            hit = {(i, j) for (i, j) in hit
                   if math.hypot((i + 0.5) * cs - dx, (j + 0.5) * cs - dy) > dr}

        # ---- observed (visible) cells -> allows clean-decay
        ost = max(2, int(g('obs_stride').value))
        gu, gv = np.meshgrid(np.arange(0, W, ost, dtype=np.float64),
                             np.arange(0, keep_h, ost, dtype=np.float64))
        Xo, Yo = self._project_many(gu.ravel(), gv.ravel(), R, t)
        observed = self._cells(Xo, Yo, cs)

        vote_cap = g('vote_cap').value
        pmove, pyaw = g('pose_min_move').value, g('pose_min_yaw').value
        for c in hit:
            rec = self.grid.get(c)
            if rec is None:
                rec = {'v': 0.0, 'px': t[0], 'py': t[1], 'pyaw': yaw, 'div': False}
                self.grid[c] = rec
            rec['v'] = min(vote_cap, rec['v'] + 1.0)
            if not rec['div']:
                dyaw = abs(math.atan2(math.sin(yaw - rec['pyaw']),
                                      math.cos(yaw - rec['pyaw'])))
                if math.hypot(t[0] - rec['px'], t[1] - rec['py']) > pmove \
                        or dyaw > pyaw:
                    rec['div'] = True

        decay = g('clean_decay').value
        for c in observed - hit:
            rec = self.grid.get(c)
            if rec is not None:
                rec['v'] -= decay
                if rec['v'] <= 0:
                    del self.grid[c]

        if len(self.grid) > 20000:      # safety valve
            self.get_logger().warn("evidence grid >20k cells - pruning weakest")
            for c in sorted(self.grid, key=lambda c: self.grid[c]['v'])[:5000]:
                del self.grid[c]

        self._debug(view, mask,
                    f"refV={self.ref_v:.0f} cells={len(self.grid)}")

    def _debug(self, view, mask, txt):
        try:
            ov = view.copy()
            ov[mask > 0] = (0, 0, 255)
            out = cv2.addWeighted(view, 0.6, ov, 0.4, 0)
            cv2.putText(out, txt, (8, 20), cv2.FONT_HERSHEY_SIMPLEX,
                        0.55, (0, 255, 0), 1, cv2.LINE_AA)
            self.dbg.publish(self.bridge.cv2_to_imgmsg(out, 'bgr8'))
        except Exception:
            pass

    # ----------------------------------------------- cluster + publish (2 Hz)
    def _publish(self):
        g = self.get_parameter
        cs = g('cell_size').value
        vmin = g('vote_min').value
        conf_cells = {c: r for c, r in self.grid.items()
                      if r['v'] >= vmin and r['div']}
        clusters = []
        seen = set()
        for c in conf_cells:
            if c in seen:
                continue
            comp, stack = [], [c]
            seen.add(c)
            while stack:
                cc = stack.pop()
                comp.append(cc)
                ci, cj = cc
                for ni in (ci - 1, ci, ci + 1):
                    for nj in (cj - 1, cj, cj + 1):
                        n = (ni, nj)
                        if n in conf_cells and n not in seen:
                            seen.add(n)
                            stack.append(n)
            clusters.append(comp)

        out = []
        amin = g('min_patch_area_m2').value
        amax = g('max_patch_area_m2').value
        for comp in clusters:
            area = len(comp) * cs * cs
            if area < amin or area > amax:
                continue
            xs = [(i + 0.5) * cs for i, _ in comp]
            ys = [(j + 0.5) * cs for _, j in comp]
            mx, my = float(np.mean(xs)), float(np.mean(ys))
            mv = float(np.mean([conf_cells[c]['v'] for c in comp]))
            conf = min(1.0, mv / (2.0 * vmin))
            out.append({'x': round(mx, 3), 'y': round(my, 3),
                        'conf': round(conf, 2), 'area_m2': round(area, 4)})
            key = (round(mx, 1), round(my, 1))
            if key not in self._announced:
                self._announced.add(key)
                self.get_logger().info(
                    f"NEW dirt at map ({mx:+.2f}, {my:+.2f})  {area:.3f} m2  "
                    f"conf={conf:.2f}")
        m = String()
        m.data = json.dumps(out)
        self.pub.publish(m)


def main():
    rclpy.init()
    n = DirtFinder()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
