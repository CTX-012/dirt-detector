#!/usr/bin/env python3
"""dirt_cleaner.py — queries Gazebo for dirt_* models, deletes when brush cleans."""
import math
import re
import subprocess
import threading
import time
import rclpy
from rclpy.node import Node
from std_msgs.msg import Bool, Int32
import tf2_ros


class DirtCleaner(Node):
    def __init__(self):
        super().__init__('dirt_cleaner')
        self.declare_parameter('clean_radius', 0.30)
        self.declare_parameter('world_name', 'default')
        self.declare_parameter('brush_frame', 'vacuum_roller_link')
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('model_prefix', 'dirt_')
        self.declare_parameter('require_vacuum', True)
        # 'ign model --list' measured 5.5-7.7s on this machine; 5s always lost.
        self.declare_parameter('ign_timeout', 20.0)
        self.declare_parameter('discover_period', 5.0)
        g = self.get_parameter
        self.clean_r = g('clean_radius').value
        self.world = g('world_name').value
        self.brush_frame = g('brush_frame').value
        self.gframe = g('global_frame').value
        self.prefix = g('model_prefix').value
        self.require_vac = g('require_vacuum').value
        self.ign_timeout = g('ign_timeout').value
        self.discover_period = g('discover_period').value
        self.dirt = {}
        self.cleaned_names = set()
        self.pending = {}      # name -> attempts, awaiting confirmed absence
        self._lock = threading.Lock()
        self._fail_streak = 0
        self.vacuum_on = False
        self.create_subscription(Bool, '/vacuum/status', self._vac_cb, 1)
        self.tfb = tf2_ros.Buffer(); self.tfl = tf2_ros.TransformListener(self.tfb, self)
        self.cleaned = 0
        self.count_pub = self.create_publisher(Int32, '/cleaned_count', 1)
        self.create_timer(0.2, self._tick)
        # discovery runs OFF the executor: each ign call takes ~6-7s and would
        # otherwise freeze _tick for that long, driving the brush past the dirt.
        threading.Thread(target=self._discovery_loop, daemon=True).start()
        self.get_logger().info(
            f"dirt_cleaner ready (world='{self.world}', brush='{self.brush_frame}', "
            f"radius={self.clean_r}). Querying Gazebo for '{self.prefix}*'.")

    def _vac_cb(self, msg):
        self.vacuum_on = msg.data

    def _list_models(self):
        try:
            r = subprocess.run(['ign', 'model', '--list'],
                               capture_output=True, text=True,
                               timeout=self.ign_timeout)
            if 'timed out' in r.stdout.lower() or 'Command failed' in r.stdout:
                raise RuntimeError(r.stdout.strip().splitlines()[-1][:80])
            names = []
            for line in r.stdout.splitlines():
                line = line.strip().lstrip('-').strip()
                if line.startswith(self.prefix):
                    names.append(line)
            self._fail_streak = 0
            return names
        except Exception as e:
            self._fail_streak += 1
            if self._fail_streak == 1 or self._fail_streak % 12 == 0:
                self.get_logger().warn(f"model list failed (x{self._fail_streak}): {e}")
            return None   # None = query failed; [] = world genuinely has no dirt

    def _model_pose(self, name):
        try:
            r = subprocess.run(['ign', 'model', '-m', name, '-p'],
                               capture_output=True, text=True,
                               timeout=self.ign_timeout)
            txt = r.stdout
            mpos = re.search(r'[Pp]osition\s*[:\[]?\s*\[?\s*(-?\d+\.?\d*)[,\s]+(-?\d+\.?\d*)', txt)
            if mpos:
                return float(mpos.group(1)), float(mpos.group(2))
            mvec = re.search(r'\[\s*(-?\d+\.?\d*)\s+(-?\d+\.?\d*)', txt)
            if mvec:
                return float(mvec.group(1)), float(mvec.group(2))
        except Exception as e:
            self.get_logger().warn(f"pose query failed for {name}: {e}")
        return None

    def _discovery_loop(self):
        while rclpy.ok():
            try:
                self._discover()
            except Exception as e:
                self.get_logger().warn(f"discovery pass failed: {e}")
            time.sleep(self.discover_period)

    def _discover(self):
        names = self._list_models()
        if names is None:
            return                    # query failed - conclude nothing
        present = set(names)

        # confirm removals by absence; re-request the ones still standing
        for name in list(self.pending):
            if name not in present:
                with self._lock:
                    self.dirt.pop(name, None)
                self.cleaned_names.add(name)
                del self.pending[name]
                self.cleaned += 1
                self.count_pub.publish(Int32(data=self.cleaned))
                self.get_logger().info(
                    f"CLEANED {name} (confirmed gone)! Total: {self.cleaned}")
            else:
                self.pending[name] += 1
                if self.pending[name] <= 3:
                    self.get_logger().warn(f"{name} still present - re-requesting removal")
                    self._remove_model(name)

        for name in names:
            if name in self.cleaned_names or name in self.pending:
                continue
            with self._lock:
                if name in self.dirt:
                    continue
            pose = self._model_pose(name)
            if pose is not None:
                with self._lock:
                    self.dirt[name] = pose
                self.get_logger().info(f"tracking {name} at ({pose[0]:.2f},{pose[1]:.2f})")

    def _remove_model(self, name):
        req = f'name: "{name}", type: 2'
        cmd = ['ign', 'service', '-s', f'/world/{self.world}/remove',
               '--reqtype', 'ignition.msgs.Entity',
               '--reptype', 'ignition.msgs.Boolean',
               '--timeout', '3000', '--req', req]
        # The reply cannot verify anything: the service answers "data: true" even
        # for a model that does not exist, and the ign CLI exits 0 on timeout.
        # Removal is confirmed by ABSENCE from a later listing (see _discover).
        try:
            subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        except Exception as e:
            self.get_logger().warn(f"remove request failed for {name}: {e}")

    def _tick(self):
        if self.require_vac and not self.vacuum_on:
            return
        with self._lock:
            items = list(self.dirt.items())
        if not items:
            return
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.brush_frame, rclpy.time.Time())
        except Exception:
            return
        bx = tf.transform.translation.x; by = tf.transform.translation.y
        for name, (dx, dy) in items:
            if name in self.pending:
                continue
            if math.hypot(dx - bx, dy - by) <= self.clean_r:
                self.pending[name] = 0
                self.get_logger().info(
                    f"brush on {name} at ({dx:.2f},{dy:.2f}) - removal requested")
                self._remove_model(name)


def main():
    rclpy.init(); node = DirtCleaner()
    try: rclpy.spin(node)
    except KeyboardInterrupt: pass
    finally: node.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
