#!/usr/bin/env python3
"""
vacuum_pump.py — simulated vacuum-pump subsystem for NOVA.

Owns the pump on/off state, exposes a service to switch it on/off whenever you
want, and continuously publishes pump status + simulated telemetry (suction
pressure in Pa, power draw in W), grounded in NOVA's target spec
(3000-6000 Pa, 40-80 W).

  Turn ON:   ros2 service call /vacuum/set_state std_srvs/srv/SetBool "{data: true}"
  Turn OFF:  ros2 service call /vacuum/set_state std_srvs/srv/SetBool "{data: false}"
  Watch:     ros2 topic echo /vacuum/report      (human-readable)
             ros2 topic echo /vacuum/status      (just the bool)
             ros2 topic echo /vacuum/pressure    (Pa)
             ros2 topic echo /vacuum/power        (W)

On real NOVA this node is the stand-in for the pump command + telemetry path:
the service call becomes an autonomy/override command actuating the real motor
via the microcontroller, and the telemetry becomes a real current/pressure read.
"""
import random
import rclpy
from rclpy.node import Node
from std_srvs.srv import SetBool
from std_msgs.msg import Bool, Float32, String, Float64


class VacuumPump(Node):
    def __init__(self):
        super().__init__('vacuum_pump')
        # tune to your actual pump
        self.declare_parameter('nominal_pressure_pa', 4500.0)  # mid of 3000-6000
        self.declare_parameter('nominal_power_w', 60.0)        # mid of 40-80
        self.declare_parameter('publish_rate', 5.0)            # Hz
        self.declare_parameter('roller_speed', 4.0)           # rad/s when ON

        self.p_nom = self.get_parameter('nominal_pressure_pa').value
        self.w_nom = self.get_parameter('nominal_power_w').value
        rate = self.get_parameter('publish_rate').value

        self.on = False  # pump starts OFF

        # service to switch the pump on/off — call it any time
        self.srv = self.create_service(SetBool, '/vacuum/set_state', self.set_state)

        # status + telemetry
        self.status_pub = self.create_publisher(Bool, '/vacuum/status', 1)
        self.pressure_pub = self.create_publisher(Float32, '/vacuum/pressure', 1)
        self.power_pub = self.create_publisher(Float32, '/vacuum/power', 1)
        self.report_pub = self.create_publisher(String, '/vacuum/report', 1)
        # roller brush joint command (spins the physical roller in Gazebo)
        self.roller_pub = self.create_publisher(Float64, '/brush/cmd_vel', 1)
        self.roller_speed = self.get_parameter('roller_speed').value

        self.create_timer(1.0 / rate, self.publish)
        self.get_logger().info(
            'vacuum_pump ready (OFF). Turn on: '
            'ros2 service call /vacuum/set_state std_srvs/srv/SetBool "{data: true}"')

    def set_state(self, req, resp):
        self.on = req.data
        state = 'ON' if self.on else 'OFF'
        self.get_logger().info(f'*** VACUUM PUMP: {state} ***')
        resp.success = True
        resp.message = f'vacuum pump {state}'
        return resp

    def publish(self):
        # nominal + small noise when on, zero when off
        if self.on:
            pressure = self.p_nom + random.uniform(-150, 150)
            power = self.w_nom + random.uniform(-4, 4)
        else:
            pressure = 0.0
            power = 0.0

        # spin the roller when the pump is on, stop it when off
        self.roller_pub.publish(Float64(data=self.roller_speed if self.on else 0.0))
        self.status_pub.publish(Bool(data=self.on))
        self.pressure_pub.publish(Float32(data=float(pressure)))
        self.power_pub.publish(Float32(data=float(power)))
        state = 'ON' if self.on else 'OFF'
        self.report_pub.publish(String(
            data=f'PUMP: {state} | {pressure:.0f} Pa | {power:.1f} W'))


def main():
    rclpy.init()
    node = VacuumPump()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()  