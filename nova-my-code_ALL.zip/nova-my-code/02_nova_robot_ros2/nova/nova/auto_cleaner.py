#!/usr/bin/env python3
"""auto_cleaner.py - roller-aligned dirt cleaning.
Aims the nav goal so the ROLLER (not base_footprint) lands on the patch,
then visually servos until the dirt centroid coincides with the roller point."""
import math, re, subprocess, threading, time

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from std_srvs.srv import Trigger, SetBool
from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus
from nav2_msgs.srv import ClearEntireCostmap
from action_msgs.srv import CancelGoal
from geometry_msgs.msg import PoseStamped
from geometry_msgs.msg import Twist
from sensor_msgs.msg import Image
from std_msgs.msg import String
import json
from cv_bridge import CvBridge
import cv2
import numpy as np
import tf2_ros


class AutoCleaner(Node):
    def __init__(self):
        super().__init__('auto_cleaner')
        p = self.declare_parameter
        p('world_name', 'default')
        p('model_prefix', 'dirt_')
        p('global_frame', 'map')
        p('base_frame', 'base_footprint')
        p('dirt_cam_topic', '/dirt_cam/image')
        # --- roller geometry ---
        p('roller_offset', 0.20)      # metres ahead of base_footprint (from tf2_echo)
        p('roller_px_x', 0.50)        # roller position in image (fraction of width)
        p('roller_px_y', 0.50)        # roller position in image (fraction of height)
        p('align_radius', 0.06)
        p('align_tol_m', 0.06)
        p('sweep_enable', True)
        p('sweep_radius', 0.10)      # inner circumference (patch radius 0.15)
        p('sweep_lead_deg', 35.0)    # carrot lead angle
        p('sweep_speed', 0.08)
        p('sweep_turns', 1.0)
        p('sweep_secs', 45.0)
        p('patch_radius', 0.15)     # dirt disc radius - the ring to trace
        p('k_radial', 2.0)          # pull onto the ring
        p('ring_step', 0.05)
        p('ring_inner', 0.03)
        p('sweep_omega', 0.6)     # rad/s around the patch centre
        p('ring_tol', 0.03)       # roller must stay within this of the ring
        p('w_max', 0.8)
        p('v_max', 0.10)
        p('sweep_capture', 0.28)    # hand off from approach to sweep
        p('sweep_timeout', 90.0)       # centroid within this fraction of img -> aligned
        # --- servo ---
        p('servo_sign_fwd', 1.0)      # flip to -1.0 if it servos the wrong way
        p('servo_sign_lat', 1.0)
        p('servo_secs', 15.0)
        p('k_fwd', 0.35); p('k_lat', 1.2)
        p('min_blob_px', 250)
        p('confirm_frames', 2)
        p('max_confirm_dist', 0.70)
        p('nav_timeout', 30.0); p('stall_timeout', 12.0); p('max_attempts', 3)
        p('autostart', False)
        # --- sweep-and-clean ---
        p('sweep_min_x', -0.30)
        p('sweep_max_x',  0.90)
        p('sweep_min_y', -0.30)
        p('sweep_max_y',  0.90)
        p('lane_spacing', 0.35)   # camera sees ~0.73 m wide -> overlap
        p('dirt_conf', 0.60)      # act on a detection at this confidence
        p('cleaned_tol', 0.35)    # do not re-clean within this radius
        p('wp_timeout', 60.0)
        # --- dirt reflex: dirt BEATS any goal ---
        p('dirt_reflex', True)
        p('resume_goal', False)   # True = go back to the goal after cleaning
        g = self.get_parameter
        self.world = g('world_name').value
        self.prefix = g('model_prefix').value
        self.gframe = g('global_frame').value
        self.bframe = g('base_frame').value
        self.roller_off = g('roller_offset').value
        self.min_px = int(g('min_blob_px').value)
        self.need_frames = int(g('confirm_frames').value)
        self.max_confirm = g('max_confirm_dist').value
        self.servo_secs = g('servo_secs').value
        self.nav_timeout = g('nav_timeout').value
        self.stall_timeout = g('stall_timeout').value
        self.max_attempts = int(g('max_attempts').value)
        self.autostart = g('autostart').value

        self.nav = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.vac = self.create_client(SetBool, '/vacuum/set_state')
        self.cmd_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.clr_local = self.create_client(
            ClearEntireCostmap, '/local_costmap/clear_entirely_local_costmap')
        self.clr_global = self.create_client(
            ClearEntireCostmap, '/global_costmap/clear_entirely_global_costmap')

        self.tfb = tf2_ros.Buffer()
        self.tfl = tf2_ros.TransformListener(self.tfb, self)

        self.bridge = CvBridge()
        self._lock = threading.Lock()
        self._cen = None          # (fx, fy) centroid as image fractions
        self._px = 0
        self._t = 0.0
        self.create_subscription(Image, g('dirt_cam_topic').value, self._img_cb, 1)
        self.overlay = self.create_publisher(Image, '/dirt_cam/roller_view', 1)

        self._dirt_seen = []
        self.create_subscription(String, '/dirt/map_points', self._dirt_cb, 10)

        self._cleaned = []
        self._cleaning = False
        self._last_goal = None
        self._cancel_cli = self.create_client(
            CancelGoal, '/navigate_to_pose/_action/cancel_goal')
        self.create_subscription(PoseStamped, '/goal_pose', self._goal_cb, 10)
        self._busy = False
        self.create_service(Trigger, '/clean_all', self._on_clean_all)
        self.create_service(Trigger, '/clean_floor', self._on_clean_floor)
        self.create_service(Trigger, '/calibrate_roller', self._on_calibrate)
        self.get_logger().info(
            "auto_cleaner ready. Calibrate: put roller ON a patch, "
            "then: ros2 service call /calibrate_roller std_srvs/srv/Trigger {}")
        if self.get_parameter('dirt_reflex').value:
            threading.Thread(target=self._reflex_loop, daemon=True).start()
            self.get_logger().info("dirt REFLEX armed - dirt overrides any goal")

        if self.autostart:
            self.create_timer(5.0, self._autostart_once)

    def _autostart_once(self):
        if not self._busy:
            threading.Thread(target=self._run, daemon=True).start()

    # ---------- camera ----------
    def _img_cb(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().warn(f"cv_bridge: {e}", throttle_duration_sec=5.0)
            return
        h, w = img.shape[:2]
        gp = self.get_parameter
        rx_f, ry_f = gp('roller_px_x').value, gp('roller_px_y').value
        rad = gp('align_radius').value

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, np.array([140, 80, 80]), np.array([170, 255, 255]))
        px = int(np.count_nonzero(mask))

        cen = None
        M = cv2.moments(mask)
        if M['m00'] > 0 and px >= self.min_px:
            cx, cy = M['m10'] / M['m00'], M['m01'] / M['m00']
            cen = (cx / w, cy / h)

        with self._lock:
            self._cen, self._px, self._t = cen, px, time.time()

        # overlay: roller crosshair + align circle + blob centroid
        rpx, rpy = int(rx_f * w), int(ry_f * h)
        cv2.drawMarker(img, (rpx, rpy), (0, 255, 255), cv2.MARKER_CROSS, 22, 2)
        cv2.circle(img, (rpx, rpy), int(rad * w), (0, 255, 255), 1)
        txt = f"px={px}"
        if cen:
            bx, by = int(cen[0] * w), int(cen[1] * h)
            cv2.circle(img, (bx, by), 6, (0, 255, 0), -1)
            cv2.line(img, (rpx, rpy), (bx, by), (0, 200, 0), 1)
            err = math.hypot(cen[0] - rx_f, cen[1] - ry_f)
            aligned = err <= rad
            txt += f" err={err:.3f} {'ALIGNED' if aligned else ''}"
        cv2.putText(img, txt, (8, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 255), 1)
        try:
            self.overlay.publish(self.bridge.cv2_to_imgmsg(img, encoding='bgr8'))
        except Exception:
            pass

    def _blob(self):
        with self._lock:
            if self._cen is None or (time.time() - self._t) > 1.0:
                return None
            return self._cen

    def _on_calibrate(self, req, resp):
        c = self._blob()
        if not c:
            resp.success = False; resp.message = "no dirt blob visible"; return resp
        self.set_parameters([
            rclpy.parameter.Parameter('roller_px_x', value=float(c[0])),
            rclpy.parameter.Parameter('roller_px_y', value=float(c[1]))])
        msg = f"roller point set to ({c[0]:.3f}, {c[1]:.3f}) - bake into launch"
        self.get_logger().info(msg)
        resp.success = True; resp.message = msg
        return resp

    def _aligned(self, streak):
        c = self._blob()
        gp = self.get_parameter
        if c is None:
            return False, 0, None
        rx_f, ry_f = gp('roller_px_x').value, gp('roller_px_y').value
        err = math.hypot(c[0] - rx_f, c[1] - ry_f)
        ok = err <= gp('align_radius').value
        streak = streak + 1 if ok else 0
        return streak >= self.need_frames, streak, err

    # ---------- servo the roller onto the patch ----------
    def _sweep(self, name, tx, ty):
        gp = self.get_parameter
        R_out = gp('patch_radius').value
        R_in  = gp('ring_inner').value
        step  = max(0.01, gp('ring_step').value)
        omega = gp('sweep_omega').value
        k_r   = gp('k_radial').value
        tol   = gp('ring_tol').value
        w_max = gp('w_max').value
        v_max = gp('v_max').value
        tmax  = gp('sweep_timeout').value
        d_off = self.roller_off

        laps  = max(1.0, (R_out - R_in) / step)
        total = 2.0 * math.pi * laps

        self.get_logger().info(
            f"   AREA sweep {name}: spiral {R_out:.2f}m -> {R_in:.2f}m, "
            f"step {step:.2f}m, {laps:.1f} laps")

        t0 = time.time(); swept = 0.0; last_log = 0.0
        rox, roy, _ = self._roller_map()
        phi_prev = math.atan2(roy - ty, rox - tx)

        while rclpy.ok() and time.time() - t0 < tmax:
            rox, roy, yaw = self._roller_map()
            dx, dy = rox - tx, roy - ty
            rad = math.hypot(dx, dy)

            if rad < 1e-3:
                t = Twist(); t.linear.x = 0.04
                self.cmd_pub.publish(t); time.sleep(0.05); continue

            phi = math.atan2(dy, dx)
            dphi = math.atan2(math.sin(phi - phi_prev), math.cos(phi - phi_prev))
            phi_prev = phi

            R = max(R_in, R_out - (abs(swept) / total) * (R_out - R_in))
            e_r = R - rad
            on_ring = abs(e_r) <= tol

            # progress ONLY counts while the roller is actually on the ring
            if on_ring:
                swept += dphi

            if abs(swept) >= total:
                self.cmd_pub.publish(Twist())
                self.get_logger().info(
                    f"   AREA SWEEP COMPLETE on {name} "
                    f"({laps:.1f} laps, {math.degrees(abs(swept)):.0f}deg) -> cleaning")
                return self._remove(name)

            # tangential speed follows the ring -> angular rate stays bounded
            v_tan = min(v_max, omega * max(R, 0.02))
            gain  = k_r
            if not on_ring:
                v_tan = 0.0          # LEASH: stop orbiting, get back on the ring
                gain  = k_r * 2.0

            r_hat = (dx / rad, dy / rad)
            t_hat = (-r_hat[1], r_hat[0])
            vx = v_tan * t_hat[0] + gain * e_r * r_hat[0]
            vy = v_tan * t_hat[1] + gain * e_r * r_hat[1]

            v = vx * math.cos(yaw) + vy * math.sin(yaw)
            w = (-vx * math.sin(yaw) + vy * math.cos(yaw)) / d_off

            t = Twist()
            t.linear.x  = max(-v_max, min(v_max, v))
            t.angular.z = max(-w_max, min(w_max, w))
            self.cmd_pub.publish(t)

            if time.time() - last_log > 0.7:
                last_log = time.time()
                cam  = "cam=ok" if self._blob() else "cam=none"
                flag = "" if on_ring else "  OFF-RING"
                self.get_logger().info(
                    f"   sweep {math.degrees(abs(swept)):3.0f}/{math.degrees(total):.0f}deg "
                    f"r={rad:.3f}m ring={R:.3f}m err={e_r:+.3f}m {cam}{flag}")
            time.sleep(0.05)

        self.cmd_pub.publish(Twist())
        pct = 100.0 * abs(swept) / total
        self.get_logger().warn(
            f"   sweep timeout on {name} ({pct:.0f}% of spiral) - cleaning anyway")
        return self._remove(name)
    def _servo(self, name, tx, ty):
        """Approach the patch, then hand off to the circumferential sweep."""
        cap = self.get_parameter('sweep_capture').value
        self.get_logger().info("   approaching patch")
        t0 = time.time(); last_log = 0.0

        while time.time() - t0 < self.servo_secs and rclpy.ok():
            rox, roy, yaw = self._roller_map()
            ex, ey = tx - rox, ty - roy
            dist = math.hypot(ex, ey)

            if dist <= cap:
                self.cmd_pub.publish(Twist())
                return self._sweep(name, tx, ty)

            bearing = math.atan2(ey, ex) - yaw
            bearing = math.atan2(math.sin(bearing), math.cos(bearing))

            t = Twist()
            if abs(bearing) > math.radians(20):
                t.linear.x = 0.0                          # face it first
                t.angular.z = max(-0.5, min(0.5, 1.2 * bearing))
            else:
                t.linear.x = max(0.03, min(0.08, 0.5 * dist))
                t.angular.z = max(-0.2, min(0.2, 1.0 * bearing))
            self.cmd_pub.publish(t)

            if time.time() - last_log > 0.7:
                last_log = time.time()
                self.get_logger().info(
                    f"   approach d={dist:.3f}m bear={math.degrees(bearing):+.0f}deg")
            time.sleep(0.05)

        self.cmd_pub.publish(Twist())
        rox, roy, _ = self._roller_map()
        if math.hypot(tx - rox, ty - roy) <= cap * 1.5:
            return self._sweep(name, tx, ty)
        self.get_logger().warn(f"   approach timeout on {name}")
        return False

    # ---------- discovery / helpers ----------
    def _dirt_cb(self, msg):
        """Dirt as seen by the CAMERA (dirt_mapper), not by asking Gazebo."""
        try:
            self._dirt_seen = json.loads(msg.data)
        except Exception:
            pass

    def _discover(self):
        """Camera-detected dirt, in map frame. No simulator query."""
        d = {}
        for i, p in enumerate(self._dirt_seen):
            if p.get('conf', 0) >= 0.5:
                d[f"cam_{i}"] = (float(p['x']), float(p['y']))
        return d

    def _gazebo_name_at(self, x, y, tol=0.35):
        """Sim bookkeeping ONLY. The robot found this dirt with its camera;
        this just tells the simulator to stop drawing the patch we vacuumed.
        A real robot has no equivalent step - it simply sucks the dirt up."""
        try:
            r = subprocess.run(['ign', 'model', '--list'],
                               capture_output=True, text=True, timeout=8)
            names = [l.strip().lstrip('-').strip() for l in r.stdout.splitlines()
                     if l.strip().lstrip('-').strip().startswith(self.prefix)]
        except Exception:
            return None
        best, bd = None, 1e9
        for n in names:
            try:
                rr = subprocess.run(['ign', 'model', '-m', n, '-p'],
                                    capture_output=True, text=True, timeout=8)
                m = re.search(r'\[\s*(-?\d+\.?\d*)\s+(-?\d+\.?\d*)\s+(-?\d+\.?\d*)\]',
                              rr.stdout)
                if not m:
                    continue
                d = math.hypot(float(m.group(1)) - x, float(m.group(2)) - y)
                if d < bd:
                    best, bd = n, d
            except Exception:
                continue
        return best if (best and bd <= tol) else None

    def _robot_xy(self):
        x, y, _ = self._robot_pose()
        return x, y

    def _robot_pose(self):
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            t, q = tf.transform.translation, tf.transform.rotation
            yaw = math.atan2(2.0 * (q.w * q.z + q.x * q.y),
                             1.0 - 2.0 * (q.y * q.y + q.z * q.z))
            return t.x, t.y, yaw
        except Exception:
            return 0.0, 0.0, 0.0

    def _roller_map(self):
        x, y, yaw = self._robot_pose()
        return (x + self.roller_off * math.cos(yaw),
                y + self.roller_off * math.sin(yaw), yaw)

    def _set_vac(self, on):
        if self.vac.wait_for_service(timeout_sec=3.0):
            req = SetBool.Request(); req.data = on
            self.vac.call_async(req)
            self.get_logger().info(f"vacuum {'ON' if on else 'OFF'}")

    def _wait(self, fut, timeout=90):
        t0 = time.time()
        while rclpy.ok() and not fut.done():
            if time.time() - t0 > timeout:
                return
            time.sleep(0.05)

    def _remove(self, name):
        x = y = None
        with_pos = getattr(self, '_target_xy', None)
        if with_pos:
            x, y = with_pos
        gz = self._gazebo_name_at(x, y) if x is not None else None
        if gz is None:
            self.get_logger().warn(f"   cleaned, but no sim model near ({x},{y})")
            return True                      # vacuumed: still a success
        try:
            subprocess.run(['ign', 'service', '-s', f'/world/{self.world}/remove',
                            '--reqtype', 'ignition.msgs.Entity',
                            '--reptype', 'ignition.msgs.Boolean',
                            '--timeout', '3000',
                            '--req', f'name: "{gz}", type: 2'],
                           capture_output=True, text=True, timeout=6)
            self.get_logger().info(f"   sim: removed {gz}")
            return True
        except Exception as e:
            self.get_logger().warn(f"remove {gz} failed: {e}")
            return True

    def _clear_costmaps(self):
        for c in (self.clr_local, self.clr_global):
            if c.wait_for_service(timeout_sec=2.0):
                c.call_async(ClearEntireCostmap.Request())
        time.sleep(0.5)

    def _escape(self):
        t = Twist(); t.linear.x = -0.12
        t0 = time.time()
        while time.time() - t0 < 1.5 and rclpy.ok():
            self.cmd_pub.publish(t); time.sleep(0.05)
        self.cmd_pub.publish(Twist()); time.sleep(0.5)

    def _cancel_and_settle(self, gh, rf):
        try:
            cf = gh.cancel_goal_async(); self._wait(cf, timeout=3)
        except Exception:
            pass
        self._wait(rf, timeout=5); time.sleep(0.8)

    # ---------- goal aimed so the ROLLER lands on the dirt ----------
    def _goal_point(self, tx, ty):
        rx, ry = self._robot_xy()
        dx, dy = tx - rx, ty - ry
        L = math.hypot(dx, dy)
        if L < 1e-3:
            return tx, ty, 0.0
        ux, uy = dx / L, dy / L
        # stand back by the roller offset, FACING the patch
        return tx - self.roller_off * ux, ty - self.roller_off * uy, math.atan2(uy, ux)

    def _try_goal(self, name, tx, ty, attempt):
        gx, gy, gyaw = self._goal_point(tx, ty)
        g = NavigateToPose.Goal()
        g.pose.header.frame_id = self.gframe
        g.pose.header.stamp = self.get_clock().now().to_msg()
        g.pose.pose.position.x = float(gx)
        g.pose.pose.position.y = float(gy)
        g.pose.pose.orientation.z = math.sin(gyaw / 2.0)
        g.pose.pose.orientation.w = math.cos(gyaw / 2.0)

        sf = self.nav.send_goal_async(g)
        self._wait(sf, timeout=10)
        gh = sf.result()
        if gh is None or not gh.accepted:
            return False, None

        rf = gh.get_result_async()
        t0 = time.time()
        last = self._robot_xy(); last_move = time.time()
        streak = 0

        while rclpy.ok():
            rx, ry = self._robot_xy()
            d = math.hypot(tx - rx, ty - ry)

            rox, roy, _ = self._roller_map()
            rd = math.hypot(tx - rox, ty - roy)
            if rd <= self.get_parameter('sweep_capture').value:
                self.cmd_pub.publish(Twist())
                self.get_logger().info(f"   in range (d={rd:.3f}m) - starting sweep")
                self._cancel_and_settle(gh, rf)
                return self._sweep(name, tx, ty), d

            if rf.done():
                if self._servo(name, tx, ty):
                    return True, d
                return False, d

            if math.hypot(rx - last[0], ry - last[1]) > 0.05:
                last = (rx, ry); last_move = time.time()
            elif time.time() - last_move > self.stall_timeout:
                self.get_logger().warn(f"   STALLED (d={d:.2f}m)")
                self._cancel_and_settle(gh, rf)
                return False, d

            if time.time() - t0 > self.nav_timeout:
                self._cancel_and_settle(gh, rf)
                if self._servo(name, tx, ty):
                    return True, d
                return False, d

            time.sleep(0.05)
        return False, None

    def _drive_and_clean(self, name, x, y):
        self._target_xy = (x, y)
        for attempt in range(1, self.max_attempts + 1):
            if attempt > 1:
                self._escape(); self._clear_costmaps()
            done, _ = self._try_goal(name, x, y, attempt)
            if done:
                return True
            if attempt < self.max_attempts:
                self.get_logger().warn(f"   retrying {name} ({attempt+1}/{self.max_attempts})")
                time.sleep(1.5)
        return False

    # ---------- main ----------
    def _on_clean_all(self, req, resp):
        if self._busy:
            resp.success = False; resp.message = "already cleaning"; return resp
        threading.Thread(target=self._run, daemon=True).start()
        resp.success = True; resp.message = "autonomous cleaning started"
        return resp

    def _run(self):
        self._busy = True
        if not self.nav.wait_for_server(timeout_sec=10.0):
            self.get_logger().error("Nav2 not available"); self._busy = False; return
        dirt = self._discover()
        if not dirt:
            self.get_logger().warn("no dirt found"); self._busy = False; return

        total = len(dirt)
        self.get_logger().info(f"found {total} dirt patches FROM CAMERA. Cleaning.")
        self._set_vac(True)

        cleaned = 0
        remaining = dict(dirt)
        while remaining and rclpy.ok():
            rx, ry = self._robot_xy()
            name = min(remaining, key=lambda n: math.hypot(remaining[n][0]-rx,
                                                           remaining[n][1]-ry))
            x, y = remaining.pop(name)
            self.get_logger().info(f"-> {name} at ({x:.2f},{y:.2f}) [{cleaned+1}/{total}]")
            if self._drive_and_clean(name, x, y):
                cleaned += 1
                self.get_logger().info(f"   CLEANED {name}. ({cleaned}/{total})")
            else:
                self.get_logger().warn(f"   could not clean {name} - moving on")
            time.sleep(1.0)

        self._set_vac(False)
        self.get_logger().info(f"*** CLEANING COMPLETE. Cleaned {cleaned}/{total}. ***")
        self._busy = False


    # ================= SWEEP AND CLEAN =================
    # Boustrophedon sweep. The camera finds dirt WHILE the robot drives.
    # On a detection the robot breaks off, cleans, and resumes the lane.
    # Nothing here asks Gazebo where the dirt is.

    def _lawnmower(self):
        g = self.get_parameter
        x0, x1 = g('sweep_min_x').value, g('sweep_max_x').value
        y0, y1 = g('sweep_min_y').value, g('sweep_max_y').value
        step = max(0.2, g('lane_spacing').value)
        pts, y, d = [], y0, 1
        while y <= y1 + 1e-6:
            pts.append((x0, y) if d > 0 else (x1, y))
            pts.append((x1, y) if d > 0 else (x0, y))
            y += step
            d = -d
        return pts

    def _is_cleaned(self, x, y):
        tol = self.get_parameter('cleaned_tol').value
        return any(math.hypot(cx - x, cy - y) <= tol for cx, cy in self._cleaned)

    def _spot_dirt(self):
        """Nearest confident, uncleaned dirt the CAMERA has seen."""
        conf = self.get_parameter('dirt_conf').value
        rx, ry = self._robot_xy()
        best, bd = None, 1e9
        for p in list(self._dirt_seen):
            if p.get('conf', 0) < conf:
                continue
            x, y = float(p['x']), float(p['y'])
            if self._is_cleaned(x, y):
                continue
            d = math.hypot(x - rx, y - ry)
            if d < bd:
                best, bd = (x, y), d
        return best

    def _goto_watching(self, wx, wy):
        """Drive to a lane waypoint, but abandon it the moment dirt appears."""
        tmax = self.get_parameter('wp_timeout').value
        nav_tries = 0
        while rclpy.ok() and nav_tries < 3:
            nav_tries += 1
            g = NavigateToPose.Goal()
            g.pose.header.frame_id = self.gframe
            g.pose.header.stamp = self.get_clock().now().to_msg()
            g.pose.pose.position.x = float(wx)
            g.pose.pose.position.y = float(wy)
            g.pose.pose.orientation.w = 1.0

            sf = self.nav.send_goal_async(g)
            self._wait(sf, timeout=10)
            gh = sf.result()
            if gh is None or not gh.accepted:
                return False
            rf = gh.get_result_async()
            t0 = time.time()

            broke_off = False
            while rclpy.ok():
                d = self._spot_dirt()
                if d is not None:
                    self.get_logger().info(
                        f"*** DIRT SPOTTED at ({d[0]:+.2f},{d[1]:+.2f}) "
                        f"- breaking off the lane ***")
                    self._cancel_and_settle(gh, rf)
                    nm = f"cam_{len(self._cleaned)}"
                    ok = self._drive_and_clean(nm, d[0], d[1])
                    self._cleaned.append(d)      # never chase it twice
                    self._found += 1
                    if ok:
                        self._done += 1
                        self.get_logger().info(
                            f"   CLEANED ({self._done}/{self._found}). resuming lane.")
                    else:
                        self.get_logger().warn("   could not clean - skipping.")
                    broke_off = True
                    break

                if rf.done():
                    st = rf.result().status
                    if st != GoalStatus.STATUS_SUCCEEDED:
                        self.get_logger().warn(
                            f"   waypoint ({wx:+.2f},{wy:+.2f}) FAILED (status {st})")
                        return False
                    return True
                if time.time() - t0 > tmax:
                    self.get_logger().warn(f"   waypoint timeout ({wx:+.2f},{wy:+.2f})")
                    self._cancel_and_settle(gh, rf)
                    return False
                time.sleep(0.1)

            if broke_off:
                nav_tries = 0          # cleaning is not a nav failure - retry the lane
                continue
        return False

    def _on_clean_floor(self, req, resp):
        if self._busy:
            resp.success = False; resp.message = "already running"; return resp
        threading.Thread(target=self._sweep_run, daemon=True).start()
        resp.success = True; resp.message = "sweep-and-clean started"
        return resp

    def _sweep_run(self):
        self._busy = True
        self._found = 0
        self._done = 0
        try:
            if not self.nav.wait_for_server(timeout_sec=10.0):
                self.get_logger().error("Nav2 not available")
                return

            wps = self._lawnmower()
            self.get_logger().info(
                f"*** SWEEP AND CLEAN: {len(wps)} waypoints. "
                f"Dirt is found BY CAMERA while sweeping. ***")
            self._set_vac(True)

            reached = 0
            for k, (wx, wy) in enumerate(wps, 1):
                if not rclpy.ok():
                    break
                self.get_logger().info(
                    f"-> lane waypoint {k}/{len(wps)} ({wx:+.2f},{wy:+.2f})")
                if self._goto_watching(wx, wy):
                    reached += 1
                else:
                    self.get_logger().warn("   waypoint unreachable - skipping")

            self._set_vac(False)
            self.get_logger().info(
                f"*** SWEEP COMPLETE. waypoints {reached}/{len(wps)} | "
                f"dirt found by camera: {self._found} | cleaned: {self._done} ***")
        finally:
            self._set_vac(False)
            self._busy = False


    # ================= DIRT REFLEX =================
    # The camera sees dirt -> whatever the robot was doing is cancelled and it
    # goes and cleans. Works on ANY goal, including one you set in RViz, because
    # a CancelGoal request with a zero goal_id cancels every goal on the server.

    def _goal_cb(self, msg):
        self._last_goal = (msg.pose.position.x, msg.pose.position.y)

    def _cancel_all_nav(self):
        if not self._cancel_cli.wait_for_service(timeout_sec=2.0):
            self.get_logger().warn("cancel service unavailable")
            return False
        fut = self._cancel_cli.call_async(CancelGoal.Request())  # zero id = cancel ALL
        self._wait(fut, timeout=3)
        time.sleep(0.5)
        return True

    def _reflex_loop(self):
        while rclpy.ok():
            time.sleep(0.2)
            if self._busy or self._cleaning:      # sweep handles its own dirt
                continue
            if not self.get_parameter('dirt_reflex').value:
                continue

            d = self._spot_dirt()
            if d is None:
                continue

            self._cleaning = True
            try:
                pending = self._last_goal
                self.get_logger().info(
                    f"*** DIRT SPOTTED at ({d[0]:+.2f},{d[1]:+.2f}) "
                    f"- OVERRIDING current goal ***")
                self._cancel_all_nav()

                self._set_vac(True)
                name = f"cam_{len(self._cleaned)}"
                ok = self._drive_and_clean(name, d[0], d[1])
                self._cleaned.append(d)
                self._set_vac(False)

                if ok:
                    self.get_logger().info(f"   CLEANED {name}.")
                else:
                    self.get_logger().warn(f"   could not clean {name}.")

                if pending and self.get_parameter('resume_goal').value:
                    self.get_logger().info(
                        f"   resuming original goal ({pending[0]:+.2f},{pending[1]:+.2f})")
                    g = NavigateToPose.Goal()
                    g.pose.header.frame_id = self.gframe
                    g.pose.header.stamp = self.get_clock().now().to_msg()
                    g.pose.pose.position.x = float(pending[0])
                    g.pose.pose.position.y = float(pending[1])
                    g.pose.pose.orientation.w = 1.0
                    self.nav.send_goal_async(g)
                    self._last_goal = None
            except Exception as e:
                self.get_logger().error(f"reflex: {e}")
            finally:
                self._cleaning = False


def main():
    rclpy.init()
    node = AutoCleaner()
    ex = MultiThreadedExecutor(); ex.add_node(node)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node(); rclpy.shutdown()


if __name__ == '__main__':
    main()
