#!/usr/bin/env python3
"""explore_cleaner.py - clean dirt WHILE frontier-exploring an unknown world."""
import json
import math
import re
import subprocess
import threading
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node

from action_msgs.msg import GoalStatus
from geometry_msgs.msg import Twist
from nav2_msgs.action import NavigateToPose
from nav2_msgs.srv import ClearEntireCostmap
from std_msgs.msg import Bool, String
from std_srvs.srv import SetBool
import tf2_ros


class ExploreCleaner(Node):
    def __init__(self):
        super().__init__('explore_cleaner')
        p = self.declare_parameter
        p('global_frame', 'map')
        p('base_frame', 'base_footprint')
        p('world_name', 'default')
        p('model_prefix', 'dirt_')
        p('dirt_conf', 0.5)
        p('cleaned_tol', 0.5)
        p('remove_tol', 0.6)
        p('roller_offset', 0.21)
        p('patch_radius', 0.15)
        p('ring_step', 0.05)
        p('ring_inner', 0.03)
        p('ring_tol', 0.03)
        p('sweep_omega', 0.6)
        p('k_radial', 2.0)
        p('v_max', 0.10)
        p('w_max', 0.8)
        p('sweep_timeout', 90.0)
        p('nav_timeout', 25.0)
        p('resume_settle', 1.0)

        g = self.get_parameter
        self.gframe = g('global_frame').value
        self.bframe = g('base_frame').value
        self.world = g('world_name').value
        self.prefix = g('model_prefix').value
        self.roller_off = g('roller_offset').value

        self._known = []
        self._cleaned = []
        self._cleaning = False
        self._patches = 0

        self.create_subscription(String, '/dirt/map_points', self._dirt_cb, 10)
        self.cmd = self.create_publisher(Twist, '/cmd_vel', 10)
        self.resume_pub = self.create_publisher(Bool, '/explore/resume', 10)
        self.status = self.create_publisher(String, '/explore_clean/status', 10)

        self.nav = ActionClient(self, NavigateToPose, '/navigate_to_pose')
        self.vac = self.create_client(SetBool, '/vacuum/set_state')
        self.clr_g = self.create_client(ClearEntireCostmap,
                                        '/global_costmap/clear_entirely_global_costmap')
        self.clr_l = self.create_client(ClearEntireCostmap,
                                        '/local_costmap/clear_entirely_local_costmap')
        self.tfb = tf2_ros.Buffer()
        tf2_ros.TransformListener(self.tfb, self)

        threading.Thread(target=self._worker, daemon=True).start()
        self.create_timer(2.0, self._pub_status)
        self.get_logger().info(
            "explore_cleaner up - exploring & cleaning. Dirt pauses exploration.")

    def _dirt_cb(self, m):
        if self._cleaning:
            return
        try:
            pts = json.loads(m.data)
        except Exception:
            return
        conf = self.get_parameter('dirt_conf').value
        tol = self.get_parameter('cleaned_tol').value
        for d in pts:
            if d.get('conf', 0) < conf:
                continue
            x, y = float(d['x']), float(d['y'])
            if any(math.hypot(cx-x, cy-y) <= tol for cx, cy in self._cleaned):
                continue
            if any(math.hypot(kx-x, ky-y) <= 0.30 for kx, ky in self._known):
                continue
            self._known.append((x, y))
            self.get_logger().info(f"   dirt seen at ({x:+.2f},{y:+.2f})")

    def _worker(self):
        self.nav.wait_for_server(timeout_sec=30.0)
        while rclpy.ok():
            if not self._known:
                time.sleep(0.5)
                continue
            self._cleaning = True
            self._set_resume(False)
            self.get_logger().info("*** dirt found - pausing exploration to clean ***")
            try:
                self._clean_all()
            except Exception as e:
                self.get_logger().error(f"clean error: {e}")
            self._set_resume(True)
            self.get_logger().info("*** cleaning done - resuming exploration ***")
            self._cleaning = False
            time.sleep(self.get_parameter('resume_settle').value)

    def _set_resume(self, on):
        b = Bool(); b.data = bool(on)
        for _ in range(3):
            self.resume_pub.publish(b)
            time.sleep(0.1)

    def _clean_all(self):
        guard = 0
        while self._known and guard < 20:
            guard += 1
            rx, ry = self._robot_xy()
            tgt = min(self._known, key=lambda k: math.hypot(k[0]-rx, k[1]-ry))
            x, y = tgt
            self.get_logger().info(f"-> cleaning dirt at ({x:+.2f},{y:+.2f})")
            ang = math.atan2(y-ry, x-rx)
            ax = x - self.roller_off * math.cos(ang)
            ay = y - self.roller_off * math.sin(ang)
            self._goto(ax, ay)
            self._spiral(x, y)
            self._cleaned.append((x, y))
            self._known = [k for k in self._known
                           if math.hypot(k[0]-x, k[1]-y) > 0.30]
            self._patches += 1

    def _robot_xy(self):
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            return tf.transform.translation.x, tf.transform.translation.y
        except Exception:
            return 0.0, 0.0

    def _robot_pose(self):
        x, y = self._robot_xy()
        try:
            tf = self.tfb.lookup_transform(self.gframe, self.bframe, rclpy.time.Time())
            q = tf.transform.rotation
            yaw = math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))
        except Exception:
            yaw = 0.0
        return x, y, yaw

    def _wait(self, fut, t):
        t0 = time.time()
        while rclpy.ok() and not fut.done():
            if time.time()-t0 > t:
                return False
            time.sleep(0.05)
        return fut.done()

    def _set_vac(self, on):
        if not self.vac.wait_for_service(timeout_sec=2.0):
            return
        req = SetBool.Request(); req.data = bool(on)
        self.vac.call_async(req)

    def _goto(self, wx, wy):
        tmax = self.get_parameter('nav_timeout').value
        goal = NavigateToPose.Goal()
        goal.pose.header.frame_id = self.gframe
        goal.pose.header.stamp = self.get_clock().now().to_msg()
        goal.pose.pose.position.x = float(wx)
        goal.pose.pose.position.y = float(wy)
        goal.pose.pose.orientation.w = 1.0
        sf = self.nav.send_goal_async(goal)
        if not self._wait(sf, 10) or sf.result() is None or not sf.result().accepted:
            return False
        rf = sf.result().get_result_async()
        t0 = time.time()
        while rclpy.ok():
            if rf.done():
                return rf.result().status == GoalStatus.STATUS_SUCCEEDED
            if time.time()-t0 > tmax:
                self.cmd.publish(Twist())
                return False
            time.sleep(0.1)
        return False

    def _roller_map(self):
        x, y, yaw = self._robot_pose()
        return (x + self.roller_off*math.cos(yaw),
                y + self.roller_off*math.sin(yaw), yaw)

    def _spiral(self, tx, ty):
        self._set_vac(True)
        gp = self.get_parameter
        R_out, R_in = gp('patch_radius').value, gp('ring_inner').value
        step = max(0.01, gp('ring_step').value)
        omega, k_r = gp('sweep_omega').value, gp('k_radial').value
        tol, w_max = gp('ring_tol').value, gp('w_max').value
        v_max, tmax = gp('v_max').value, gp('sweep_timeout').value
        d_off = self.roller_off
        laps = max(1.0, (R_out - R_in) / step)
        total = 2.0 * math.pi * laps
        t0, swept = time.time(), 0.0
        rox, roy, _ = self._roller_map()
        phi_prev = math.atan2(roy-ty, rox-tx)
        while rclpy.ok() and time.time()-t0 < tmax:
            rox, roy, yaw = self._roller_map()
            dx, dy = rox-tx, roy-ty
            rad = math.hypot(dx, dy)
            if rad < 1e-3:
                t = Twist(); t.linear.x = 0.04; self.cmd.publish(t); time.sleep(0.05); continue
            phi = math.atan2(dy, dx)
            dphi = math.atan2(math.sin(phi-phi_prev), math.cos(phi-phi_prev))
            phi_prev = phi
            R = max(R_in, R_out - (abs(swept)/total)*(R_out-R_in))
            e_r = R - rad
            on_ring = abs(e_r) <= tol
            if on_ring:
                swept += dphi
            if abs(swept) >= total:
                break
            v_tan, gain = (min(v_max, omega*max(R, 0.02)), k_r) if on_ring else (0.0, k_r*2.0)
            r_hat = (dx/rad, dy/rad)
            t_hat = (-r_hat[1], r_hat[0])
            vx = v_tan*t_hat[0] + gain*e_r*r_hat[0]
            vy = v_tan*t_hat[1] + gain*e_r*r_hat[1]
            v = vx*math.cos(yaw) + vy*math.sin(yaw)
            w = (-vx*math.sin(yaw) + vy*math.cos(yaw)) / d_off
            t = Twist()
            t.linear.x = max(-v_max, min(v_max, v))
            t.angular.z = max(-w_max, min(w_max, w))
            self.cmd.publish(t)
            time.sleep(0.05)
        self.cmd.publish(Twist())
        self._remove_model(tx, ty)
        self._set_vac(False)

    def _remove_model(self, x, y):
        try:
            r = subprocess.run(['ign', 'model', '--list'],
                               capture_output=True, text=True, timeout=8)
            names = [l.strip().lstrip('-').strip() for l in r.stdout.splitlines()
                     if l.strip().lstrip('-').strip().startswith(self.prefix)]
        except Exception:
            return
        best, bd = None, 1e9
        for n in names:
            try:
                rr = subprocess.run(['ign', 'model', '-m', n, '-p'],
                                    capture_output=True, text=True, timeout=8)
                m = re.search(r'\[\s*(-?\d+\.?\d*)\s+(-?\d+\.?\d*)', rr.stdout)
                if not m:
                    continue
                d = math.hypot(float(m.group(1))-x, float(m.group(2))-y)
                if d < bd:
                    best, bd = n, d
            except Exception:
                continue
        if best and bd <= self.get_parameter('remove_tol').value:
            subprocess.run(
                ['ign', 'service', '-s', f'/world/{self.world}/remove',
                 '--reqtype', 'ignition.msgs.Entity',
                 '--reptype', 'ignition.msgs.Boolean',
                 '--timeout', '3000', '--req', f'name: "{best}", type: 2'],
                capture_output=True, text=True, timeout=6)
            self.get_logger().info(f"   sim: removed {best}")

    def _pub_status(self):
        m = String()
        m.data = json.dumps({
            'cleaning': self._cleaning,
            'patches_cleaned': self._patches,
            'known_dirt': len(self._known)})
        self.status.publish(m)


def main():
    rclpy.init()
    node = ExploreCleaner()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
