#!/usr/bin/env python3
"""dirt_mapper.py - find dirt with the CAMERA, not by asking Gazebo.

Geometry (measured, not assumed):
  base_footprint -> dirt_cam_link = [0.370, 0, 0.393], pitch 90 (straight down)
  fx = fy = 343.5, 640x480  =>  visible floor x in [0.097, 0.645] (camera-relative
  -0.275 .. +0.275), y in [-0.366, +0.366]

  The robot's chassis occupies x < ~0.27, i.e. the BOTTOM ~30% of every frame.
  Blobs there are the robot, not dirt. Blobs clipped by any border are FRAGMENTS
  and their centroids are meaningless - that is what reported dirt at 0.64 and
  0.90 instead of 0.80.

Publishes:
  /dirt/map_points  std_msgs/String  JSON [{x, y, conf, area_m2}, ...]
  /dirt/markers     MarkerArray
  /dirt/detect_view Image (annotated)
Services:
  /dirt/clear, /dirt/list
"""
import json
import math
import threading

import numpy as np
import cv2
import rclpy
from rclpy.node import Node
from rclpy.executors import MultiThreadedExecutor
from sensor_msgs.msg import Image, CameraInfo
from std_msgs.msg import String, ColorRGBA
from std_srvs.srv import Trigger
from visualization_msgs.msg import Marker, MarkerArray
from cv_bridge import CvBridge
import tf2_ros


def quat_to_R(x, y, z, w):
    n = math.sqrt(x * x + y * y + z * z + w * w)
    if n < 1e-9:
        return np.eye(3)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w),     2 * (x * z + y * w)],
        [2 * (x * y + z * w),     1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w),     2 * (y * z + x * w),     1 - 2 * (x * x + y * y)],
    ])


class DirtMapper(Node):
    def __init__(self):
        super().__init__('dirt_mapper')
        p = self.declare_parameter
        p('image_topic', '/dirt_cam/image')
        p('info_topic', '/dirt_cam/camera_info')
        p('map_frame', 'map')
        p('optical_convention', False)   # Gazebo body frame: x fwd, y left, z up
        p('fallback_hfov', 1.5)
        # magenta
        p('h_lo', 140); p('s_lo', 80);  p('v_lo', 80)
        p('h_hi', 170); p('s_hi', 255); p('v_hi', 255)
        # --- the three rules that make this work ---
        p('body_crop', 0.30)            # bottom band = the robot itself
        p('edge_margin_px', 6)          # blob touching a border = fragment
        p('min_patch_area_m2', 0.040)   # a full 0.15 m disc is ~0.071 m2
        # tracking
        p('min_area_px', 120)
        p('cluster_radius', 0.25)
        p('close_range', 0.15)          # too close to see it -> do NOT decay it
        p('lock_conf', 0.80)            # trusted -> stop moving the estimate
        p('conf_gain', 0.25)
        p('conf_loss', 0.15)
        p('max_range', 2.0)
        p('publish_rate', 2.0)
        g = self.get_parameter

        self.map_frame = g('map_frame').value
        self.optical = g('optical_convention').value
        self.cluster_r = g('cluster_radius').value
        self.conf_gain = g('conf_gain').value
        self.conf_loss = g('conf_loss').value
        self.max_range = g('max_range').value

        self.K = None
        self.cam_frame = None
        self.bridge = CvBridge()
        self.lock = threading.Lock()
        self.points = []

        self.tfb = tf2_ros.Buffer()
        self.tfl = tf2_ros.TransformListener(self.tfb, self)

        self.create_subscription(CameraInfo, g('info_topic').value, self._info_cb, 1)
        self.create_subscription(Image, g('image_topic').value, self._img_cb, 1)
        self.pub = self.create_publisher(String, '/dirt/map_points', 10)
        self.mark = self.create_publisher(MarkerArray, '/dirt/markers', 1)
        self.dbg = self.create_publisher(Image, '/dirt/detect_view', 1)
        self.create_service(Trigger, '/dirt/clear', self._on_clear)
        self.create_service(Trigger, '/dirt/list', self._on_list)
        self.create_timer(1.0 / max(0.5, g('publish_rate').value), self._publish)

        self.get_logger().info("dirt_mapper up - finding dirt with the CAMERA")

    def _info_cb(self, m):
        if self.K is None and m.k[0] > 0:
            self.K = (m.k[0], m.k[4], m.k[2], m.k[5])
            self.get_logger().info(
                f"camera_info: fx={m.k[0]:.1f} fy={m.k[4]:.1f} "
                f"cx={m.k[2]:.1f} cy={m.k[5]:.1f}  {m.width}x{m.height}")

    def _ensure_K(self, w, h):
        if self.K is None:
            hfov = self.get_parameter('fallback_hfov').value
            fx = (w / 2.0) / math.tan(hfov / 2.0)
            self.K = (fx, fx, w / 2.0, h / 2.0)
            self.get_logger().warn(f"no camera_info - synthesised fx={fx:.1f}")

    def _ray(self, u, v):
        fx, fy, cx, cy = self.K
        a, b = (u - cx) / fx, (v - cy) / fy
        return np.array([a, b, 1.0]) if self.optical else np.array([1.0, -a, -b])

    def _to_pixel(self, pc):
        fx, fy, cx, cy = self.K
        if self.optical:
            if pc[2] <= 1e-6:
                return None
            return (fx * pc[0] / pc[2] + cx, fy * pc[1] / pc[2] + cy)
        if pc[0] <= 1e-6:
            return None
        return (-fx * pc[1] / pc[0] + cx, -fy * pc[2] / pc[0] + cy)

    def _cam_pose(self):
        try:
            tf = self.tfb.lookup_transform(
                self.map_frame, self.cam_frame, rclpy.time.Time())
            t, q = tf.transform.translation, tf.transform.rotation
            return np.array([t.x, t.y, t.z]), quat_to_R(q.x, q.y, q.z, q.w)
        except Exception as e:
            self.get_logger().warn(f"TF {self.map_frame}->{self.cam_frame}: {e}",
                                   throttle_duration_sec=5.0)
            return None, None

    def _floor_hit(self, u, v, org, R):
        d = R @ self._ray(u, v)
        if d[2] >= -1e-6:
            return None
        s = -org[2] / d[2]
        if s <= 0 or s > self.max_range:
            return None
        p = org + s * d
        return float(p[0]), float(p[1]), s

    def _img_cb(self, msg):
        try:
            img = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')
        except Exception as e:
            self.get_logger().warn(f"cv_bridge: {e}", throttle_duration_sec=5.0)
            return
        h, w = img.shape[:2]
        self.cam_frame = msg.header.frame_id or self.cam_frame
        if not self.cam_frame:
            return
        self._ensure_K(w, h)
        org, R = self._cam_pose()
        if org is None:
            return

        g = self.get_parameter
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(
            hsv,
            np.array([g('h_lo').value, g('s_lo').value, g('v_lo').value]),
            np.array([g('h_hi').value, g('s_hi').value, g('v_hi').value]))
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))

        # RULE 1: the bottom band is the robot's own chassis. Never dirt.
        crop = int(h * g('body_crop').value)
        vmax = h - crop
        if crop > 0:
            mask[vmax:, :] = 0
            cv2.rectangle(img, (0, vmax), (w, h), (0, 0, 255), 2)
            cv2.putText(img, "ROBOT BODY", (8, vmax + 22),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 255), 1)

        em = int(g('edge_margin_px').value)
        min_a = g('min_patch_area_m2').value
        cnts, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        seen = []
        for c in cnts:
            apx = cv2.contourArea(c)
            if apx < g('min_area_px').value:
                continue
            bx, by, bw, bh = cv2.boundingRect(c)

            # RULE 2: a blob touching any border (incl. the crop line) is a
            # FRAGMENT. Its centroid is not the patch centre.
            if bx <= em or by <= em or bx + bw >= w - em or by + bh >= vmax - em:
                cv2.drawContours(img, [c], -1, (0, 0, 255), 1)
                continue

            M = cv2.moments(c)
            if M['m00'] <= 0:
                continue
            u, v = M['m10'] / M['m00'], M['m01'] / M['m00']
            hit = self._floor_hit(u, v, org, R)
            if hit is None:
                continue
            x, y, dist = hit
            mpp = dist / self.K[0]
            area_m2 = apx * mpp * mpp

            # RULE 3: pixels can lie about shape; AREA IN METRES cannot.
            if area_m2 < min_a:
                cv2.drawContours(img, [c], -1, (0, 140, 255), 1)
                continue

            seen.append((x, y, area_m2))
            cv2.drawContours(img, [c], -1, (0, 255, 0), 2)
            cv2.circle(img, (int(u), int(v)), 5, (0, 255, 0), -1)
            cv2.putText(img, f"({x:.2f},{y:.2f}) {area_m2:.3f}m2",
                        (int(u) + 8, int(v)), cv2.FONT_HERSHEY_SIMPLEX,
                        0.45, (0, 255, 0), 1)

        self._fuse(seen, org, R, w, h, vmax, em)
        try:
            self.dbg.publish(self.bridge.cv2_to_imgmsg(img, encoding='bgr8'))
        except Exception:
            pass

    def _fuse(self, seen, org, R, w, h, vmax, em):
        gp = self.get_parameter
        close = gp('close_range').value
        lock = gp('lock_conf').value
        cam = org[:2]

        with self.lock:
            matched = set()
            for (x, y, a) in seen:
                best, bd = None, 1e9
                for i, pt in enumerate(self.points):
                    d = math.hypot(pt['x'] - x, pt['y'] - y)
                    if d < bd:
                        best, bd = i, d
                if best is not None and bd <= self.cluster_r:
                    pt = self.points[best]
                    matched.add(best)
                    pt['conf'] = min(1.0, pt['conf'] + self.conf_gain)
                    if pt['conf'] < lock:
                        k = 0.3
                        pt['x'] = (1 - k) * pt['x'] + k * x
                        pt['y'] = (1 - k) * pt['y'] + k * y
                    pt['area_m2'] = max(pt['area_m2'], a)
                else:
                    self.points.append({'x': x, 'y': y, 'conf': 0.4,
                                        'area_m2': float(a)})
                    self.get_logger().info(
                        f"NEW dirt at map ({x:+.2f}, {y:+.2f})  {a:.3f} m2")

            keep = []
            Rt = R.T
            for i, pt in enumerate(self.points):
                if i not in matched:
                    d_cam = float(np.linalg.norm(cam - np.array([pt['x'], pt['y']])))
                    # Standing on it -> cannot see it -> NOT evidence of absence.
                    # Without this the robot forgets the dirt exactly when it
                    # arrives to clean it.
                    if d_cam < close:
                        keep.append(pt)
                        continue

                    rel = np.array([pt['x'], pt['y'], 0.0]) - org
                    px = self._to_pixel(Rt @ rel)
                    inview = False
                    if px is not None:
                        dist = float(np.linalg.norm(rel))
                        r_m = math.sqrt(max(pt['area_m2'], 1e-4) / math.pi)
                        pad = r_m * self.K[0] / max(dist, 1e-3) + em + 4
                        inview = (pad < px[0] < w - pad
                                  and pad < px[1] < vmax - pad)   # respect the crop
                    if inview:
                        pt['conf'] -= self.conf_loss

                if pt['conf'] > 0.05:
                    keep.append(pt)
                else:
                    self.get_logger().info(
                        f"forgot dirt at ({pt['x']:+.2f}, {pt['y']:+.2f}) - gone")
            self.points = keep

    def _snapshot(self):
        with self.lock:
            return [{'x': round(p['x'], 3), 'y': round(p['y'], 3),
                     'conf': round(p['conf'], 2),
                     'area_m2': round(p['area_m2'], 4)} for p in self.points]

    def _publish(self):
        pts = self._snapshot()
        self.pub.publish(String(data=json.dumps(pts)))
        arr = MarkerArray()
        for i, p in enumerate(pts):
            m = Marker()
            m.header.frame_id = self.map_frame
            m.header.stamp = self.get_clock().now().to_msg()
            m.ns = 'dirt'; m.id = i
            m.type = Marker.CYLINDER
            m.action = Marker.ADD
            m.pose.position.x = p['x']
            m.pose.position.y = p['y']
            m.pose.position.z = 0.01
            m.pose.orientation.w = 1.0
            r = max(0.05, math.sqrt(max(p['area_m2'], 1e-4) / math.pi))
            m.scale.x = m.scale.y = 2 * r
            m.scale.z = 0.02
            m.color = ColorRGBA(r=0.94, g=0.62, b=0.15, a=0.3 + 0.6 * p['conf'])
            arr.markers.append(m)
        self.mark.publish(arr)

    def _on_clear(self, req, resp):
        with self.lock:
            n = len(self.points); self.points = []
        resp.success = True; resp.message = f"cleared {n}"
        return resp

    def _on_list(self, req, resp):
        resp.success = True
        resp.message = json.dumps(self._snapshot())
        return resp


def main():
    rclpy.init()
    n = DirtMapper()
    ex = MultiThreadedExecutor(); ex.add_node(n)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        rclpy.ok() and rclpy.shutdown()


if __name__ == '__main__':
    main()
