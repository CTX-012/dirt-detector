import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_desc = get_package_share_directory('cleaner_bot_description')
    pkg_world = get_package_share_directory('aws_robomaker_small_house_world')
    nav2_bringup = get_package_share_directory('nav2_bringup')

    nav_params = os.path.join(pkg_desc, 'config', 'nav2_navigation_params.yaml')
    map_yaml = os.path.join(pkg_world, 'maps', 'turtlebot3_waffle_pi', 'map.yaml')

    display = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(pkg_desc, 'launch', 'display.launch.py'))
    )

    localization = TimerAction(period=6.0, actions=[
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav2_bringup, 'launch', 'localization_launch.py')
            ),
            launch_arguments={
                'use_sim_time': 'true',
                'map': map_yaml,
                'params_file': nav_params,
            }.items()
        )
    ])

    navigation = TimerAction(period=10.0, actions=[
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource(
                os.path.join(nav2_bringup, 'launch', 'navigation_launch.py')
            ),
            launch_arguments={
                'use_sim_time': 'true',
                'params_file': nav_params,
            }.items()
        )
    ])

    return LaunchDescription([display, localization, navigation])