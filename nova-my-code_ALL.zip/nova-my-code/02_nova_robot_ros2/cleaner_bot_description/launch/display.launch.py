import os
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, DeclareLaunchArgument
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import Command, LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory
from launch.actions import SetEnvironmentVariable


def generate_launch_description():

    pkg_desc  = get_package_share_directory('cleaner_bot_description')
    pkg_world = get_package_share_directory('aws_robomaker_small_house_world')

    use_sim_time = LaunchConfiguration('use_sim_time', default='true')

    robot_desc = Command([
        'xacro ', os.path.join(pkg_desc, 'urdf', 'cleaner_bot.urdf.xacro')
    ])

    robot_desc_param = {'robot_description': robot_desc,
                        'use_sim_time': use_sim_time}
    
    pkg_desc_share = get_package_share_directory('cleaner_bot_description')

    set_resource_path = SetEnvironmentVariable(
        name='IGN_GAZEBO_RESOURCE_PATH',
        value=os.path.join(pkg_desc_share, '..', '..')
    )

    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_world, 'launch', 'small_house.launch.py')
        )
    )

    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[robot_desc_param]
    )

    relay = Node(
    package='topic_tools',
    executable='relay',
    arguments=[
        '/world/default/model/cleaner_bot/joint_state',
        '/joint_states'
    ],
    output='screen'
    )

    spawn = Node(
        package='ros_gz_sim',
        executable='create',
        arguments=[
            '-name',  'cleaner_bot',
            '-topic', '/robot_description',
            '-x', '0.0',
            '-y', '0.0',
            '-z', '0.15',
            '-R', '0.0',
            '-P', '0.0',
            '-Y', '0.0',
        ],
        output='screen'
    )

    bridge = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='ros_gz_bridge',
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[ignition.msgs.Clock',
            '/scan@sensor_msgs/msg/LaserScan[ignition.msgs.LaserScan',
            '/tf@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            # '/tf_static@tf2_msgs/msg/TFMessage[ignition.msgs.Pose_V',
            '/cmd_vel@geometry_msgs/msg/Twist]ignition.msgs.Twist',
            '/odom@nav_msgs/msg/Odometry[ignition.msgs.Odometry',
            '/world/default/model/cleaner_bot/joint_state@sensor_msgs/msg/JointState[ignition.msgs.Model',
        ],
        output='screen'
    )

    # load_jsb = Node(
    #     package='controller_manager',
    #     executable='spawner',
    #     arguments=['joint_state_broadcaster',
    #                '--controller-manager', '/controller_manager'],
    #     output='screen'
    # )

    # load_diff = Node(
    #     package='controller_manager',
    #     executable='spawner',
    #     arguments=['diff_drive_controller',
    #                '--controller-manager', '/controller_manager'],
    #     output='screen'
    # )

    # controllers = TimerAction(period=3.0, actions=[load_jsb, load_diff])

    rviz = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen'
    )

    return LaunchDescription([
        set_resource_path,
        gazebo,
        rsp,
        relay,
        spawn,
        bridge,
        # controllers,
        rviz,
    ])