from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():

    explore = Node(
        package='explore_lite',
        executable='explore',
        name='explore',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'robot_base_frame': 'base_footprint',
            'costmap_topic': 'global_costmap/costmap',
            'costmap_updates_topic': 'global_costmap/costmap_updates',
            'visualize': True,
            'planner_frequency': 0.33,
            'progress_timeout': 30.0,
            'potential_scale': 4.0,
            'gain_scale': 2.0,
            'transform_tolerance': 0.3,
            'min_frontier_size': 0.6,
        }]
    )

    return LaunchDescription([explore])