"""
Track A test suite — T-A1..T-A6.

CoverageStore is deliberately free of ROS types, so the whole rasterization and
stats layer is testable in plain pytest with no rclpy spin, no TF, no sim.
"""

import numpy as np
import pytest

from nova_coverage_tracker.coverage_store import (
    CoverageStore,
    COVERED,
    FREE_UNCOVERED,
    UNKNOWN,
)


def make_store(w=100, h=100, res=0.05, ox=0.0, oy=0.0, walls=True):
    """10 cells of wall around a 5 m × 5 m free room."""
    src = np.zeros(w * h, dtype=np.int8)
    if walls:
        g = src.reshape(h, w)
        g[0, :] = 100
        g[-1, :] = 100
        g[:, 0] = 100
        g[:, -1] = 100
    return CoverageStore(w, h, res, ox, oy, src)


# ── T-A1: disc rasterization against a golden fixture ────────────────────

def test_ta1_disc_rasterization_exact_cells():
    s = make_store(walls=False)
    # 0.10 m radius at 0.05 m/cell = 2 cells. The disc |dx,dy| <= 2 has 13 cells.
    n = s.stamp_disc(x=2.5, y=2.5, radius_m=0.10)
    assert n == 13
    assert s.covered_cells == 13


def test_ta1_stripe_width_matches_footprint():
    """
    E-A1 in unit form: a straight drive paints a band of the right width.

    Sample the MIDDLE of the stripe, not the ends. The stripe has rounded
    end-caps (it is a union of discs), so a column near the final pose crosses
    the disc off-center and measures narrower than the true band width. This
    caught a bad first version of this test — the code was right, the probe
    was in the wrong place.
    """
    s = make_store(walls=False)
    radius = 0.18                      # → 4 cells (0.18/0.05 = 3.6, rounds to 4)
    for i in range(60):
        s.stamp_disc(x=0.5 + i * 0.025, y=2.5, radius_m=radius)

    grid = s.render().reshape(s.height, s.width)
    col = grid[:, 25]                  # mid-stripe, far from both end-caps
    band = np.count_nonzero(col == COVERED)
    expected = 2 * 4 + 1               # diameter in cells
    assert abs(band - expected) <= 1   # ±1 cell, per the E-A1 criterion


# ── T-A2: idempotency ────────────────────────────────────────────────────

def test_ta2_marking_twice_is_idempotent():
    s = make_store(walls=False)
    first = s.stamp_disc(2.5, 2.5, 0.18)
    count_after_first = s.covered_cells

    second = s.stamp_disc(2.5, 2.5, 0.18)   # same pose
    assert second == 0                       # nothing newly covered
    assert s.covered_cells == count_after_first
    assert first > 0


def test_ta2_second_lap_does_not_change_coverage():
    s = make_store(walls=False)
    path = [(0.5 + i * 0.05, 2.5) for i in range(80)]
    for x, y in path:
        s.stamp_disc(x, y, 0.18)
    lap1 = s.coverage_pct

    for x, y in path:
        s.stamp_disc(x, y, 0.18)
    assert s.coverage_pct == pytest.approx(lap1)


# ── T-A3: pose-jump gate is enforced by the node, but the store must never
#          be asked to paint a jump. Assert the store's own contract: a disc
#          stamped at B does not touch cells near A.

def test_ta3_no_bleed_between_distant_poses():
    s = make_store(walls=False)
    s.stamp_disc(0.5, 0.5, 0.18)
    near_a = s.covered_cells

    s.stamp_disc(4.5, 4.5, 0.18)     # 5.6 m away — a teleport
    grid = s.render().reshape(s.height, s.width)

    # The corridor between them must be untouched.
    mid_r, mid_c = s.world_to_cell(2.5, 2.5)
    assert grid[mid_r, mid_c] == FREE_UNCOVERED
    assert s.covered_cells == near_a * 2


# ── T-A4: stats math excludes unknown and occupied ───────────────────────

def test_ta4_walls_excluded_from_denominator():
    s = make_store(walls=True)
    total = s.width * s.height
    wall_cells = 100 * 4 - 4          # perimeter, corners counted once
    assert s.free_cells == total - wall_cells


def test_ta4_unknown_cells_excluded():
    src = np.zeros(100 * 100, dtype=np.int8)
    src[:1000] = UNKNOWN               # 1000 unknown cells
    s = CoverageStore(100, 100, 0.05, 0.0, 0.0, src)
    assert s.free_cells == 10000 - 1000


def test_ta4_coverage_pct_is_covered_over_free():
    s = make_store(walls=False)
    s.stamp_disc(2.5, 2.5, 0.10)       # 13 cells
    assert s.coverage_pct == pytest.approx(100.0 * 13 / 10000)


def test_ta4_cannot_mark_a_wall():
    """A robot cannot clean a wall. Marking one would inflate coverage_pct."""
    s = make_store(walls=True)
    # Stamp centered on the left wall (x = 0.0 is column 0).
    s.stamp_disc(x=0.0, y=2.5, radius_m=0.18)
    grid = s.render().reshape(s.height, s.width)
    assert np.all(grid[:, 0] == UNKNOWN)      # wall column never covered
    assert s.coverage_pct <= 100.0


def test_ta4_full_coverage_can_reach_100_pct():
    """
    The gate is 'coverage >= 85%'. If walls were in the denominator, 100% would
    be unreachable and the gate would be nonsense. Sweep every free cell and
    confirm the ceiling is actually 100.
    """
    s = make_store(w=40, h=40, walls=True)
    for r in range(1, 39):
        for c in range(1, 39):
            x = (c + 0.5) * 0.05
            y = (r + 0.5) * 0.05
            s.stamp_disc(x, y, 0.01)   # 0-cell radius → single cell
    assert s.coverage_pct == pytest.approx(100.0, abs=0.01)


# ── T-A5: reset ──────────────────────────────────────────────────────────

def test_ta5_clear_empties_store():
    s = make_store(walls=False)
    s.stamp_disc(2.5, 2.5, 0.18)
    assert s.covered_cells > 0

    s.clear()
    assert s.covered_cells == 0
    assert s.coverage_pct == 0.0
    grid = s.render().reshape(s.height, s.width)
    assert np.count_nonzero(grid == COVERED) == 0


# ── Render correctness (the incremental-cache path) ──────────────────────

def test_incremental_render_matches_full_render():
    """
    The dirty-bbox optimization is 745× faster; it must not be 745× wrong.
    Render incrementally, then force a full render, and compare byte-for-byte.
    """
    s = make_store(walls=True)
    for i in range(40):
        s.stamp_disc(0.5 + i * 0.1, 2.5, 0.18)
        s.render()                     # force the incremental path each step

    incremental = s.render().copy()
    s.force_full_render()
    full = s.render().copy()
    assert np.array_equal(incremental, full)


def test_render_preserves_unknown():
    src = np.full(100 * 100, UNKNOWN, dtype=np.int8)
    src.reshape(100, 100)[40:60, 40:60] = 0     # a small free island
    s = CoverageStore(100, 100, 0.05, 0.0, 0.0, src)
    s.stamp_disc(2.5, 2.5, 0.18)
    grid = s.render().reshape(100, 100)
    assert grid[10, 10] == UNKNOWN               # outside the island
    assert np.count_nonzero(grid == COVERED) > 0


# ── Origin handling — the thing everyone gets wrong ──────────────────────

def test_nonzero_origin_offset():
    s = make_store(ox=-2.5, oy=-2.5, walls=False)
    # World (0,0) is now the middle of the map, i.e. cell (50, 50).
    r, c = s.world_to_cell(0.0, 0.0)
    assert (r, c) == (50, 50)

    s.stamp_disc(0.0, 0.0, 0.10)
    grid = s.render().reshape(s.height, s.width)
    assert grid[50, 50] == COVERED
    assert grid[10, 10] == FREE_UNCOVERED


def test_off_map_stamp_does_not_crash():
    s = make_store(walls=False)
    n = s.stamp_disc(x=999.0, y=999.0, radius_m=0.18)
    assert n == 0
    assert s.covered_cells == 0


# ── Nozzle mode ──────────────────────────────────────────────────────────

def test_nozzle_rect_is_narrower_than_footprint():
    """
    D-2: the nozzle is narrower than the chassis, so footprint mode overstates
    cleaned area. Assert the two modes actually differ.
    """
    a = make_store(walls=False)
    b = make_store(walls=False)
    a.stamp_disc(2.5, 2.5, 0.18)
    b.stamp_rect(2.5, 2.5, 0.0, width_m=0.25, depth_m=0.06)
    assert b.covered_cells < a.covered_cells


def test_nozzle_rotation_changes_footprint():
    a = make_store(walls=False)
    b = make_store(walls=False)
    a.stamp_rect(2.5, 2.5, 0.0, 0.30, 0.06)
    b.stamp_rect(2.5, 2.5, np.pi / 2, 0.30, 0.06)

    ga = a.render().reshape(a.height, a.width)
    gb = b.render().reshape(b.height, b.width)
    assert not np.array_equal(ga, gb)          # orientation matters
    assert a.covered_cells == pytest.approx(b.covered_cells, rel=0.2)
