import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg = get_package_share_directory('nova_coverage_tracker')
    default_params = os.path.join(pkg, 'config', 'coverage_tracker.yaml')

    return LaunchDescription([
        DeclareLaunchArgument(
            'params_file',
            default_value=default_params,
            description='Path to the coverage_tracker parameter YAML.',
        ),
        Node(
            package='nova_coverage_tracker',
            executable='coverage_tracker',
            name='coverage_tracker',
            output='screen',
            parameters=[LaunchConfiguration('params_file')],
        ),
    ])
