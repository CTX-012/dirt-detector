import os
from launch import LaunchDescription
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():
    pkg = get_package_share_directory('nova_coverage_tracker')
    params = os.path.join(pkg, 'config', 'coverage_params.yaml')
    return LaunchDescription([
        Node(
            package='nova_coverage_tracker',
            executable='coverage_tracker',
            name='coverage_tracker',
            output='screen',
            parameters=[params],
        ),
    ])
