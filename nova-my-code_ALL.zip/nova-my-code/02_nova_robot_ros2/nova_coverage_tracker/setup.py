from glob import glob
import os
from setuptools import find_packages, setup

package_name = 'nova_coverage_tracker'

setup(
    name=package_name,
    version='1.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Cybertronix',
    maintainer_email='faiz@cybertronix.in',
    description='NOVA Track A — cleaned-area coverage tracking.',
    license='Proprietary',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'coverage_tracker = nova_coverage_tracker.coverage_tracker:main',
        ],
    },
)
