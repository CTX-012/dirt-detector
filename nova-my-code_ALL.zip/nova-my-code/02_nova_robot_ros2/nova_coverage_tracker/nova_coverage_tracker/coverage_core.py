"""coverage_core - pure geometry + stats logic for Track A (no ROS deps).

Kept ROS-free so it can be unit-tested directly (T-A1..T-A4).
The ROS node (coverage_tracker.py) imports these functions.
"""
import math
import numpy as np


def world_to_grid(x, y, origin_x, origin_y, resolution):
    """Convert a world (map-frame) point to grid cell indices (gx, gy)."""
    gx = int((x - origin_x) / resolution)
    gy = int((y - origin_y) / resolution)
    return gx, gy


def footprint_cells(cx, cy, radius, resolution):
    """Return the set of (gx, gy) cells covered by a disc of `radius`
    centered at grid index (cx, cy). Pure integer rasterization."""
    r_cells = int(radius / resolution)
    r2 = r_cells * r_cells
    cells = set()
    for gy in range(cy - r_cells, cy + r_cells + 1):
        for gx in range(cx - r_cells, cx + r_cells + 1):
            if (gx - cx) ** 2 + (gy - cy) ** 2 <= r2:
                cells.add((gx, gy))
    return cells


def nozzle_cells(cx, cy, width, resolution):
    """Return the set of (gx, gy) cells for a square nozzle of `width`
    centered at grid index (cx, cy)."""
    half = int((width / 2) / resolution)
    cells = set()
    for gy in range(cy - half, cy + half + 1):
        for gx in range(cx - half, cx + half + 1):
            cells.add((gx, gy))
    return cells


def pose_jumped(last_xy, x, y, gate):
    """True if the pose jumped further than `gate` meters since last_xy.
    Guards against AMCL relocalization smears (R3)."""
    if last_xy is None:
        return False
    return math.hypot(x - last_xy[0], y - last_xy[1]) > gate


def mark_cells(covered, map_data, cells):
    """Mark `cells` as covered, but ONLY where the source map is free floor (0).
    Mutates `covered` (bool array) in place. Returns number of NEW cells marked."""
    h, w = covered.shape
    newly = 0
    for gx, gy in cells:
        if 0 <= gx < w and 0 <= gy < h:
            if map_data[gy, gx] == 0 and not covered[gy, gx]:
                covered[gy, gx] = True
                newly += 1
    return newly


def build_coverage_grid(covered, map_data):
    """Build the OccupancyGrid data array:
      -1  = unknown / non-floor
       0  = free but uncovered
       100 = covered
    Returns a flat int8 numpy array (row-major, same as OccupancyGrid.data)."""
    out = np.full(map_data.shape, -1, dtype=np.int8)
    free_mask = (map_data == 0)
    out[free_mask] = 0
    out[covered] = 100
    return out.flatten()


def compute_stats(covered, map_data):
    """Return coverage stats dict. coverage_pct = covered / free (unknowns excluded)."""
    free_mask = (map_data == 0)
    covered_cells = int((covered & free_mask).sum())
    free_cells = int(free_mask.sum())
    pct = (covered_cells / free_cells * 100.0) if free_cells > 0 else 0.0
    return {
        'covered_cells': covered_cells,
        'free_cells': free_cells,
        'coverage_pct': round(pct, 2),
    }
