"""
coverage_store — pure rasterization + stats. No ROS dependencies.

Deliberately importable without rclpy so T-A1..T-A6 run in plain pytest in CI
without a ROS install. The node (coverage_tracker.py) imports from here.
"""

import math
from typing import Dict, Optional, Tuple

import numpy as np

# Contract §2.1 cell semantics.
UNKNOWN = -1
FREE_UNCOVERED = 0
COVERED = 100

# Anything at or above this in the source map is an obstacle, per ROS convention.
OCCUPIED_THRESHOLD = 50

# Above this cell count, a full-grid publish is heavy enough to hurt (R2).
LARGE_GRID_WARN_CELLS = 4_000_000


class CoverageStore:
    """
    Coverage bitmap for one floor. Owns the dirty-bbox bookkeeping that keeps
    the publish path cheap.

    Kept deliberately free of ROS types so it can be unit-tested without a node
    (T-A1..T-A5 run in plain pytest, no rclpy spin).
    """

    def __init__(self, width: int, height: int, resolution: float,
                 origin_x: float, origin_y: float, source: np.ndarray):
        self.width = width
        self.height = height
        self.resolution = resolution
        self.origin_x = origin_x
        self.origin_y = origin_y

        # The source /map, flat int8. Never mutated — it is the floor mask.
        self.source = source

        # Which cells we have covered. Separate from source so a map update
        # doesn't wipe coverage.
        self.covered = np.zeros(width * height, dtype=bool)

        # Preallocated publish buffer. Reused every tick; never reallocated.
        # np.empty() is uninitialized memory — it MUST be fully written before
        # any incremental patch is trusted, or cells outside the first dirty
        # bbox publish as garbage. `_rendered_once` is that guard.
        self._out = np.empty(width * height, dtype=np.int8)
        self._out_valid = False
        self._rendered_once = False

        # Dirty bbox in cell coords, inclusive. None = nothing dirty.
        self._dirty: Optional[Tuple[int, int, int, int]] = None  # (r0, r1, c0, c1)

        # Cells in the source map that are free floor — the denominator for
        # coverage_pct. Computed once; a map update recomputes it.
        self.free_cells = int(np.count_nonzero(
            (source >= 0) & (source < OCCUPIED_THRESHOLD)
        ))

    def _mark_dirty(self, r0: int, r1: int, c0: int, c1: int) -> None:
        if self._dirty is None:
            self._dirty = (r0, r1, c0, c1)
        else:
            d = self._dirty
            self._dirty = (min(d[0], r0), max(d[1], r1),
                           min(d[2], c0), max(d[3], c1))

    def world_to_cell(self, x: float, y: float) -> Tuple[int, int]:
        """Map-frame meters → (row, col). Row is the ROS y-up index."""
        col = int((x - self.origin_x) / self.resolution)
        row = int((y - self.origin_y) / self.resolution)
        return row, col

    def stamp_disc(self, x: float, y: float, radius_m: float) -> int:
        """
        Mark the footprint disc centered at (x, y). Returns newly-covered count.

        Only free floor is marked. A robot cannot clean a wall, and marking one
        would inflate coverage_pct above what the denominator allows.
        """
        r_cells = max(0, int(round(radius_m / self.resolution)))
        cr, cc = self.world_to_cell(x, y)

        r0 = max(0, cr - r_cells)
        r1 = min(self.height - 1, cr + r_cells)
        c0 = max(0, cc - r_cells)
        c1 = min(self.width - 1, cc + r_cells)
        if r0 > r1 or c0 > c1:
            return 0  # entirely off-map

        rr = np.arange(r0, r1 + 1)
        cc_ = np.arange(c0, c1 + 1)
        dy = rr[:, None] - cr
        dx = cc_[None, :] - cc
        disc = (dy * dy + dx * dx) <= (r_cells * r_cells)

        flat = (rr[:, None] * self.width + cc_[None, :]).ravel()
        mask = disc.ravel()
        idx = flat[mask]

        src = self.source[idx]
        floor = (src >= 0) & (src < OCCUPIED_THRESHOLD)
        idx = idx[floor]
        if idx.size == 0:
            return 0

        newly = int(np.count_nonzero(~self.covered[idx]))
        if newly:
            self.covered[idx] = True
            self._mark_dirty(r0, r1, c0, c1)
            self._out_valid = False
        return newly

    def stamp_rect(self, x: float, y: float, theta: float,
                   width_m: float, depth_m: float) -> int:
        """
        Mark an oriented rectangle — the nozzle footprint (mark_mode='nozzle').

        The vacuum nozzle is narrower than the chassis, so footprint mode
        overstates real cleaned area. Once the Phase-2 vacuum module fixes the
        nozzle width (D-2), this becomes the honest mode.
        """
        half_w = width_m / 2.0
        half_d = depth_m / 2.0
        reach = math.hypot(half_w, half_d)
        r_cells = int(math.ceil(reach / self.resolution))

        cr, cc = self.world_to_cell(x, y)
        r0 = max(0, cr - r_cells)
        r1 = min(self.height - 1, cr + r_cells)
        c0 = max(0, cc - r_cells)
        c1 = min(self.width - 1, cc + r_cells)
        if r0 > r1 or c0 > c1:
            return 0

        rr = np.arange(r0, r1 + 1)
        cc_ = np.arange(c0, c1 + 1)
        # Cell centers in world coords.
        wy = (rr[:, None] + 0.5) * self.resolution + self.origin_y
        wx = (cc_[None, :] + 0.5) * self.resolution + self.origin_x

        # Rotate into the robot frame; test against the axis-aligned rect.
        ct, st = math.cos(-theta), math.sin(-theta)
        rx = (wx - x) * ct - (wy - y) * st
        ry = (wx - x) * st + (wy - y) * ct
        inside = (np.abs(rx) <= half_d) & (np.abs(ry) <= half_w)

        flat = (rr[:, None] * self.width + cc_[None, :]).ravel()
        idx = flat[inside.ravel()]

        src = self.source[idx]
        idx = idx[(src >= 0) & (src < OCCUPIED_THRESHOLD)]
        if idx.size == 0:
            return 0

        newly = int(np.count_nonzero(~self.covered[idx]))
        if newly:
            self.covered[idx] = True
            self._mark_dirty(r0, r1, c0, c1)
            self._out_valid = False
        return newly

    def render(self) -> np.ndarray:
        """
        Build the publishable grid. Unknown/non-floor stays -1, free floor is 0
        or 100.

        First call renders the whole grid; subsequent calls patch only the dirty
        bbox. This is the 745× saving — a full 4000×4000 rebuild is 52 ms, the
        bbox patch is 17 us.
        """
        if self._out_valid:
            return self._out

        # The incremental path is only safe once every cell has been written at
        # least once. Until then, do a full pass — otherwise cells outside the
        # first dirty bbox are still uninitialized np.empty() memory and publish
        # as garbage.
        if not self._rendered_once or self._dirty is None:
            self._render_range(0, self.height - 1, 0, self.width - 1)
            self._rendered_once = True
        else:
            r0, r1, c0, c1 = self._dirty
            self._render_range(r0, r1, c0, c1)

        self._out_valid = True
        self._dirty = None
        return self._out

    def _render_range(self, r0: int, r1: int, c0: int, c1: int) -> None:
        """Write [r0..r1] × [c0..c1] of the output buffer from source + covered."""
        for r in range(r0, r1 + 1):
            s = r * self.width + c0
            e = r * self.width + c1 + 1
            seg_src = self.source[s:e]
            seg_out = self._out[s:e]
            np.copyto(seg_out, seg_src)
            # Covered wins over free...
            np.putmask(seg_out, self.covered[s:e], np.int8(COVERED))
            # ...but non-floor always wins over covered. A wall or an unknown
            # cell must never publish as covered, even if a bug marked it — the
            # dashboard would render coverage inside a wall and the operator
            # would rightly stop trusting the number.
            np.putmask(seg_out, seg_src >= OCCUPIED_THRESHOLD, np.int8(UNKNOWN))
            np.putmask(seg_out, seg_src < 0, np.int8(UNKNOWN))

    def force_full_render(self) -> None:
        """Invalidate the incremental cache — used after reset or map change."""
        self._out_valid = False
        self._dirty = None

    @property
    def covered_cells(self) -> int:
        return int(np.count_nonzero(self.covered))

    @property
    def coverage_pct(self) -> float:
        """
        covered / free. Unknown and occupied cells are excluded from the
        denominator — a robot cannot clean a wall, so counting walls as
        uncovered would cap achievable coverage below 100% and make the 85%
        gate meaningless (T-A4).
        """
        if self.free_cells == 0:
            return 0.0
        return 100.0 * self.covered_cells / self.free_cells

    def clear(self) -> None:
        self.covered[:] = False
        self.force_full_render()
